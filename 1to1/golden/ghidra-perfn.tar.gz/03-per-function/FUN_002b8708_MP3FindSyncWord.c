/* ============================================================
 * MP3FindSyncWord   @ 0x002b8708   size=84B   callers=3
 * module: 06_helix_mp3
 * ============================================================ */

int MP3FindSyncWord(byte *param_1,int param_2)

{
  int iVar1;
  byte *pbVar2;
  
  if (1 < param_2) {
    iVar1 = 0;
    do {
      while (pbVar2 = param_1 + 1, *param_1 == 0xff) {
        if ((*pbVar2 & 0xe0) == 0xe0) {
          return iVar1;
        }
        iVar1 = iVar1 + 1;
        param_1 = pbVar2;
        if (param_2 + -1 == iVar1) {
          return -1;
        }
      }
      iVar1 = iVar1 + 1;
      param_1 = pbVar2;
    } while (param_2 + -1 != iVar1);
  }
  return -1;
}
