/* ============================================================
 * stbtt__tesselate_cubic   @ 0x0001467c   size=492B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x00014764 */
/* WARNING: Restarted to delay deadcode elimination for space: register */

void stbtt__tesselate_cubic
               (float param_1,float param_2,float param_3,float param_4,float param_5,float param_6,
               float param_7,float *param_8,int *param_9,int param_10)

{
  int iVar1;
  bool bVar2;
  float fVar3;
  undefined8 in_d0;
  double __x;
  double __x_00;
  double __x_01;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  
  fVar6 = (float)((ulonglong)in_d0 >> 0x20);
  fVar9 = (float)in_d0;
  while( true ) {
    __x = (double)((param_2 - fVar6) * (param_2 - fVar6) + (param_1 - fVar9) * (param_1 - fVar9));
    if (__x < 0.0) {
      sqrt(__x);
    }
    __x_00 = (double)((param_4 - param_2) * (param_4 - param_2) +
                     (param_3 - param_1) * (param_3 - param_1));
    if (__x_00 < 0.0) {
      sqrt(__x_00);
    }
    __x_01 = (double)((param_6 - param_4) * (param_6 - param_4) +
                     (param_5 - param_3) * (param_5 - param_3));
    if (__x_01 < 0.0) {
      sqrt(__x_01);
    }
    fVar3 = (param_6 - fVar6) * (param_6 - fVar6) + (param_5 - fVar9) * (param_5 - fVar9);
    fVar8 = (float)(SQRT(__x) + SQRT(__x_00) + SQRT(__x_01));
    if (fVar3 < 0.0) {
      sqrtf(fVar3);
    }
    if (0x10 < param_10) break;
    if (fVar8 * fVar8 - SQRT(fVar3) * SQRT(fVar3) <= param_7) {
      iVar1 = *param_9;
      bVar2 = param_8 != (float *)0x0;
      if (bVar2) {
        param_8 = param_8 + iVar1 * 2;
        *param_8 = param_5;
      }
      if (bVar2) {
        param_8[1] = param_6;
      }
      *param_9 = iVar1 + 1;
      return;
    }
    param_10 = param_10 + 1;
    fVar3 = (param_1 + fVar9) * 0.5;
    fVar7 = (param_1 + param_3) * 0.5;
    fVar4 = (param_2 + fVar6) * 0.5;
    fVar6 = (param_2 + param_4) * 0.5;
    param_3 = (param_3 + param_5) * 0.5;
    param_4 = (param_4 + param_6) * 0.5;
    fVar8 = (fVar3 + fVar7) * 0.5;
    fVar5 = (fVar4 + fVar6) * 0.5;
    param_1 = (fVar7 + param_3) * 0.5;
    param_2 = (fVar6 + param_4) * 0.5;
    fVar7 = (fVar8 + param_1) * 0.5;
    fVar6 = (fVar5 + param_2) * 0.5;
    stbtt__tesselate_cubic
              (fVar9,(int)((ulonglong)__x_01 >> 0x20),fVar3,fVar4,fVar8,fVar5,fVar7,fVar6,param_7,
               param_8,param_9,param_10);
    fVar9 = fVar7;
  }
  return;
}
