/* ============================================================
 * mxml_write_node   @ 0x002c18f0   size=1584B   callers=4
 * module: 04_mini_xml
 * ============================================================ */

size_t mxml_write_node(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4,
                      code *param_5,int param_6)

{
  char *pcVar1;
  int iVar2;
  char *__s;
  size_t sVar3;
  int iVar4;
  size_t sVar5;
  int iVar6;
  char cVar7;
  undefined4 *puVar8;
  bool bVar9;
  char acStack_128 [260];
  
  switch(*param_1) {
  case 0:
    iVar2 = mxml_write_ws(param_1,param_2,param_3,0,param_4,param_5);
    iVar6 = (*param_5)(0x3c,param_2);
    if (iVar6 < 0) {
      return 0xffffffff;
    }
    pcVar1 = (char *)param_1[6];
    cVar7 = *pcVar1;
    if (cVar7 == '?') {
LAB_002c1b3c:
      do {
        iVar6 = (*param_5)(cVar7,param_2);
        if (iVar6 < 0) {
          return 0xffffffff;
        }
        pcVar1 = pcVar1 + 1;
        cVar7 = *pcVar1;
      } while (cVar7 != '\0');
    }
    else {
      iVar6 = strncmp(pcVar1,"!--",3);
      if ((iVar6 == 0) || (iVar6 = strncmp(pcVar1,"![CDATA[",8), iVar6 == 0)) {
        if (cVar7 == '\0') goto LAB_002c1a10;
        goto LAB_002c1b3c;
      }
      iVar6 = mxml_write_name(pcVar1,param_2,param_5);
      if (iVar6 < 0) {
        return 0xffffffff;
      }
    }
    pcVar1 = (char *)param_1[6];
LAB_002c1a10:
    sVar3 = strlen(pcVar1);
    iVar6 = param_1[7];
    puVar8 = (undefined4 *)param_1[8];
    iVar2 = iVar2 + 1 + sVar3;
    if (0 < iVar6) {
      do {
        sVar3 = strlen((char *)*puVar8);
        if ((char *)puVar8[1] != (char *)0x0) {
          sVar5 = strlen((char *)puVar8[1]);
          sVar3 = sVar3 + 3 + sVar5;
        }
        if ((*(int *)(param_6 + 0x198) < 1) || ((int)(sVar3 + iVar2) <= *(int *)(param_6 + 0x198)))
        {
          iVar4 = (*param_5)(0x20,param_2);
          if (iVar4 < 0) {
            return 0xffffffff;
          }
          iVar2 = iVar2 + 1;
        }
        else {
          iVar2 = (*param_5)(10);
          if (iVar2 < 0) {
            return 0xffffffff;
          }
          iVar2 = 0;
        }
        iVar4 = mxml_write_name(*puVar8,param_2,param_5);
        if (iVar4 < 0) {
          return 0xffffffff;
        }
        if (puVar8[1] != 0) {
          iVar4 = (*param_5)(0x3d,param_2);
          if (iVar4 < 0) {
            return 0xffffffff;
          }
          iVar4 = (*param_5)(0x22,param_2);
          if (iVar4 < 0) {
            return 0xffffffff;
          }
          iVar4 = mxml_write_string(puVar8[1],param_2,param_5);
          if (iVar4 < 0) {
            return 0xffffffff;
          }
          iVar4 = (*param_5)(0x22,param_2);
          if (iVar4 < 0) {
            return 0xffffffff;
          }
        }
        iVar6 = iVar6 + -1;
        iVar2 = iVar2 + sVar3;
        puVar8 = puVar8 + 2;
      } while (iVar6 != 0);
    }
    if (param_1[4] == 0) {
      if (*(char *)param_1[6] == '?' || *(char *)param_1[6] == '!') {
        iVar6 = (*param_5)(0x3e);
        if (iVar6 < 0) {
          return 0xffffffff;
        }
        iVar2 = iVar2 + 1;
      }
      else {
        iVar6 = (*param_5)(0x20,param_2);
        if (iVar6 < 0) {
          return 0xffffffff;
        }
        iVar6 = (*param_5)(0x2f,param_2);
        if (iVar6 < 0) {
          return 0xffffffff;
        }
        iVar6 = (*param_5)(0x3e,param_2);
        if (iVar6 < 0) {
          return 0xffffffff;
        }
        iVar2 = iVar2 + 3;
      }
      sVar3 = mxml_write_ws(param_1,param_2,param_3,1,iVar2,param_5);
    }
    else {
      iVar6 = (*param_5)(0x3e,param_2);
      if (iVar6 < 0) {
        return 0xffffffff;
      }
      sVar3 = mxml_write_ws(param_1,param_2,param_3,1,iVar2 + 1,param_5);
      for (iVar2 = param_1[4]; iVar2 != 0; iVar2 = *(int *)(iVar2 + 4)) {
        sVar3 = mxml_write_node(iVar2,param_2,param_3,sVar3,param_5,param_6);
        if ((int)sVar3 < 0) {
          return 0xffffffff;
        }
      }
      if (*(char *)param_1[6] != '!' && *(char *)param_1[6] != '?') {
        iVar2 = mxml_write_ws(param_1,param_2,param_3,2,sVar3,param_5);
        iVar6 = (*param_5)(0x3c,param_2);
        if (iVar6 < 0) {
          return 0xffffffff;
        }
        iVar6 = (*param_5)(0x2f,param_2);
        if (iVar6 < 0) {
          return 0xffffffff;
        }
        iVar6 = mxml_write_string(param_1[6],param_2,param_5);
        if (iVar6 < 0) {
          return 0xffffffff;
        }
        iVar6 = (*param_5)(0x3e,param_2);
        if (iVar6 < 0) {
          return 0xffffffff;
        }
        sVar3 = strlen((char *)param_1[6]);
        sVar3 = mxml_write_ws(param_1,param_2,param_3,3,iVar2 + 3 + sVar3,param_5);
      }
    }
    return sVar3;
  case 1:
    if (param_1[2] != 0) {
      iVar6 = *(int *)(param_6 + 0x198);
      bVar9 = param_4 == iVar6;
      iVar2 = param_4 - iVar6;
      if (param_4 > iVar6) {
        bVar9 = iVar6 == 0;
        iVar2 = iVar6;
      }
      if (bVar9 || iVar2 < 0 != (param_4 <= iVar6 && SBORROW4(param_4,iVar6))) {
        iVar2 = (*param_5)(0x20);
        if (iVar2 < 0) {
          return 0xffffffff;
        }
        param_4 = param_4 + 1;
      }
      else {
        iVar2 = (*param_5)(10,param_2);
        if (iVar2 < 0) {
          return 0xffffffff;
        }
        param_4 = 0;
      }
    }
    sprintf(acStack_128,"%d",param_1[6]);
    goto LAB_002c1bb0;
  case 2:
    iVar2 = mxml_write_string(param_1[6],param_2,param_5);
    if (-1 < iVar2) {
      sVar3 = strlen((char *)param_1[6]);
      return param_4 + sVar3;
    }
    break;
  case 3:
    if (param_1[2] != 0) {
      iVar6 = *(int *)(param_6 + 0x198);
      bVar9 = param_4 == iVar6;
      iVar2 = param_4 - iVar6;
      if (param_4 > iVar6) {
        bVar9 = iVar6 == 0;
        iVar2 = iVar6;
      }
      if (bVar9 || iVar2 < 0 != (param_4 <= iVar6 && SBORROW4(param_4,iVar6))) {
        iVar2 = (*param_5)(0x20);
        if (iVar2 < 0) {
          return 0xffffffff;
        }
        param_4 = param_4 + 1;
      }
      else {
        iVar2 = (*param_5)(10,param_2);
        if (iVar2 < 0) {
          return 0xffffffff;
        }
        param_4 = 0;
      }
    }
    sprintf(acStack_128,"%f",param_1[6],param_1[7]);
LAB_002c1bb0:
    iVar2 = mxml_write_string(acStack_128,param_2,param_5);
    if (-1 < iVar2) {
      sVar3 = strlen(acStack_128);
      return param_4 + sVar3;
    }
    break;
  case 4:
    iVar2 = 0;
    if (param_1[6] != 0) {
      iVar2 = param_4;
    }
    if ((param_1[6] != 0 && param_4 != 0) && -1 < iVar2) {
      iVar6 = *(int *)(param_6 + 0x198);
      bVar9 = param_4 == iVar6;
      iVar2 = param_4 - iVar6;
      if (param_4 > iVar6) {
        bVar9 = iVar6 == 0;
        iVar2 = iVar6;
      }
      if (bVar9 || iVar2 < 0 != (param_4 <= iVar6 && SBORROW4(param_4,iVar6))) {
        iVar2 = (*param_5)(0x20);
        if (iVar2 < 0) {
          return 0xffffffff;
        }
        param_4 = param_4 + 1;
      }
      else {
        iVar2 = (*param_5)(10,param_2);
        if (iVar2 < 0) {
          return 0xffffffff;
        }
        param_4 = 0;
      }
    }
    iVar2 = mxml_write_string(param_1[7],param_2,param_5);
    if (-1 < iVar2) {
      sVar3 = strlen((char *)param_1[7]);
      return param_4 + sVar3;
    }
    break;
  case 5:
    if (*(code **)(param_6 + 0x1a0) == (code *)0x0) {
      return 0xffffffff;
    }
    pcVar1 = (char *)(**(code **)(param_6 + 0x1a0))();
    if (pcVar1 != (char *)0x0) {
      iVar2 = mxml_write_string(pcVar1,param_2,param_5);
      if (-1 < iVar2) {
        __s = strrchr(pcVar1,10);
        if (__s == (char *)0x0) {
          sVar3 = strlen(pcVar1);
          sVar3 = param_4 + sVar3;
        }
        else {
          sVar3 = strlen(__s);
        }
        free(pcVar1);
        return sVar3;
      }
      return 0xffffffff;
    }
    return 0xffffffff;
  }
  return 0xffffffff;
}
