/* ============================================================
 * mxmlSetCustom   @ 0x002c3628   size=116B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlSetCustom(int *param_1,int param_2,int param_3)

{
  int iVar1;
  
  if (param_1 != (int *)0x0) {
    iVar1 = *param_1;
    if (iVar1 == 0) {
      param_1 = (int *)param_1[4];
      if (param_1 == (int *)0x0) {
        return 0xffffffff;
      }
      iVar1 = *param_1;
    }
    if (iVar1 == 5) {
      if ((param_1[6] != 0) && ((code *)param_1[7] != (code *)0x0)) {
        (*(code *)param_1[7])();
      }
      param_1[6] = param_2;
      param_1[7] = param_3;
      return 0;
    }
  }
  return 0xffffffff;
}
