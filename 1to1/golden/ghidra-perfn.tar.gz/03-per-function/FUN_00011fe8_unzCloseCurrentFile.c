/* ============================================================
 * unzCloseCurrentFile   @ 0x00011fe8   size=144B   callers=6
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzCloseCurrentFile(unz_s*) */

undefined4 unzCloseCurrentFile(unz_s *param_1)

{
  undefined4 *__ptr;
  undefined4 uVar1;
  
  if ((param_1 == (unz_s *)0x0) ||
     (__ptr = *(undefined4 **)(param_1 + 0x7c), __ptr == (undefined4 *)0x0)) {
    uVar1 = 0xffffff9a;
  }
  else {
    if (__ptr[0x17] == 0) {
      if (__ptr[0x14] == __ptr[0x15]) {
        uVar1 = 0;
      }
      else {
        uVar1 = 0xffffff97;
      }
    }
    else {
      uVar1 = 0;
    }
    if ((void *)*__ptr != (void *)0x0) {
      free((void *)*__ptr);
    }
    *__ptr = 0;
    if (__ptr[0x10] != 0) {
      inflateEnd((z_stream_s *)(__ptr + 1));
    }
    free(__ptr);
    *(undefined4 *)(param_1 + 0x7c) = 0;
  }
  return uVar1;
}
