/* ============================================================
 * _mxml_fini   @ 0x00009b10   size=64B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

void _mxml_fini(void)

{
  void *__ptr;
  
  if (_mxml_key == 0xffffffff) {
    return;
  }
  __ptr = pthread_getspecific(_mxml_key);
  if (__ptr != (void *)0x0) {
    free(__ptr);
  }
  pthread_key_delete(_mxml_key);
  _mxml_key = 0xffffffff;
  return;
}
