/* ============================================================
 * Get   @ 0x00012290   size=884B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* TUnzip::Get(int, ZIPENTRY*) [clone .part.5] */

undefined4 __thiscall TUnzip::Get(TUnzip *this,int param_1,ZIPENTRY *param_2)

{
  char cVar1;
  byte bVar2;
  unz_s *puVar3;
  undefined4 uVar4;
  void *pvVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  char *pcVar10;
  bool bVar11;
  undefined4 local_198;
  undefined4 uStack_194;
  char local_18c;
  char local_18b;
  undefined1 local_18a;
  uint local_188;
  uint uStack_184;
  ulong local_180;
  unz_file_info_s auStack_17c [16];
  undefined4 local_16c;
  undefined4 local_168;
  undefined4 local_164;
  undefined4 local_160;
  uint local_148;
  char acStack_12c [264];
  
  if (param_1 == -1) {
    uVar4 = *(undefined4 *)(*(int *)this + 4);
    param_2[4] = (ZIPENTRY)0x0;
    *(undefined4 *)(param_2 + 0x108) = 0;
    *(undefined4 *)param_2 = uVar4;
    *(undefined4 *)(param_2 + 0x10c) = 0;
    *(undefined4 *)(param_2 + 0x110) = 0;
    *(undefined4 *)(param_2 + 0x114) = 0;
    *(undefined4 *)(param_2 + 0x118) = 0;
    *(undefined4 *)(param_2 + 0x11c) = 0;
    *(undefined4 *)(param_2 + 0x120) = 0;
    *(undefined4 *)(param_2 + 0x124) = 0;
    *(undefined4 *)(param_2 + 0x128) = 0;
    return 0;
  }
  puVar3 = *(unz_s **)this;
  iVar9 = *(int *)(puVar3 + 0x10);
  if (param_1 < iVar9) {
    unzGoToFirstFile(puVar3);
    puVar3 = *(unz_s **)this;
    iVar9 = *(int *)(puVar3 + 0x10);
  }
  while (iVar9 < param_1) {
    unzGoToNextFile(puVar3);
    puVar3 = *(unz_s **)this;
    iVar9 = *(int *)(puVar3 + 0x10);
  }
  unzGetCurrentFileInfo(puVar3,auStack_17c,acStack_12c,0x104,(void *)0x0,0,(char *)0x0,0);
  iVar9 = unzlocal_CheckCurrentFileCoherencyHeader
                    (*(unz_s **)this,&uStack_184,&local_180,&local_188);
  if (iVar9 == 0) {
    iVar9 = lufseek((LUFILE *)**(undefined4 **)this,local_180,0);
    if (iVar9 == 0) {
      pvVar5 = operator_new__(local_188);
      uVar6 = lufread(pvVar5,1,local_188,(LUFILE *)**(undefined4 **)this);
      if (uVar6 == local_188) {
        *(undefined4 *)param_2 = *(undefined4 *)(*(int *)this + 0x10);
        strcpy((char *)(param_2 + 4),acStack_12c);
        uVar8 = local_148 & 1;
        if ((int)(local_148 << 1) < 0 || (int)(local_148 << 0x1b) < 0) {
          uVar4 = 0x90;
        }
        else {
          uVar4 = 0x80;
        }
        *(undefined4 *)(param_2 + 0x108) = uVar4;
        if ((local_148 & 0x20) != 0) {
          *(uint *)(param_2 + 0x108) = *(uint *)(param_2 + 0x108) | 0x20;
        }
        if ((local_148 & 2) != 0) {
          *(uint *)(param_2 + 0x108) = *(uint *)(param_2 + 0x108) | 2;
        }
        if ((local_148 & 0x800000) == 0) {
          uVar8 = 1;
        }
        bVar11 = uVar8 != 0;
        uVar8 = 0;
        if (bVar11) {
          uVar8 = *(uint *)(param_2 + 0x108);
        }
        *(undefined4 *)(param_2 + 0x124) = local_164;
        if (bVar11) {
          uVar8 = uVar8 | 1;
        }
        *(undefined4 *)(param_2 + 300) = local_168;
        if (bVar11) {
          *(uint *)(param_2 + 0x108) = uVar8;
        }
        bVar11 = (local_148 & 4) != 0;
        if (bVar11) {
          uVar8 = *(uint *)(param_2 + 0x108) | 4;
        }
        *(undefined4 *)(param_2 + 0x128) = local_160;
        if (bVar11) {
          *(uint *)(param_2 + 0x108) = uVar8;
        }
        *(undefined4 *)(param_2 + 0x10c) = local_16c;
        *(undefined4 *)(param_2 + 0x110) = local_16c;
        *(undefined4 *)(param_2 + 0x114) = local_16c;
        *(undefined4 *)(param_2 + 0x118) = local_16c;
        *(undefined4 *)(param_2 + 0x11c) = local_16c;
        *(undefined4 *)(param_2 + 0x120) = local_16c;
        if (4 < uVar6) {
          uVar8 = 4;
          iVar9 = 0;
          do {
            pcVar10 = (char *)((int)pvVar5 + iVar9);
            local_18c = *pcVar10;
            local_18a = 0;
            local_18b = pcVar10[1];
            cVar1 = pcVar10[2];
            iVar7 = strcmp(&local_18c,"UT");
            if (iVar7 == 0) {
              bVar2 = *(byte *)((int)pvVar5 + uVar8);
              if ((bVar2 & 1) != 0) {
                timet2filetime((long)&local_198);
                *(undefined4 *)(param_2 + 0x11c) = local_198;
                *(undefined4 *)(param_2 + 0x120) = uStack_194;
              }
              if ((bVar2 & 2) != 0) {
                timet2filetime((long)&local_198);
                *(undefined4 *)(param_2 + 0x10c) = local_198;
                *(undefined4 *)(param_2 + 0x110) = uStack_194;
              }
              if ((bVar2 & 4) != 0) {
                timet2filetime((long)&local_198);
                *(undefined4 *)(param_2 + 0x114) = local_198;
                *(undefined4 *)(param_2 + 0x118) = uStack_194;
              }
              break;
            }
            iVar9 = iVar9 + cVar1 + 4;
            uVar8 = iVar9 + 4;
          } while (uVar8 < uVar6);
        }
        operator_delete__(pvVar5);
        memcpy(this + 8,param_2,0x130);
        *(int *)(this + 0x138) = param_1;
        uVar4 = 0;
      }
      else {
        operator_delete__(pvVar5);
        uVar4 = 0x800;
      }
    }
    else {
      uVar4 = 0x800;
    }
  }
  else {
    uVar4 = 0x700;
  }
  return uVar4;
}
