/* ============================================================
 * stbtt__csctx_v   @ 0x000139e8   size=156B   callers=4
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt__csctx_v(int *param_1,int param_2,undefined4 param_3,undefined4 param_4,
                   undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  
  if (*param_1 == 0) {
    iVar4 = param_1[0xb];
    iVar3 = param_1[10];
    iVar1 = iVar3 + iVar4 * 0xe;
    *(char *)(iVar1 + 0xc) = (char)param_2;
    *(short *)(iVar3 + iVar4 * 0xe) = (short)param_3;
    *(short *)(iVar1 + 2) = (short)param_4;
    *(undefined2 *)(iVar1 + 4) = (undefined2)param_5;
    *(undefined2 *)(iVar1 + 6) = (undefined2)param_6;
    *(undefined2 *)(iVar1 + 8) = (undefined2)param_7;
    *(undefined2 *)(iVar1 + 10) = (undefined2)param_8;
  }
  else {
    uVar2 = stbtt__track_vertex(param_1,param_3,param_4);
    if (param_2 == 4) {
      uVar2 = stbtt__track_vertex(uVar2,param_5,param_6);
      stbtt__track_vertex(uVar2,param_7,param_8);
    }
    iVar4 = param_1[0xb];
  }
  param_1[0xb] = iVar4 + 1;
  return;
}
