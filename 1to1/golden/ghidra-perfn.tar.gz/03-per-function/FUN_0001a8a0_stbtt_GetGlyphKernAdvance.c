/* ============================================================
 * stbtt_GetGlyphKernAdvance   @ 0x0001a8a0   size=1308B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

int stbtt_GetGlyphKernAdvance(int param_1,int param_2,uint param_3)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  byte bVar5;
  byte bVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  uint uVar15;
  int iVar16;
  int iVar17;
  int iVar18;
  int iVar19;
  int iVar20;
  int iVar21;
  int local_40;
  
  iVar7 = *(int *)(param_1 + 0x28);
  iVar11 = 0;
  if (iVar7 != 0) {
    iVar11 = *(int *)(param_1 + 4) + iVar7;
    if (((uint)*(byte *)(iVar11 + 1) + (uint)*(byte *)(*(int *)(param_1 + 4) + iVar7) * 0x100 == 1)
       && ((uint)*(byte *)(iVar11 + 3) + (uint)*(byte *)(iVar11 + 2) * 0x100 == 0)) {
      iVar7 = (uint)*(byte *)(iVar11 + 9) + (uint)*(byte *)(iVar11 + 8) * 0x100;
      iVar20 = iVar11 + iVar7;
      iVar7 = (uint)*(byte *)(iVar20 + 1) + (uint)*(byte *)(iVar11 + iVar7) * 0x100;
      iVar11 = 0;
      if (iVar7 == 0) goto LAB_0001a8c0;
      local_40 = iVar20;
      do {
        iVar11 = (uint)*(byte *)(local_40 + 3) + (uint)*(byte *)(local_40 + 2) * 0x100;
        iVar17 = iVar20 + iVar11;
        if (((uint)*(byte *)(iVar17 + 1) + (uint)*(byte *)(iVar20 + iVar11) * 0x100 == 2) &&
           (iVar11 = (uint)*(byte *)(iVar17 + 5) + (uint)*(byte *)(iVar17 + 4) * 0x100, iVar11 != 0)
           ) {
          iVar18 = iVar17;
LAB_0001a9f8:
          iVar19 = (uint)*(byte *)(iVar18 + 7) + (uint)*(byte *)(iVar18 + 6) * 0x100;
          iVar16 = iVar17 + iVar19;
          iVar14 = (uint)*(byte *)(iVar16 + 3) + (uint)*(byte *)(iVar16 + 2) * 0x100;
          iVar9 = iVar16 + iVar14;
          iVar14 = (uint)*(byte *)(iVar9 + 1) + (uint)*(byte *)(iVar16 + iVar14) * 0x100;
          if (iVar14 == 1) {
            iVar21 = (uint)*(byte *)(iVar9 + 3) + (uint)*(byte *)(iVar9 + 2) * 0x100;
            iVar14 = iVar21 + -1;
            if (iVar21 != 0) {
              iVar21 = 0;
              do {
                iVar13 = iVar14 + iVar21 >> 1;
                iVar12 = iVar13 * 2 + 4;
                iVar12 = (uint)*(byte *)(iVar9 + iVar12 + 1) +
                         (uint)*(byte *)(iVar9 + iVar12) * 0x100;
                if (param_2 < iVar12) {
                  iVar14 = iVar13 + -1;
                }
                else {
                  iVar21 = iVar13 + 1;
                  if (param_2 <= iVar12) goto LAB_0001abd4;
                }
              } while (iVar21 <= iVar14);
            }
          }
          else if ((iVar14 == 2) &&
                  (iVar21 = (uint)*(byte *)(iVar9 + 3) + (uint)*(byte *)(iVar9 + 2) * 0x100,
                  iVar14 = iVar21 + -1, iVar21 != 0)) {
            iVar21 = 0;
            do {
              iVar12 = iVar14 + iVar21 >> 1;
              iVar13 = iVar12 * 6 + 4;
              iVar8 = iVar9 + iVar13;
              iVar13 = (uint)*(byte *)(iVar8 + 1) + (uint)*(byte *)(iVar9 + iVar13) * 0x100;
              if (param_2 < iVar13) {
                iVar14 = iVar12 + -1;
              }
              else {
                iVar21 = iVar12 + 1;
                if (param_2 <=
                    (int)((uint)*(byte *)(iVar8 + 3) + (uint)*(byte *)(iVar8 + 2) * 0x100)) {
                  iVar13 = (param_2 +
                           (uint)*(byte *)(iVar8 + 5) + (uint)*(byte *)(iVar8 + 4) * 0x100) - iVar13
                  ;
                  if (iVar13 != -1) goto LAB_0001abd4;
                  break;
                }
              }
            } while (iVar21 <= iVar14);
          }
          goto LAB_0001aab0;
        }
LAB_0001aac0:
        local_40 = local_40 + 2;
      } while (iVar20 + iVar7 * 2 != local_40);
    }
LAB_0001a93c:
    iVar11 = 0;
  }
LAB_0001a8c0:
  if (*(int *)(param_1 + 0x24) == 0) {
    return iVar11;
  }
  iVar20 = *(int *)(param_1 + 4) + *(int *)(param_1 + 0x24);
  iVar7 = 0;
  if ((uint)*(byte *)(iVar20 + 3) + (uint)*(byte *)(iVar20 + 2) * 0x100 != 0) {
    if ((uint)*(byte *)(iVar20 + 9) + (uint)*(byte *)(iVar20 + 8) * 0x100 == 1) {
      param_3 = param_3 | param_2 << 0x10;
      iVar17 = (uint)*(byte *)(iVar20 + 0xb) + (uint)*(byte *)(iVar20 + 10) * 0x100;
      iVar7 = iVar17 + -1;
      if (iVar17 != 0) {
        iVar17 = 0;
        do {
          iVar18 = iVar7 + iVar17 >> 1;
          iVar14 = iVar18 * 6 + 0x12;
          iVar9 = iVar20 + iVar14;
          uVar15 = (uint)*(byte *)(iVar9 + 1) * 0x10000 +
                   (uint)*(byte *)(iVar20 + iVar14) * 0x1000000 + (uint)*(byte *)(iVar9 + 2) * 0x100
                   + (uint)*(byte *)(iVar9 + 3);
          if (param_3 < uVar15) {
            iVar7 = iVar18 + -1;
          }
          else {
            if (param_3 == uVar15) {
              iVar7 = iVar18 * 6 + 0x16;
              iVar7 = (int)(short)((ushort)*(byte *)(iVar20 + iVar7 + 1) +
                                  (ushort)*(byte *)(iVar20 + iVar7) * 0x100);
              goto LAB_0001a910;
            }
            iVar17 = iVar18 + 1;
          }
        } while (iVar17 <= iVar7);
      }
    }
    iVar7 = 0;
  }
LAB_0001a910:
  return iVar11 + iVar7;
LAB_0001abd4:
  iVar9 = (uint)*(byte *)(iVar16 + 1) + (uint)*(byte *)(iVar17 + iVar19) * 0x100;
  if (iVar9 == 1) {
    iVar9 = iVar13 * 2 + 10;
    iVar9 = (uint)*(byte *)(iVar16 + iVar9 + 1) + (uint)*(byte *)(iVar16 + iVar9) * 0x100;
    iVar14 = iVar16 + iVar9;
    iVar9 = (uint)*(byte *)(iVar14 + 1) + (uint)*(byte *)(iVar16 + iVar9) * 0x100;
    if ((uint)*(byte *)(iVar16 + 5) + (uint)*(byte *)(iVar16 + 4) * 0x100 != 4 ||
        (uint)*(byte *)(iVar16 + 7) + (uint)*(byte *)(iVar16 + 6) * 0x100 != 0) goto LAB_0001a93c;
    iVar19 = 0;
    iVar16 = iVar9 + -1;
    if (iVar9 != 0) {
      do {
        iVar9 = iVar16 + iVar19 >> 1;
        iVar21 = iVar9 * 4 + 2;
        iVar13 = iVar14 + iVar21;
        iVar21 = (uint)*(byte *)(iVar13 + 1) + (uint)*(byte *)(iVar14 + iVar21) * 0x100;
        if ((int)param_3 < iVar21) {
          iVar16 = iVar9 + -1;
        }
        else {
          if ((int)param_3 <= iVar21) {
            iVar11 = (int)(short)((ushort)*(byte *)(iVar13 + 3) +
                                 (ushort)*(byte *)(iVar13 + 2) * 0x100);
            goto LAB_0001a8c0;
          }
          iVar19 = iVar9 + 1;
        }
      } while (iVar19 <= iVar16);
    }
  }
  else if (iVar9 == 2) {
    bVar1 = *(byte *)(iVar16 + 10);
    bVar2 = *(byte *)(iVar16 + 0xb);
    bVar3 = *(byte *)(iVar16 + 4);
    bVar4 = *(byte *)(iVar16 + 6);
    bVar5 = *(byte *)(iVar16 + 5);
    bVar6 = *(byte *)(iVar16 + 7);
    iVar9 = stbtt__GetGlyphClass
                      (iVar16 + (uint)*(byte *)(iVar16 + 9) + (uint)*(byte *)(iVar16 + 8) * 0x100,
                       param_2);
    uVar15 = stbtt__GetGlyphClass(iVar16 + (uint)bVar2 + (uint)bVar1 * 0x100,param_3);
    if ((uint)bVar6 + (uint)bVar4 * 0x100 != 0 || (uint)bVar5 + (uint)bVar3 * 0x100 != 4)
    goto LAB_0001a93c;
    if (-1 < iVar9) {
      uVar10 = ~uVar15 >> 0x1f;
      if ((int)((uint)*(byte *)(iVar16 + 0xd) + (uint)*(byte *)(iVar16 + 0xc) * 0x100) <= iVar9) {
        uVar10 = 0;
      }
      if ((uVar10 != 0) &&
         (iVar14 = (uint)*(byte *)(iVar16 + 0xf) + (uint)*(byte *)(iVar16 + 0xe) * 0x100,
         (int)uVar15 < iVar14)) {
        iVar11 = uVar15 * 2 + 0x10 + iVar14 * iVar9 * 2;
        iVar11 = (int)(short)((ushort)*(byte *)(iVar16 + iVar11 + 1) +
                             (ushort)*(byte *)(iVar16 + iVar11) * 0x100);
        goto LAB_0001a8c0;
      }
    }
  }
LAB_0001aab0:
  iVar18 = iVar18 + 2;
  if (iVar17 + iVar11 * 2 == iVar18) goto LAB_0001aac0;
  goto LAB_0001a9f8;
}
