/* ============================================================
 * xmp3_DequantChannel   @ 0x002bc604   size=1112B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

int xmp3_DequantChannel(int param_1,int param_2,int *param_3,int *param_4,int param_5,int param_6,
                       uint *param_7)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  byte *pbVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  int iVar13;
  uint uVar14;
  int *piVar15;
  bool bVar16;
  int local_6c;
  int local_68;
  int local_64;
  uint local_60;
  byte *local_58;
  uint local_34 [4];
  
  if (*(int *)(param_5 + 0x14) == 2) {
    if (*(int *)(param_5 + 0x18) != 0) {
      local_60 = 3;
      if (*param_4 == 0) {
        iVar13 = 8;
      }
      else {
        iVar13 = 6;
      }
      goto LAB_002bc63c;
    }
    local_60 = param_4[8] >> 1;
    bVar16 = local_60 != 0;
    if (bVar16) {
      local_60 = 0;
    }
    local_68 = *(int *)(param_5 + 8);
    local_6c = (*(int *)(param_5 + 0x40) + 1) * 2;
    if (bVar16) {
LAB_002bca04:
      *param_7 = 0;
      param_7[5] = 0;
      param_7[3] = 0;
      param_7[2] = 0;
      param_7[1] = 0;
      param_7[4] = 0;
      if (0xb < (int)local_60) {
        return 0x1f;
      }
    }
    else {
      local_68 = local_68 + 2;
      *param_7 = local_60;
      param_7[5] = local_60;
      param_7[3] = local_60;
      param_7[2] = local_60;
      param_7[1] = local_60;
      param_7[4] = local_60;
    }
    uVar14 = 0;
    local_68 = 0xd2 - local_68;
    local_64 = 0;
  }
  else {
    iVar13 = 0x16;
    local_60 = 0xd;
LAB_002bc63c:
    local_34[0] = 0;
    local_6c = (*(int *)(param_5 + 0x40) + 1) * 2;
    local_68 = *(int *)(param_5 + 8);
    if ((uint)param_4[8] >> 1 == 0) {
      local_68 = local_68 + 2;
    }
    else if (iVar13 == 0) goto LAB_002bca04;
    uVar14 = 0;
    local_68 = 0xd2 - local_68;
    pbVar10 = (byte *)(param_6 + -1);
    local_64 = 0;
    uVar2 = 0;
    do {
      uVar7 = uVar2 + 1;
      iVar3 = (int)*(short *)(param_4[0xd] + uVar2 * 2 + 2) -
              (int)*(short *)(param_4[0xd] + uVar2 * 2);
      uVar4 = 0;
      if (*(int *)(param_5 + 0x3c) != 0) {
        uVar4 = (uint)(byte)preTab[uVar2];
      }
      pbVar10 = pbVar10 + 1;
      iVar1 = param_1 + local_64 * 4;
      local_64 = local_64 + iVar3;
      uVar4 = DequantBlock(iVar1,iVar1,iVar3,local_6c * (uVar4 + *pbVar10) + local_68);
      if (uVar4 != 0) {
        local_34[0] = uVar2;
      }
      uVar14 = uVar14 | uVar4;
    } while ((local_64 < *param_3) && (uVar2 = uVar7, (int)uVar7 < iVar13));
    *param_7 = 0;
    param_7[3] = 0;
    param_7[5] = local_34[0];
    param_7[2] = 0;
    param_7[1] = 0;
    param_7[4] = 0;
    if (0xb < local_60) {
      if (uVar14 == 0) {
        return 0x1f;
      }
      iVar13 = 0;
      if ((int)uVar14 < 0) {
        return -1;
      }
      do {
        iVar3 = iVar13;
        uVar14 = uVar14 << 1;
        iVar13 = iVar3 + 1;
      } while (-1 < (int)uVar14);
      return iVar3;
    }
  }
  local_34[0] = local_60;
  local_58 = (byte *)(param_6 + local_60 * 3 + 0x16);
  local_34[1] = local_60;
  local_34[2] = local_60;
  do {
    iVar1 = 0;
    puVar6 = (undefined4 *)(param_1 + local_64 * 4);
    iVar13 = param_4[0xd] + local_60 * 2;
    iVar3 = (int)*(short *)(iVar13 + 0x30) - (int)*(short *)(iVar13 + 0x2e);
    uVar2 = local_60 + 1;
    iVar13 = param_2;
    puVar8 = puVar6;
    pbVar10 = local_58;
    piVar15 = (int *)(param_5 + 0x28);
    do {
      pbVar10 = pbVar10 + 1;
      uVar4 = DequantBlock(puVar8,iVar13,iVar3,local_6c * (uint)*pbVar10 + local_68 + *piVar15 * 8);
      uVar14 = uVar14 | uVar4;
      if (uVar4 != 0) {
        local_34[iVar1] = local_60;
      }
      iVar1 = iVar1 + 1;
      iVar13 = iVar13 + iVar3 * 4;
      puVar8 = puVar8 + iVar3;
      piVar15 = piVar15 + 1;
    } while (iVar1 != 3);
    local_64 = local_64 + iVar3 * 3;
    if (0 < iVar3) {
      puVar11 = (undefined4 *)(param_2 + iVar3 * 8);
      puVar5 = (undefined4 *)(param_2 + -4);
      puVar8 = (undefined4 *)(param_2 + iVar3 * 4);
      puVar12 = puVar11;
      do {
        puVar5 = puVar5 + 1;
        *puVar6 = *puVar5;
        puVar9 = puVar8 + 1;
        puVar6[1] = *puVar8;
        puVar6[2] = *puVar12;
        puVar6 = puVar6 + 3;
        puVar8 = puVar9;
        puVar12 = puVar12 + 1;
      } while (puVar11 != puVar9);
    }
    local_58 = local_58 + 3;
    bVar16 = SBORROW4(uVar2,0xc);
    iVar13 = local_60 - 0xb;
    if ((int)uVar2 < 0xd) {
      bVar16 = SBORROW4(local_64,*param_3);
      iVar13 = local_64 - *param_3;
    }
    local_60 = uVar2;
  } while (iVar13 < 0 != bVar16);
  *param_3 = local_64;
  iVar13 = *(int *)(param_5 + 0x18);
  param_7[1] = local_34[0];
  param_7[2] = local_34[1];
  param_7[3] = local_34[2];
  if (iVar13 == 0) {
    uVar2 = 1;
  }
  else {
    uVar2 = 2;
  }
  *param_7 = uVar2;
  if ((int)local_34[1] <= (int)local_34[0]) {
    local_34[1] = local_34[0];
  }
  if ((int)local_34[1] < (int)local_34[2]) {
    local_34[1] = local_34[2];
  }
  param_7[4] = local_34[1];
  if (uVar14 != 0) {
    iVar13 = 0;
    if ((int)uVar14 < 0) {
      return -1;
    }
    do {
      iVar3 = iVar13;
      uVar14 = uVar14 << 1;
      iVar13 = iVar3 + 1;
    } while (-1 < (int)uVar14);
    return iVar3;
  }
  return 0x1f;
}
