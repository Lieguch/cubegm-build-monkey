/* ============================================================
 * stbtt_GetCodepointBitmapBoxSubpixel   @ 0x0001b1dc   size=100B   callers=3
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_GetCodepointBitmapBoxSubpixel
               (undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
               undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  
  uVar1 = stbtt_FindGlyphIndex();
  stbtt_GetGlyphBitmapBoxSubpixel(param_1,param_2,param_3,param_4,param_5,uVar1,param_7,param_8);
  return;
}
