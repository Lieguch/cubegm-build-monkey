/* ============================================================
 * MP3FreeDecoder   @ 0x002b86fc   size=12B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

void MP3FreeDecoder(int param_1)

{
  if (param_1 == 0) {
    return;
  }
  xmp3_FreeBuffers();
  return;
}
