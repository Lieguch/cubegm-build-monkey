/* ============================================================
 * mxmlFindPath   @ 0x002c33ec   size=304B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

int * mxmlFindPath(int *param_1,char *param_2)

{
  char cVar1;
  char *__s;
  int iVar2;
  size_t sVar3;
  int *piVar4;
  uint __n;
  undefined4 uVar5;
  undefined1 auStack_120 [256];
  
  if (param_2 == (char *)0x0 || param_1 == (int *)0x0) {
    return (int *)0x0;
  }
  if (*param_2 == '\0') {
LAB_002c34e0:
    param_1 = (int *)0x0;
  }
  else {
    do {
      iVar2 = strncmp(param_2,"*/",2);
      if (iVar2 == 0) {
        uVar5 = 1;
        __s = param_2 + 2;
      }
      else {
        uVar5 = 0xffffffff;
        __s = param_2;
      }
      param_2 = strchr(__s,0x2f);
      if (param_2 == (char *)0x0) {
        sVar3 = strlen(__s);
        param_2 = __s + sVar3;
      }
      if ((__s == param_2) || (__n = (int)param_2 - (int)__s, 0xff < __n)) goto LAB_002c34e0;
      memcpy(auStack_120,__s,__n);
      cVar1 = *param_2;
      auStack_120[__n] = 0;
      if (cVar1 != '\0') {
        param_2 = param_2 + 1;
      }
      param_1 = (int *)mxmlFindElement(param_1,param_1,auStack_120,0,0,uVar5);
      if (param_1 == (int *)0x0) goto LAB_002c34e0;
    } while (*param_2 != '\0');
    piVar4 = (int *)param_1[4];
    if (piVar4 != (int *)0x0) {
      if (*piVar4 == 0) {
        piVar4 = param_1;
      }
      return piVar4;
    }
  }
  return param_1;
}
