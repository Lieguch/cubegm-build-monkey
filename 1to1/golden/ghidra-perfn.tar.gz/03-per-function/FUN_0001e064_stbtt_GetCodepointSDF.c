/* ============================================================
 * stbtt_GetCodepointSDF   @ 0x0001e064   size=100B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_GetCodepointSDF
               (undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
               undefined4 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  
  uVar1 = stbtt_FindGlyphIndex();
  stbtt_GetGlyphSDF(param_1,param_2,param_3,uVar1,param_5,param_6);
  return;
}
