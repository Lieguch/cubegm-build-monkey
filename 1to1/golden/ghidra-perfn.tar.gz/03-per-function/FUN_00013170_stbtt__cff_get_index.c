/* ============================================================
 * stbtt__cff_get_index   @ 0x00013170   size=336B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt__cff_get_index(int *param_1,int *param_2)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  
  uVar4 = param_2[1];
  uVar5 = param_2[2];
  uVar7 = uVar4;
  if ((int)uVar5 <= (int)uVar4) goto LAB_00013244;
  iVar6 = *param_2;
  uVar7 = uVar4 + 1;
  param_2[1] = uVar7;
  bVar1 = *(byte *)(iVar6 + uVar4);
  if ((int)uVar7 < (int)uVar5) {
    uVar3 = uVar4 + 2;
    param_2[1] = uVar3;
    uVar2 = (uint)*(byte *)(iVar6 + uVar7) | (uint)bVar1 * 0x100;
    uVar7 = uVar3;
    if (uVar2 == 0) goto LAB_00013244;
    if ((int)uVar5 <= (int)uVar3) goto LAB_000132a4;
    param_2[1] = uVar4 + 3;
    uVar3 = (uint)*(byte *)(iVar6 + uVar3);
    uVar7 = uVar3 * uVar2 + uVar4 + 3;
    if ((int)uVar5 < (int)uVar7 || (int)uVar7 < 0) {
      uVar7 = uVar5;
    }
    param_2[1] = uVar7;
    if (uVar3 == 0) {
      iVar6 = -1;
    }
    else {
      uVar8 = 0;
      uVar2 = 0;
      do {
        uVar8 = uVar8 + 1;
        uVar9 = 0;
        if ((int)uVar7 < (int)uVar5) {
          param_2[1] = uVar7 + 1;
        }
        if ((int)uVar7 < (int)uVar5) {
          uVar9 = (uint)*(byte *)(iVar6 + uVar7);
          uVar7 = uVar7 + 1;
        }
        uVar2 = uVar2 << 8 | uVar9;
      } while (uVar3 != uVar8);
      iVar6 = uVar2 - 1;
    }
  }
  else {
    if (bVar1 == 0) goto LAB_00013244;
LAB_000132a4:
    uVar2 = uVar7 >> 0x1f;
    iVar6 = -1;
    if ((int)uVar5 < (int)uVar7) {
      uVar2 = 1;
    }
    if (uVar2 != 0) {
      uVar7 = uVar5;
    }
  }
  uVar7 = uVar7 + iVar6;
  if ((int)uVar5 < (int)uVar7 || (int)uVar7 < 0) {
    uVar7 = uVar5;
  }
  param_2[1] = uVar7;
LAB_00013244:
  uVar7 = uVar7 - uVar4;
  if (((-1 < (int)(uVar7 | uVar4)) && ((int)uVar4 <= param_2[2])) &&
     ((int)uVar7 <= (int)(param_2[2] - uVar4))) {
    iVar6 = *param_2;
    param_1[1] = 0;
    param_1[2] = uVar7;
    *param_1 = iVar6 + uVar4;
    return;
  }
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  return;
}
