/* ============================================================
 * MP3GetLastFrameInfo   @ 0x002b875c   size=144B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

void MP3GetLastFrameInfo(int param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  if ((param_1 != 0) && (*(int *)(param_1 + 2000) == 3)) {
    iVar3 = *(int *)(param_1 + 0x7bc);
    uVar2 = *(undefined4 *)(param_1 + 0x7c0);
    *param_2 = *(undefined4 *)(param_1 + 0x7b8);
    iVar1 = *(int *)(param_1 + 0x7d4);
    param_2[1] = iVar3;
    param_2[2] = uVar2;
    param_2[3] = 0x10;
    param_2[6] = iVar1;
    param_2[5] = 3;
    param_2[4] = iVar3 * *(short *)(xmp3_samplesPerFrameTab + iVar1 * 6 + 4);
    return;
  }
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  param_2[5] = 0;
  param_2[6] = 0;
  return;
}
