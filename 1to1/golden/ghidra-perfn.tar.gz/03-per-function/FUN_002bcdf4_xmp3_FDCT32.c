/* ============================================================
 * xmp3_FDCT32   @ 0x002bcdf4   size=2428B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

void xmp3_FDCT32(uint *param_1,int param_2,int param_3,int param_4,int param_5)

{
  uint *puVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  int iVar13;
  uint uVar14;
  undefined1 *puVar15;
  int iVar16;
  uint uVar17;
  int iVar18;
  uint uVar19;
  uint *puVar20;
  uint local_58;
  int local_54;
  uint local_50;
  int local_4c;
  
  if (param_5 < 6) {
    uVar17 = 6 - param_5;
    puVar20 = param_1 + -1;
    do {
      puVar1 = puVar20 + 1;
      puVar20 = puVar20 + 1;
      *puVar20 = (int)*puVar1 >> (uVar17 & 0xff);
    } while (param_1 + 0x1f != puVar20);
  }
  else {
    uVar17 = 0;
  }
  iVar13 = *param_1 + param_1[0x1f];
  iVar5 = (int)((ulonglong)((longlong)(int)(*param_1 - param_1[0x1f]) * 0x4013c251) >> 0x20) * 2;
  iVar2 = param_1[0xf] + param_1[0x10];
  iVar8 = (int)((ulonglong)((longlong)(int)(param_1[0xf] - param_1[0x10]) * 0x518522fb) >> 0x20);
  uVar3 = iVar13 + iVar2;
  *param_1 = uVar3;
  param_1[0xf] = (int)((ulonglong)((longlong)(iVar13 - iVar2) * 0x404f4672) >> 0x20) << 1;
  param_1[0x10] = iVar5 + iVar8 * 0x20;
  param_1[0x1f] = (int)((ulonglong)((longlong)(iVar5 + iVar8 * -0x20) * 0x404f4672) >> 0x20) << 1;
  iVar13 = param_1[1] + param_1[0x1e];
  iVar5 = (int)((ulonglong)((longlong)(int)(param_1[1] - param_1[0x1e]) * 0x40b345bd) >> 0x20) * 2;
  iVar8 = param_1[0xe] + param_1[0x11];
  iVar2 = (int)((ulonglong)((longlong)(int)(param_1[0xe] - param_1[0x11]) * 0x6d0b20cf) >> 0x20);
  uVar9 = iVar13 + iVar8;
  param_1[1] = uVar9;
  param_1[0xe] = (int)((ulonglong)((longlong)(iVar13 - iVar8) * 0x42e13c10) >> 0x20) << 1;
  param_1[0x11] = iVar5 + iVar2 * 8;
  param_1[0x1e] = (int)((ulonglong)((longlong)(iVar5 + iVar2 * -8) * 0x42e13c10) >> 0x20) << 1;
  iVar13 = param_1[2] + param_1[0x1d];
  iVar5 = (int)((ulonglong)((longlong)(int)(param_1[2] - param_1[0x1d]) * 0x41fa2d6d) >> 0x20) * 2;
  iVar8 = param_1[0xd] + param_1[0x12];
  iVar2 = (int)((ulonglong)((longlong)(int)(param_1[0xd] - param_1[0x12]) * 0x41d95790) >> 0x20);
  local_58 = iVar13 + iVar8;
  param_1[2] = local_58;
  param_1[0xd] = (int)((ulonglong)((longlong)(iVar13 - iVar8) * 0x48919f44) >> 0x20) << 1;
  param_1[0x12] = iVar5 + iVar2 * 8;
  param_1[0x1d] = (int)((ulonglong)((longlong)(iVar5 + iVar2 * -8) * 0x48919f44) >> 0x20) << 1;
  iVar8 = param_1[3] + param_1[0x1c];
  iVar5 = (int)((ulonglong)((longlong)(int)(param_1[3] - param_1[0x1c]) * 0x43f93421) >> 0x20) * 2;
  iVar13 = param_1[0xc] + param_1[0x13];
  iVar2 = (int)((ulonglong)((longlong)(int)(param_1[0xc] - param_1[0x13]) * 0x5efc8d96) >> 0x20);
  uVar19 = iVar8 + iVar13;
  param_1[3] = uVar19;
  param_1[0xc] = (int)((ulonglong)((longlong)(iVar8 - iVar13) * 0x52cb0e63) >> 0x20) << 1;
  param_1[0x13] = iVar5 + iVar2 * 4;
  param_1[0x1c] = (int)((ulonglong)((longlong)(iVar5 + iVar2 * -4) * 0x52cb0e63) >> 0x20) << 1;
  iVar8 = param_1[4] + param_1[0x1b];
  iVar5 = (int)((ulonglong)((longlong)(int)(param_1[4] - param_1[0x1b]) * 0x46cc1bc4) >> 0x20) * 2;
  iVar13 = param_1[0xb] + param_1[0x14];
  iVar2 = (int)((ulonglong)((longlong)(int)(param_1[0xb] - param_1[0x14]) * 0x4ad81a97) >> 0x20);
  uVar11 = iVar8 + iVar13;
  param_1[4] = uVar11;
  param_1[0xb] = (int)((ulonglong)((longlong)(iVar8 - iVar13) * 0x64e2402e) >> 0x20) << 1;
  param_1[0x14] = iVar5 + iVar2 * 4;
  param_1[0x1b] = (int)((ulonglong)((longlong)(iVar5 + iVar2 * -4) * 0x64e2402e) >> 0x20) << 1;
  iVar8 = param_1[5] + param_1[0x1a];
  iVar5 = (int)((ulonglong)((longlong)(int)(param_1[5] - param_1[0x1a]) * 0x4a9d9cf0) >> 0x20) * 2;
  iVar13 = param_1[10] + param_1[0x15];
  iVar2 = (int)((ulonglong)((longlong)(int)(param_1[10] - param_1[0x15]) * 0x7c7d1db3) >> 0x20);
  uVar12 = iVar8 + iVar13;
  param_1[5] = uVar12;
  param_1[10] = (int)((ulonglong)((longlong)(iVar8 - iVar13) * 0x43e224a9) >> 0x20) << 2;
  param_1[0x15] = iVar5 + iVar2 * 2;
  param_1[0x1a] = (int)((ulonglong)((longlong)(iVar5 + iVar2 * -2) * 0x43e224a9) >> 0x20) << 2;
  iVar13 = param_1[6] + param_1[0x19];
  iVar5 = (int)((ulonglong)((longlong)(int)(param_1[6] - param_1[0x19]) * 0x4fae3711) >> 0x20) * 2;
  iVar8 = param_1[9] + param_1[0x16];
  iVar2 = (int)((ulonglong)((longlong)(int)(param_1[9] - param_1[0x16]) * 0x6b6fcf26) >> 0x20);
  local_50 = iVar13 + iVar8;
  param_1[6] = local_50;
  param_1[9] = (int)((ulonglong)((longlong)(iVar13 - iVar8) * 0x6e3c92c1) >> 0x20) << 2;
  param_1[0x16] = iVar5 + iVar2 * 2;
  param_1[0x19] = (int)((ulonglong)((longlong)(iVar5 + iVar2 * -2) * 0x6e3c92c1) >> 0x20) << 2;
  iVar8 = param_1[7] + param_1[0x18];
  iVar5 = (int)((ulonglong)((longlong)(int)(param_1[7] - param_1[0x18]) * 0x56601ea7) >> 0x20) * 2;
  iVar2 = param_1[8] + param_1[0x17];
  iVar13 = (int)((ulonglong)((longlong)(int)(param_1[8] - param_1[0x17]) * 0x5f4cf6eb) >> 0x20);
  uVar14 = iVar8 + iVar2;
  param_1[7] = uVar14;
  param_1[8] = (int)((ulonglong)((longlong)(iVar8 - iVar2) * 0x519e4e04) >> 0x20) << 4;
  param_1[0x17] = iVar5 + iVar13 * 2;
  param_1[0x18] = (int)((ulonglong)((longlong)(iVar5 + iVar13 * -2) * 0x519e4e04) >> 0x20) << 4;
  local_54 = 0x4cf8de88;
  iVar5 = 0x4140fb46;
  iVar13 = 0x539eba45;
  iVar2 = 0x4545e9ef;
  iVar8 = 0x52036742;
  local_4c = 0x73326bbf;
  puVar15 = &dcttab;
  puVar20 = param_1;
  while( true ) {
    iVar5 = (int)((ulonglong)((longlong)iVar5 * (longlong)(int)(uVar3 - uVar14)) >> 0x20) * 2;
    iVar6 = (int)((ulonglong)((longlong)iVar8 * (longlong)(int)(uVar19 - uVar11)) >> 0x20);
    iVar10 = uVar3 + uVar14 + uVar19 + uVar11;
    iVar8 = (int)((ulonglong)
                  ((longlong)iVar2 * (longlong)(int)((uVar3 + uVar14) - (uVar19 + uVar11))) >> 0x20)
            * 2;
    iVar7 = iVar5 + iVar6 * 8;
    iVar5 = (int)((ulonglong)((longlong)iVar2 * (longlong)(iVar5 + iVar6 * -8)) >> 0x20) * 2;
    iVar2 = (int)((ulonglong)((longlong)local_54 * (longlong)(int)(uVar9 - local_50)) >> 0x20) * 2;
    iVar6 = (int)((ulonglong)((longlong)local_4c * (longlong)(int)(local_58 - uVar12)) >> 0x20);
    iVar18 = uVar9 + local_50 + local_58 + uVar12;
    iVar16 = (int)((ulonglong)
                   ((longlong)iVar13 * (longlong)(int)((uVar9 + local_50) - (local_58 + uVar12))) >>
                  0x20);
    iVar4 = iVar2 + iVar6 * 2;
    iVar13 = (int)((ulonglong)((longlong)iVar13 * (longlong)(iVar2 + iVar6 * -2)) >> 0x20);
    uVar3 = (int)((ulonglong)((longlong)(iVar8 + iVar16 * -4) * 0x5a82799a) >> 0x20) * 2;
    puVar20[3] = uVar3;
    puVar20[2] = iVar8 + iVar16 * 4 + uVar3;
    *puVar20 = iVar10 + iVar18;
    puVar20[1] = (int)((ulonglong)((longlong)(iVar10 - iVar18) * 0x5a82799a) >> 0x20) << 1;
    iVar2 = (int)((ulonglong)((longlong)(iVar7 - iVar4) * 0x5a82799a) >> 0x20) * 2;
    uVar3 = (int)((ulonglong)((longlong)(iVar5 + iVar13 * -4) * 0x5a82799a) >> 0x20) * 2;
    iVar5 = iVar5 + iVar13 * 4 + uVar3;
    puVar20[7] = uVar3;
    puVar20[6] = iVar2 + iVar5;
    puVar20[4] = iVar7 + iVar4 + iVar5;
    puVar20[5] = iVar2 + uVar3;
    if (puVar15 + 0x18 == &DAT_002e42ec) break;
    local_50 = puVar20[0xe];
    local_54 = *(int *)(puVar15 + 0x84);
    uVar3 = puVar20[8];
    local_58 = puVar20[10];
    local_4c = *(int *)(puVar15 + 0x88);
    uVar14 = puVar20[0xf];
    uVar19 = puVar20[0xb];
    uVar11 = puVar20[0xc];
    iVar5 = *(int *)(puVar15 + 0x78);
    iVar8 = *(int *)(puVar15 + 0x7c);
    iVar2 = *(int *)(puVar15 + 0x80);
    uVar9 = puVar20[9];
    uVar12 = puVar20[0xd];
    iVar13 = *(int *)(puVar15 + 0x8c);
    puVar15 = puVar15 + 0x18;
    puVar20 = puVar20 + 8;
  }
  iVar2 = (param_3 - param_4 & 7U) + 0x400;
  iVar5 = iVar2 * 4;
  if (param_4 == 0) {
    uVar3 = *param_1;
    iVar8 = 0x1100;
    puVar20 = (uint *)(param_2 + iVar5 + 0x1100);
    puVar20[8] = uVar3;
    *(uint *)(param_2 + iVar5 + 0x1100) = uVar3;
    iVar2 = 0;
  }
  else {
    iVar8 = 0;
    uVar3 = *param_1;
    puVar20 = (uint *)(param_2 + iVar5);
    puVar20[8] = uVar3;
    *(uint *)(param_2 + iVar2 * 4) = uVar3;
    iVar2 = 0x1100;
  }
  iVar2 = iVar2 + param_3 * 4;
  uVar3 = param_1[1];
  iVar13 = param_2 + iVar2;
  iVar8 = iVar5 + -0xfc0 + iVar8;
  iVar5 = param_2 + iVar8;
  *(uint *)(iVar13 + 0x20) = uVar3;
  *(uint *)(param_2 + iVar2) = uVar3;
  uVar12 = param_1[0x1d];
  uVar3 = param_1[0x19];
  iVar2 = uVar3 + uVar12 + param_1[0x11];
  *(int *)(iVar13 + 0x120) = iVar2;
  *(int *)(iVar13 + 0x100) = iVar2;
  uVar19 = param_1[0xd];
  uVar9 = param_1[9];
  *(uint *)(iVar13 + 0x220) = uVar9 + uVar19;
  *(uint *)(iVar13 + 0x200) = uVar9 + uVar19;
  iVar2 = uVar3 + uVar12 + param_1[0x15];
  *(int *)(iVar13 + 800) = iVar2;
  *(int *)(iVar13 + 0x300) = iVar2;
  uVar9 = param_1[5];
  uVar12 = param_1[0x1b];
  uVar3 = param_1[0x1d];
  *(uint *)(iVar13 + 0x420) = uVar9;
  *(uint *)(iVar13 + 0x400) = uVar9;
  iVar2 = uVar3 + uVar12 + param_1[0x15];
  *(int *)(iVar13 + 0x520) = iVar2;
  *(int *)(iVar13 + 0x500) = iVar2;
  uVar19 = param_1[0xb];
  uVar9 = param_1[0xd];
  *(uint *)(iVar13 + 0x620) = uVar9 + uVar19;
  *(uint *)(iVar13 + 0x600) = uVar9 + uVar19;
  iVar2 = uVar3 + uVar12 + param_1[0x13];
  *(int *)(iVar13 + 0x720) = iVar2;
  *(int *)(iVar13 + 0x700) = iVar2;
  uVar12 = param_1[0x1b];
  uVar3 = param_1[0x1f];
  uVar9 = param_1[3];
  *(uint *)(iVar13 + 0x820) = uVar9;
  *(uint *)(iVar13 + 0x800) = uVar9;
  iVar2 = uVar12 + uVar3 + param_1[0x13];
  *(int *)(iVar13 + 0x920) = iVar2;
  *(int *)(iVar13 + 0x900) = iVar2;
  uVar9 = param_1[0xb];
  uVar19 = param_1[0xf];
  *(uint *)(iVar13 + 0xa20) = uVar9 + uVar19;
  *(uint *)(iVar13 + 0xa00) = uVar9 + uVar19;
  iVar2 = uVar12 + uVar3 + param_1[0x17];
  *(int *)(iVar13 + 0xb20) = iVar2;
  *(int *)(iVar13 + 0xb00) = iVar2;
  uVar3 = param_1[7];
  uVar9 = param_1[0x1f];
  *(uint *)(iVar13 + 0xc20) = uVar3;
  *(uint *)(iVar13 + 0xc00) = uVar3;
  uVar3 = param_1[0x17];
  *(uint *)(iVar13 + 0xd20) = uVar9 + uVar3;
  *(uint *)(iVar13 + 0xd00) = uVar9 + uVar3;
  uVar3 = param_1[0xf];
  *(uint *)(iVar13 + 0xf20) = uVar9;
  *(uint *)(iVar13 + 0xf00) = uVar9;
  *(uint *)(iVar13 + 0xe20) = uVar3;
  *(uint *)(iVar13 + 0xe00) = uVar3;
  uVar3 = param_1[1];
  *(uint *)(iVar5 + 0x20) = uVar3;
  *(uint *)(param_2 + iVar8) = uVar3;
  uVar9 = param_1[0x19];
  uVar3 = param_1[0x1e];
  iVar2 = uVar3 + uVar9 + param_1[0x11];
  *(int *)(iVar5 + 0x120) = iVar2;
  *(int *)(iVar5 + 0x100) = iVar2;
  uVar12 = param_1[9];
  uVar19 = param_1[0xe];
  *(uint *)(iVar5 + 0x220) = uVar19 + uVar12;
  *(uint *)(iVar5 + 0x200) = uVar19 + uVar12;
  iVar2 = uVar3 + uVar9 + param_1[0x16];
  *(int *)(iVar5 + 800) = iVar2;
  *(int *)(iVar5 + 0x300) = iVar2;
  uVar3 = param_1[6];
  *(uint *)(iVar5 + 0x420) = uVar3;
  *(uint *)(iVar5 + 0x400) = uVar3;
  uVar9 = param_1[0x1e];
  uVar3 = param_1[0x1a];
  iVar2 = uVar3 + uVar9 + param_1[0x16];
  *(int *)(iVar5 + 0x520) = iVar2;
  *(int *)(iVar5 + 0x500) = iVar2;
  uVar12 = param_1[0xe];
  uVar19 = param_1[10];
  *(uint *)(iVar5 + 0x620) = uVar19 + uVar12;
  *(uint *)(iVar5 + 0x600) = uVar19 + uVar12;
  iVar2 = uVar3 + uVar9 + param_1[0x12];
  *(int *)(iVar5 + 0x720) = iVar2;
  *(int *)(iVar5 + 0x700) = iVar2;
  uVar3 = param_1[2];
  *(uint *)(iVar5 + 0x820) = uVar3;
  *(uint *)(iVar5 + 0x800) = uVar3;
  uVar3 = param_1[0x1c];
  uVar9 = param_1[0x1a];
  iVar2 = uVar3 + uVar9 + param_1[0x12];
  *(int *)(iVar5 + 0x920) = iVar2;
  *(int *)(iVar5 + 0x900) = iVar2;
  uVar19 = param_1[0xc];
  uVar12 = param_1[10];
  *(uint *)(iVar5 + 0xa20) = uVar19 + uVar12;
  *(uint *)(iVar5 + 0xa00) = uVar19 + uVar12;
  iVar2 = uVar3 + uVar9 + param_1[0x14];
  *(int *)(iVar5 + 0xb20) = iVar2;
  *(int *)(iVar5 + 0xb00) = iVar2;
  uVar3 = param_1[4];
  *(uint *)(iVar5 + 0xc20) = uVar3;
  *(uint *)(iVar5 + 0xc00) = uVar3;
  uVar9 = param_1[0x1c];
  uVar3 = param_1[0x18];
  iVar2 = uVar3 + uVar9 + param_1[0x14];
  *(int *)(iVar5 + 0xd20) = iVar2;
  *(int *)(iVar5 + 0xd00) = iVar2;
  uVar19 = param_1[8];
  uVar12 = param_1[0xc];
  *(uint *)(iVar5 + 0xe20) = uVar19 + uVar12;
  *(uint *)(iVar5 + 0xe00) = uVar19 + uVar12;
  iVar2 = uVar3 + uVar9 + param_1[0x10];
  *(int *)(iVar5 + 0xf20) = iVar2;
  *(int *)(iVar5 + 0xf00) = iVar2;
  if (uVar17 != 0) {
    uVar3 = *puVar20;
    uVar12 = 0x1f - uVar17;
    uVar9 = ~(-1 << (uVar12 & 0xff));
    if ((int)uVar3 >> 0x1f != (int)uVar3 >> (uVar12 & 0xff)) {
      uVar3 = ~(-1 << (uVar12 & 0xff)) ^ (int)uVar3 >> 0x1f;
    }
    uVar3 = uVar3 << (uVar17 & 0xff);
    puVar20[8] = uVar3;
    *puVar20 = uVar3;
    iVar2 = iVar13 + 0x100;
    do {
      uVar3 = *(uint *)(iVar2 + -0x100);
      iVar8 = iVar2 + 0x100;
      if ((int)uVar3 >> 0x1f != (int)uVar3 >> (uVar12 & 0xff)) {
        uVar3 = (int)uVar3 >> 0x1f ^ uVar9;
      }
      iVar6 = uVar3 << (uVar17 & 0xff);
      *(int *)(iVar2 + -0xe0) = iVar6;
      *(int *)(iVar2 + -0x100) = iVar6;
      iVar2 = iVar8;
    } while (iVar13 + 0x1100 != iVar8);
    iVar2 = iVar5 + 0x100;
    do {
      uVar3 = *(uint *)(iVar2 + -0x100);
      iVar8 = iVar2 + 0x100;
      if ((int)uVar3 >> 0x1f != (int)uVar3 >> (uVar12 & 0xff)) {
        uVar3 = uVar9 ^ (int)uVar3 >> 0x1f;
      }
      iVar13 = uVar3 << (uVar17 & 0xff);
      *(int *)(iVar2 + -0xe0) = iVar13;
      *(int *)(iVar2 + -0x100) = iVar13;
      iVar2 = iVar8;
    } while (iVar5 + 0x1100 != iVar8);
  }
  return;
}
