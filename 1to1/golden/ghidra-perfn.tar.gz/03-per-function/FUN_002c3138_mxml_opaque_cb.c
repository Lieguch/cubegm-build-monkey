/* ============================================================
 * mxml_opaque_cb   @ 0x002c3138   size=8B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxml_opaque_cb(void)

{
  return 2;
}
