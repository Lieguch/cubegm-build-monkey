/* ============================================================
 * mxml_ignore_cb   @ 0x002c3128   size=8B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxml_ignore_cb(void)

{
  return 0xffffffff;
}
