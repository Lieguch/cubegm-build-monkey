/* ============================================================
 * stbtt_GetCodepointHMetrics   @ 0x0001ae10   size=44B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_GetCodepointHMetrics
               (undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  
  uVar1 = stbtt_FindGlyphIndex();
  stbtt_GetGlyphHMetrics(param_1,uVar1,param_3,param_4);
  return;
}
