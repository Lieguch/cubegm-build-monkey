/* ============================================================
 * _mxml_destructor   @ 0x002c3108   size=4B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

void _mxml_destructor(void *param_1)

{
  free(param_1);
  return;
}
