/* ============================================================
 * mxml_string_putc   @ 0x002bf00c   size=36B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxml_string_putc(undefined1 param_1,undefined4 *param_2)

{
  undefined1 *puVar1;
  
  puVar1 = (undefined1 *)*param_2;
  if (puVar1 < (undefined1 *)param_2[1]) {
    *puVar1 = param_1;
    puVar1 = (undefined1 *)*param_2;
  }
  *param_2 = puVar1 + 1;
  return 0;
}
