/* ============================================================
 * stbtt_ScaleForPixelHeight   @ 0x0001b000   size=80B   callers=6
 * module: 05_stb_truetype_font
 * ============================================================ */

float stbtt_ScaleForPixelHeight(float param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint in_fpscr;
  float fVar4;
  
  iVar1 = *(int *)(param_2 + 4);
  iVar3 = *(int *)(param_2 + 0x1c) + 4;
  iVar2 = *(int *)(param_2 + 0x1c) + 6;
  fVar4 = (float)VectorSignedToFloat((int)(short)((ushort)*(byte *)(iVar1 + iVar3 + 1) +
                                                 (ushort)*(byte *)(iVar1 + iVar3) * 0x100) -
                                     (int)(short)((ushort)*(byte *)(iVar1 + iVar2 + 1) +
                                                 (ushort)*(byte *)(iVar1 + iVar2) * 0x100),
                                     (byte)(in_fpscr >> 0x16) & 3);
  return param_1 / fVar4;
}
