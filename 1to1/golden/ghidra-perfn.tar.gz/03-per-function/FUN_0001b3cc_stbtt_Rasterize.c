/* ============================================================
 * stbtt_Rasterize   @ 0x0001b3cc   size=1240B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

/* WARNING: Removing unreachable block (ram,0x0001b6d8) */

void stbtt_Rasterize(float param_1,float param_2,float param_3,float param_4,float param_5,
                    undefined4 param_6,short *param_7,int param_8,undefined4 param_9,
                    undefined4 param_10,int param_11)

{
  uint uVar1;
  byte bVar2;
  float fVar3;
  float *pfVar4;
  int *__ptr;
  undefined4 *__ptr_00;
  int iVar5;
  int iVar6;
  float *pfVar7;
  int *piVar8;
  float *pfVar9;
  int *piVar10;
  float *pfVar11;
  short *psVar12;
  short *psVar13;
  int *piVar14;
  float *pfVar15;
  int iVar16;
  undefined4 *puVar17;
  int *piVar18;
  undefined4 *puVar19;
  int iVar20;
  int iVar21;
  uint in_fpscr;
  uint uVar22;
  int iVar23;
  undefined4 uVar24;
  undefined4 uVar25;
  undefined4 uVar26;
  undefined4 uVar27;
  undefined4 uVar28;
  undefined4 uVar29;
  float fVar30;
  float fVar31;
  float fVar32;
  float fVar33;
  int *local_54;
  float local_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 local_44;
  
  uVar1 = in_fpscr & 0xfffffff | (uint)(param_2 < param_3) << 0x1f |
          (uint)(param_2 == param_3) << 0x1e;
  uVar22 = uVar1 | (uint)(NAN(param_2) || NAN(param_3)) << 0x1c;
  iVar6 = 0;
  bVar2 = (byte)(uVar1 >> 0x18);
  fVar33 = param_2;
  if (!(bool)(bVar2 >> 6 & 1) && bVar2 >> 7 == ((byte)(uVar22 >> 0x1c) & 1)) {
    fVar33 = param_3;
  }
  local_54 = (int *)0x0;
  fVar33 = (param_1 / fVar33) * (param_1 / fVar33);
  if (0 < param_8) {
    psVar13 = param_7;
    do {
      psVar12 = psVar13 + 6;
      psVar13 = psVar13 + 7;
      if ((char)*psVar12 == '\x01') {
        iVar6 = iVar6 + 1;
      }
    } while (param_7 + param_8 * 7 != psVar13);
    if ((iVar6 != 0) && (__ptr = malloc(iVar6 * 4), __ptr != (int *)0x0)) {
      piVar14 = (int *)0x0;
      iVar16 = 0;
      piVar18 = (int *)0x0;
      do {
        iVar23 = 0;
        iVar20 = -1;
        local_54 = (int *)0x0;
        psVar12 = param_7;
        iVar21 = iVar23;
        do {
          piVar8 = local_54;
          switch((char)psVar12[6]) {
          case '\x01':
            if (iVar20 != -1) {
              __ptr[iVar20] = (int)local_54 - (int)piVar14;
            }
            iVar20 = iVar20 + 1;
            iVar23 = VectorSignedToFloat((int)*psVar12,(byte)(uVar22 >> 0x16) & 3);
            piVar8 = (int *)((int)local_54 + 1);
            iVar21 = VectorSignedToFloat((int)psVar12[1],(byte)(uVar22 >> 0x16) & 3);
            piVar10 = piVar8;
            if (piVar18 != (int *)0x0) {
              piVar10 = piVar18 + (int)local_54 * 2;
              *piVar10 = iVar23;
            }
            piVar14 = local_54;
            if (piVar18 != (int *)0x0) {
              piVar10[1] = iVar21;
            }
            break;
          case '\x02':
            iVar23 = VectorSignedToFloat((int)*psVar12,(byte)(uVar22 >> 0x16) & 3);
            piVar8 = (int *)((int)local_54 + 1);
            iVar21 = VectorSignedToFloat((int)psVar12[1],(byte)(uVar22 >> 0x16) & 3);
            if (piVar18 != (int *)0x0) {
              local_54 = piVar18 + (int)local_54 * 2;
              *local_54 = iVar23;
            }
            if (piVar18 != (int *)0x0) {
              local_54[1] = iVar21;
            }
            break;
          case '\x03':
            uVar27 = VectorSignedToFloat((int)psVar12[1],(byte)(uVar22 >> 0x16) & 3);
            uVar26 = VectorSignedToFloat((int)*psVar12,(byte)(uVar22 >> 0x16) & 3);
            uVar25 = VectorSignedToFloat((int)psVar12[3],(byte)(uVar22 >> 0x16) & 3);
            uVar24 = VectorSignedToFloat((int)psVar12[2],(byte)(uVar22 >> 0x16) & 3);
            stbtt__tesselate_curve
                      (iVar23,iVar21,uVar24,uVar25,uVar26,uVar27,fVar33,piVar18,&local_54,0);
            goto LAB_0001b524;
          case '\x04':
            uVar29 = VectorSignedToFloat((int)psVar12[1],(byte)(uVar22 >> 0x16) & 3);
            uVar28 = VectorSignedToFloat((int)*psVar12,(byte)(uVar22 >> 0x16) & 3);
            uVar27 = VectorSignedToFloat((int)psVar12[5],(byte)(uVar22 >> 0x16) & 3);
            uVar26 = VectorSignedToFloat((int)psVar12[4],(byte)(uVar22 >> 0x16) & 3);
            uVar25 = VectorSignedToFloat((int)psVar12[3],(byte)(uVar22 >> 0x16) & 3);
            uVar24 = VectorSignedToFloat((int)psVar12[2],(byte)(uVar22 >> 0x16) & 3);
            stbtt__tesselate_cubic
                      (iVar23,iVar21,uVar24,uVar25,uVar26,uVar27,uVar28,uVar29,fVar33,piVar18,
                       &local_54,0);
LAB_0001b524:
            iVar23 = VectorSignedToFloat((int)*psVar12,(byte)(uVar22 >> 0x16) & 3);
            iVar21 = VectorSignedToFloat((int)psVar12[1],(byte)(uVar22 >> 0x16) & 3);
            piVar8 = local_54;
          }
          local_54 = piVar8;
          psVar12 = psVar12 + 7;
        } while (psVar12 != psVar13);
        iVar16 = iVar16 + 1;
        __ptr[iVar20] = (int)local_54 - (int)piVar14;
        if (iVar16 == 2) {
          if (piVar18 == (int *)0x0) {
            return;
          }
          iVar16 = 0;
          if (param_11 != 0) {
            param_3 = -param_3;
          }
          piVar14 = __ptr;
          do {
            piVar8 = piVar14 + 1;
            iVar16 = iVar16 + *piVar14;
            piVar14 = piVar8;
          } while (__ptr + iVar6 != piVar8);
          __ptr_00 = malloc(iVar16 * 0x14 + 0x14);
          if (__ptr_00 != (undefined4 *)0x0) {
            iVar6 = 0;
            iVar16 = 0;
            piVar14 = __ptr;
            do {
              piVar10 = piVar14 + 1;
              iVar21 = *piVar14;
              pfVar15 = (float *)(piVar18 + iVar16 * 2);
              iVar16 = iVar16 + iVar21;
              if (0 < iVar21) {
                iVar20 = 0;
                iVar23 = iVar21 + -1;
                pfVar11 = pfVar15;
                fVar33 = pfVar15[(iVar21 + -1) * 2 + 1];
                do {
                  iVar5 = iVar20;
                  fVar32 = pfVar11[1];
                  pfVar9 = (float *)(__ptr_00 + iVar6 * 5);
                  if (fVar32 != fVar33) {
                    pfVar7 = pfVar15 + iVar23 * 2;
                    iVar6 = iVar6 + 1;
                    if (param_11 != 0 || (NAN(fVar32) || NAN(fVar33))) {
                      pfVar9[4] = 0.0;
                      fVar3 = fVar33;
                      pfVar4 = pfVar7;
                      pfVar7 = pfVar11;
                    }
                    else {
                      pfVar9[4] = 1.4013e-45;
                      fVar3 = fVar32;
                      pfVar4 = pfVar11;
                    }
                    fVar30 = *pfVar7;
                    if (param_11 != 0 || (NAN(fVar32) || NAN(fVar33))) {
                      fVar33 = fVar32;
                    }
                    fVar31 = *pfVar4;
                    pfVar9[1] = param_5 + param_3 * fVar33;
                    pfVar9[3] = param_5 + param_3 * fVar3;
                    *pfVar9 = param_4 + param_2 * fVar30;
                    pfVar9[2] = param_4 + param_2 * fVar31;
                  }
                  iVar20 = iVar5 + 1;
                  pfVar11 = pfVar11 + 2;
                  iVar23 = iVar5;
                  fVar33 = fVar32;
                } while (iVar21 != iVar20);
              }
              piVar14 = piVar10;
            } while (piVar8 != piVar10);
            stbtt__sort_edges_quicksort(__ptr_00,iVar6);
            if (1 < iVar6) {
              iVar16 = 1;
              puVar17 = __ptr_00;
              do {
                puVar19 = puVar17 + 5;
                fVar33 = (float)puVar17[6];
                local_54 = (int *)*puVar19;
                local_50 = (float)puVar17[6];
                uStack_4c = puVar17[7];
                uStack_48 = puVar17[8];
                local_44 = puVar17[9];
                puVar17 = puVar19;
                iVar21 = iVar16;
                do {
                  iVar20 = (int)puVar17 - (int)__ptr_00;
                  if ((float)puVar17[-4] <= fVar33) {
                    if (iVar16 == iVar21) goto LAB_0001b840;
                    goto LAB_0001b824;
                  }
                  iVar21 = iVar21 + -1;
                  *puVar17 = puVar17[-5];
                  puVar17[1] = puVar17[-4];
                  puVar17[2] = puVar17[-3];
                  puVar17[3] = puVar17[-2];
                  puVar17[4] = puVar17[-1];
                  puVar17 = puVar17 + -5;
                } while (iVar21 != 0);
                iVar20 = 0;
LAB_0001b824:
                puVar17 = (undefined4 *)((int)__ptr_00 + iVar20);
                *puVar17 = local_54;
                puVar17[1] = fVar33;
                puVar17[2] = uStack_4c;
                puVar17[3] = uStack_48;
                puVar17[4] = local_44;
                local_50 = fVar33;
LAB_0001b840:
                iVar16 = iVar16 + 1;
                puVar17 = puVar19;
              } while (iVar16 != iVar6);
            }
            stbtt__rasterize_sorted_edges_isra_16(param_6,__ptr_00,iVar6,param_9,param_10);
            free(__ptr_00);
          }
          free(__ptr);
          __ptr = piVar18;
LAB_0001b880:
          free(__ptr);
          return;
        }
        piVar18 = malloc((int)local_54 << 3);
        if (piVar18 == (int *)0x0) goto LAB_0001b880;
      } while( true );
    }
  }
  return;
}
