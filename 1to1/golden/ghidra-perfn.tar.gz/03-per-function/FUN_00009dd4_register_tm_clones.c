/* ============================================================
 * register_tm_clones   @ 0x00009dd4   size=56B   callers=1
 * module: 99_crt_glibc
 * ============================================================ */

/* WARNING: Removing unreachable block (ram,0x00009df8) */
/* WARNING: Removing unreachable block (ram,0x00009e04) */
/* WARNING: Removing unreachable block (ram,0x00009e08) */

void register_tm_clones(void)

{
  return;
}
