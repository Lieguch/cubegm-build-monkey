/* ============================================================
 * stbtt_GetFontVMetrics   @ 0x0001ae3c   size=140B   callers=3
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_GetFontVMetrics(int param_1,int *param_2,int *param_3,int *param_4)

{
  int iVar1;
  
  if (param_2 != (int *)0x0) {
    iVar1 = *(int *)(param_1 + 0x1c) + 4;
    *param_2 = (int)(short)((ushort)*(byte *)(*(int *)(param_1 + 4) + iVar1 + 1) +
                           (ushort)*(byte *)(*(int *)(param_1 + 4) + iVar1) * 0x100);
  }
  if (param_3 != (int *)0x0) {
    iVar1 = *(int *)(param_1 + 0x1c) + 6;
    *param_3 = (int)(short)((ushort)*(byte *)(*(int *)(param_1 + 4) + iVar1 + 1) +
                           (ushort)*(byte *)(*(int *)(param_1 + 4) + iVar1) * 0x100);
  }
  if (param_4 == (int *)0x0) {
    return;
  }
  iVar1 = *(int *)(param_1 + 0x1c) + 8;
  *param_4 = (int)(short)((ushort)*(byte *)(*(int *)(param_1 + 4) + iVar1 + 1) +
                         (ushort)*(byte *)(*(int *)(param_1 + 4) + iVar1) * 0x100);
  return;
}
