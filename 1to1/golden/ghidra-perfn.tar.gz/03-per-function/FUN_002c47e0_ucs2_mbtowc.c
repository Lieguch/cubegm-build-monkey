/* ============================================================
 * ucs2_mbtowc   @ 0x002c47e0   size=222B   callers=0
 * module: 08_iconv_encoding
 * ============================================================ */

uint ucs2_mbtowc(int param_1,uint *param_2,byte *param_3,uint param_4)

{
  uint uVar1;
  uint local_28;
  byte *local_24;
  int local_10;
  uint local_c;
  
  local_c = *(uint *)(param_1 + 0x14);
  local_28 = param_4;
  local_24 = param_3;
  for (local_10 = 0; ((1 < local_28 && (local_10 < 0x3fffffff)) && (local_10 < 0x7ffffffe));
      local_10 = local_10 + 2) {
    if (local_c == 0) {
      uVar1 = (uint)*local_24 * 0x100 + (uint)local_24[1];
    }
    else {
      uVar1 = (uint)local_24[1] * 0x100 + (uint)*local_24;
    }
    if (uVar1 != 0xfeff) {
      if (uVar1 != 0xfffe) {
        if ((0xd7ff < uVar1) && (uVar1 < 0xe000)) {
          *(uint *)(param_1 + 0x14) = local_c;
          return ~(local_10 << 1);
        }
        *param_2 = uVar1;
        *(uint *)(param_1 + 0x14) = local_c;
        return local_10 + 2;
      }
      local_c = local_c ^ 1;
    }
    local_24 = local_24 + 2;
    local_28 = local_28 - 2;
  }
  *(uint *)(param_1 + 0x14) = local_c;
  return local_10 * -2 - 2;
}
