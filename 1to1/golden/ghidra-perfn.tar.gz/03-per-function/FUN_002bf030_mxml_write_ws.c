/* ============================================================
 * mxml_write_ws   @ 0x002bf030   size=164B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

int mxml_write_ws(undefined4 param_1,undefined4 param_2,code *param_3,undefined4 param_4,int param_5
                 ,code *param_6)

{
  char cVar1;
  char *pcVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  
  if ((param_3 == (code *)0x0) ||
     (pcVar2 = (char *)(*param_3)(param_1,param_4), pcVar2 == (char *)0x0)) {
    return param_5;
  }
  cVar1 = *pcVar2;
joined_r0x002bf060:
  if (cVar1 == '\0') {
    return param_5;
  }
  do {
    iVar3 = (*param_6)(cVar1,param_2);
    if (iVar3 < 0) {
      return -1;
    }
    if (*pcVar2 == '\n') {
      param_5 = 0;
    }
    else {
      if (*pcVar2 == '\t') break;
      param_5 = param_5 + 1;
    }
    pcVar2 = pcVar2 + 1;
    cVar1 = *pcVar2;
    if (cVar1 == '\0') {
      return param_5;
    }
  } while( true );
  uVar5 = param_5 + 8;
  uVar4 = uVar5 & 7;
  if (-1 < (int)-uVar5) {
    uVar4 = -(-uVar5 & 7);
  }
  param_5 = uVar5 - uVar4;
  pcVar2 = pcVar2 + 1;
  cVar1 = *pcVar2;
  goto joined_r0x002bf060;
}
