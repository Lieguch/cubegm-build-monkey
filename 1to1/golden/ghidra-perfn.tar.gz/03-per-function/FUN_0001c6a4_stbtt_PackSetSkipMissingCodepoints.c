/* ============================================================
 * stbtt_PackSetSkipMissingCodepoints   @ 0x0001c6a4   size=8B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_PackSetSkipMissingCodepoints(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x18) = param_2;
  return;
}
