/* ============================================================
 * unzeof   @ 0x00011f18   size=44B   callers=0
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzeof(unz_s*) */

uint unzeof(unz_s *param_1)

{
  if ((param_1 != (unz_s *)0x0) && (*(int *)(param_1 + 0x7c) != 0)) {
    return (uint)(*(int *)(*(int *)(param_1 + 0x7c) + 0x5c) == 0);
  }
  return 0xffffff9a;
}
