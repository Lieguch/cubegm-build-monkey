/* ============================================================
 * _mxml_entity_cb   @ 0x002bef64   size=160B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 _mxml_entity_cb(char *param_1)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  
  uVar4 = 0x100;
  uVar1 = 0;
  while (uVar5 = uVar1, uVar1 = (uVar4 + uVar5) / 2, 1 < (int)(uVar4 - uVar5)) {
    iVar2 = strcmp(param_1,*(char **)(&entities_6989 + uVar1 * 8));
    if (iVar2 == 0) {
      return *(undefined4 *)(&UNK_003ae6bc + uVar1 * 8);
    }
    if (iVar2 < 0) {
      uVar4 = uVar1;
      uVar1 = uVar5;
    }
  }
  iVar2 = strcmp(param_1,*(char **)(&entities_6989 + uVar5 * 8));
  if (iVar2 != 0) {
    iVar2 = strcmp(param_1,*(char **)(&entities_6989 + uVar4 * 8));
    if (iVar2 == 0) {
      uVar3 = *(undefined4 *)(&UNK_003ae6bc + uVar4 * 8);
    }
    else {
      uVar3 = 0xffffffff;
    }
    return uVar3;
  }
  return *(undefined4 *)(&UNK_003ae6bc + uVar5 * 8);
}
