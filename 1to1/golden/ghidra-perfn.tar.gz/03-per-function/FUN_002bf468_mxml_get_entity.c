/* ============================================================
 * mxml_get_entity   @ 0x002bf468   size=448B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

uint mxml_get_entity(int param_1,undefined4 param_2,undefined4 param_3,code *param_4)

{
  ushort **ppuVar1;
  int iVar2;
  uint uVar3;
  undefined *puVar4;
  char *pcVar5;
  char local_68 [68];
  
  pcVar5 = local_68;
  do {
    iVar2 = (*param_4)(param_2,param_3);
    if (0x7e < iVar2 || iVar2 == -1) {
      *pcVar5 = '\0';
LAB_002bf4f4:
      if (param_1 == 0) {
        puVar4 = &DAT_002de820;
      }
      else {
        puVar4 = *(undefined **)(param_1 + 0x18);
      }
      mxml_error("Character entity \"%s\" not terminated under parent <%s>!",local_68,puVar4);
      return 0xffffffff;
    }
    ppuVar1 = __ctype_b_loc();
    if (((uint)(iVar2 != 0x23) & ((*ppuVar1)[iVar2] ^ 8) >> 3) != 0) {
LAB_002bf534:
      *pcVar5 = '\0';
      if (iVar2 == 0x3b) {
        if (local_68[0] == '#') {
          if (local_68[1] == 'x') {
            pcVar5 = local_68 + 2;
            iVar2 = 0x10;
          }
          else {
            pcVar5 = local_68 + 1;
            iVar2 = 10;
          }
          uVar3 = strtol(pcVar5,(char **)0x0,iVar2);
        }
        else {
          uVar3 = mxmlEntityGetValue(local_68);
          if ((int)uVar3 < 0) {
            if (param_1 == 0) {
              puVar4 = &DAT_002de820;
            }
            else {
              puVar4 = *(undefined **)(param_1 + 0x18);
            }
            mxml_error("Entity name \"%s;\" not supported under parent <%s>!",local_68,puVar4);
            goto LAB_002bf58c;
          }
        }
        if (uVar3 == 10 || 0x1f < (int)uVar3) {
          return uVar3;
        }
LAB_002bf58c:
        if ((uVar3 & 0xfffffffb) == 9) {
          return uVar3;
        }
        if (param_1 == 0) {
          puVar4 = &DAT_002de820;
        }
        else {
          puVar4 = *(undefined **)(param_1 + 0x18);
        }
        mxml_error("Bad control character 0x%02x under parent <%s> not allowed by XML standard!",
                   uVar3,puVar4);
        return 0xffffffff;
      }
      goto LAB_002bf4f4;
    }
    if (pcVar5 == local_68 + 0x3f) {
      if (param_1 == 0) {
        puVar4 = &DAT_002de820;
      }
      else {
        puVar4 = *(undefined **)(param_1 + 0x18);
      }
      mxml_error("Entity name too long under parent <%s>!",puVar4);
      pcVar5 = local_68 + 0x3f;
      goto LAB_002bf534;
    }
    *pcVar5 = (char)iVar2;
    pcVar5 = pcVar5 + 1;
  } while( true );
}
