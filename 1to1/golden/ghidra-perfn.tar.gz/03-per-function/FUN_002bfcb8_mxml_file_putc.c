/* ============================================================
 * mxml_file_putc   @ 0x002bfcb8   size=28B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

int mxml_file_putc(int param_1,_IO_FILE *param_2)

{
  int iVar1;
  
  iVar1 = _IO_putc(param_1,param_2);
  return -(uint)(iVar1 == -1);
}
