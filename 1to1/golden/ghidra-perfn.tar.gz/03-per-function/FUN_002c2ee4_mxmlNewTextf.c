/* ============================================================
 * mxmlNewTextf   @ 0x002c2ee4   size=96B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

int mxmlNewTextf(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  
  if (param_3 == 0) {
    iVar1 = 0;
  }
  else {
    iVar1 = mxml_new(param_1,4);
    if (iVar1 != 0) {
      *(undefined4 *)(iVar1 + 0x18) = param_2;
      uVar2 = _mxml_vstrdupf(param_3);
      *(undefined4 *)(iVar1 + 0x1c) = uVar2;
    }
  }
  return iVar1;
}
