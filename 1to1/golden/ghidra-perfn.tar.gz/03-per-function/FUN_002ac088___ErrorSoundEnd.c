/* ============================================================
 * __ErrorSoundEnd   @ 0x002ac088   size=8B   callers=0
 * module: 99_crt_glibc
 * ============================================================ */

/* WARNING: Control flow encountered bad instruction data */

void __ErrorSoundEnd(void)

{
  int unaff_r4;
  undefined4 *unaff_r10;
  undefined4 in_r12;
  bool in_ZR;
  
  if (in_ZR) {
    *unaff_r10 = in_r12;
    *(undefined4 *)((int)unaff_r10 - unaff_r4) = in_r12;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}
