/* ============================================================
 * mxmlSetOpaque   @ 0x002c3740   size=128B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlSetOpaque(int *param_1,int param_2)

{
  int iVar1;
  
  if ((param_1 != (int *)0x0) &&
     (((iVar1 = *param_1, iVar1 != 0 ||
       ((param_1 = (int *)param_1[4], param_1 != (int *)0x0 && (iVar1 = *param_1, iVar1 == 2)))) &&
      (iVar1 == 2 && param_2 != 0)))) {
    if ((void *)param_1[6] != (void *)0x0) {
      free((void *)param_1[6]);
    }
    iVar1 = __strdup(param_2);
    param_1[6] = iVar1;
    return 0;
  }
  return 0xffffffff;
}
