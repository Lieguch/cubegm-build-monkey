/* ============================================================
 * unzGetLocalExtrafield   @ 0x00011f44   size=164B   callers=0
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzGetLocalExtrafield(unz_s*, void*, unsigned int) */

uint unzGetLocalExtrafield(unz_s *param_1,void *param_2,uint param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  
  if (param_1 == (unz_s *)0x0) {
    return 0xffffff9a;
  }
  iVar4 = *(int *)(param_1 + 0x7c);
  if (iVar4 == 0) {
    return 0xffffff9a;
  }
  uVar3 = *(int *)(iVar4 + 0x48) - *(int *)(iVar4 + 0x4c);
  if (param_2 == (void *)0x0) {
    return uVar3;
  }
  uVar2 = uVar3;
  if (param_3 <= uVar3) {
    uVar2 = param_3;
  }
  if ((uVar2 != 0) &&
     ((iVar1 = lufseek(*(LUFILE **)(iVar4 + 0x60),*(int *)(iVar4 + 0x4c) + *(int *)(iVar4 + 0x44),0)
      , iVar1 != 0 || (iVar4 = lufread(param_2,uVar3,1,*(LUFILE **)(iVar4 + 0x60)), iVar4 != 1)))) {
    return 0xffffffff;
  }
  return uVar2;
}
