/* ============================================================
 * stbtt__handle_clipped_edge.part.9   @ 0x00016368   size=264B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt__handle_clipped_edge_part_9
               (float param_1,float param_2,float param_3,float param_4,int param_5,int param_6,
               int param_7)

{
  uint uVar1;
  byte bVar2;
  float *pfVar3;
  uint in_fpscr;
  uint uVar4;
  float fVar5;
  float fVar6;
  
  fVar6 = *(float *)(param_7 + 0x18);
  uVar1 = in_fpscr & 0xfffffff;
  if (fVar6 < param_2) {
    return;
  }
  fVar5 = *(float *)(param_7 + 0x14);
  if (param_4 < fVar5) {
    return;
  }
  if (param_2 < fVar5) {
    param_1 = param_1 + ((param_3 - param_1) * (fVar5 - param_2)) / (param_4 - param_2);
    param_2 = fVar5;
  }
  uVar4 = uVar1 | (uint)(fVar6 < param_4) << 0x1f;
  if (SUB41(uVar4 >> 0x1f,0)) {
    param_3 = param_3 + ((param_3 - param_1) * (fVar6 - param_4)) / (param_4 - param_2);
    param_4 = fVar6;
  }
  fVar6 = (float)VectorSignedToFloat(param_6,(byte)(uVar4 >> 0x16) & 3);
  uVar4 = uVar1 | (uint)(param_1 == fVar6) << 0x1e | (uint)(fVar6 <= param_1) << 0x1d;
  bVar2 = (byte)(uVar4 >> 0x18);
  if ((!(bool)(bVar2 >> 5 & 1) || (bool)(bVar2 >> 6)) &&
     (uVar4 = uVar1 | (uint)(fVar6 < param_3) << 0x1f,
     SUB41(uVar4 >> 0x1f,0) == (NAN(fVar6) || NAN(param_3)))) {
    pfVar3 = (float *)(param_5 + param_6 * 4);
    *pfVar3 = *pfVar3 + (param_4 - param_2) * *(float *)(param_7 + 0x10);
    return;
  }
  fVar5 = (float)VectorSignedToFloat(param_6 + 1,(byte)(uVar4 >> 0x16) & 3);
  if ((fVar5 <= param_1) && (fVar5 <= param_3)) {
    return;
  }
  pfVar3 = (float *)(param_5 + param_6 * 4);
  *pfVar3 = *pfVar3 + (1.0 - ((param_1 - fVar6) + (param_3 - fVar6)) * 0.5) *
                      (param_4 - param_2) * *(float *)(param_7 + 0x10);
  return;
}
