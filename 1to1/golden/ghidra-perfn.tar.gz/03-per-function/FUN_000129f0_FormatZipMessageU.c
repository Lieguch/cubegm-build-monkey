/* ============================================================
 * FormatZipMessageU   @ 0x000129f0   size=640B   callers=0
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* FormatZipMessageU(unsigned int, char*, unsigned int) */

size_t FormatZipMessageU(uint param_1,char *param_2,uint param_3)

{
  char *__src;
  size_t __n;
  size_t sVar1;
  
  if (param_1 == 1) {
    param_1 = (uint)lasterrorU;
  }
  if ((undefined *)param_1 == (undefined *)0x20000) {
    sVar1 = 0x2f;
    __src = "Caller: can only get memory of a memory zipfile";
    goto LAB_00012b58;
  }
  if (param_1 < (undefined *)0x20001) {
    if ((undefined *)param_1 == (undefined *)0x400) {
      sVar1 = 0x15;
      __src = "Error writing to file";
      goto LAB_00012b58;
    }
    if (param_1 < (undefined *)0x401) {
      if ((undefined *)param_1 == (undefined *)0x100) {
        sVar1 = 0x18;
        __src = "Culdn\'t duplicate handle";
        goto LAB_00012b58;
      }
      if (param_1 < (undefined *)0x101) {
        if ((undefined *)param_1 == (undefined *)0x0) {
          sVar1 = 7;
          __src = "Success";
          goto LAB_00012b58;
        }
      }
      else {
        if ((undefined *)param_1 == (undefined *)0x200) {
          sVar1 = 0x19;
          __src = "Couldn\'t create/open file";
          goto LAB_00012b58;
        }
        if ((undefined *)param_1 == (undefined *)0x300) {
          sVar1 = 0x19;
          __src = "Failed to allocate memory";
          goto LAB_00012b58;
        }
      }
    }
    else {
      if ((undefined *)param_1 == (undefined *)0x700) {
        sVar1 = 0x23;
        __src = "Zipfile is corrupt or not a zipfile";
        goto LAB_00012b58;
      }
      if (param_1 < (undefined *)0x701) {
        if ((undefined *)param_1 == (undefined *)0x500) {
          sVar1 = 0x1d;
          __src = "File not found in the zipfile";
          goto LAB_00012b58;
        }
        if ((undefined *)param_1 == (undefined *)0x600) {
          sVar1 = 0x18;
          __src = "Still more data to unzip";
          goto LAB_00012b58;
        }
      }
      else {
        if ((undefined *)param_1 == (undefined *)0x800) {
          sVar1 = 0x12;
          __src = "Error reading file";
          goto LAB_00012b58;
        }
        if ((undefined *)param_1 == (undefined *)0x10000) {
          sVar1 = 0x18;
          __src = "Caller: faulty arguments";
          goto LAB_00012b58;
        }
      }
    }
  }
  else {
    if ((undefined *)param_1 == (undefined *)0x70000) {
      sVar1 = 0x34;
      __src = "Caller: the file had already been partially unzipped";
      goto LAB_00012b58;
    }
    if (param_1 < &DAT_00070001) {
      if ((undefined *)param_1 == (undefined *)0x40000) {
        sVar1 = 0x22;
        __src = "Caller: there was a previous error";
        goto LAB_00012b58;
      }
      if (param_1 < &DAT_00040001) {
        if ((undefined *)param_1 == (undefined *)0x30000) {
          sVar1 = 0x35;
          __src = "Caller: not enough space allocated for memory zipfile";
          goto LAB_00012b58;
        }
      }
      else {
        if ((undefined *)param_1 == &DAT_00050000) {
          sVar1 = 0x34;
          __src = "Caller: additions to the zip have already been ended";
          goto LAB_00012b58;
        }
        if ((undefined *)param_1 == (undefined *)0x60000) {
          sVar1 = 0x2e;
          __src = "Zip-bug: the anticipated size turned out wrong";
          goto LAB_00012b58;
        }
      }
    }
    else {
      if ((undefined *)param_1 == (undefined *)0x2000000) {
        sVar1 = 0x26;
        __src = "Zip-bug: trying to seek the unseekable";
        goto LAB_00012b58;
      }
      if (param_1 < (undefined *)0x2000001) {
        if ((undefined *)param_1 == (undefined *)0x80000) {
          sVar1 = 0x2a;
          __src = "Caller: mixing creation and opening of zip";
          goto LAB_00012b58;
        }
        if ((undefined *)param_1 == (undefined *)0x1000000) {
          sVar1 = 0x2e;
          __src = "Zip-bug: internal initialisation not completed";
          goto LAB_00012b58;
        }
      }
      else {
        if ((undefined *)param_1 == (undefined *)0x4000000) {
          sVar1 = 0x2e;
          __src = "Zip-bug: tried to change mind, but not allowed";
          goto LAB_00012b58;
        }
        if ((undefined *)param_1 == (undefined *)0x5000000) {
          sVar1 = 0x29;
          __src = "Zip-bug: an internal error during flation";
          goto LAB_00012b58;
        }
      }
    }
  }
  sVar1 = 0x17;
  __src = "unknown zip result code";
LAB_00012b58:
  if (param_3 != 0 && param_2 != (char *)0x0) {
    __n = sVar1;
    if (param_3 < sVar1 + 1) {
      __n = param_3 - 1;
    }
    strncpy(param_2,__src,__n);
    param_2[__n] = '\0';
  }
  return sVar1;
}
