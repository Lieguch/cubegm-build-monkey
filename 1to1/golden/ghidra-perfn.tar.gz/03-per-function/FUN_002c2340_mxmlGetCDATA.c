/* ============================================================
 * mxmlGetCDATA   @ 0x002c2340   size=72B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

char * mxmlGetCDATA(int *param_1)

{
  int iVar1;
  char *__s1;
  
  if (param_1 == (int *)0x0) {
    return (char *)0x0;
  }
  if (*param_1 == 0) {
    __s1 = (char *)param_1[6];
    iVar1 = strncmp(__s1,"![CDATA[",8);
    if (iVar1 == 0) {
      return __s1 + 8;
    }
  }
  return (char *)0x0;
}
