/* ============================================================
 * IsZipHandleU   @ 0x00013150   size=28B   callers=0
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* IsZipHandleU(HZIP__*) */

bool IsZipHandleU(HZIP__ *param_1)

{
  bool bVar1;
  
  if (param_1 == (HZIP__ *)0x0) {
    bVar1 = true;
  }
  else {
    bVar1 = *(int *)param_1 == 1;
  }
  return bVar1;
}
