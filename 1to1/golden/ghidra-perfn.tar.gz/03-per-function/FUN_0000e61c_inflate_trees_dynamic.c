/* ============================================================
 * inflate_trees_dynamic   @ 0x0000e61c   size=428B   callers=1
 * module: 07_zlib
 * ============================================================ */

/* inflate_trees_dynamic(unsigned int, unsigned int, unsigned int*, unsigned int*, unsigned int*,
   inflate_huft_s**, inflate_huft_s**, inflate_huft_s*, z_stream_s*) */

int inflate_trees_dynamic
              (uint param_1,uint param_2,uint *param_3,uint *param_4,uint *param_5,
              inflate_huft_s **param_6,inflate_huft_s **param_7,inflate_huft_s *param_8,
              z_stream_s *param_9)

{
  uint *puVar1;
  int iVar2;
  uint local_2c [2];
  
  local_2c[0] = 0;
  puVar1 = (uint *)(**(code **)(param_9 + 0x20))(*(undefined4 *)(param_9 + 0x28),0x120,4);
  if (puVar1 == (uint *)0x0) {
    return -4;
  }
  iVar2 = huft_build(param_3,param_1,0x101,(uint *)&cplens,(uint *)cplext,param_6,param_4,param_8,
                     local_2c,puVar1);
  if (iVar2 == 0) {
    if (*param_4 != 0) {
      iVar2 = huft_build(param_3 + param_1,param_2,0,(uint *)cpdist,(uint *)cpdext,param_7,param_5,
                         param_8,local_2c,puVar1);
      if (iVar2 == 0) {
        if (param_1 < 0x102 || *param_5 != 0) goto LAB_0000e6bc;
      }
      else {
        if (iVar2 == -3) {
          *(char **)(param_9 + 0x18) = "oversubscribed distance tree";
          goto LAB_0000e6bc;
        }
        if (iVar2 == -5) {
          iVar2 = -3;
          *(char **)(param_9 + 0x18) = "incomplete distance tree";
          goto LAB_0000e6bc;
        }
        if (iVar2 == -4) goto LAB_0000e6bc;
      }
      iVar2 = -3;
      *(char **)(param_9 + 0x18) = "empty distance tree with lengths";
      goto LAB_0000e6bc;
    }
  }
  else {
    if (iVar2 == -3) {
      *(char **)(param_9 + 0x18) = "oversubscribed literal/length tree";
      goto LAB_0000e6bc;
    }
    if (iVar2 == -4) goto LAB_0000e6bc;
  }
  iVar2 = -3;
  *(char **)(param_9 + 0x18) = "incomplete literal/length tree";
LAB_0000e6bc:
  (**(code **)(param_9 + 0x24))(*(undefined4 *)(param_9 + 0x28),puVar1);
  return iVar2;
}
