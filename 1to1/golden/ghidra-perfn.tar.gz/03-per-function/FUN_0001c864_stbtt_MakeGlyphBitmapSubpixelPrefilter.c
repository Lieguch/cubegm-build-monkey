/* ============================================================
 * stbtt_MakeGlyphBitmapSubpixelPrefilter   @ 0x0001c864   size=224B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_MakeGlyphBitmapSubpixelPrefilter
               (undefined4 param_1,undefined4 param_2,int param_3,int param_4,undefined4 param_5,
               int param_6,int param_7,float *param_8,float *param_9,undefined4 param_10)

{
  uint in_fpscr;
  float fVar1;
  float extraout_s14;
  float extraout_s14_00;
  float extraout_s14_01;
  float extraout_s15;
  float extraout_s15_00;
  float extraout_s15_01;
  float fVar2;
  float fVar3;
  
  stbtt_MakeGlyphBitmapSubpixel
            (param_1,param_2,param_3 - (param_6 + -1),param_4 - (param_7 + -1),param_5,param_10);
  fVar2 = extraout_s14;
  fVar3 = extraout_s15;
  if (1 < param_6) {
    stbtt__h_prefilter(param_2,param_3,param_4,param_5,param_6);
    fVar2 = extraout_s14_00;
    fVar3 = extraout_s15_00;
  }
  if (1 < param_7) {
    stbtt__v_prefilter(param_2,param_3,param_4,param_5,param_7);
    fVar2 = extraout_s14_01;
    fVar3 = extraout_s15_01;
  }
  if (param_6 == 0) {
    fVar1 = 0.0;
  }
  else {
    fVar2 = (float)VectorSignedToFloat(param_6,(byte)(in_fpscr >> 0x16) & 3);
    fVar2 = fVar2 + fVar2;
    fVar3 = (float)VectorSignedToFloat(1 - param_6,(byte)(in_fpscr >> 0x16) & 3);
    fVar1 = fVar3 / fVar2;
  }
  if (param_7 != 0) {
    fVar3 = (float)VectorSignedToFloat(param_7,(byte)(in_fpscr >> 0x16) & 3);
    fVar3 = fVar3 + fVar3;
    fVar2 = (float)VectorSignedToFloat(1 - param_7,(byte)(in_fpscr >> 0x16) & 3);
  }
  *param_8 = fVar1;
  if (param_7 != 0) {
    fVar2 = fVar2 / fVar3;
  }
  else {
    fVar2 = 0.0;
  }
  *param_9 = fVar2;
  return;
}
