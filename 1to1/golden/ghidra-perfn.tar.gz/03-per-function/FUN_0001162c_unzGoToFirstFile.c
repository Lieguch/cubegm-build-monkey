/* ============================================================
 * unzGoToFirstFile   @ 0x0001162c   size=96B   callers=4
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzGoToFirstFile(unz_s*) */

int unzGoToFirstFile(unz_s *param_1)

{
  int iVar1;
  
  if (param_1 == (unz_s *)0x0) {
    iVar1 = -0x66;
  }
  else {
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = *(undefined4 *)(param_1 + 0x24);
    iVar1 = unzlocal_GetCurrentFileInfoInternal
                      (param_1,(unz_file_info_s *)(param_1 + 0x28),
                       (unz_file_info_internal_s *)(param_1 + 0x78),(char *)0x0,0,(void *)0x0,0,
                       (char *)0x0,0);
    *(uint *)(param_1 + 0x18) = (uint)(iVar1 == 0);
  }
  return iVar1;
}
