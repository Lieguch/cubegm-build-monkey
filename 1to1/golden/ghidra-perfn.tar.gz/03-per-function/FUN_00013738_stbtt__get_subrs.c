/* ============================================================
 * stbtt__get_subrs   @ 0x00013738   size=284B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

undefined4 * stbtt__get_subrs(undefined4 *param_1,int param_2,undefined4 param_3,int param_4)

{
  int local_34;
  int local_30;
  int local_2c;
  int local_28;
  uint local_24;
  uint local_20;
  uint local_1c [3];
  
  local_28 = 0;
  local_24 = 0;
  local_20 = 0;
  local_34 = param_2;
  local_30 = param_3;
  local_2c = param_4;
  stbtt__dict_get_ints(&stack0x00000000,0x12,2,&local_24);
  if ((local_20 != 0) && (local_24 != 0)) {
    if ((int)(local_24 | local_20) < 0) {
      local_1c[0] = 0;
      local_1c[2] = local_1c[0];
    }
    else if ((local_2c < (int)local_20) || ((int)(local_2c - local_20) < (int)local_24)) {
      local_1c[0] = 0;
      local_1c[2] = 0;
    }
    else {
      local_1c[0] = local_34 + local_20;
      local_1c[2] = local_24;
    }
    local_1c[1] = 0;
    stbtt__dict_get_ints(local_1c,0x13,1,&local_28);
    if (local_28 != 0) {
      local_30 = local_28 + local_20;
      if (local_2c < local_30 || local_30 < 0) {
        local_30 = local_2c;
      }
      stbtt__cff_get_index(param_1,&local_34);
      return param_1;
    }
  }
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  return param_1;
}
