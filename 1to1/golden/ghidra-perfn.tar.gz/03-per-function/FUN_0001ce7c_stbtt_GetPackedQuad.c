/* ============================================================
 * stbtt_GetPackedQuad   @ 0x0001ce7c   size=348B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_GetPackedQuad(int param_1,undefined4 param_2,undefined4 param_3,int param_4,
                        float *param_5,float *param_6,float *param_7,int param_8)

{
  int iVar1;
  uint in_fpscr;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  
  iVar1 = param_1 + param_4 * 0x1c;
  fVar3 = (float)VectorSignedToFloat(param_2,(byte)(in_fpscr >> 0x16) & 3);
  fVar4 = (float)VectorSignedToFloat(param_3,(byte)(in_fpscr >> 0x16) & 3);
  if (param_8 == 0) {
    fVar5 = *(float *)(iVar1 + 0xc);
    fVar2 = *(float *)(iVar1 + 0x18);
    fVar7 = *(float *)(iVar1 + 0x14);
    *param_7 = *param_5 + *(float *)(iVar1 + 8);
    param_7[1] = *param_6 + fVar5;
    param_7[4] = *param_5 + fVar7;
    param_7[5] = *param_6 + fVar2;
  }
  else {
    fVar9 = *(float *)(iVar1 + 8);
    fVar2 = floorf(fVar9 + *param_5 + 0.5);
    fVar8 = *(float *)(iVar1 + 0xc);
    fVar5 = floorf(fVar8 + *param_6 + 0.5);
    fVar7 = *(float *)(iVar1 + 0x14);
    fVar6 = *(float *)(iVar1 + 0x18);
    fVar2 = (float)VectorSignedToFloat((int)fVar2,(byte)(in_fpscr >> 0x16) & 3);
    *param_7 = fVar2;
    param_7[4] = (fVar2 + fVar7) - fVar9;
    fVar2 = (float)VectorSignedToFloat((int)fVar5,(byte)(in_fpscr >> 0x16) & 3);
    param_7[1] = fVar2;
    param_7[5] = (fVar2 + fVar6) - fVar8;
  }
  fVar2 = *(float *)(iVar1 + 0x10);
  fVar5 = (float)VectorSignedToFloat((uint)*(ushort *)(param_1 + param_4 * 0x1c),
                                     (byte)(in_fpscr >> 0x16) & 3);
  fVar7 = (float)VectorSignedToFloat((uint)*(ushort *)(iVar1 + 2),(byte)(in_fpscr >> 0x16) & 3);
  fVar6 = (float)VectorSignedToFloat((uint)*(ushort *)(iVar1 + 4),(byte)(in_fpscr >> 0x16) & 3);
  fVar8 = (float)VectorSignedToFloat((uint)*(ushort *)(iVar1 + 6),(byte)(in_fpscr >> 0x16) & 3);
  param_7[2] = fVar5 * (1.0 / fVar3);
  param_7[7] = fVar8 * (1.0 / fVar4);
  param_7[3] = fVar7 * (1.0 / fVar4);
  param_7[6] = fVar6 * (1.0 / fVar3);
  *param_5 = *param_5 + fVar2;
  return;
}
