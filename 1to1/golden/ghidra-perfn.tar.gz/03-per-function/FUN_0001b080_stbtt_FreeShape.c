/* ============================================================
 * stbtt_FreeShape   @ 0x0001b080   size=8B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_FreeShape(undefined4 param_1,void *param_2)

{
  free(param_2);
  return;
}
