/* ============================================================
 * mxmlSetCustomHandlers   @ 0x002c22f8   size=28B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

void mxmlSetCustomHandlers(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = _mxml_global();
  *(undefined4 *)(iVar1 + 0x19c) = param_1;
  *(undefined4 *)(iVar1 + 0x1a0) = param_2;
  return;
}
