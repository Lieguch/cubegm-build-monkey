/* ============================================================
 * mxmlIndexNew   @ 0x002c29e0   size=444B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 * mxmlIndexNew(int param_1,int param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  char *pcVar5;
  int iVar6;
  void *pvVar7;
  int iVar8;
  
  if (param_1 == 0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1 = calloc(1,0x14);
    if (puVar1 == (undefined4 *)0x0) {
      piVar4 = __errno_location();
      pcVar5 = strerror(*piVar4);
      mxml_error("Unable to allocate %d bytes for index - %s",0x14,pcVar5);
    }
    else {
      if (param_3 == 0) {
        iVar3 = param_1;
        if (param_2 == 0) goto LAB_002c2aac;
      }
      else {
        uVar2 = __strdup(param_3);
        *puVar1 = uVar2;
      }
      for (iVar3 = mxmlFindElement(param_1,param_1,param_2,param_3,0,1); iVar3 != 0;
          iVar3 = mxmlFindElement(iVar3,param_1,param_2,param_3,0,1)) {
LAB_002c2aac:
        iVar8 = puVar1[1];
        iVar6 = puVar1[2];
        if (iVar8 < iVar6) {
          pvVar7 = (void *)puVar1[4];
        }
        else {
          if (iVar6 == 0) {
            pvVar7 = malloc(0x100);
            iVar6 = 0;
          }
          else {
            pvVar7 = realloc((void *)puVar1[4],(iVar6 + 0x40) * 4);
            iVar6 = puVar1[2];
          }
          if (pvVar7 == (void *)0x0) {
            piVar4 = __errno_location();
            pcVar5 = strerror(*piVar4);
            mxml_error("Unable to allocate %d bytes for index: %s",(iVar6 + 0x40) * 4,pcVar5);
            mxmlIndexDelete(puVar1);
            return (undefined4 *)0x0;
          }
          iVar8 = puVar1[1];
          puVar1[4] = pvVar7;
          puVar1[2] = iVar6 + 0x40;
        }
        puVar1[1] = iVar8 + 1;
        *(int *)((int)pvVar7 + iVar8 * 4) = iVar3;
      }
      if (1 < (int)puVar1[1]) {
        index_sort(puVar1,0,puVar1[1] + -1);
        return puVar1;
      }
    }
  }
  return puVar1;
}
