/* ============================================================
 * mxmlSetUserData   @ 0x002c3930   size=20B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlSetUserData(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  if (param_1 == 0) {
    uVar1 = 0xffffffff;
  }
  else {
    *(undefined4 *)(param_1 + 0x2c) = param_2;
    uVar1 = 0;
  }
  return uVar1;
}
