/* ============================================================
 * _mxml_strdupf   @ 0x002c39c4   size=44B   callers=3
 * module: 04_mini_xml
 * ============================================================ */

void _mxml_strdupf(undefined4 param_1)

{
  _mxml_vstrdupf(param_1);
  return;
}
