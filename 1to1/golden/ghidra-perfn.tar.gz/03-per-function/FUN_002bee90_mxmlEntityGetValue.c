/* ============================================================
 * mxmlEntityGetValue   @ 0x002bee90   size=80B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

int mxmlEntityGetValue(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  
  iVar1 = _mxml_global();
  if (0 < *(int *)(iVar1 + 4)) {
    iVar3 = 0;
    puVar4 = (undefined4 *)(iVar1 + 4);
    do {
      puVar4 = puVar4 + 1;
      iVar2 = (*(code *)*puVar4)(param_1);
      iVar3 = iVar3 + 1;
      if (-1 < iVar2) {
        return iVar2;
      }
    } while (iVar3 < *(int *)(iVar1 + 4));
  }
  return -1;
}
