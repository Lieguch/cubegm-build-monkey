/* ============================================================
 * mxmlIndexReset   @ 0x002c2ba4   size=48B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlIndexReset(int param_1)

{
  if ((param_1 != 0) && (*(undefined4 *)(param_1 + 0xc) = 0, *(int *)(param_1 + 4) != 0)) {
    return **(undefined4 **)(param_1 + 0x10);
  }
  return 0;
}
