/* ============================================================
 * mxml_integer_cb   @ 0x002c3130   size=8B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxml_integer_cb(void)

{
  return 1;
}
