/* ============================================================
 * mxml_load_data   @ 0x002bfce8   size=5260B   callers=6
 * module: 04_mini_xml
 * ============================================================ */

/* WARNING: Type propagation algorithm not settling */

int mxml_load_data(int param_1,undefined4 param_2,code *param_3,code *param_4,code *param_5,
                  undefined4 param_6)

{
  char cVar1;
  char *pcVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined1 *__ptr;
  int iVar7;
  long lVar8;
  uint uVar9;
  undefined *puVar10;
  char *pcVar11;
  uint extraout_r3;
  int unaff_r8;
  bool bVar12;
  bool bVar13;
  int local_88;
  int local_84;
  char *local_4c;
  char *local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined1 *local_3c;
  undefined1 *local_38;
  undefined1 *local_34;
  undefined4 local_30;
  undefined4 local_2c [2];
  
  iVar3 = _mxml_global();
  local_4c = malloc(0x40);
  if (local_4c == (char *)0x0) {
    mxml_error("Unable to allocate string buffer!");
  }
  else {
    local_44 = 0x40;
    if (param_1 == 0 || param_3 == (code *)0x0) {
      unaff_r8 = 4;
    }
    local_40 = 0;
    local_48 = local_4c;
    if (param_1 != 0 && param_3 != (code *)0x0) {
      unaff_r8 = (*param_3)(param_1);
    }
    bVar12 = false;
    local_84 = 0;
    local_88 = param_1;
LAB_002bfd94:
    iVar4 = (*param_4)(param_2,&local_40);
    if (iVar4 == -1) goto LAB_002c06cc;
    if (iVar4 == 0x3c) {
      if (local_4c < local_48) {
LAB_002c0350:
        *local_48 = '\0';
        switch(unaff_r8) {
        case 1:
          lVar8 = strtol(local_4c,&local_48,0);
          iVar5 = mxmlNewInteger(local_88,lVar8);
          break;
        case 2:
          iVar5 = mxmlNewOpaque(local_88,local_4c);
          break;
        case 3:
          strtod(local_4c,&local_48);
          iVar5 = mxmlNewReal(local_88);
          break;
        case 4:
          iVar5 = mxmlNewText(local_88,bVar12,local_4c);
          break;
        case 5:
          iVar5 = 0;
          if (*(int *)(iVar3 + 0x19c) != 0) {
            iVar5 = mxmlNewCustom(local_88,0);
            iVar7 = (**(code **)(iVar3 + 0x19c))(iVar5,local_4c);
            if (iVar7 != 0) {
              if (local_88 == 0) {
                puVar10 = &DAT_002de820;
              }
              else {
                puVar10 = *(undefined **)(local_88 + 0x18);
              }
              mxml_error("Bad custom value \'%s\' in parent <%s>!",local_4c,puVar10);
              mxmlDelete(iVar5);
              iVar5 = 0;
            }
          }
          break;
        default:
          iVar5 = 0;
        }
        if (*local_48 != '\0') {
          if (unaff_r8 == 1) {
            pcVar11 = "integer";
          }
          else {
            pcVar11 = "real";
          }
          if (local_88 == 0) {
            puVar10 = &DAT_002de820;
          }
          else {
            puVar10 = *(undefined **)(local_88 + 0x18);
          }
          mxml_error("Bad %s value \'%s\' in parent <%s>!",pcVar11,local_4c,puVar10);
          goto LAB_002c06cc;
        }
        local_48 = local_4c;
        if (iVar4 == 9 || iVar4 == 0x20) {
LAB_002c013c:
          bVar12 = unaff_r8 == 4;
        }
        else {
          iVar7 = mxml_isspace_part_0(iVar4);
          bVar12 = false;
          if (iVar7 != 0) goto LAB_002c013c;
        }
        if (unaff_r8 != -1 && iVar5 == 0) {
          if (local_88 == 0) {
            puVar10 = &DAT_002de820;
          }
          else {
            puVar10 = *(undefined **)(local_88 + 0x18);
          }
          mxml_error("Unable to add value node of type %s to parent <%s>!",(&types_7806)[unaff_r8],
                     puVar10);
          goto LAB_002c008c;
        }
        if (param_5 != (code *)0x0) {
          (*param_5)(iVar5,2,param_6);
          iVar7 = mxmlRelease(iVar5);
          if (iVar7 == 0) goto LAB_002c01b0;
        }
        if (iVar5 != 0 && local_84 == 0) {
          local_84 = iVar5;
        }
      }
      else {
        iVar5 = mxml_isspace_part_0();
        if (iVar5 != 0) goto LAB_002bfdd8;
      }
LAB_002c01b0:
      if ((bVar12 & iVar4 == 0x3c) == 0) {
LAB_002c0244:
        if (iVar4 != 0x3c) {
LAB_002c024c:
          if (iVar4 != 0x26) goto LAB_002c0254;
LAB_002c02f8:
          iVar4 = mxml_get_entity(local_88,param_2,&local_40,param_4);
          if (iVar4 != -1) goto LAB_002c0280;
          goto LAB_002c008c;
        }
      }
      else {
        if (unaff_r8 == 4) goto LAB_002c01cc;
LAB_002bfdf4:
        bVar12 = true;
      }
LAB_002bfdf8:
      local_48 = local_4c;
LAB_002bfe04:
      do {
        uVar6 = (*param_4)(param_2,&local_40);
        pcVar11 = local_48;
        if ((((uVar6 == 0xffffffff) || (uVar6 == 9 || uVar6 == 0x20)) ||
            (iVar4 = mxml_isspace_part_0(), pcVar11 = local_48, iVar4 != 0)) || (uVar6 == 0x3e))
        break;
        if (uVar6 == 0x2f) {
          if (local_4c < local_48) break;
        }
        else {
          if (uVar6 == 0x3c) {
            mxml_error("Bare < in element!");
            goto LAB_002c008c;
          }
          if (uVar6 == 0x26) {
            iVar4 = mxml_get_entity(local_88,param_2,&local_40,param_4);
            if ((iVar4 == -1) ||
               (iVar4 = mxml_add_char(iVar4,&local_48,&local_4c,&local_44), iVar4 != 0))
            goto LAB_002c008c;
            goto LAB_002bfe04;
          }
        }
        iVar4 = mxml_add_char(uVar6,&local_48,&local_4c,&local_44);
        pcVar11 = local_48;
        if (iVar4 != 0) goto LAB_002c008c;
        iVar4 = (int)local_48 - (int)local_4c;
        if (iVar4 == 1) {
          if (*local_4c == '?') break;
          goto LAB_002bfe04;
        }
        if (iVar4 == 3) {
          iVar4 = strncmp(local_4c,"!--",3);
        }
        else {
          if (iVar4 != 8) goto LAB_002bfe04;
          iVar4 = strncmp(local_4c,"![CDATA[",8);
        }
      } while (iVar4 != 0);
      pcVar2 = local_4c;
      *pcVar11 = '\0';
      cVar1 = *local_4c;
      if (cVar1 != '!') {
        iVar4 = strcmp(local_4c,"![CDATA[");
        if (iVar4 == 0) {
LAB_002c04c8:
          while( true ) {
            iVar4 = (*param_4)(param_2,&local_40);
            pcVar11 = local_48;
            if (iVar4 == -1) {
              mxml_error("Early EOF in CDATA node!");
              goto LAB_002c008c;
            }
            if ((iVar4 == 0x3e) && (iVar5 = strncmp(local_48 + -2,"]]",2), iVar5 == 0)) break;
            iVar4 = mxml_add_char(iVar4,&local_48,&local_4c,&local_44);
            if (iVar4 != 0) goto LAB_002c008c;
          }
          *pcVar11 = '\0';
          if (local_84 == 0 || local_88 != 0) {
            iVar4 = mxmlNewElement(local_88,local_4c);
            if (iVar4 != 0) {
              if (param_5 != (code *)0x0) {
                (*param_5)(iVar4,0,param_6);
                iVar5 = mxmlRelease(iVar4);
                if (iVar5 == 0) goto LAB_002c04a4;
              }
              if (local_84 == 0) {
                local_84 = iVar4;
              }
              goto LAB_002c04a4;
            }
            if (local_88 == 0) {
              puVar10 = &DAT_002de820;
            }
            else {
              puVar10 = *(undefined **)(local_88 + 0x18);
            }
            mxml_error("Unable to add CDATA node to parent <%s>!",puVar10);
          }
          else {
            mxml_error("<%s> cannot be a second root node after <%s>",local_4c,
                       *(undefined4 *)(local_84 + 0x18));
          }
        }
        else if (cVar1 == '?') {
          while( true ) {
            iVar4 = (*param_4)(param_2,&local_40);
            if (iVar4 == -1) {
              mxml_error("Early EOF in processing instruction node!");
              goto LAB_002c008c;
            }
            if (((iVar4 == 0x3e) && (local_4c < local_48)) && (local_48[-1] == '?')) break;
            iVar4 = mxml_add_char(iVar4,&local_48,&local_4c,&local_44);
            if (iVar4 != 0) goto LAB_002c008c;
          }
          *local_48 = '\0';
          if (local_84 == 0 || local_88 != 0) {
            iVar4 = mxmlNewElement(local_88,local_4c);
            if (iVar4 != 0) goto LAB_002c0900;
            if (local_88 == 0) {
              puVar10 = &DAT_002de820;
            }
            else {
              puVar10 = *(undefined **)(local_88 + 0x18);
            }
            mxml_error("Unable to add processing instruction node to parent <%s>!",puVar10);
          }
          else {
            mxml_error("<%s> cannot be a second root node after <%s>",local_4c,
                       *(undefined4 *)(local_84 + 0x18));
          }
        }
        else if (cVar1 == '/') {
          if (local_88 == 0) {
            pcVar11 = "(null)";
          }
          else {
            pcVar11 = *(char **)(local_88 + 0x18);
            iVar4 = strcmp(pcVar2 + 1,pcVar11);
            if (iVar4 == 0) {
              if (uVar6 != 0x3e && uVar6 != 0xffffffff) {
                do {
                  iVar4 = (*param_4)(param_2,&local_40);
                } while (iVar4 != 0x3e && iVar4 != -1);
              }
              iVar4 = *(int *)(local_88 + 0xc);
              if (param_5 != (code *)0x0) {
                (*param_5)(local_88,4,param_6);
                iVar5 = mxmlRelease(local_88);
                if (iVar5 == 0 && local_88 == local_84) {
                  local_84 = 0;
                }
              }
              local_88 = iVar4;
              if (iVar4 != 0 && param_3 != (code *)0x0) {
                unaff_r8 = (*param_3)(iVar4);
              }
              goto LAB_002c04a4;
            }
          }
          mxml_error("Mismatched close tag <%s> under parent <%s>!",pcVar2,pcVar11);
        }
        else if (local_84 == 0 || local_88 != 0) {
          iVar4 = mxmlNewElement(local_88);
          if (iVar4 == 0) {
            if (local_88 == 0) {
              puVar10 = &DAT_002de820;
            }
            else {
              puVar10 = *(undefined **)(local_88 + 0x18);
            }
            mxml_error("Unable to add element node to parent <%s>!",puVar10);
          }
          else if ((uVar6 == 9 || uVar6 == 0x20) || (iVar5 = mxml_isspace_part_0(uVar6), iVar5 != 0)
                  ) {
            __ptr = malloc(0x40);
            local_3c = __ptr;
            if (__ptr == (undefined1 *)0x0) {
              mxml_error("Unable to allocate memory for name!");
            }
            else {
              local_30 = 0x40;
              local_38 = malloc(0x40);
              if (local_38 != (undefined1 *)0x0) {
                local_2c[0] = 0x40;
LAB_002bff80:
                do {
                  uVar6 = (*param_4)(param_2,&local_40);
                  if (uVar6 == 0xffffffff) goto LAB_002c007c;
                } while ((uVar6 == 9 || uVar6 == 0x20) ||
                        (iVar5 = mxml_isspace_part_0(), iVar5 != 0));
                if ((uVar6 & 0xffffffef) == 0x2f) {
                  iVar5 = (*param_4)(param_2,&local_40);
                  if (iVar5 != 0x3e) {
                    mxml_error("Expected \'>\' after \'%c\' for element %s, but got \'%c\'!",uVar6,
                               *(undefined4 *)(iVar4 + 0x18),iVar5);
                    goto LAB_002c007c;
                  }
                  goto LAB_002c0e84;
                }
                if (uVar6 == 0x3c) {
                  mxml_error("Bare < in element %s!",*(undefined4 *)(iVar4 + 0x18));
                  goto LAB_002c007c;
                }
                if (uVar6 != 0x3e) {
                  *local_3c = (char)uVar6;
                  local_34 = local_3c + 1;
                  if (uVar6 == 0x27 || uVar6 == 0x22) {
                    do {
                      uVar9 = (*param_4)(param_2,&local_40);
                      if (uVar9 == 0xffffffff) goto LAB_002c0ebc;
                      if (((uVar9 == 0x26) &&
                          (uVar9 = mxml_get_entity(iVar4,param_2,&local_40,param_4),
                          uVar9 == 0xffffffff)) ||
                         (iVar5 = mxml_add_char(uVar9,&local_34,&local_3c,&local_30), iVar5 != 0))
                      goto LAB_002c007c;
                    } while (uVar6 != uVar9);
                  }
                  else {
                    while( true ) {
                      uVar6 = (*param_4)(param_2,&local_40);
                      if (uVar6 == 0xffffffff) goto LAB_002c0ebc;
                      if (uVar6 == 9 || uVar6 == 0x20) break;
                      iVar5 = mxml_isspace_part_0();
                      if (iVar5 != 0) break;
                      bVar13 = 0x2e < uVar6;
                      if (uVar6 != 0x2f) {
                        bVar13 = 1 < uVar6 - 0x3d;
                      }
                      if (!bVar13 || (uVar6 == 0x2f || uVar6 - 0x3d == 2)) break;
                      if (((uVar6 == 0x26) &&
                          (uVar6 = mxml_get_entity(iVar4,param_2,&local_40,param_4),
                          uVar6 == 0xffffffff)) ||
                         (iVar5 = mxml_add_char(uVar6,&local_34,&local_3c,&local_30), iVar5 != 0))
                      goto LAB_002c007c;
                    }
                  }
                  *local_34 = 0;
                  iVar5 = mxmlElementGetAttr(iVar4,local_3c);
                  if (iVar5 != 0) goto LAB_002c007c;
                  while ((uVar6 == 9 || uVar6 == 0x20 ||
                         (iVar5 = mxml_isspace_part_0(uVar6), iVar5 != 0))) {
                    uVar6 = (*param_4)(param_2,&local_40);
                    if (uVar6 == 0xffffffff) goto LAB_002c0ad0;
                  }
                  if (uVar6 != 0x3d) goto LAB_002c0ad0;
                  do {
                    uVar9 = (*param_4)(param_2,&local_40);
                    if (uVar9 == 0xffffffff) {
                      mxml_error("Missing value for attribute \'%s\' in element %s!",local_3c,
                                 *(undefined4 *)(iVar4 + 0x18));
                      goto LAB_002c007c;
                    }
                  } while ((uVar9 == 9 || uVar9 == 0x20) ||
                          (iVar5 = mxml_isspace_part_0(), iVar5 != 0));
                  if (uVar9 == 0x22 || uVar9 == 0x27) {
                    local_34 = local_38;
                    while (uVar6 = (*param_4)(param_2,&local_40), uVar6 != 0xffffffff) {
                      if (uVar9 == uVar6) {
                        uVar9 = uVar6 & 0xffffffef;
                        goto LAB_002c0e4c;
                      }
                      if (((uVar6 == 0x26) &&
                          (uVar6 = mxml_get_entity(iVar4,param_2,&local_40,param_4),
                          uVar6 == 0xffffffff)) ||
                         (iVar5 = mxml_add_char(uVar6,&local_34,&local_38,local_2c), iVar5 != 0))
                      goto LAB_002c007c;
                    }
                    uVar9 = 0xffffffef;
                  }
                  else {
                    *local_38 = (char)uVar9;
                    local_34 = local_38 + 1;
                    while (uVar6 = (*param_4)(param_2,&local_40), uVar6 != 0xffffffff) {
                      if (((uVar6 == 9 || uVar6 == 0x20) ||
                          (iVar5 = mxml_isspace_part_0(), uVar6 = extraout_r3, iVar5 != 0)) ||
                         (extraout_r3 == 0x2f || extraout_r3 == 0x3d)) {
                        uVar9 = uVar6 & 0xffffffef;
                        goto LAB_002c0e4c;
                      }
                      if (extraout_r3 == 0x3e) {
                        uVar9 = 0x2e;
                        goto LAB_002c0e4c;
                      }
                      if (((extraout_r3 == 0x26) &&
                          (uVar6 = mxml_get_entity(iVar4,param_2,&local_40,param_4),
                          uVar6 == 0xffffffff)) ||
                         (iVar5 = mxml_add_char(uVar6,&local_34,&local_38,local_2c), iVar5 != 0))
                      goto LAB_002c007c;
                    }
                    uVar9 = 0xffffffef;
                  }
LAB_002c0e4c:
                  *local_34 = 0;
                  mxmlElementSetAttr(iVar4,local_3c,local_38);
                  if (uVar9 != 0x2f) goto code_r0x002c0e70;
                  iVar5 = (*param_4)(param_2,&local_40);
                  if (iVar5 != 0x3e) {
                    mxml_error("Expected \'>\' after \'%c\' for element %s, but got \'%c\'!",uVar6,
                               *(undefined4 *)(iVar4 + 0x18),iVar5);
                    goto LAB_002c007c;
                  }
                  free(local_3c);
                  free(local_38);
                  if (uVar6 != 0xffffffff) goto LAB_002c07d8;
                  goto LAB_002c008c;
                }
                goto LAB_002c0e78;
              }
              free(__ptr);
              mxml_error("Unable to allocate memory for value!");
            }
          }
          else {
            if (uVar6 != 0x2f) goto LAB_002c07d8;
            iVar5 = (*param_4)(param_2,&local_40);
            if (iVar5 == 0x3e) {
              if (param_5 == (code *)0x0) {
                if (local_84 == 0) {
                  local_84 = iVar4;
                }
                goto LAB_002c04a4;
              }
              (*param_5)(iVar4,5,param_6);
              iVar5 = iVar4;
              if (local_84 != 0) goto LAB_002c0b20;
              goto LAB_002c0b2c;
            }
            mxml_error("Expected > but got \'%c\' instead for element <%s/>!",iVar5,local_4c);
            mxmlDelete(iVar4);
          }
        }
        else {
          mxml_error("<%s> cannot be a second root node after <%s>",pcVar2,
                     *(undefined4 *)(local_84 + 0x18));
        }
        goto LAB_002c008c;
      }
      if (((local_4c[1] == '-') && (local_4c[2] == '-')) && (local_4c[3] == '\0')) {
        while( true ) {
          iVar4 = (*param_4)(param_2,&local_40);
          if (iVar4 == -1) {
            mxml_error("Early EOF in comment node!",&local_48,&local_4c,&local_44);
            goto LAB_002c008c;
          }
          if (((iVar4 == 0x3e) && (local_4c + 4 < local_48)) &&
             ((local_48[-3] != '-' && ((local_48[-2] == '-' && (local_48[-1] == '-')))))) break;
          iVar4 = mxml_add_char();
          if (iVar4 != 0) goto LAB_002c008c;
        }
        *local_48 = '\0';
        if (local_84 == 0 || local_88 != 0) {
          iVar4 = mxmlNewElement(local_88,local_4c);
          if (iVar4 == 0) {
            if (local_88 == 0) {
              puVar10 = &DAT_002de820;
            }
            else {
              puVar10 = *(undefined **)(local_88 + 0x18);
            }
            mxml_error("Unable to add comment node to parent <%s>!",puVar10);
            goto LAB_002c06cc;
          }
          if (param_5 != (code *)0x0) {
            (*param_5)(iVar4,1,param_6);
            iVar5 = mxmlRelease(iVar4);
            if (iVar5 == 0) goto LAB_002c04a4;
          }
          if (local_84 == 0) {
            local_84 = iVar4;
          }
          goto LAB_002c04a4;
        }
        mxml_error("<%s> cannot be a second root node after <%s>",local_4c,
                   *(undefined4 *)(local_84 + 0x18));
        goto LAB_002c008c;
      }
      iVar4 = strcmp(local_4c,"![CDATA[");
      if (iVar4 == 0) goto LAB_002c04c8;
      if (uVar6 != 0x3e) {
        do {
          if (((uVar6 == 0x26) &&
              (uVar6 = mxml_get_entity(local_88,param_2,&local_40,param_4), uVar6 == 0xffffffff)) ||
             (iVar4 = mxml_add_char(uVar6,&local_48,&local_4c,&local_44), iVar4 != 0))
          goto LAB_002c008c;
          uVar6 = (*param_4)(param_2,&local_40);
          if (uVar6 == 0xffffffff) {
            mxml_error("Early EOF in declaration node!");
            goto LAB_002c008c;
          }
        } while (uVar6 != 0x3e);
      }
      *local_48 = '\0';
      if (local_84 != 0 && local_88 == 0) {
        mxml_error("<%s> cannot be a second root node after <%s>",local_4c,
                   *(undefined4 *)(local_84 + 0x18));
        goto LAB_002c008c;
      }
      iVar4 = mxmlNewElement(local_88,local_4c);
      if (iVar4 == 0) {
        if (local_88 == 0) {
          puVar10 = &DAT_002de820;
        }
        else {
          puVar10 = *(undefined **)(local_88 + 0x18);
        }
        mxml_error("Unable to add declaration node to parent <%s>!",puVar10);
        goto LAB_002c008c;
      }
LAB_002c0900:
      if (param_5 != (code *)0x0) {
        (*param_5)(iVar4,3,param_6);
        iVar5 = mxmlRelease(iVar4);
        if (iVar5 == 0) goto LAB_002c04a4;
      }
      if (local_84 == 0) {
        local_84 = iVar4;
      }
      if ((local_88 == 0) && (local_88 = iVar4, param_3 != (code *)0x0)) {
        unaff_r8 = (*param_3)(iVar4);
      }
      goto LAB_002c04a4;
    }
    if (iVar4 != 0x20 && iVar4 != 9) {
      iVar5 = mxml_isspace_part_0();
      if (iVar5 == 0) goto LAB_002c01b0;
      if (unaff_r8 != 2 && unaff_r8 != 5) {
        if (local_4c < local_48) goto LAB_002c0350;
        iVar5 = mxml_isspace_part_0(iVar4);
        if (iVar5 == 0) goto LAB_002c024c;
      }
LAB_002bfdd8:
      if (unaff_r8 != 4) goto LAB_002bfde0;
LAB_002c02e4:
      if (iVar4 != 0x3c) goto LAB_002c02f0;
LAB_002c01cc:
      if (local_88 == 0) {
        bVar12 = false;
      }
      else {
        iVar4 = mxmlNewText(local_88,1,&DAT_002dbcb4);
        if (param_5 != (code *)0x0) {
          (*param_5)(iVar4,2,param_6);
          iVar5 = mxmlRelease(iVar4);
          bVar12 = false;
          if (iVar5 == 0) goto LAB_002bfdf8;
        }
        bVar12 = false;
        if (iVar4 != 0 && local_84 == 0) {
          local_84 = iVar4;
        }
      }
      goto LAB_002bfdf8;
    }
    if (unaff_r8 != 2 && unaff_r8 != 5) {
      if (local_4c < local_48) goto LAB_002c0350;
      if (unaff_r8 == 4) goto LAB_002c02e4;
      goto LAB_002c024c;
    }
    if (unaff_r8 != 4) {
LAB_002bfde0:
      if ((bVar12 & iVar4 == 0x3c) != 0) goto LAB_002bfdf4;
      goto LAB_002c0244;
    }
LAB_002c02f0:
    bVar12 = true;
    if (iVar4 == 0x26) goto LAB_002c02f8;
LAB_002c0254:
    if ((unaff_r8 != 5 && unaff_r8 != 2) &&
       ((iVar4 == 9 || iVar4 == 0x20 || (iVar5 = mxml_isspace_part_0(iVar4), iVar5 != 0))))
    goto LAB_002bfd94;
LAB_002c0280:
    iVar4 = mxml_add_char(iVar4,&local_48,&local_4c,&local_44);
    if (iVar4 == 0) goto LAB_002bfd94;
LAB_002c008c:
    mxmlDelete(local_84);
    free(local_4c);
  }
  return 0;
LAB_002c0ebc:
  *local_34 = 0;
  iVar3 = mxmlElementGetAttr(iVar4,local_3c);
  if (iVar3 == 0) {
LAB_002c0ad0:
    mxml_error("Missing value for attribute \'%s\' in element %s!",local_3c,
               *(undefined4 *)(iVar4 + 0x18));
  }
LAB_002c007c:
  free(local_3c);
  free(local_38);
  goto LAB_002c008c;
code_r0x002c0e70:
  if (uVar6 == 0x3e) goto LAB_002c0e78;
  goto LAB_002bff80;
LAB_002c0e78:
  uVar6 = 0x3e;
LAB_002c0e84:
  free(local_3c);
  free(local_38);
LAB_002c07d8:
  if (param_5 != (code *)0x0) {
    (*param_5)(iVar4,5,param_6);
  }
  if (local_84 == 0) {
    local_84 = iVar4;
  }
  if (uVar6 == 0xffffffff) {
LAB_002c06cc:
    free(local_4c);
    iVar3 = local_88;
    if (local_88 == 0) {
      return local_84;
    }
    do {
      iVar4 = iVar3;
      iVar3 = *(int *)(iVar4 + 0xc);
    } while (param_1 != iVar3 && iVar3 != 0);
    if (local_88 != iVar4) {
      if (*(int *)(local_88 + 0xc) == 0) {
        pcVar11 = "(null)";
      }
      else {
        pcVar11 = *(char **)(*(int *)(local_88 + 0xc) + 0x18);
      }
      mxml_error("Missing close tag </%s> under parent <%s>!",*(undefined4 *)(local_88 + 0x18),
                 pcVar11);
      mxmlDelete(local_84);
      return 0;
    }
    return iVar4;
  }
  if (uVar6 == 0x2f) {
LAB_002c0b20:
    iVar5 = local_84;
    if (param_5 != (code *)0x0) {
LAB_002c0b2c:
      local_84 = iVar5;
      (*param_5)(iVar4,4,param_6);
      iVar5 = mxmlRelease(iVar4);
      if (iVar5 == 0 && iVar4 == local_84) {
        local_84 = 0;
      }
    }
  }
  else {
    local_88 = iVar4;
    if (param_3 != (code *)0x0) {
      unaff_r8 = (*param_3)(iVar4);
    }
  }
LAB_002c04a4:
  local_48 = local_4c;
  goto LAB_002bfd94;
}
