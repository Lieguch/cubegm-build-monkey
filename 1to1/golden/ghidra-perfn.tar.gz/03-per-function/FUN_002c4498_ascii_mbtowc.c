/* ============================================================
 * ascii_mbtowc   @ 0x002c4498   size=54B   callers=21
 * module: 08_iconv_encoding
 * ============================================================ */

undefined4 ascii_mbtowc(undefined4 param_1,uint *param_2,byte *param_3)

{
  undefined4 uVar1;
  
  if ((char)*param_3 < '\0') {
    uVar1 = 0xffffffff;
  }
  else {
    *param_2 = (uint)*param_3;
    uVar1 = 1;
  }
  return uVar1;
}
