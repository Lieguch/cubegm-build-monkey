/* ============================================================
 * mxmlNewCustom   @ 0x002c2dd0   size=36B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

void mxmlNewCustom(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  
  iVar1 = mxml_new(param_1,5);
  if (iVar1 != 0) {
    *(undefined4 *)(iVar1 + 0x18) = param_2;
    *(undefined4 *)(iVar1 + 0x1c) = param_3;
  }
  return;
}
