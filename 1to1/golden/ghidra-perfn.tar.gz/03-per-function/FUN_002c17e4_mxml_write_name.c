/* ============================================================
 * mxml_write_name   @ 0x002c17e4   size=268B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

int mxml_write_name(char *param_1,undefined4 param_2,code *param_3)

{
  char cVar1;
  char cVar2;
  int iVar3;
  char *pcVar4;
  char *pcVar5;
  
  cVar2 = *param_1;
  if (cVar2 == '\'' || cVar2 == '\"') {
    iVar3 = (*param_3)();
    if (-1 < iVar3) {
      cVar2 = *param_1;
      pcVar5 = param_1 + 1;
      if (cVar2 != param_1[1] && param_1[1] != '\0') {
        do {
          pcVar4 = (char *)mxmlEntityGetName();
          if (pcVar4 == (char *)0x0) {
            iVar3 = (*param_3)(*pcVar5,param_2);
          }
          else {
            iVar3 = (*param_3)(0x26);
            if (iVar3 < 0) {
              return -1;
            }
            cVar1 = *pcVar4;
            while (cVar1 != '\0') {
              iVar3 = (*param_3)(cVar1,param_2);
              if (iVar3 < 0) {
                return -1;
              }
              pcVar4 = pcVar4 + 1;
              cVar1 = *pcVar4;
            }
            iVar3 = (*param_3)(0x3b,param_2);
          }
          if (iVar3 < 0) {
            return -1;
          }
          pcVar5 = pcVar5 + 1;
        } while (cVar2 != *pcVar5 && *pcVar5 != '\0');
      }
      iVar3 = (*param_3)(cVar2,param_2);
      return iVar3 >> 0x1f;
    }
  }
  else {
    while( true ) {
      if (cVar2 == '\0') {
        return 0;
      }
      iVar3 = (*param_3)(cVar2,param_2);
      if (iVar3 < 0) break;
      param_1 = param_1 + 1;
      cVar2 = *param_1;
    }
  }
  return -1;
}
