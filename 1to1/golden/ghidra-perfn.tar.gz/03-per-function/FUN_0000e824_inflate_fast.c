/* ============================================================
 * inflate_fast   @ 0x0000e824   size=1116B   callers=1
 * module: 07_zlib
 * ============================================================ */

/* inflate_fast(unsigned int, unsigned int, inflate_huft_s const*, inflate_huft_s const*,
   inflate_blocks_state*, z_stream_s*) */

undefined4
inflate_fast(uint param_1,uint param_2,inflate_huft_s *param_3,inflate_huft_s *param_4,
            inflate_blocks_state *param_5,z_stream_s *param_6)

{
  byte bVar1;
  inflate_huft_s iVar2;
  undefined4 uVar3;
  byte *pbVar4;
  inflate_huft_s *piVar5;
  undefined1 *puVar6;
  inflate_huft_s *piVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  undefined1 *puVar14;
  uint uVar15;
  uint uVar16;
  int iVar17;
  byte *pbVar18;
  int iVar19;
  undefined1 *puVar20;
  undefined1 *puVar21;
  uint uVar22;
  undefined1 *puVar23;
  undefined1 *puVar24;
  uint uVar25;
  uint uVar26;
  bool bVar27;
  bool bVar28;
  
  puVar24 = *(undefined1 **)(param_5 + 0x30);
  puVar20 = *(undefined1 **)(param_5 + 0x34);
  uVar26 = *(uint *)(param_5 + 0x20);
  uVar25 = *(uint *)(param_5 + 0x1c);
  bVar27 = puVar20 < puVar24;
  if (bVar27) {
    puVar24 = puVar24 + (-1 - (int)puVar20);
  }
  pbVar18 = *(byte **)param_6;
  uVar16 = *(uint *)(param_6 + 4);
  if (!bVar27) {
    puVar24 = (undefined1 *)(*(int *)(param_5 + 0x2c) - (int)puVar20);
  }
  uVar10 = *(uint *)(inflate_mask + param_1 * 4);
  uVar11 = *(uint *)(inflate_mask + param_2 * 4);
  while( true ) {
    for (; uVar25 < 0x14; uVar25 = uVar25 + 8) {
      bVar1 = *pbVar18;
      uVar16 = uVar16 - 1;
      pbVar18 = pbVar18 + 1;
      uVar26 = uVar26 | (uint)bVar1 << (uVar25 & 0xff);
    }
    uVar12 = (uint)(byte)param_3[(uVar26 & uVar10) * 8];
    piVar7 = param_3 + (uVar26 & uVar10) * 8;
    if (uVar12 != 0) break;
LAB_0000e8e4:
    puVar24 = puVar24 + -1;
    iVar2 = piVar7[1];
    puVar21 = puVar20 + 1;
    *puVar20 = (char)*(undefined4 *)(piVar7 + 4);
    uVar26 = uVar26 >> (uint)(byte)iVar2;
    uVar25 = uVar25 - (byte)iVar2;
LAB_0000e900:
    bVar28 = 8 < uVar16;
    bVar27 = uVar16 == 9;
    if (9 < uVar16) {
      bVar28 = (undefined1 *)0x100 < puVar24;
      bVar27 = puVar24 == (undefined1 *)0x101;
    }
    puVar20 = puVar21;
    if (!bVar28 || bVar27) {
      uVar3 = 0;
      iVar8 = *(int *)(param_6 + 4);
      uVar10 = uVar25 >> 3;
      *(uint *)(param_5 + 0x20) = uVar26;
LAB_0000eb24:
      if (iVar8 - uVar16 <= uVar10) {
        uVar10 = iVar8 - uVar16;
      }
      iVar8 = *(int *)param_6;
      iVar9 = *(int *)(param_6 + 8);
      *(uint *)(param_5 + 0x1c) = uVar25 + uVar10 * -8;
      *(uint *)(param_6 + 8) = iVar9 + (((int)pbVar18 - uVar10) - iVar8);
      *(uint *)(param_6 + 4) = uVar16 + uVar10;
      *(uint *)param_6 = (int)pbVar18 - uVar10;
      *(undefined1 **)(param_5 + 0x34) = puVar20;
      return uVar3;
    }
  }
LAB_0000e954:
  uVar26 = uVar26 >> (uint)(byte)piVar7[1];
  uVar25 = uVar25 - (byte)piVar7[1];
  if ((uVar12 & 0x10) == 0) {
    if ((uVar12 & 0x40) == 0) goto code_r0x0000e934;
    iVar8 = *(int *)(param_6 + 4);
    uVar10 = uVar25 >> 3;
    if ((uVar12 & 0x20) != 0) {
      uVar3 = 1;
      *(uint *)(param_5 + 0x20) = uVar26;
      goto LAB_0000eb24;
    }
    if (iVar8 - uVar16 <= uVar10) {
      uVar10 = iVar8 - uVar16;
    }
    iVar19 = (int)pbVar18 - uVar10;
    iVar17 = uVar16 + uVar10;
    iVar9 = *(int *)param_6;
    iVar8 = *(int *)(param_6 + 8);
    *(char **)(param_6 + 0x18) = "invalid literal/length code";
    *(uint *)(param_5 + 0x1c) = uVar25 + uVar10 * -8;
    iVar8 = iVar8 + (iVar19 - iVar9);
    *(uint *)(param_5 + 0x20) = uVar26;
  }
  else {
    uVar12 = uVar12 & 0xf;
    uVar25 = uVar25 - uVar12;
    uVar15 = uVar26 >> uVar12;
    pbVar4 = pbVar18;
    uVar13 = uVar25;
    if (uVar25 < 0xf) {
      do {
        uVar15 = uVar15 | (uint)*pbVar4 << (uVar13 & 0xff);
        uVar13 = uVar13 + 8;
        pbVar4 = pbVar4 + 1;
      } while (uVar13 < 0xf);
      uVar13 = 0xe - uVar25 >> 3;
      uVar25 = (0xe - uVar25 & 0xfffffff8) + uVar25 + 8;
      uVar16 = (uVar16 - 1) - uVar13;
      pbVar18 = pbVar18 + uVar13 + 1;
    }
    piVar5 = param_4 + (uVar11 & uVar15) * 8;
    iVar2 = param_4[(uVar11 & uVar15) * 8];
    uVar15 = uVar15 >> (uint)(byte)piVar5[1];
    uVar25 = uVar25 - (byte)piVar5[1];
    while( true ) {
      if (((byte)iVar2 & 0x10) != 0) {
        uVar13 = (byte)iVar2 & 0xf;
        for (; uVar25 < uVar13; uVar25 = uVar25 + 8) {
          uVar16 = uVar16 - 1;
          uVar15 = uVar15 | (uint)*pbVar18 << (uVar25 & 0xff);
          pbVar18 = pbVar18 + 1;
        }
        uVar25 = uVar25 - uVar13;
        uVar22 = (*(uint *)(inflate_mask + uVar13 * 4) & uVar15) + *(int *)(piVar5 + 4);
        uVar12 = (uVar26 & *(uint *)(inflate_mask + uVar12 * 4)) + *(int *)(piVar7 + 4);
        uVar26 = uVar15 >> uVar13;
        puVar24 = puVar24 + -uVar12;
        if ((uint)((int)puVar20 - *(int *)(param_5 + 0x28)) < uVar22) {
          uVar22 = uVar22 - ((int)puVar20 - *(int *)(param_5 + 0x28));
          puVar23 = *(undefined1 **)(param_5 + 0x2c);
          puVar21 = puVar23 + -uVar22;
          if (uVar22 < uVar12) {
            uVar12 = uVar12 - uVar22;
            puVar6 = puVar20 + -1;
            do {
              puVar14 = puVar21 + 1;
              puVar6 = puVar6 + 1;
              *puVar6 = *puVar21;
              puVar21 = puVar14;
            } while (puVar23 != puVar14);
            puVar20 = puVar20 + uVar22;
            puVar21 = *(undefined1 **)(param_5 + 0x28);
          }
        }
        else {
          puVar23 = puVar20 + -uVar22;
          uVar12 = uVar12 - 2;
          puVar21 = puVar23 + 2;
          *puVar20 = *puVar23;
          puVar20[1] = puVar23[1];
          puVar20 = puVar20 + 2;
        }
        puVar6 = puVar20 + -1;
        puVar23 = puVar21;
        do {
          puVar14 = puVar23 + 1;
          puVar6 = puVar6 + 1;
          *puVar6 = *puVar23;
          puVar23 = puVar14;
        } while (puVar14 != puVar21 + uVar12);
        puVar21 = puVar20 + uVar12;
        goto LAB_0000e900;
      }
      if (((byte)iVar2 & 0x40) != 0) break;
      piVar5 = piVar5 + ((*(uint *)(inflate_mask + (uint)(byte)iVar2 * 4) & uVar15) +
                        *(int *)(piVar5 + 4)) * 8;
      iVar2 = *piVar5;
      uVar15 = uVar15 >> (uint)(byte)piVar5[1];
      uVar25 = uVar25 - (byte)piVar5[1];
    }
    uVar26 = uVar25 >> 3;
    if (*(int *)(param_6 + 4) - uVar16 <= uVar25 >> 3) {
      uVar26 = *(int *)(param_6 + 4) - uVar16;
    }
    iVar19 = (int)pbVar18 - uVar26;
    iVar17 = uVar26 + uVar16;
    *(char **)(param_6 + 0x18) = "invalid distance code";
    iVar8 = *(int *)(param_6 + 8) + (iVar19 - *(int *)param_6);
    *(uint *)(param_5 + 0x1c) = uVar25 + uVar26 * -8;
    *(uint *)(param_5 + 0x20) = uVar15;
  }
  *(int *)(param_6 + 4) = iVar17;
  *(int *)param_6 = iVar19;
  *(int *)(param_6 + 8) = iVar8;
  *(undefined1 **)(param_5 + 0x34) = puVar20;
  return 0xfffffffd;
code_r0x0000e934:
  piVar7 = piVar7 + ((*(uint *)(inflate_mask + uVar12 * 4) & uVar26) + *(int *)(piVar7 + 4)) * 8;
  uVar12 = (uint)(byte)*piVar7;
  if (uVar12 == 0) goto LAB_0000e8e4;
  goto LAB_0000e954;
}
