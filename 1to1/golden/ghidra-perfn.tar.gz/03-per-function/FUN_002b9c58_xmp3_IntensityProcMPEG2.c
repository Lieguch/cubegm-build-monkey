/* ============================================================
 * xmp3_IntensityProcMPEG2   @ 0x002b9c58   size=1064B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

void xmp3_IntensityProcMPEG2
               (int param_1,int param_2,int param_3,int param_4,int *param_5,int *param_6,
               int param_7,undefined4 param_8,uint *param_9)

{
  uint uVar1;
  byte bVar2;
  short sVar3;
  uint *puVar4;
  int iVar5;
  int iVar6;
  uint *puVar7;
  int *piVar8;
  int iVar9;
  short *psVar10;
  short *psVar11;
  uint uVar12;
  int iVar13;
  int iVar14;
  uint uVar15;
  int iVar16;
  int iVar17;
  int iVar18;
  uint *local_b0;
  byte *local_a8;
  uint *local_a4;
  int *local_a0;
  uint auStack_88 [25];
  
  iVar9 = 0;
  piVar8 = (int *)(xmp3_ISFMpeg2 + (param_7 + *param_6 * 2) * 0x40);
  puVar4 = (uint *)(param_6 + 1);
  do {
    puVar7 = puVar4 + 1;
    uVar15 = *puVar4;
    uVar12 = puVar4[4];
    if (0 < (int)uVar12) {
      puVar4 = auStack_88 + iVar9;
      do {
        puVar4 = puVar4 + 1;
        *puVar4 = (1 << (uVar15 & 0xff)) - 1;
      } while (puVar4 != auStack_88 + iVar9 + uVar12 + 0x40000000);
      iVar9 = iVar9 + uVar12;
    }
    puVar4 = puVar7;
  } while (puVar7 != (uint *)(param_6 + 5));
  if (param_5[6] != 0) {
    iVar9 = *(int *)(param_3 + 0x34);
    uVar15 = 0;
    uVar12 = 0;
    local_a4 = (uint *)0x0;
    do {
      local_a0 = param_5 + 1;
      iVar17 = param_5[7];
      iVar13 = *local_a0;
      sVar3 = *(short *)(iVar9 + iVar17 * 2 + 0x30);
      iVar16 = sVar3 * 3 + (int)local_a4;
      if (iVar17 + 1 <= iVar13) {
        local_b0 = auStack_88 + iVar17 + 1;
        iVar14 = param_4 + iVar17 * 3 + (int)local_a4;
        iVar6 = (int)sVar3;
        psVar10 = (short *)(iVar9 + (iVar17 + 0x19) * 2);
        do {
          bVar2 = *(byte *)(iVar14 + 0x1a);
          local_b0 = local_b0 + 1;
          if ((uint)bVar2 == *local_b0) {
            iVar18 = *(int *)(xmp3_ISFIIP + param_7 * 8);
            iVar17 = *(int *)(xmp3_ISFIIP + param_7 * 8 + 4);
          }
          else {
            iVar17 = (int)(bVar2 + 1) >> 1;
            if ((bVar2 & 1) == 0) {
              iVar17 = iVar17 << 2;
              iVar18 = *piVar8;
            }
            else {
              iVar18 = piVar8[iVar17];
              iVar17 = 0;
            }
            iVar17 = *(int *)((int)piVar8 + iVar17);
          }
          psVar11 = psVar10 + 1;
          sVar3 = *psVar10;
          iVar6 = sVar3 - iVar6;
          if (0 < iVar6) {
            iVar5 = param_1 + iVar16 * 4;
            iVar6 = iVar6 * 3 + iVar16;
            do {
              uVar1 = (int)((ulonglong)((longlong)iVar17 * (longlong)*(int *)(param_1 + iVar16 * 4))
                           >> 0x20) << 2;
              *(uint *)(iVar5 + 0x900) = uVar1;
              uVar15 = uVar15 | (uVar1 ^ (int)uVar1 >> 0x1f) - ((int)uVar1 >> 0x1f);
              uVar1 = (int)((ulonglong)((longlong)iVar18 * (longlong)*(int *)(param_1 + iVar16 * 4))
                           >> 0x20) << 2;
              *(uint *)(param_1 + iVar16 * 4) = uVar1;
              iVar16 = iVar16 + 3;
              uVar12 = uVar12 | (uVar1 ^ (int)uVar1 >> 0x1f) - ((int)uVar1 >> 0x1f);
              iVar5 = iVar5 + 0xc;
            } while (iVar16 != iVar6);
          }
          iVar14 = iVar14 + 3;
          iVar6 = (int)sVar3;
          psVar10 = psVar11;
        } while (psVar11 != (short *)(iVar9 + (iVar13 + 0x19) * 2));
      }
      local_a4 = (uint *)((int)local_a4 + 1);
      param_5 = local_a0;
    } while (local_a4 != (uint *)0x3);
    *param_9 = uVar12;
    param_9[1] = uVar15;
    return;
  }
  iVar9 = param_5[0xb];
  iVar16 = param_5[5];
  iVar13 = iVar9 + 1;
  local_b0 = (uint *)(int)*(short *)(*(int *)(param_3 + 0x34) + iVar13 * 2);
  param_2 = param_2 - (int)local_b0;
  uVar12 = 0;
  uVar15 = uVar12;
  if (iVar13 <= iVar16) {
    local_a0 = (int *)(*(int *)(param_3 + 0x34) + iVar9 * 2 + 2);
    local_a8 = (byte *)(param_4 + iVar9);
    local_a4 = auStack_88 + iVar13;
    iVar9 = (int)local_b0;
    do {
      local_a8 = local_a8 + 1;
      bVar2 = *local_a8;
      local_a4 = local_a4 + 1;
      if ((uint)bVar2 == *local_a4) {
        iVar17 = *(int *)(xmp3_ISFIIP + param_7 * 8);
        iVar6 = *(int *)(xmp3_ISFIIP + param_7 * 8 + 4);
      }
      else {
        iVar6 = (int)(bVar2 + 1) >> 1;
        if ((bVar2 & 1) == 0) {
          iVar6 = iVar6 << 2;
          iVar17 = *piVar8;
        }
        else {
          iVar17 = piVar8[iVar6];
          iVar6 = 0;
        }
        iVar6 = *(int *)((int)piVar8 + iVar6);
      }
      iVar13 = iVar13 + 1;
      local_a0 = (int *)((int)local_a0 + 2);
      sVar3 = *(short *)local_a0;
      iVar9 = sVar3 - iVar9;
      if (param_2 <= iVar9) {
        iVar9 = param_2;
      }
      if (0 < iVar9) {
        puVar7 = (uint *)(param_1 + (int)local_b0 * 4 + -4);
        puVar4 = (uint *)(param_1 + (int)local_b0 * 4 + 0x8fc);
        do {
          uVar1 = (int)((ulonglong)((longlong)iVar6 * (longlong)(int)puVar7[1]) >> 0x20) << 2;
          puVar4 = puVar4 + 1;
          *puVar4 = uVar1;
          uVar15 = uVar15 | (uVar1 ^ (int)uVar1 >> 0x1f) - ((int)uVar1 >> 0x1f);
          uVar1 = (int)((ulonglong)((longlong)iVar17 * (longlong)(int)puVar7[1]) >> 0x20) << 2;
          puVar7 = puVar7 + 1;
          *puVar7 = uVar1;
          uVar12 = uVar12 | (uVar1 ^ (int)uVar1 >> 0x1f) - ((int)uVar1 >> 0x1f);
        } while (puVar7 != (uint *)(param_1 + ((int)local_b0 + 0x3fffffff + iVar9) * 4));
        local_b0 = (uint *)((int)local_b0 + iVar9);
      }
      param_2 = param_2 - iVar9;
    } while ((param_2 != 0) && (iVar9 = (int)sVar3, iVar13 <= iVar16));
  }
  *param_9 = uVar12;
  param_9[1] = uVar15;
  return;
}
