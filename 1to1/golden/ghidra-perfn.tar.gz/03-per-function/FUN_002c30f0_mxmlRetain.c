/* ============================================================
 * mxmlRetain   @ 0x002c30f0   size=24B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

void mxmlRetain(int param_1)

{
  if (param_1 != 0) {
    *(int *)(param_1 + 0x28) = *(int *)(param_1 + 0x28) + 1;
  }
  return;
}
