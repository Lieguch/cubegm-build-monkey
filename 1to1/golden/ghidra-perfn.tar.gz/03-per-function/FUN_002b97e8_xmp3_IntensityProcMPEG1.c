/* ============================================================
 * xmp3_IntensityProcMPEG1   @ 0x002b97e8   size=1124B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

void xmp3_IntensityProcMPEG1
               (int param_1,int param_2,int param_3,int param_4,int param_5,int param_6,
               undefined4 param_7,uint *param_8)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  byte *pbVar9;
  uint *puVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  uint uVar15;
  uint uVar16;
  int iVar17;
  int iVar18;
  int iVar19;
  bool bVar20;
  bool bVar21;
  byte *local_88;
  int local_84;
  byte *local_68;
  int local_54;
  int local_40 [7];
  
  if (*(int *)(param_5 + 0x18) == 0) {
    iVar7 = *(int *)(param_5 + 0x2c) + 1;
    local_84 = *(int *)(param_5 + 0x14) + 1;
    iVar14 = (int)*(short *)(*(int *)(param_3 + 0x34) + iVar7 * 2);
    param_2 = param_2 - iVar14;
    local_54 = 0;
    iVar17 = 0;
  }
  else if (*(int *)(param_5 + 0x18) - 1U < 2) {
    local_84 = 0;
    iVar7 = 0;
    iVar17 = *(int *)(param_5 + 0x28) + 1;
    local_54 = *(int *)(param_5 + 0x10) + 1;
    iVar12 = (int)*(short *)(*(int *)(param_3 + 0x34) + *(int *)(param_5 + 0x28) * 2 + 0x30);
    iVar14 = iVar12 * 3;
    param_2 = param_2 + iVar12 * -3;
  }
  else {
    iVar7 = 0;
    local_54 = 0;
    local_84 = 0;
    iVar14 = iVar7;
    iVar17 = iVar7;
  }
  local_88 = (byte *)(param_4 + iVar7 + -1);
  uVar16 = 0;
  uVar15 = 0;
  iVar12 = param_6 * 0x1c;
  while (iVar11 = iVar14, 0 < param_2 && iVar7 < local_84) {
    local_88 = local_88 + 1;
    if (*local_88 == 7) {
      iVar19 = *(int *)(xmp3_ISFIIP + param_6 * 8);
      iVar18 = *(int *)(xmp3_ISFIIP + param_6 * 8 + 4);
    }
    else {
      iVar19 = *(int *)(xmp3_ISFMpeg1 + (uint)*local_88 * 4 + iVar12);
      iVar18 = *(int *)(xmp3_ISFMpeg1 + iVar12 + 0x18) - iVar19;
    }
    iVar14 = iVar7 * 2;
    iVar7 = iVar7 + 1;
    iVar13 = (int)*(short *)(*(int *)(param_3 + 0x34) + iVar14 + 2) -
             (int)*(short *)(*(int *)(param_3 + 0x34) + iVar14);
    iVar14 = iVar11;
    if (0 < iVar13) {
      iVar8 = 0;
      puVar10 = (uint *)(param_1 + iVar11 * 4 + -4);
      do {
        uVar1 = (int)((ulonglong)((longlong)iVar18 * (longlong)(int)puVar10[1]) >> 0x20) << 2;
        puVar10[0x241] = uVar1;
        uVar16 = uVar16 | (uVar1 ^ (int)uVar1 >> 0x1f) - ((int)uVar1 >> 0x1f);
        uVar1 = (int)((ulonglong)((longlong)iVar19 * (longlong)(int)puVar10[1]) >> 0x20) << 2;
        puVar10 = puVar10 + 1;
        *puVar10 = uVar1;
        iVar8 = iVar8 + 1;
        param_2 = param_2 + -1;
        bVar20 = iVar13 == iVar8;
        iVar6 = iVar13 - iVar8;
        if (iVar13 > iVar8) {
          bVar20 = param_2 == 0;
          iVar6 = param_2;
        }
        uVar15 = uVar15 | (uVar1 ^ (int)uVar1 >> 0x1f) - ((int)uVar1 >> 0x1f);
        iVar14 = iVar8 + iVar11;
      } while (!bVar20 && iVar6 < 0 == (iVar13 <= iVar8 && SBORROW4(iVar13,iVar8)));
    }
  }
  local_68 = (byte *)(param_4 + iVar17 * 3 + 0x16);
  while (2 < param_2 && iVar17 < local_54) {
    iVar14 = 0;
    pbVar9 = local_68;
    do {
      pbVar9 = pbVar9 + 1;
      if (*pbVar9 == 7) {
        iVar7 = *(int *)(xmp3_ISFIIP + param_6 * 8 + 4);
        local_40[iVar14] = *(int *)(xmp3_ISFIIP + param_6 * 8);
        local_40[iVar14 + 3] = iVar7;
      }
      else {
        iVar18 = *(int *)(xmp3_ISFMpeg1 + (uint)*pbVar9 * 4 + iVar12);
        iVar7 = *(int *)(xmp3_ISFMpeg1 + iVar12 + 0x18);
        local_40[iVar14] = iVar18;
        local_40[iVar14 + 3] = iVar7 - iVar18;
      }
      iVar14 = iVar14 + 1;
    } while (iVar14 != 3);
    iVar14 = *(int *)(param_3 + 0x34) + iVar17 * 2;
    iVar14 = (int)*(short *)(iVar14 + 0x30) - (int)*(short *)(iVar14 + 0x2e);
    if (0 < iVar14) {
      iVar18 = 0;
      puVar10 = (uint *)(param_1 + iVar11 * 4);
      iVar7 = param_2;
      local_88 = (byte *)iVar11;
      do {
        uVar1 = (int)((ulonglong)((longlong)local_40[3] * (longlong)(int)*puVar10) >> 0x20) << 2;
        puVar10[0x240] = uVar1;
        uVar2 = (int)((ulonglong)((longlong)local_40[0] * (longlong)(int)*puVar10) >> 0x20) << 2;
        *puVar10 = uVar2;
        uVar3 = (int)((ulonglong)((longlong)local_40[4] * (longlong)(int)puVar10[1]) >> 0x20) << 2;
        puVar10[0x241] = uVar3;
        uVar4 = (int)((ulonglong)((longlong)local_40[1] * (longlong)(int)puVar10[1]) >> 0x20) << 2;
        puVar10[1] = uVar4;
        uVar5 = (int)((ulonglong)((longlong)local_40[5] * (longlong)(int)puVar10[2]) >> 0x20) << 2;
        puVar10[0x242] = uVar5;
        uVar16 = uVar16 | (uVar3 ^ (int)uVar3 >> 0x1f) - ((int)uVar3 >> 0x1f) |
                          (uVar1 ^ (int)uVar1 >> 0x1f) - ((int)uVar1 >> 0x1f) |
                          (uVar5 ^ (int)uVar5 >> 0x1f) - ((int)uVar5 >> 0x1f);
        uVar1 = (int)((ulonglong)((longlong)local_40[2] * (longlong)(int)puVar10[2]) >> 0x20) << 2;
        puVar10[2] = uVar1;
        param_2 = iVar7 + -3;
        iVar18 = iVar18 + 1;
        bVar21 = SBORROW4(iVar14,iVar18);
        iVar19 = iVar14 - iVar18;
        bVar20 = iVar14 == iVar18;
        if (iVar18 < iVar14) {
          bVar21 = SBORROW4(param_2,2);
          iVar19 = iVar7 + -5;
          bVar20 = param_2 == 2;
        }
        puVar10 = puVar10 + 3;
        iVar11 = (int)local_88 + 3;
        uVar15 = uVar15 | (uVar4 ^ (int)uVar4 >> 0x1f) - ((int)uVar4 >> 0x1f) |
                          (uVar2 ^ (int)uVar2 >> 0x1f) - ((int)uVar2 >> 0x1f) |
                          (uVar1 ^ (int)uVar1 >> 0x1f) - ((int)uVar1 >> 0x1f);
        iVar7 = param_2;
        local_88 = (byte *)iVar11;
      } while (!bVar20 && iVar19 < 0 == bVar21);
    }
    local_68 = local_68 + 3;
    iVar17 = iVar17 + 1;
  }
  *param_8 = uVar15;
  param_8[1] = uVar16;
  return;
}
