/* ============================================================
 * stbtt_FindMatchingFont   @ 0x0001ef58   size=464B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

int stbtt_FindMatchingFont(int param_1,char *param_2,uint param_3)

{
  int iVar1;
  size_t sVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar5 = 0;
  do {
    iVar1 = stbtt_GetFontOffsetForIndex(param_1,iVar5);
    if (iVar1 < 0) {
      return iVar1;
    }
    sVar2 = strlen(param_2);
    iVar3 = stbtt__isfont(param_1 + iVar1);
    if (iVar3 != 0) {
      if (param_3 == 0) {
        iVar3 = stbtt__find_table(param_1,iVar1,&DAT_002dcd70);
        if (iVar3 != 0) {
          iVar4 = stbtt__matchpair(param_1,iVar3,param_2,sVar2,0x10,0x11);
          if (iVar4 != 0) {
            return iVar1;
          }
          iVar4 = stbtt__matchpair(param_1,iVar3,param_2,sVar2,1,2);
          if (iVar4 != 0) {
            return iVar1;
          }
          goto LAB_0001f080;
        }
      }
      else {
        iVar3 = stbtt__find_table(param_1,iVar1,&DAT_002dce64);
        if ((((*(byte *)(param_1 + iVar3 + 0x2d) ^ param_3) & 7) == 0) &&
           (iVar3 = stbtt__find_table(param_1,iVar1,&DAT_002dcd70), iVar3 != 0)) {
          iVar4 = stbtt__matchpair(param_1,iVar3,param_2,sVar2,0x10,0xffffffff);
          if (iVar4 != 0) {
            return iVar1;
          }
          iVar4 = stbtt__matchpair(param_1,iVar3,param_2,sVar2,1,0xffffffff);
          if (iVar4 != 0) {
            return iVar1;
          }
LAB_0001f080:
          iVar3 = stbtt__matchpair(param_1,iVar3,param_2,sVar2,3,0xffffffff);
          if (iVar3 != 0) {
            return iVar1;
          }
        }
      }
    }
    iVar5 = iVar5 + 1;
  } while( true );
}
