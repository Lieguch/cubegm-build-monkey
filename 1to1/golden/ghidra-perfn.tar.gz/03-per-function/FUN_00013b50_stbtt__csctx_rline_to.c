/* ============================================================
 * stbtt__csctx_rline_to   @ 0x00013b50   size=84B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt__csctx_rline_to(float param_1,float param_2,int param_3)

{
  param_1 = param_1 + *(float *)(param_3 + 0x10);
  param_2 = param_2 + *(float *)(param_3 + 0x14);
  *(float *)(param_3 + 0x10) = param_1;
  *(float *)(param_3 + 0x14) = param_2;
  stbtt__csctx_v(param_3,2,(int)param_1,(int)param_2,0,0,0,0);
  return;
}
