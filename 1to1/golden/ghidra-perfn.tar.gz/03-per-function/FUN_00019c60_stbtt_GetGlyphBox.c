/* ============================================================
 * stbtt_GetGlyphBox   @ 0x00019c60   size=372B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

undefined4
stbtt_GetGlyphBox(int param_1,undefined4 param_2,int *param_3,int *param_4,int *param_5,int *param_6
                 )

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 local_50;
  int iStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 local_40;
  int iStack_3c;
  int local_38;
  int iStack_34;
  int local_30;
  int iStack_2c;
  undefined4 local_28;
  int iStack_24;
  
  if (*(int *)(param_1 + 0x3c) != 0) {
    iStack_4c = *(int *)((undefined1  [16])0x0 + (undefined1  [16])0x4);
    uStack_48 = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0x8);
    uStack_44 = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0xc);
    local_50 = 1;
    local_40 = 0;
    local_38 = 0;
    local_30 = 0;
    local_28 = 0;
    iStack_3c = iStack_4c;
    iStack_34 = iStack_4c;
    iStack_2c = iStack_4c;
    iStack_24 = iStack_4c;
    iVar1 = stbtt__run_charstring(param_1,param_2,&local_50);
    if (param_3 != (int *)0x0) {
      if (iVar1 == 0) {
        local_38 = 0;
      }
      *param_3 = local_38;
    }
    if (param_4 != (int *)0x0) {
      if (iVar1 == 0) {
        local_30 = 0;
      }
      *param_4 = local_30;
    }
    if (param_5 != (int *)0x0) {
      if (iVar1 == 0) {
        iStack_34 = 0;
      }
      *param_5 = iStack_34;
    }
    if (param_6 != (int *)0x0) {
      iVar3 = 0;
      if (iVar1 != 0) {
        iVar3 = iStack_2c;
      }
      *param_6 = iVar3;
    }
    return 1;
  }
  iVar1 = stbtt__GetGlyfOffset();
  if (iVar1 < 0) {
    uVar2 = 0;
  }
  else {
    if (param_3 != (int *)0x0) {
      *param_3 = (int)(short)((ushort)*(byte *)(*(int *)(param_1 + 4) + iVar1 + 2 + 1) +
                             (ushort)*(byte *)(*(int *)(param_1 + 4) + iVar1 + 2) * 0x100);
    }
    if (param_4 != (int *)0x0) {
      *param_4 = (int)(short)((ushort)*(byte *)(*(int *)(param_1 + 4) + iVar1 + 4 + 1) +
                             (ushort)*(byte *)(*(int *)(param_1 + 4) + iVar1 + 4) * 0x100);
    }
    if (param_5 != (int *)0x0) {
      *param_5 = (int)(short)((ushort)*(byte *)(*(int *)(param_1 + 4) + iVar1 + 6 + 1) +
                             (ushort)*(byte *)(*(int *)(param_1 + 4) + iVar1 + 6) * 0x100);
    }
    if (param_6 == (int *)0x0) {
      return 1;
    }
    uVar2 = 1;
    *param_6 = (int)(short)((ushort)*(byte *)(*(int *)(param_1 + 4) + iVar1 + 8 + 1) +
                           (ushort)*(byte *)(*(int *)(param_1 + 4) + iVar1 + 8) * 0x100);
  }
  return uVar2;
}
