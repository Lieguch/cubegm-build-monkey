/* ============================================================
 * unzGetCurrentFileInfo   @ 0x000115ec   size=64B   callers=2
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzGetCurrentFileInfo(unz_s*, unz_file_info_s*, char*, unsigned long, void*, unsigned long,
   char*, unsigned long) */

void unzGetCurrentFileInfo
               (unz_s *param_1,unz_file_info_s *param_2,char *param_3,ulong param_4,void *param_5,
               ulong param_6,char *param_7,ulong param_8)

{
  unzlocal_GetCurrentFileInfoInternal
            (param_1,param_2,(unz_file_info_internal_s *)0x0,param_3,param_4,param_5,param_6,param_7
             ,param_8);
  return;
}
