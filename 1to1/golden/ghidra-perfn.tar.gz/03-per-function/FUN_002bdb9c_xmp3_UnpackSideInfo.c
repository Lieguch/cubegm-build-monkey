/* ============================================================
 * xmp3_UnpackSideInfo   @ 0x002bdb9c   size=864B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

undefined4 xmp3_UnpackSideInfo(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  int *piVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  undefined4 local_3c;
  undefined1 auStack_38 [20];
  
  if (((param_1 == (undefined4 *)0x0) || (piVar8 = (int *)*param_1, piVar8 == (int *)0x0)) ||
     (puVar11 = (undefined4 *)param_1[1], puVar11 == (undefined4 *)0x0)) {
    local_3c = 0xffffffff;
  }
  else {
    if (*piVar8 == 0) {
      if (piVar8[7] == 3) {
        local_3c = 0x11;
      }
      else {
        local_3c = 0x20;
      }
      xmp3_SetBitstreamPointer(auStack_38,local_3c,param_2);
      uVar1 = xmp3_GetBits(auStack_38,9);
      if (piVar8[7] == 3) {
        uVar2 = 5;
      }
      else {
        uVar2 = 3;
      }
      *puVar11 = uVar1;
      uVar1 = xmp3_GetBits(auStack_38,uVar2);
      iVar3 = param_1[0x1ef];
      puVar11[1] = uVar1;
      if (0 < iVar3) {
        puVar7 = puVar11 + 2;
        iVar3 = 0;
        do {
          puVar10 = puVar7 + 4;
          puVar6 = puVar7;
          do {
            uVar1 = xmp3_GetBits(auStack_38,1);
            puVar7 = puVar6 + 1;
            *puVar6 = uVar1;
            puVar6 = puVar7;
          } while (puVar7 != puVar10);
          iVar3 = iVar3 + 1;
        } while (iVar3 < (int)param_1[0x1ef]);
      }
    }
    else {
      if (piVar8[7] == 3) {
        local_3c = 9;
      }
      else {
        local_3c = 0x11;
      }
      xmp3_SetBitstreamPointer(auStack_38,local_3c,param_2);
      uVar1 = xmp3_GetBits(auStack_38,8);
      if (piVar8[7] == 3) {
        uVar2 = 1;
      }
      else {
        uVar2 = 2;
      }
      *puVar11 = uVar1;
      uVar1 = xmp3_GetBits(auStack_38,uVar2);
      puVar11[1] = uVar1;
    }
    iVar3 = param_1[0x1f1];
    if (0 < iVar3) {
      iVar4 = param_1[0x1ef];
      iVar9 = 0;
      puVar7 = puVar11;
      do {
        if (0 < iVar4) {
          iVar3 = 0;
          puVar6 = puVar7;
          do {
            uVar1 = xmp3_GetBits(auStack_38,0xc);
            puVar6[10] = uVar1;
            uVar1 = xmp3_GetBits(auStack_38,9);
            puVar6[0xb] = uVar1;
            uVar1 = xmp3_GetBits(auStack_38,8);
            if (*piVar8 == 0) {
              uVar2 = 4;
            }
            else {
              uVar2 = 9;
            }
            puVar6[0xc] = uVar1;
            uVar1 = xmp3_GetBits(auStack_38,uVar2);
            puVar6[0xd] = uVar1;
            iVar4 = xmp3_GetBits(auStack_38,1);
            puVar6[0xe] = iVar4;
            if (iVar4 == 0) {
              puVar6[0xf] = 0;
              puVar6[0x10] = 0;
              uVar1 = xmp3_GetBits(auStack_38,5);
              puVar6[0x11] = uVar1;
              uVar1 = xmp3_GetBits(auStack_38,5);
              puVar6[0x12] = uVar1;
              uVar1 = xmp3_GetBits(auStack_38,5);
              puVar6[0x13] = uVar1;
              uVar1 = xmp3_GetBits(auStack_38,4);
              puVar6[0x17] = uVar1;
              uVar1 = xmp3_GetBits(auStack_38,3);
              iVar4 = *piVar8;
              puVar6[0x18] = uVar1;
              if (iVar4 == 0) goto LAB_002bdeac;
              uVar1 = 0;
            }
            else {
              uVar1 = xmp3_GetBits(auStack_38,2);
              puVar6[0xf] = uVar1;
              uVar1 = xmp3_GetBits(auStack_38,1);
              puVar6[0x10] = uVar1;
              uVar1 = xmp3_GetBits(auStack_38,5);
              puVar6[0x11] = uVar1;
              uVar1 = xmp3_GetBits(auStack_38,5);
              puVar6[0x13] = 0;
              puVar6[0x12] = uVar1;
              uVar1 = xmp3_GetBits(auStack_38,3);
              puVar6[0x14] = uVar1;
              uVar1 = xmp3_GetBits(auStack_38,3);
              puVar6[0x15] = uVar1;
              uVar1 = xmp3_GetBits(auStack_38,3);
              puVar6[0x16] = uVar1;
              if (puVar6[0xf] == 0) {
                puVar6[0xb] = 0;
                iVar4 = 0x14 - puVar6[0x17];
                puVar6[10] = 0;
                puVar6[0xd] = 0;
              }
              else if ((puVar6[0xf] == 2) && (puVar6[0x10] == 0)) {
                iVar4 = 0xc;
                puVar6[0x17] = 8;
              }
              else {
                iVar4 = 0xd;
                puVar6[0x17] = 7;
              }
              iVar5 = *piVar8;
              puVar6[0x18] = iVar4;
              if (iVar5 == 0) {
LAB_002bdeac:
                uVar1 = xmp3_GetBits(auStack_38,1);
              }
              else {
                uVar1 = 0;
              }
            }
            puVar6[0x19] = uVar1;
            iVar3 = iVar3 + 1;
            uVar1 = xmp3_GetBits(auStack_38);
            puVar6[0x1a] = uVar1;
            uVar1 = xmp3_GetBits(auStack_38,1);
            iVar4 = param_1[0x1ef];
            puVar6[0x1b] = uVar1;
            puVar6 = puVar6 + 0x12;
          } while (iVar3 < iVar4);
          iVar3 = param_1[0x1f1];
        }
        iVar9 = iVar9 + 1;
        puVar7 = puVar7 + 0x24;
      } while (iVar9 < iVar3);
    }
    param_1[0x1f6] = *puVar11;
  }
  return local_3c;
}
