/* ============================================================
 * stbtt__cuberoot   @ 0x00016470   size=64B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

float stbtt__cuberoot(float param_1)

{
  double dVar1;
  
  if (0.0 <= param_1) {
    dVar1 = pow((double)param_1,0.3333333432674408);
    return (float)dVar1;
  }
  dVar1 = pow((double)-param_1,0.3333333432674408);
  return -(float)dVar1;
}
