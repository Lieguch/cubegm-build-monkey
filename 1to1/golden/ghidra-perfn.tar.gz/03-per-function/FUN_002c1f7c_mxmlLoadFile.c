/* ============================================================
 * mxmlLoadFile   @ 0x002c1f7c   size=40B   callers=4
 * module: 04_mini_xml
 * ============================================================ */

void mxmlLoadFile(void)

{
  mxml_load_data();
  return;
}
