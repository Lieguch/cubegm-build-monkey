/* ============================================================
 * unzOpenCurrentFile   @ 0x000120b4   size=316B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzOpenCurrentFile(unz_s*) */

undefined4 unzOpenCurrentFile(unz_s *param_1)

{
  int iVar1;
  undefined4 *__ptr;
  void *pvVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint local_1c;
  ulong local_18;
  uint local_14;
  
  if ((param_1 == (unz_s *)0x0) || (*(int *)(param_1 + 0x18) == 0)) {
    uVar3 = 0xffffff9a;
  }
  else {
    if (*(int *)(param_1 + 0x7c) != 0) {
      unzCloseCurrentFile(param_1);
    }
    iVar1 = unzlocal_CheckCurrentFileCoherencyHeader(param_1,&local_1c,&local_18,&local_14);
    if (iVar1 == 0) {
      __ptr = malloc(0x6c);
      if (__ptr == (undefined4 *)0x0) {
        uVar3 = 0xffffff98;
      }
      else {
        pvVar2 = malloc(0x4000);
        __ptr[0x13] = 0;
        __ptr[0x11] = local_18;
        __ptr[0x12] = local_14;
        *__ptr = pvVar2;
        if (pvVar2 == (void *)0x0) {
          uVar3 = 0xffffff98;
          free(__ptr);
        }
        else {
          iVar1 = *(int *)(param_1 + 0x34);
          uVar3 = *(undefined4 *)(param_1 + 0x3c);
          uVar4 = *(undefined4 *)param_1;
          uVar5 = *(undefined4 *)(param_1 + 0xc);
          __ptr[0x10] = 0;
          __ptr[0x14] = 0;
          __ptr[6] = 0;
          __ptr[0x19] = iVar1;
          __ptr[0x15] = uVar3;
          __ptr[0x18] = uVar4;
          __ptr[0x1a] = uVar5;
          if (iVar1 != 0) {
            __ptr[9] = 0;
            __ptr[10] = 0;
            __ptr[0xb] = 0;
            iVar1 = inflateInit2((z_stream_s *)(__ptr + 1));
            if (iVar1 == 0) {
              __ptr[0x10] = 1;
            }
          }
          uVar3 = *(undefined4 *)(param_1 + 0x44);
          iVar1 = *(int *)(param_1 + 0x78);
          *(undefined4 **)(param_1 + 0x7c) = __ptr;
          __ptr[0x16] = *(undefined4 *)(param_1 + 0x40);
          __ptr[0xf] = local_1c + 0x1e + iVar1;
          __ptr[0x17] = uVar3;
          __ptr[2] = 0;
          uVar3 = 0;
        }
      }
    }
    else {
      uVar3 = 0xffffff99;
    }
  }
  return uVar3;
}
