/* ============================================================
 * stbtt_InitFont   @ 0x0001e380   size=1192B   callers=4
 * module: 05_stb_truetype_font
 * ============================================================ */

undefined4 stbtt_InitFont(int param_1,int param_2,undefined4 param_3)

{
  byte bVar1;
  byte bVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  uint uVar10;
  uint uVar11;
  undefined4 local_70;
  undefined4 uStack_6c;
  int iStack_68;
  int local_5c;
  uint local_58;
  uint local_54;
  uint local_50;
  int local_4c;
  uint local_48;
  uint local_44;
  undefined4 local_40;
  undefined4 uStack_3c;
  int iStack_38;
  undefined4 local_34 [2];
  undefined4 local_2c;
  
  *(int *)(param_1 + 4) = param_2;
  *(undefined4 *)(param_1 + 8) = param_3;
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0;
  iVar3 = stbtt__find_table(param_2,param_3,&DAT_002dce54);
  iVar4 = stbtt__find_table(param_2,param_3,&DAT_002dce5c);
  *(int *)(param_1 + 0x10) = iVar4;
  iVar5 = stbtt__find_table(param_2,param_3,&DAT_002dce64);
  *(int *)(param_1 + 0x14) = iVar5;
  uVar6 = stbtt__find_table(param_2,param_3,&DAT_002dce6c);
  *(uint *)(param_1 + 0x18) = uVar6;
  iVar7 = stbtt__find_table(param_2,param_3,&DAT_002dce74);
  *(int *)(param_1 + 0x1c) = iVar7;
  iVar8 = stbtt__find_table(param_2,param_3,&DAT_002dce7c);
  *(int *)(param_1 + 0x20) = iVar8;
  uVar9 = stbtt__find_table(param_2,param_3,&DAT_002dce84);
  *(undefined4 *)(param_1 + 0x24) = uVar9;
  uVar9 = stbtt__find_table(param_2,param_3,&DAT_002dce8c);
  *(undefined4 *)(param_1 + 0x28) = uVar9;
  if (iVar8 != 0 && (iVar3 != 0 && (iVar5 != 0 && iVar7 != 0))) {
    if (uVar6 == 0) {
      local_5c = 2;
      local_58 = uVar6;
      local_54 = uVar6;
      local_50 = uVar6;
      iVar4 = stbtt__find_table(param_2,param_3,&DAT_002dce94);
      if (iVar4 == 0) {
        return 0;
      }
      *(undefined4 *)(param_1 + 100) = 0;
      *(int *)(param_1 + 0x34) = param_2 + iVar4;
      *(undefined4 *)(param_1 + 0x68) = 0;
      *(undefined4 *)(param_1 + 0x6c) = 0;
      *(undefined4 *)(param_1 + 0x70) = 0;
      *(undefined4 *)(param_1 + 0x74) = 0;
      *(undefined4 *)(param_1 + 0x78) = 0;
      *(undefined4 *)(param_1 + 0x3c) = 0x20000000;
      local_4c = *(int *)(param_1 + 0x34);
      local_44 = *(uint *)(param_1 + 0x3c);
      if (((int)local_44 < 2) || (local_44 == 2)) {
        uVar6 = 0;
      }
      else {
        uVar6 = (uint)*(byte *)(param_2 + iVar4 + 2);
      }
      local_48 = local_44;
      if ((int)uVar6 <= (int)local_44) {
        local_48 = uVar6;
      }
      stbtt__cff_get_index(&local_70,&local_4c);
      stbtt__cff_get_index(local_34,&local_4c);
      stbtt__cff_index_get_isra_2(&local_70,local_34[0],local_2c,0);
      local_40 = local_70;
      uStack_3c = uStack_6c;
      iStack_38 = iStack_68;
      stbtt__cff_get_index(&local_70,&local_4c);
      stbtt__cff_get_index(&local_70,&local_4c);
      *(undefined4 *)(param_1 + 0x4c) = local_70;
      *(undefined4 *)(param_1 + 0x50) = uStack_6c;
      *(int *)(param_1 + 0x54) = iStack_68;
      stbtt__dict_get_ints(&local_40,0x11,1,&local_58);
      stbtt__dict_get_ints(&local_40,0x106,1,&local_5c);
      stbtt__dict_get_ints(&local_40,0x124,1,&local_54);
      stbtt__dict_get_ints(&local_40,0x125,1,&local_50);
      stbtt__get_subrs(&local_70,local_4c,local_48,local_44,local_40,uStack_3c,iStack_38);
      *(undefined4 *)(param_1 + 0x58) = local_70;
      *(undefined4 *)(param_1 + 0x5c) = uStack_6c;
      *(int *)(param_1 + 0x60) = iStack_68;
      if (local_5c != 2) {
        return 0;
      }
      if (local_58 == 0) {
        return 0;
      }
      if (local_54 != 0) {
        if (local_50 == 0) {
          return 0;
        }
        uVar6 = local_54 >> 0x1f;
        if ((int)local_44 < (int)local_54) {
          uVar6 = 1;
        }
        local_48 = local_54;
        if (uVar6 != 0) {
          local_48 = local_44;
        }
        stbtt__cff_get_index(&local_70,&local_4c);
        uVar6 = local_44 - local_50;
        uVar10 = (uVar6 | local_50) >> 0x1f;
        if ((int)local_44 < (int)local_50) {
          uVar10 = 1;
        }
        *(undefined4 *)(param_1 + 100) = local_70;
        *(undefined4 *)(param_1 + 0x68) = uStack_6c;
        *(int *)(param_1 + 0x6c) = iStack_68;
        uVar11 = local_50;
        iVar4 = local_4c;
        if (uVar10 != 0) {
          uVar6 = 0;
          uVar11 = 0;
          iVar4 = iStack_68;
        }
        *(uint *)(param_1 + 0x78) = uVar6;
        if (uVar10 == 0) {
          uVar11 = iVar4 + uVar11;
        }
        *(uint *)(param_1 + 0x70) = uVar11;
        *(undefined4 *)(param_1 + 0x74) = 0;
      }
      uVar6 = local_58 >> 0x1f;
      if ((int)local_44 < (int)local_58) {
        uVar6 = 1;
      }
      local_48 = local_44;
      if (uVar6 == 0) {
        local_48 = local_58;
      }
      stbtt__cff_get_index(&local_70,&local_4c);
      *(undefined4 *)(param_1 + 0x40) = local_70;
      *(undefined4 *)(param_1 + 0x44) = uStack_6c;
      *(int *)(param_1 + 0x48) = iStack_68;
    }
    else if (iVar4 == 0) {
      return 0;
    }
    iVar4 = stbtt__find_table(param_2,param_3,&DAT_002dce9c);
    if (iVar4 == 0) {
      iVar4 = 0xffff;
    }
    else {
      iVar4 = (uint)*(byte *)(param_2 + iVar4 + 4 + 1) +
              (uint)*(byte *)(param_2 + iVar4 + 4) * 0x100;
    }
    *(int *)(param_1 + 0xc) = iVar4;
    bVar1 = *(byte *)(param_2 + iVar3 + 2);
    bVar2 = *(byte *)(param_2 + iVar3 + 2 + 1);
    *(undefined4 *)(param_1 + 0x2c) = 0;
    iVar4 = (uint)bVar2 + (uint)bVar1 * 0x100;
    if (iVar4 != 0) {
      iVar5 = param_2 + iVar3;
      do {
        iVar7 = (uint)*(byte *)(iVar5 + 5) + (uint)*(byte *)(iVar5 + 4) * 0x100;
        if ((iVar7 == 0) ||
           ((iVar7 == 3 &&
            ((iVar7 = (uint)*(byte *)(iVar5 + 7) + (uint)*(byte *)(iVar5 + 6) * 0x100, iVar7 == 1 ||
             (iVar7 == 10)))))) {
          *(uint *)(param_1 + 0x2c) =
               (uint)*(byte *)(iVar5 + 9) * 0x10000 + (uint)*(byte *)(iVar5 + 8) * 0x1000000 +
               (uint)*(byte *)(iVar5 + 10) * 0x100 + (uint)*(byte *)(iVar5 + 0xb) + iVar3;
        }
        iVar5 = iVar5 + 8;
      } while (iVar5 != param_2 + iVar3 + iVar4 * 8);
      if (*(int *)(param_1 + 0x2c) != 0) {
        iVar3 = *(int *)(param_1 + 0x14) + 0x32;
        *(uint *)(param_1 + 0x30) =
             (uint)*(byte *)(param_2 + iVar3 + 1) + (uint)*(byte *)(param_2 + iVar3) * 0x100;
        return 1;
      }
    }
  }
  return 0;
}
