/* ============================================================
 * xmp3_UnpackScaleFactors   @ 0x002b8ce8   size=2660B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

int xmp3_UnpackScaleFactors
              (undefined4 *param_1,undefined4 param_2,uint *param_3,int param_4,int param_5,
              int param_6)

{
  undefined1 uVar1;
  undefined1 uVar2;
  undefined1 uVar3;
  uint *puVar4;
  uint *puVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  undefined1 *puVar10;
  uint *puVar11;
  uint *puVar12;
  int *piVar13;
  uint uVar14;
  int iVar15;
  uint uVar16;
  int iVar17;
  int iVar18;
  undefined1 *puVar19;
  int iVar20;
  int iVar21;
  uint uVar22;
  bool bVar23;
  undefined1 auStack_58 [16];
  uint local_48 [9];
  
  if (param_1 == (undefined4 *)0x0) {
    return -1;
  }
  piVar13 = (int *)*param_1;
  if (((piVar13 == (int *)0x0) || (iVar21 = param_1[1], iVar21 == 0)) ||
     (iVar15 = param_1[2], iVar15 == 0)) {
    return -1;
  }
  iVar8 = param_4 + *param_3 + 7;
  if (iVar8 < 0) {
    iVar8 = param_4 + *param_3 + 0xe;
  }
  xmp3_SetBitstreamPointer(auStack_58,iVar8 >> 3,param_2);
  if (*param_3 != 0) {
    xmp3_GetBits(auStack_58);
  }
  if (*piVar13 == 0) {
    iVar8 = iVar21 + param_6 * 0x48 + param_5 * 0x90;
    uVar2 = (&SFLenTab)[*(int *)(iVar8 + 0x34) * 2];
    uVar1 = (&DAT_002e1421)[*(int *)(iVar8 + 0x34) * 2];
    if (*(int *)(iVar8 + 0x3c) != 2) {
      if (param_5 == 0) {
        iVar8 = param_6 * 0x3e;
        puVar19 = (undefined1 *)(iVar15 + iVar8 + -1);
        do {
          uVar3 = xmp3_GetBits(auStack_58,uVar2);
          puVar19 = puVar19 + 1;
          *puVar19 = uVar3;
        } while ((undefined1 *)(iVar15 + iVar8 + 10) != puVar19);
        puVar19 = (undefined1 *)(iVar15 + iVar8 + 10);
        do {
          uVar2 = xmp3_GetBits(auStack_58,uVar1);
          puVar19 = puVar19 + 1;
          *puVar19 = uVar2;
        } while ((undefined1 *)(iVar15 + iVar8 + 0x14) != puVar19);
      }
      else {
        iVar8 = param_6 * 0x10 + 8;
        iVar7 = iVar21 + iVar8;
        if (*(int *)(iVar21 + iVar8) == 0) {
          puVar19 = (undefined1 *)(iVar15 + param_6 * 0x3e + param_5 * 0x7c + -1);
          do {
            uVar3 = xmp3_GetBits(auStack_58,uVar2);
            puVar19 = puVar19 + 1;
            *puVar19 = uVar3;
          } while (puVar19 != (undefined1 *)(iVar15 + param_6 * 0x3e + 5 + param_5 * 0x7c));
        }
        else {
          iVar8 = param_6 * 0x3e;
          puVar10 = (undefined1 *)(iVar15 + iVar8 + -1);
          puVar19 = (undefined1 *)(iVar15 + param_5 * 0x7c + iVar8 + -1);
          do {
            puVar10 = puVar10 + 1;
            puVar19 = puVar19 + 1;
            *puVar19 = *puVar10;
          } while (puVar10 != (undefined1 *)(iVar15 + iVar8 + 5));
        }
        if (*(int *)(iVar7 + 4) == 0) {
          puVar19 = (undefined1 *)(iVar15 + param_6 * 0x3e + param_5 * 0x7c + 5);
          do {
            uVar3 = xmp3_GetBits(auStack_58,uVar2);
            puVar19 = puVar19 + 1;
            *puVar19 = uVar3;
          } while (puVar19 != (undefined1 *)(iVar15 + param_6 * 0x3e + 10 + param_5 * 0x7c));
        }
        else {
          iVar8 = param_6 * 0x3e;
          puVar19 = (undefined1 *)(iVar15 + iVar8 + 5);
          puVar10 = (undefined1 *)(iVar15 + param_5 * 0x7c + iVar8 + 5);
          do {
            puVar19 = puVar19 + 1;
            puVar10 = puVar10 + 1;
            *puVar10 = *puVar19;
          } while (puVar19 != (undefined1 *)(iVar15 + iVar8 + 10));
        }
        if (*(int *)(iVar7 + 8) == 0) {
          puVar19 = (undefined1 *)(iVar15 + param_6 * 0x3e + param_5 * 0x7c + 10);
          do {
            uVar2 = xmp3_GetBits(auStack_58,uVar1);
            puVar19 = puVar19 + 1;
            *puVar19 = uVar2;
          } while (puVar19 != (undefined1 *)(iVar15 + param_6 * 0x3e + 0xf + param_5 * 0x7c));
        }
        else {
          iVar8 = param_6 * 0x3e;
          puVar19 = (undefined1 *)(iVar15 + iVar8 + 10);
          puVar10 = (undefined1 *)(iVar15 + param_5 * 0x7c + iVar8 + 10);
          do {
            puVar19 = puVar19 + 1;
            puVar10 = puVar10 + 1;
            *puVar10 = *puVar19;
          } while (puVar19 != (undefined1 *)(iVar15 + iVar8 + 0xf));
        }
        if (*(int *)(iVar7 + 0xc) == 0) {
          puVar19 = (undefined1 *)(iVar15 + param_6 * 0x3e + param_5 * 0x7c + 0xf);
          do {
            uVar2 = xmp3_GetBits(auStack_58,uVar1);
            puVar19 = puVar19 + 1;
            *puVar19 = uVar2;
          } while (puVar19 != (undefined1 *)(iVar15 + param_6 * 0x3e + 0x14 + param_5 * 0x7c));
        }
        else {
          iVar8 = param_6 * 0x3e;
          puVar19 = (undefined1 *)(iVar15 + iVar8 + 0xf);
          puVar10 = (undefined1 *)(iVar15 + param_5 * 0x7c + iVar8 + 0xf);
          do {
            puVar19 = puVar19 + 1;
            puVar10 = puVar10 + 1;
            *puVar10 = *puVar19;
          } while (puVar19 != (undefined1 *)(iVar15 + iVar8 + 0x14));
        }
        iVar15 = iVar15 + param_6 * 0x3e + param_5 * 0x7c;
        *(undefined1 *)(iVar15 + 0x15) = 0;
        *(undefined1 *)(iVar15 + 0x16) = 0;
      }
      goto LAB_002b8f68;
    }
    iVar7 = 0;
    if (*(int *)(iVar8 + 0x40) != 0) {
      puVar19 = (undefined1 *)(iVar15 + param_5 * 0x7c + param_6 * 0x3e + -1);
      do {
        uVar3 = xmp3_GetBits(auStack_58,uVar2);
        puVar19 = puVar19 + 1;
        *puVar19 = uVar3;
      } while ((undefined1 *)(iVar15 + param_6 * 0x3e + 7 + param_5 * 0x7c) != puVar19);
      iVar7 = 3;
    }
    iVar17 = param_6 * 0x3e + param_5 * 0x7c;
    iVar8 = iVar15 + iVar7 * 3 + iVar17;
    do {
      uVar3 = xmp3_GetBits(auStack_58,uVar2);
      iVar7 = iVar7 + 1;
      *(undefined1 *)(iVar8 + 0x17) = uVar3;
      uVar3 = xmp3_GetBits(auStack_58,uVar2);
      *(undefined1 *)(iVar8 + 0x18) = uVar3;
      uVar3 = xmp3_GetBits(auStack_58,uVar2);
      *(undefined1 *)(iVar8 + 0x19) = uVar3;
      iVar8 = iVar8 + 3;
    } while (iVar7 != 6);
    iVar8 = iVar15 + iVar17 + 0x12;
    do {
      uVar2 = xmp3_GetBits(auStack_58,uVar1);
      iVar7 = iVar8 + 3;
      *(undefined1 *)(iVar8 + 0x17) = uVar2;
      uVar2 = xmp3_GetBits(auStack_58,uVar1);
      *(undefined1 *)(iVar8 + 0x18) = uVar2;
      uVar2 = xmp3_GetBits(auStack_58,uVar1);
      *(undefined1 *)(iVar8 + 0x19) = uVar2;
      iVar8 = iVar7;
    } while (iVar15 + param_6 * 0x3e + 0x24 + param_5 * 0x7c != iVar7);
  }
  else {
    uVar16 = ~piVar13[8] & 1;
    if (param_6 != 1) {
      uVar16 = 1;
    }
    iVar8 = iVar21 + param_6 * 0x48 + param_5 * 0x90;
    uVar6 = *(uint *)(iVar8 + 0x34);
    if (uVar16 == 0) {
      iVar8 = (int)uVar6 >> 1;
      uVar14 = uVar6 & 1;
      if (iVar8 < 0xb4) {
        local_48[3] = uVar16;
        local_48[0] = iVar8 / 0x24;
        uVar22 = 3;
        local_48[1] = (iVar8 % 0x24) / 6;
        local_48[2] = (iVar8 % 0x24) % 6;
      }
      else if (iVar8 < 0xf4) {
        uVar6 = iVar8 - 0xb4;
        local_48[3] = uVar16;
        uVar22 = 4;
        local_48[1] = (uVar6 & 0xf) >> 2;
        local_48[0] = (int)uVar6 >> 4;
        local_48[2] = uVar6 & 3;
      }
      else {
        local_48[3] = uVar16;
        local_48[2] = uVar16;
        uVar22 = 5;
        local_48[0] = (iVar8 + -0xf4) / 3;
        local_48[1] = (iVar8 + -0xf4) % 3;
      }
    }
    else if ((int)uVar6 < 400) {
      local_48[2] = (uVar6 & 0xf) >> 2;
      local_48[3] = uVar6 & 3;
      local_48[0] = ((int)uVar6 >> 4) / 5;
      local_48[1] = ((int)uVar6 >> 4) % 5;
      uVar14 = 0;
      uVar16 = 0;
      uVar22 = 0;
    }
    else if ((int)uVar6 < 500) {
      uVar22 = 1;
      iVar8 = (int)(uVar6 - 400) >> 2;
      uVar14 = 0;
      local_48[3] = 0;
      local_48[2] = uVar6 - 400 & 3;
      local_48[0] = iVar8 / 5;
      local_48[1] = iVar8 % 5;
      uVar16 = uVar14;
    }
    else {
      uVar9 = 0;
      local_48[3] = 0;
      local_48[0] = (int)(uVar6 - 500) / 3;
      bVar23 = *(int *)(iVar8 + 0x40) == 0;
      local_48[2] = 0;
      if (bVar23) {
        uVar16 = 1;
      }
      if (bVar23) {
        uVar9 = 2;
      }
      local_48[1] = (int)(uVar6 - 500) % 3;
      uVar14 = 0;
      uVar22 = uVar9;
      if (!bVar23) {
        local_48[2] = local_48[1];
        local_48[1] = local_48[0];
        uVar22 = 2;
        uVar14 = uVar9;
        uVar16 = 1;
      }
    }
    uVar6 = local_48[0];
    iVar8 = iVar21 + param_6 * 0x48 + param_5 * 0x90;
    iVar7 = *(int *)(iVar8 + 0x3c);
    if (iVar7 == 2) {
      if (*(int *)(iVar8 + 0x40) == 0) {
        iVar8 = 1;
      }
      else {
        iVar8 = 2;
      }
    }
    else {
      iVar8 = 0;
    }
    if (param_6 == 1) {
      uVar9 = piVar13[8] & 1;
    }
    else {
      uVar9 = 0;
    }
    iVar8 = (uVar22 * 3 + iVar8) * 4;
    local_48[4] = (uint)(byte)NRTab[iVar8];
    local_48[5] = (uint)(byte)NRTab[iVar8 + 1];
    local_48[7] = (uint)(byte)NRTab[iVar8 + 3];
    local_48[6] = (uint)(byte)NRTab[iVar8 + 2];
    if (uVar9 != 0) {
      puVar4 = local_48;
      puVar5 = local_48 + 4;
      puVar11 = (uint *)(iVar15 + 0xfc);
      do {
        uVar22 = *puVar5;
        puVar12 = puVar11 + 1;
        *puVar11 = *puVar4;
        puVar11[4] = uVar22;
        puVar4 = puVar4 + 1;
        puVar5 = puVar5 + 1;
        puVar11 = puVar12;
      } while (puVar12 != (uint *)(iVar15 + 0x10c));
      *(uint *)(iVar15 + 0xf8) = uVar14;
    }
    iVar8 = iVar21 + param_6 * 0x48 + param_5 * 0x90;
    *(uint *)(iVar8 + 100) = uVar16;
    if (iVar7 != 2) {
      iVar17 = 0;
      iVar7 = 0;
      iVar8 = param_6 * 0x3e + param_5 * 0x7c;
      do {
        uVar16 = (local_48 + 4)[iVar7];
        if (0 < (int)uVar16) {
          puVar19 = (undefined1 *)(iVar15 + iVar8 + iVar17 + -1);
          uVar6 = local_48[iVar7];
          do {
            uVar2 = xmp3_GetBits(auStack_58,uVar6);
            puVar19 = puVar19 + 1;
            *puVar19 = uVar2;
          } while (puVar19 != (undefined1 *)(iVar15 + iVar8 + -1 + iVar17 + uVar16));
          iVar17 = iVar17 + uVar16;
        }
        iVar7 = iVar7 + 1;
      } while (iVar7 != 4);
      iVar15 = iVar15 + param_6 * 0x3e + param_5 * 0x7c;
      *(undefined1 *)(iVar15 + 0x16) = 0;
      *(undefined1 *)(iVar15 + 0x15) = 0;
      goto LAB_002b8f68;
    }
    if (*(int *)(iVar8 + 0x40) == 0) {
      iVar8 = 0;
      iVar7 = 0;
    }
    else {
      puVar19 = (undefined1 *)(iVar15 + param_6 * 0x3e + param_5 * 0x7c + -1);
      do {
        uVar2 = xmp3_GetBits(auStack_58,uVar6);
        puVar19 = puVar19 + 1;
        *puVar19 = uVar2;
      } while (puVar19 != (undefined1 *)(iVar15 + param_6 * 0x3e + 5 + param_5 * 0x7c));
      iVar8 = 3;
      iVar7 = 1;
    }
    puVar4 = local_48 + iVar7 + 3;
    iVar17 = param_6 * 0x3e + param_5 * 0x7c;
    do {
      puVar4 = puVar4 + 1;
      iVar18 = iVar8;
      if (0 < (int)*puVar4) {
        iVar18 = *puVar4 + iVar8;
        uVar16 = local_48[iVar7];
        iVar8 = iVar15 + iVar8 * 3 + iVar17;
        do {
          uVar2 = xmp3_GetBits(auStack_58,uVar16);
          iVar20 = iVar8 + 3;
          *(undefined1 *)(iVar8 + 0x17) = uVar2;
          uVar2 = xmp3_GetBits(auStack_58,uVar16);
          *(undefined1 *)(iVar8 + 0x18) = uVar2;
          uVar2 = xmp3_GetBits(auStack_58,uVar16);
          *(undefined1 *)(iVar8 + 0x19) = uVar2;
          iVar8 = iVar20;
        } while (iVar20 != iVar15 + iVar18 * 3 + iVar17);
      }
      iVar7 = iVar7 + 1;
      iVar8 = iVar18;
    } while (iVar7 != 4);
  }
  iVar15 = iVar15 + param_6 * 0x3e + param_5 * 0x7c;
  *(undefined1 *)(iVar15 + 0x3d) = 0;
  *(undefined1 *)(iVar15 + 0x3c) = 0;
  *(undefined1 *)(iVar15 + 0x3b) = 0;
LAB_002b8f68:
  param_1[param_6 + param_5 * 2 + 0x1f8] =
       *(undefined4 *)(iVar21 + param_6 * 0x48 + param_5 * 0x90 + 0x28);
  iVar21 = xmp3_CalcBitsUsed(auStack_58,param_2,*param_3);
  uVar16 = *param_3;
  *param_3 = iVar21 + uVar16 & 7;
  return (int)(iVar21 + uVar16) >> 3;
}
