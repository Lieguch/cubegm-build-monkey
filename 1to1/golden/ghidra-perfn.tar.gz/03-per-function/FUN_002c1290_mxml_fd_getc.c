/* ============================================================
 * mxml_fd_getc   @ 0x002c1290   size=1340B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

uint mxml_fd_getc(int param_1,int *param_2)

{
  byte bVar1;
  undefined1 uVar2;
  ushort uVar3;
  int iVar4;
  byte *pbVar5;
  byte *pbVar6;
  undefined1 *puVar7;
  undefined1 *puVar8;
  uint uVar9;
  byte *pbVar10;
  undefined1 *puVar11;
  uint uVar12;
  bool bVar13;
  
  pbVar10 = *(byte **)(param_1 + 4);
  while( true ) {
    if (*(byte **)(param_1 + 8) <= pbVar10) {
      iVar4 = mxml_fd_read_part_1(param_1);
      if (iVar4 < 0) {
        return 0xffffffff;
      }
      pbVar10 = *(byte **)(param_1 + 4);
    }
    iVar4 = *param_2;
    pbVar6 = pbVar10 + 1;
    *(byte **)(param_1 + 4) = pbVar6;
    bVar1 = *pbVar10;
    uVar12 = (uint)bVar1;
    if (iVar4 == 1) break;
    if (iVar4 == 2) {
      if ((*(byte **)(param_1 + 8) <= pbVar6) && (iVar4 = mxml_fd_read_part_1(param_1), iVar4 < 0))
      {
        return 0xffffffff;
      }
      puVar7 = *(undefined1 **)(param_1 + 4);
      puVar11 = puVar7 + 1;
      *(undefined1 **)(param_1 + 4) = puVar11;
      uVar12 = (uint)CONCAT11(*puVar7,bVar1);
      if (uVar12 < 0x20) {
        bVar13 = 0xc < uVar12;
        if (uVar12 != 0xd) {
          bVar13 = uVar12 != 9;
        }
        if (bVar13 && (uVar12 != 0xd && uVar12 != 10)) {
          mxml_error("Bad control character 0x%02x not allowed by XML standard!",uVar12);
          return 0xffffffff;
        }
      }
      if (0x3ff < uVar12 - 0xd800) {
        return uVar12;
      }
      puVar7 = *(undefined1 **)(param_1 + 8);
      if (puVar7 <= puVar11) {
        iVar4 = mxml_fd_read_part_1(param_1);
        if (iVar4 < 0) {
          return 0xffffffff;
        }
        puVar11 = *(undefined1 **)(param_1 + 4);
        puVar7 = *(undefined1 **)(param_1 + 8);
      }
      puVar8 = puVar11 + 1;
      *(undefined1 **)(param_1 + 4) = puVar8;
      uVar2 = *puVar11;
      if (puVar7 <= puVar8) {
        iVar4 = mxml_fd_read_part_1(param_1);
        if (iVar4 < 0) {
          return 0xffffffff;
        }
        puVar8 = *(undefined1 **)(param_1 + 4);
      }
      *(undefined1 **)(param_1 + 4) = puVar8 + 1;
      uVar3 = CONCAT11(*puVar8,uVar2);
      goto joined_r0x002c152c;
    }
    if (iVar4 != 0) {
      return uVar12;
    }
    if ((bVar1 & 0x80) == 0) {
      if (0x1f < uVar12) {
        return uVar12;
      }
      bVar13 = 0xc < uVar12;
      if (uVar12 != 0xd) {
        bVar13 = uVar12 != 9;
      }
      if (bVar13 && (uVar12 != 0xd && uVar12 != 10)) {
        mxml_error("Bad control character 0x%02x not allowed by XML standard!",uVar12);
        return 0xffffffff;
      }
      return uVar12;
    }
    if (uVar12 == 0xfe) {
      if (*(byte **)(param_1 + 8) <= pbVar6) {
        iVar4 = mxml_fd_read_part_1(param_1);
        if (iVar4 < 0) {
          return 0xffffffff;
        }
        pbVar6 = *(byte **)(param_1 + 4);
      }
      pbVar10 = pbVar6 + 1;
      *(byte **)(param_1 + 4) = pbVar10;
      if (*pbVar6 != 0xff) {
        return 0xffffffff;
      }
      *param_2 = 1;
    }
    else if (uVar12 == 0xff) {
      if (*(byte **)(param_1 + 8) <= pbVar6) {
        iVar4 = mxml_fd_read_part_1(param_1);
        if (iVar4 < 0) {
          return 0xffffffff;
        }
        pbVar6 = *(byte **)(param_1 + 4);
      }
      pbVar10 = pbVar6 + 1;
      *(byte **)(param_1 + 4) = pbVar10;
      if (*pbVar6 != 0xfe) {
        return 0xffffffff;
      }
      *param_2 = 2;
    }
    else {
      if ((uVar12 & 0xe0) == 0xc0) {
        if ((*(byte **)(param_1 + 8) <= pbVar6) && (iVar4 = mxml_fd_read_part_1(param_1), iVar4 < 0)
           ) {
          return 0xffffffff;
        }
        pbVar10 = *(byte **)(param_1 + 4);
        *(byte **)(param_1 + 4) = pbVar10 + 1;
        uVar9 = (uint)*pbVar10;
        if ((uVar9 & 0xc0) != 0x80) {
          return 0xffffffff;
        }
        uVar12 = uVar9 & 0x3f | (uVar12 & 0x1f) << 6;
        if (uVar12 < 0x80) {
          mxml_error("Invalid UTF-8 sequence for character 0x%04x!",uVar12);
          return 0xffffffff;
        }
        return uVar12;
      }
      if ((uVar12 & 0xf0) != 0xe0) {
        if ((uVar12 & 0xf8) != 0xf0) {
          return 0xffffffff;
        }
        if ((*(byte **)(param_1 + 8) <= pbVar6) && (iVar4 = mxml_fd_read_part_1(param_1), iVar4 < 0)
           ) {
          return 0xffffffff;
        }
        pbVar10 = *(byte **)(param_1 + 4);
        pbVar6 = pbVar10 + 1;
        *(byte **)(param_1 + 4) = pbVar6;
        uVar9 = (uint)*pbVar10;
        if ((uVar9 & 0xc0) != 0x80) {
          return 0xffffffff;
        }
        if (*(byte **)(param_1 + 8) <= pbVar6) {
          iVar4 = mxml_fd_read_part_1(param_1);
          if (iVar4 < 0) {
            return 0xffffffff;
          }
          pbVar6 = *(byte **)(param_1 + 4);
        }
        pbVar10 = pbVar6 + 1;
        *(byte **)(param_1 + 4) = pbVar10;
        bVar1 = *pbVar6;
        if ((bVar1 & 0xc0) != 0x80) {
          return 0xffffffff;
        }
        if (*(byte **)(param_1 + 8) <= pbVar10) {
          iVar4 = mxml_fd_read_part_1(param_1);
          if (iVar4 < 0) {
            return 0xffffffff;
          }
          pbVar10 = *(byte **)(param_1 + 4);
        }
        *(byte **)(param_1 + 4) = pbVar10 + 1;
        if ((*pbVar10 & 0xc0) != 0x80) {
          return 0xffffffff;
        }
        uVar12 = *pbVar10 & 0x3f | (bVar1 & 0x3f | (uVar9 & 0x3f | (uVar12 & 7) << 6) << 6) << 6;
        if (uVar12 < 0x10000) {
          mxml_error("Invalid UTF-8 sequence for character 0x%04x!",uVar12);
          return 0xffffffff;
        }
        return uVar12;
      }
      if (*(byte **)(param_1 + 8) <= pbVar6) {
        iVar4 = mxml_fd_read_part_1(param_1);
        if (iVar4 < 0) {
          return 0xffffffff;
        }
        pbVar6 = *(byte **)(param_1 + 4);
      }
      pbVar5 = pbVar6 + 1;
      *(byte **)(param_1 + 4) = pbVar5;
      bVar1 = *pbVar6;
      if ((bVar1 & 0xc0) != 0x80) {
        return 0xffffffff;
      }
      if (*(byte **)(param_1 + 8) <= pbVar5) {
        iVar4 = mxml_fd_read_part_1(param_1);
        if (iVar4 < 0) {
          return 0xffffffff;
        }
        pbVar5 = *(byte **)(param_1 + 4);
      }
      pbVar10 = pbVar5 + 1;
      *(byte **)(param_1 + 4) = pbVar10;
      if ((*pbVar5 & 0xc0) != 0x80) {
        return 0xffffffff;
      }
      uVar12 = *pbVar5 & 0x3f | (bVar1 & 0x3f | (uVar12 & 0xf) << 6) << 6;
      if (uVar12 < 0x800) {
        mxml_error("Invalid UTF-8 sequence for character 0x%04x!",uVar12);
        return 0xffffffff;
      }
      if (uVar12 != 0xfeff) {
        return uVar12;
      }
    }
  }
  if ((*(byte **)(param_1 + 8) <= pbVar6) && (iVar4 = mxml_fd_read_part_1(param_1), iVar4 < 0)) {
    return 0xffffffff;
  }
  puVar11 = *(undefined1 **)(param_1 + 4);
  puVar7 = puVar11 + 1;
  *(undefined1 **)(param_1 + 4) = puVar7;
  uVar12 = (uint)CONCAT11(bVar1,*puVar11);
  if (uVar12 < 0x20) {
    bVar13 = 0xc < uVar12;
    if (uVar12 != 0xd) {
      bVar13 = uVar12 != 9;
    }
    if (bVar13 && (uVar12 != 0xd && uVar12 != 10)) {
      mxml_error("Bad control character 0x%02x not allowed by XML standard!",uVar12);
      return 0xffffffff;
    }
  }
  if (0x3ff < uVar12 - 0xd800) {
    return uVar12;
  }
  puVar11 = *(undefined1 **)(param_1 + 8);
  if (puVar11 <= puVar7) {
    iVar4 = mxml_fd_read_part_1(param_1);
    if (iVar4 < 0) {
      return 0xffffffff;
    }
    puVar7 = *(undefined1 **)(param_1 + 4);
    puVar11 = *(undefined1 **)(param_1 + 8);
  }
  puVar8 = puVar7 + 1;
  *(undefined1 **)(param_1 + 4) = puVar8;
  uVar2 = *puVar7;
  if (puVar11 <= puVar8) {
    iVar4 = mxml_fd_read_part_1(param_1);
    if (iVar4 < 0) {
      return 0xffffffff;
    }
    puVar8 = *(undefined1 **)(param_1 + 4);
  }
  *(undefined1 **)(param_1 + 4) = puVar8 + 1;
  uVar3 = CONCAT11(uVar2,*puVar8);
joined_r0x002c152c:
  if (0x3fe < uVar3 - 0xdc00) {
    return 0xffffffff;
  }
  return ((uVar12 & 0x3ff) << 10 | uVar3 & 0x3ff) + 0x10000;
}
