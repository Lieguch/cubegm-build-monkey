/* ============================================================
 * mxmlEntityGetName   @ 0x002bedc4   size=188B   callers=2
 * module: 04_mini_xml
 * ============================================================ */

undefined * mxmlEntityGetName(undefined4 param_1)

{
  switch(param_1) {
  case 0x22:
    return &DAT_002de080;
  case 0x23:
    break;
  case 0x24:
    break;
  case 0x25:
    break;
  case 0x26:
    return &DAT_002de074;
  case 0x27:
    break;
  case 0x28:
    break;
  case 0x29:
    break;
  case 0x2a:
    break;
  case 0x2b:
    break;
  case 0x2c:
    break;
  case 0x2d:
    break;
  case 0x2e:
    break;
  case 0x2f:
    break;
  case 0x30:
    break;
  case 0x31:
    break;
  case 0x32:
    break;
  case 0x33:
    break;
  case 0x34:
    break;
  case 0x35:
    break;
  case 0x36:
    break;
  case 0x37:
    break;
  case 0x38:
    break;
  case 0x39:
    break;
  case 0x3a:
    break;
  case 0x3b:
    break;
  case 0x3c:
    return &DAT_002de078;
  case 0x3d:
    break;
  case 0x3e:
    return &DAT_002de07c;
  }
  return (undefined *)0x0;
}
