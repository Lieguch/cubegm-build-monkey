/* ============================================================
 * mxml_file_getc   @ 0x002bf7ec   size=848B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

uint mxml_file_getc(_IO_FILE *param_1,int *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  bool bVar6;
  
  while( true ) {
    uVar1 = _IO_getc(param_1);
    if (uVar1 == 0xffffffff) {
      return 0xffffffff;
    }
    iVar5 = *param_2;
    if (iVar5 == 1) break;
    if (iVar5 == 2) {
      iVar5 = _IO_getc(param_1);
      uVar1 = uVar1 | iVar5 << 8;
      if ((int)uVar1 < 0x20) {
        bVar6 = 0xc < uVar1;
        if (uVar1 != 0xd) {
          bVar6 = uVar1 != 9;
        }
        if (bVar6 && (uVar1 != 0xd && uVar1 != 10)) {
          mxml_error("Bad control character 0x%02x not allowed by XML standard!",uVar1);
          return 0xffffffff;
        }
      }
      if (0x3ff < uVar1 - 0xd800) {
        return uVar1;
      }
      uVar2 = _IO_getc(param_1);
      iVar5 = _IO_getc(param_1);
      uVar2 = uVar2 | iVar5 << 8;
      goto joined_r0x002bf9a0;
    }
    if (iVar5 != 0) {
      return uVar1;
    }
    if ((uVar1 & 0x80) == 0) {
      if (0x1f < (int)uVar1) {
        return uVar1;
      }
      bVar6 = 0xc < uVar1;
      if (uVar1 != 0xd) {
        bVar6 = uVar1 != 9;
      }
      if (bVar6 && (uVar1 != 0xd && uVar1 != 10)) {
        mxml_error("Bad control character 0x%02x not allowed by XML standard!",uVar1);
        return 0xffffffff;
      }
      return uVar1;
    }
    if (uVar1 == 0xfe) {
      iVar5 = _IO_getc(param_1);
      if (iVar5 != 0xff) {
        return 0xffffffff;
      }
      *param_2 = 1;
    }
    else if (uVar1 == 0xff) {
      iVar5 = _IO_getc(param_1);
      if (iVar5 != 0xfe) {
        return 0xffffffff;
      }
      *param_2 = 2;
    }
    else {
      if ((uVar1 & 0xe0) == 0xc0) {
        uVar2 = _IO_getc(param_1);
        if (uVar2 == 0xffffffff) {
          return 0xffffffff;
        }
        if ((uVar2 & 0xc0) != 0x80) {
          return 0xffffffff;
        }
        uVar1 = uVar2 & 0x3f | (uVar1 & 0x1f) << 6;
        if (uVar1 < 0x80) {
          mxml_error("Invalid UTF-8 sequence for character 0x%04x!",uVar1);
          return 0xffffffff;
        }
        return uVar1;
      }
      if ((uVar1 & 0xf0) != 0xe0) {
        if ((uVar1 & 0xf8) != 0xf0) {
          return 0xffffffff;
        }
        uVar2 = _IO_getc(param_1);
        if (uVar2 == 0xffffffff) {
          return 0xffffffff;
        }
        if ((uVar2 & 0xc0) != 0x80) {
          return 0xffffffff;
        }
        uVar3 = _IO_getc(param_1);
        if (uVar3 == 0xffffffff) {
          return 0xffffffff;
        }
        if ((uVar3 & 0xc0) != 0x80) {
          return 0xffffffff;
        }
        uVar4 = _IO_getc(param_1);
        if (uVar4 == 0xffffffff) {
          return 0xffffffff;
        }
        if ((uVar4 & 0xc0) != 0x80) {
          return 0xffffffff;
        }
        uVar1 = uVar4 & 0x3f | (uVar3 & 0x3f | (uVar2 & 0x3f | (uVar1 & 7) << 6) << 6) << 6;
        if (uVar1 < 0x10000) {
          mxml_error("Invalid UTF-8 sequence for character 0x%04x!",uVar1);
          return 0xffffffff;
        }
        return uVar1;
      }
      uVar2 = _IO_getc(param_1);
      if (uVar2 == 0xffffffff) {
        return 0xffffffff;
      }
      if ((uVar2 & 0xc0) != 0x80) {
        return 0xffffffff;
      }
      uVar3 = _IO_getc(param_1);
      if (uVar3 == 0xffffffff) {
        return 0xffffffff;
      }
      if ((uVar3 & 0xc0) != 0x80) {
        return 0xffffffff;
      }
      uVar1 = uVar3 & 0x3f | (uVar2 & 0x3f | (uVar1 & 0xf) << 6) << 6;
      if (uVar1 < 0x800) {
        mxml_error("Invalid UTF-8 sequence for character 0x%04x!",uVar1);
        return 0xffffffff;
      }
      if (uVar1 != 0xfeff) {
        return uVar1;
      }
    }
  }
  uVar2 = _IO_getc(param_1);
  uVar1 = uVar1 << 8 | uVar2;
  if ((int)uVar1 < 0x20) {
    bVar6 = 0xc < uVar1;
    if (uVar1 != 0xd) {
      bVar6 = uVar1 != 9;
    }
    if (bVar6 && (uVar1 != 0xd && uVar1 != 10)) {
      mxml_error("Bad control character 0x%02x not allowed by XML standard!",uVar1);
      return 0xffffffff;
    }
  }
  if (0x3ff < uVar1 - 0xd800) {
    return uVar1;
  }
  iVar5 = _IO_getc(param_1);
  uVar2 = _IO_getc(param_1);
  uVar2 = uVar2 | iVar5 << 8;
joined_r0x002bf9a0:
  if (0x3fe < uVar2 - 0xdc00) {
    return 0xffffffff;
  }
  return ((uVar1 & 0x3ff) << 10 | uVar2 & 0x3ff) + 0x10000;
}
