/* ============================================================
 * Unzip   @ 0x000126f4   size=484B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* TUnzip::Unzip(int, void*, unsigned int, unsigned int) [clone .part.7] */

undefined4 TUnzip::Unzip(int param_1,void *param_2,uint param_3,uint param_4)

{
  unz_s *puVar1;
  FILE *__stream;
  size_t sVar2;
  void *pvVar3;
  int iVar4;
  ZIPENTRY aZStack_4148 [304];
  undefined1 auStack_4018 [16388];
  
  pvVar3 = *(void **)(param_1 + 4);
  if (param_4 == 3) {
    if (pvVar3 != param_2) {
      if (pvVar3 != (void *)0xffffffff) {
        unzCloseCurrentFile(*(unz_s **)param_1);
      }
      puVar1 = *(unz_s **)param_1;
      *(undefined4 *)(param_1 + 4) = 0xffffffff;
      if (*(int *)(puVar1 + 4) <= (int)param_2) {
        return 0x10000;
      }
      iVar4 = *(int *)(puVar1 + 0x10);
      if ((int)param_2 < iVar4) {
        unzGoToFirstFile(puVar1);
        puVar1 = *(unz_s **)param_1;
        iVar4 = *(int *)(puVar1 + 0x10);
      }
      while (iVar4 < (int)param_2) {
        unzGoToNextFile(puVar1);
        puVar1 = *(unz_s **)param_1;
        iVar4 = *(int *)(puVar1 + 0x10);
      }
      unzOpenCurrentFile(puVar1);
      *(void **)(param_1 + 4) = param_2;
    }
    while( true ) {
      iVar4 = unzReadCurrentFile(*(unz_s **)param_1,(void *)param_3,0x4000);
      if (iVar4 < 0) break;
      param_3 = (uint)(param_3 + 0x4000);
      if (iVar4 == 0) {
LAB_000128c0:
        unzCloseCurrentFile(*(unz_s **)param_1);
        return 0;
      }
    }
  }
  else {
    if (pvVar3 != (void *)0xffffffff) {
      unzCloseCurrentFile(*(unz_s **)param_1);
    }
    puVar1 = *(unz_s **)param_1;
    *(undefined4 *)(param_1 + 4) = 0xffffffff;
    if (*(int *)(puVar1 + 4) <= (int)param_2) {
      return 0x10000;
    }
    if ((int)param_2 < *(int *)(puVar1 + 0x10)) {
      unzGoToFirstFile(puVar1);
      puVar1 = *(unz_s **)param_1;
    }
    iVar4 = *(int *)(puVar1 + 0x10);
    while (iVar4 < (int)param_2) {
      unzGoToNextFile(puVar1);
      puVar1 = *(unz_s **)param_1;
      iVar4 = *(int *)(puVar1 + 0x10);
    }
    Get((TUnzip *)param_1,(int)param_2,aZStack_4148);
    __stream = fopen((char *)param_3,"w+b");
    if (__stream == (FILE *)0x0) {
      return 0x200;
    }
    unzOpenCurrentFile(*(unz_s **)param_1);
    do {
      sVar2 = unzReadCurrentFile(*(unz_s **)param_1,auStack_4018,0x4000);
      if ((int)sVar2 < 0) break;
      if (sVar2 == 0) {
        fclose(__stream);
        goto LAB_000128c0;
      }
      sVar2 = fwrite(auStack_4018,sVar2,1,__stream);
    } while (sVar2 != 0);
    fclose(__stream);
  }
  unzCloseCurrentFile(*(unz_s **)param_1);
  return 0x400;
}
