/* ============================================================
 * MP3Decode   @ 0x002b8844   size=1088B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

undefined4 MP3Decode(int param_1,int *param_2,int *param_3,int param_4,int param_5)

{
  char *pcVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  size_t __n;
  int iVar7;
  int iVar8;
  char *pcVar9;
  void *__dest;
  int iVar10;
  int iVar11;
  int *unaff_r11;
  int *local_38;
  int local_2c [2];
  
  if (param_1 == 0) {
    return 0xfffffffb;
  }
  iVar2 = xmp3_UnpackFrameHeader(param_1,*param_2);
  if (iVar2 < 0) {
LAB_002b8c10:
    uVar5 = 0xfffffffa;
  }
  else {
    *param_2 = *param_2 + iVar2;
    iVar3 = xmp3_UnpackSideInfo(param_1);
    if (iVar3 < 0) {
      return 0xfffffff9;
    }
    iVar8 = *param_2;
    iVar7 = *param_3 - (iVar2 + iVar3);
    piVar6 = (int *)(iVar8 + iVar3);
    *param_2 = (int)piVar6;
    *param_3 = iVar7;
    if (*(int *)(param_1 + 0x7b8) == 0) {
      if (*(int *)(param_1 + 0x7b0) != 0) goto LAB_002b88c4;
      *(undefined4 *)(param_1 + 0x7b0) = 1;
      pcVar9 = (char *)(iVar8 - iVar2);
      iVar7 = *param_3;
      unaff_r11 = piVar6;
      do {
        iVar8 = MP3FindSyncWord(unaff_r11,iVar7);
        iVar11 = (int)unaff_r11 + iVar8;
        iVar7 = iVar7 - (iVar8 + 3);
        if (iVar8 < 0) {
          *(undefined4 *)(param_1 + 0x7b4) = 0xffffffff;
          return 0xfffffffd;
        }
        pcVar1 = (char *)((int)unaff_r11 + iVar8);
        unaff_r11 = (int *)(iVar11 + 3);
      } while (((*pcVar1 != *pcVar9) || (*(char *)(iVar11 + 1) != pcVar9[1])) ||
              (((*(byte *)(iVar11 + 2) ^ pcVar9[2]) & 0xfc) != 0));
      if ((pcVar9[2] & 2U) != 0) {
        iVar11 = iVar11 + -1;
      }
      iVar11 = iVar11 - (int)piVar6;
      *(int *)(param_1 + 0x7b4) = iVar11;
      if (iVar11 < 0) {
        return 0xfffffffd;
      }
      uVar5 = __aeabi_idiv(*(int *)(param_1 + 0x7c0) * (iVar2 + iVar11 + iVar3) * 8,
                           *(int *)(param_1 + 0x7c8) * *(int *)(param_1 + 0x7c4));
      *(undefined4 *)(param_1 + 0x7b8) = uVar5;
LAB_002b88c8:
      iVar2 = xmp3_CheckPadBit(param_1);
      *(int *)(param_1 + 0x7cc) = iVar11 + iVar2;
      iVar7 = *param_3;
    }
    else if (*(int *)(param_1 + 0x7b0) != 0) {
LAB_002b88c4:
      iVar11 = *(int *)(param_1 + 0x7b4);
      goto LAB_002b88c8;
    }
    if (param_5 == 0) {
      if (iVar7 < (int)*(size_t *)(param_1 + 0x7cc)) {
        return 0xffffffff;
      }
      iVar2 = *(int *)(param_1 + 0x7dc);
      __n = *(size_t *)(param_1 + 0x7d8);
      if (iVar2 < (int)__n) {
        memcpy((void *)(param_1 + 0x1c + iVar2),(void *)*param_2,*(size_t *)(param_1 + 0x7cc));
        iVar3 = *(int *)(param_1 + 0x7cc);
        iVar2 = *param_2;
        *(int *)(param_1 + 0x7dc) = *(int *)(param_1 + 0x7dc) + iVar3;
        iVar7 = *param_3;
        *param_2 = iVar2 + iVar3;
        *param_3 = iVar7 - iVar3;
        return 0xfffffffe;
      }
      __dest = (void *)(param_1 + 0x1c);
      memmove(__dest,(void *)((int)__dest + (iVar2 - __n)),__n);
      memcpy((void *)((int)__dest + *(int *)(param_1 + 0x7d8)),(void *)*param_2,
             *(size_t *)(param_1 + 0x7cc));
      iVar3 = *(int *)(param_1 + 0x7cc);
      iVar2 = *param_2;
      *(int *)(param_1 + 0x7dc) = *(int *)(param_1 + 0x7d8) + iVar3;
      iVar7 = *param_3;
      *param_2 = iVar2 + iVar3;
      *param_3 = iVar7 - iVar3;
    }
    else {
      *(int *)(param_1 + 0x7cc) = iVar7;
      if (*(int *)(param_1 + 0x7d8) != 0 || iVar7 < 1) goto LAB_002b8c10;
      *(int *)(param_1 + 0x7dc) = iVar7;
      __dest = (void *)*param_2;
      iVar2 = *param_3;
      *param_2 = (int)__dest + iVar7;
      *param_3 = iVar2 - iVar7;
    }
    piVar6 = *(int **)(param_1 + 0x7c4);
    iVar2 = 0;
    local_2c[0] = 0;
    local_38 = piVar6;
    if (0 < (int)piVar6) {
      local_38 = (int *)(param_1 + 0x7e0);
      unaff_r11 = local_2c;
    }
    iVar3 = *(int *)(param_1 + 0x7dc) << 3;
    if (0 < (int)piVar6) {
      do {
        if (0 < *(int *)(param_1 + 0x7bc)) {
          iVar7 = 0;
          piVar6 = local_38;
          do {
            iVar8 = local_2c[0];
            iVar4 = xmp3_UnpackScaleFactors(param_1,__dest,unaff_r11,iVar3,iVar2,iVar7);
            iVar11 = local_2c[0];
            iVar8 = (iVar4 * 8 - iVar8) + local_2c[0];
            iVar3 = iVar3 - iVar8;
            iVar8 = *piVar6 - iVar8;
            if (iVar3 < iVar8 || iVar4 < 0) {
              return 0xfffffff8;
            }
            iVar10 = iVar7 + 1;
            iVar7 = xmp3_DecodeHuffman(param_1,(int)__dest + iVar4,unaff_r11,iVar8,iVar2,iVar7);
            __dest = (void *)((int)__dest + iVar4 + iVar7);
            if (iVar7 < 0) {
              return 0xfffffff7;
            }
            iVar3 = iVar3 - ((iVar7 * 8 - iVar11) + local_2c[0]);
            iVar7 = iVar10;
            piVar6 = piVar6 + 1;
          } while (iVar10 < *(int *)(param_1 + 0x7bc));
        }
        iVar7 = xmp3_Dequantize(param_1,iVar2);
        if (iVar7 < 0) {
          return 0xfffffff6;
        }
        iVar7 = *(int *)(param_1 + 0x7bc);
        if (0 < iVar7) {
          iVar8 = 0;
          do {
            iVar11 = iVar8 + 1;
            iVar7 = xmp3_IMDCT(param_1,iVar2,iVar8);
            if (iVar7 < 0) {
              return 0xfffffff5;
            }
            iVar7 = *(int *)(param_1 + 0x7bc);
            iVar8 = iVar11;
          } while (iVar11 < iVar7);
        }
        iVar7 = xmp3_Subband(param_1,param_4 + iVar7 * *(int *)(param_1 + 0x7c8) * iVar2 * 2);
        if (iVar7 < 0) {
          return 0xfffffff4;
        }
        iVar2 = iVar2 + 1;
        local_38 = local_38 + 2;
      } while (iVar2 < *(int *)(param_1 + 0x7c4));
    }
    uVar5 = 0;
  }
  return uVar5;
}
