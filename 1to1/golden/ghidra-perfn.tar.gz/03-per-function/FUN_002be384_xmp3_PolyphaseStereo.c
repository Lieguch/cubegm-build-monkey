/* ============================================================
 * xmp3_PolyphaseStereo   @ 0x002be384   size=1732B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

void xmp3_PolyphaseStereo(ushort *param_1,int *param_2,int *param_3)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  ushort uVar11;
  uint uVar12;
  uint uVar13;
  int iVar14;
  int iVar15;
  int iVar16;
  int iVar17;
  uint uVar18;
  int iVar19;
  int iVar20;
  int iVar21;
  int iVar22;
  int iVar23;
  int iVar24;
  int iVar25;
  int iVar26;
  int iVar27;
  int iVar28;
  int iVar29;
  int iVar30;
  int iVar31;
  int iVar32;
  bool bVar33;
  int *local_48;
  int *local_44;
  ushort *local_38;
  ushort *local_34;
  
  iVar30 = param_3[0x101];
  iVar19 = param_3[0x100];
  iVar24 = param_2[0x420];
  lVar1 = (longlong)-param_3[0xf] * (longlong)param_2[0x30] +
          (longlong)param_3[0xe] * (longlong)param_2[0x27] +
          (longlong)-param_3[0xd] * (longlong)param_2[0x31] +
          (longlong)param_3[0xc] * (longlong)param_2[0x26] +
          (longlong)param_2[0x32] * (longlong)-param_3[0xb] +
          (longlong)param_2[0x25] * (longlong)param_3[10] +
          (longlong)param_2[0x33] * (longlong)-param_3[9] +
          (longlong)param_2[0x24] * (longlong)param_3[8] +
          (longlong)param_2[0x34] * (longlong)-param_3[7] +
          (longlong)param_2[0x23] * (longlong)param_3[6] +
          (longlong)param_2[0x35] * (longlong)-param_3[5] +
          (longlong)param_2[0x22] * (longlong)param_3[4] +
          (longlong)param_2[0x36] * (longlong)-param_3[3] +
          (longlong)param_2[0x21] * (longlong)param_3[2] +
          (longlong)param_2[0x37] * (longlong)-param_3[1] +
          (longlong)param_2[0x20] * (longlong)*param_3 + 0x2000000;
  lVar2 = (longlong)-param_3[0xf] * (longlong)param_2[0x10] +
          (longlong)param_3[0xe] * (longlong)param_2[7] +
          (longlong)-param_3[0xd] * (longlong)param_2[0x11] +
          (longlong)param_3[0xc] * (longlong)param_2[6] +
          (longlong)param_2[0x12] * (longlong)-param_3[0xb] +
          (longlong)param_2[5] * (longlong)param_3[10] +
          (longlong)param_2[0x13] * (longlong)-param_3[9] +
          (longlong)param_2[4] * (longlong)param_3[8] +
          (longlong)param_2[0x14] * (longlong)-param_3[7] +
          (longlong)param_2[3] * (longlong)param_3[6] +
          (longlong)param_2[0x15] * (longlong)-param_3[5] +
          (longlong)param_2[2] * (longlong)param_3[4] +
          (longlong)param_2[0x16] * (longlong)-param_3[3] +
          (longlong)param_2[1] * (longlong)param_3[2] +
          (longlong)param_2[0x17] * (longlong)-param_3[1] +
          (longlong)*param_2 * (longlong)*param_3 + 0x2000000;
  uVar13 = (int)((ulonglong)lVar2 >> 0x20) << 0xc;
  uVar12 = (uint)lVar2 >> 0x14 | uVar13;
  bVar33 = (int)uVar12 >> 0x1f != (int)uVar12 >> 0x15;
  if (bVar33) {
    uVar11 = (ushort)((int)uVar13 >> 0x1f) ^ 0x7f00;
  }
  else {
    uVar11 = (ushort)((int)uVar12 >> 6);
  }
  uVar13 = (uint)lVar1 >> 0x14 | (int)((ulonglong)lVar1 >> 0x20) << 0xc;
  if (bVar33) {
    uVar11 = uVar11 ^ 0xff;
  }
  *param_1 = uVar11;
  iVar4 = (int)uVar13 >> 0x1f;
  bVar33 = iVar4 == (int)uVar13 >> 0x15;
  if (bVar33) {
    iVar4 = (int)uVar13 >> 6;
  }
  uVar11 = (ushort)iVar4;
  iVar4 = param_2[0x400];
  iVar14 = param_2[0x401];
  iVar27 = param_2[0x402];
  if (!bVar33) {
    uVar11 = uVar11 ^ 0x7f00;
  }
  if (!bVar33) {
    uVar11 = uVar11 ^ 0xff;
  }
  iVar5 = param_3[0x102];
  iVar20 = param_2[0x421];
  iVar25 = param_2[0x423];
  iVar21 = param_2[0x422];
  iVar15 = param_3[0x103];
  iVar31 = param_3[0x104];
  iVar22 = param_2[0x405];
  iVar6 = param_2[0x403];
  iVar28 = param_3[0x105];
  iVar26 = param_2[0x406];
  iVar16 = param_2[0x404];
  iVar7 = param_2[0x424];
  iVar8 = param_2[0x407];
  iVar32 = param_2[0x425];
  iVar17 = param_3[0x106];
  iVar23 = param_2[0x426];
  iVar9 = param_3[0x107];
  local_48 = param_2 + 0x80;
  iVar29 = param_2[0x427];
  param_1[1] = uVar11;
  local_44 = param_3 + 0x20;
  lVar1 = (longlong)iVar9 * (longlong)iVar8 +
          (longlong)iVar17 * (longlong)iVar26 +
          (longlong)iVar28 * (longlong)iVar22 +
          (longlong)iVar31 * (longlong)iVar16 +
          (longlong)iVar15 * (longlong)iVar6 +
          (longlong)iVar5 * (longlong)iVar27 +
          (longlong)iVar30 * (longlong)iVar14 + (longlong)iVar19 * (longlong)iVar4 + 0x2000000;
  lVar2 = (longlong)iVar9 * (longlong)iVar29 +
          (longlong)iVar17 * (longlong)iVar23 +
          (longlong)iVar28 * (longlong)iVar32 +
          (longlong)iVar31 * (longlong)iVar7 +
          (longlong)iVar15 * (longlong)iVar25 +
          (longlong)iVar5 * (longlong)iVar21 +
          (longlong)iVar30 * (longlong)iVar20 + (longlong)iVar19 * (longlong)iVar24 + 0x2000000;
  local_38 = param_1 + 4;
  uVar13 = (int)((ulonglong)lVar1 >> 0x20) << 0xc;
  uVar12 = (uint)lVar1 >> 0x14 | uVar13;
  bVar33 = (int)uVar12 >> 0x1f != (int)uVar12 >> 0x15;
  if (bVar33) {
    uVar11 = (ushort)((int)uVar13 >> 0x1f) ^ 0x7f00;
  }
  else {
    uVar11 = (ushort)((int)uVar12 >> 6);
  }
  uVar13 = (int)((ulonglong)lVar2 >> 0x20) << 0xc;
  uVar12 = (uint)lVar2 >> 0x14 | uVar13;
  if (bVar33) {
    uVar11 = uVar11 ^ 0xff;
  }
  param_1[0x20] = uVar11;
  if ((int)uVar12 >> 0x1f == (int)uVar12 >> 0x15) {
    uVar11 = (ushort)((int)uVar12 >> 6);
  }
  else {
    uVar11 = (ushort)((int)uVar13 >> 0x1f) ^ 0x7fff;
  }
  param_1[0x21] = uVar11;
  local_34 = param_1;
  do {
    iVar15 = local_44[-0x10];
    iVar6 = local_44[-0xf];
    iVar21 = local_44[-0xe];
    iVar14 = local_44[-0xd];
    iVar27 = local_44[-0xc];
    iVar16 = local_44[-0xb];
    iVar17 = local_44[-10];
    iVar24 = local_44[-9];
    iVar30 = local_44[-8];
    iVar7 = local_44[-7];
    iVar20 = local_44[-6];
    iVar8 = local_44[-5];
    iVar9 = local_44[-4];
    iVar4 = local_44[-3];
    iVar5 = local_44[-2];
    iVar22 = local_44[-1];
    lVar1 = (longlong)local_48[-0x30] * (longlong)-iVar22 +
            (longlong)local_48[-0x39] * (longlong)iVar5 +
            (longlong)local_48[-0x2f] * (longlong)-iVar4 +
            (longlong)local_48[-0x3a] * (longlong)iVar9 +
            (longlong)local_48[-0x2e] * (longlong)-iVar8 +
            (longlong)local_48[-0x3b] * (longlong)iVar20 +
            (longlong)local_48[-0x2d] * (longlong)-iVar7 +
            (longlong)local_48[-0x3c] * (longlong)iVar30 +
            (longlong)local_48[-0x2c] * (longlong)-iVar24 +
            (longlong)local_48[-0x3d] * (longlong)iVar17 +
            (longlong)local_48[-0x2b] * (longlong)-iVar16 +
            (longlong)local_48[-0x3e] * (longlong)iVar27 +
            (longlong)local_48[-0x2a] * (longlong)-iVar14 +
            (longlong)local_48[-0x3f] * (longlong)iVar21 +
            (longlong)local_48[-0x29] * (longlong)-iVar6 +
            (longlong)local_48[-0x40] * (longlong)iVar15 + 0x2000000;
    uVar13 = (uint)lVar1 >> 0x14 | (int)((ulonglong)lVar1 >> 0x20) << 0xc;
    iVar19 = (int)uVar13 >> 0x1f;
    bVar33 = iVar19 == (int)uVar13 >> 0x15;
    lVar1 = (longlong)local_48[-0x10] * (longlong)-iVar22 +
            (longlong)local_48[-0x19] * (longlong)iVar5 +
            (longlong)local_48[-0xf] * (longlong)-iVar4 +
            (longlong)local_48[-0x1a] * (longlong)iVar9 +
            (longlong)local_48[-0xe] * (longlong)-iVar8 +
            (longlong)local_48[-0x1b] * (longlong)iVar20 +
            (longlong)local_48[-0xd] * (longlong)-iVar7 +
            (longlong)local_48[-0x1c] * (longlong)iVar30 +
            (longlong)local_48[-0xc] * (longlong)-iVar24 +
            (longlong)local_48[-0x1d] * (longlong)iVar17 +
            (longlong)local_48[-0xb] * (longlong)-iVar16 +
            (longlong)local_48[-0x1e] * (longlong)iVar27 +
            (longlong)local_48[-10] * (longlong)-iVar14 +
            (longlong)local_48[-0x1f] * (longlong)iVar21 +
            (longlong)local_48[-9] * (longlong)-iVar6 +
            (longlong)local_48[-0x20] * (longlong)iVar15 + 0x2000000;
    lVar2 = (longlong)local_48[-0x30] * (longlong)iVar5 +
            (longlong)iVar22 * (longlong)local_48[-0x39] +
            (longlong)local_48[-0x2f] * (longlong)iVar9 +
            (longlong)iVar4 * (longlong)local_48[-0x3a] +
            (longlong)local_48[-0x2e] * (longlong)iVar20 +
            (longlong)iVar8 * (longlong)local_48[-0x3b] +
            (longlong)local_48[-0x2d] * (longlong)iVar30 +
            (longlong)iVar7 * (longlong)local_48[-0x3c] +
            (longlong)local_48[-0x2c] * (longlong)iVar17 +
            (longlong)iVar24 * (longlong)local_48[-0x3d] +
            (longlong)local_48[-0x2b] * (longlong)iVar27 +
            (longlong)iVar16 * (longlong)local_48[-0x3e] +
            (longlong)local_48[-0x2a] * (longlong)iVar21 +
            (longlong)iVar14 * (longlong)local_48[-0x3f] +
            (longlong)local_48[-0x29] * (longlong)iVar15 +
            (longlong)iVar6 * (longlong)local_48[-0x40] + 0x2000000;
    lVar3 = (longlong)local_48[-0x10] * (longlong)iVar5 +
            (longlong)local_48[-0x19] * (longlong)iVar22 +
            (longlong)local_48[-0xf] * (longlong)iVar9 +
            (longlong)local_48[-0x1a] * (longlong)iVar4 +
            (longlong)local_48[-0xe] * (longlong)iVar20 +
            (longlong)local_48[-0x1b] * (longlong)iVar8 +
            (longlong)local_48[-0xd] * (longlong)iVar30 +
            (longlong)local_48[-0x1c] * (longlong)iVar7 +
            (longlong)local_48[-0xc] * (longlong)iVar17 +
            (longlong)local_48[-0x1d] * (longlong)iVar24 +
            (longlong)local_48[-0xb] * (longlong)iVar27 +
            (longlong)local_48[-0x1e] * (longlong)iVar16 +
            (longlong)local_48[-10] * (longlong)iVar21 +
            (longlong)local_48[-0x1f] * (longlong)iVar14 +
            (longlong)local_48[-9] * (longlong)iVar15 +
            (longlong)local_48[-0x20] * (longlong)iVar6 + 0x2000000;
    if (bVar33) {
      iVar19 = (int)uVar13 >> 6;
    }
    uVar11 = (ushort)iVar19;
    uVar13 = (int)((ulonglong)lVar1 >> 0x20) << 0xc;
    uVar12 = (uint)lVar1 >> 0x14 | uVar13;
    if (!bVar33) {
      uVar11 = uVar11 ^ 0x7fff;
    }
    local_38[-2] = uVar11;
    bVar33 = (int)uVar12 >> 0x1f != (int)uVar12 >> 0x15;
    if (bVar33) {
      uVar11 = (ushort)((int)uVar13 >> 0x1f) ^ 0x7f00;
    }
    else {
      uVar11 = (ushort)((int)uVar12 >> 6);
    }
    uVar13 = (int)((ulonglong)lVar2 >> 0x20) << 0xc;
    uVar18 = (uint)lVar2 >> 0x14 | uVar13;
    uVar12 = (int)((ulonglong)lVar3 >> 0x20) << 0xc;
    uVar10 = (uint)lVar3 >> 0x14 | uVar12;
    if (bVar33) {
      uVar11 = uVar11 ^ 0xff;
    }
    local_38[-1] = uVar11;
    if ((int)uVar18 >> 0x1f == (int)uVar18 >> 0x15) {
      uVar11 = (ushort)((int)uVar18 >> 6);
    }
    else {
      uVar11 = (ushort)((int)uVar13 >> 0x1f) ^ 0x7fff;
    }
    local_34[0x3e] = uVar11;
    if ((int)uVar10 >> 0x1f == (int)uVar10 >> 0x15) {
      uVar11 = (ushort)((int)uVar10 >> 6);
    }
    else {
      uVar11 = (ushort)((int)uVar12 >> 0x1f) ^ 0x7fff;
    }
    local_44 = local_44 + 0x10;
    local_34[0x3f] = uVar11;
    local_48 = local_48 + 0x40;
    local_38 = local_38 + 2;
    local_34 = local_34 + -2;
  } while (param_3 + 0x110 != local_44);
  return;
}
