/* ============================================================
 * lufseek   @ 0x00010b74   size=172B   callers=8
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* lufseek(LUFILE*, long, int) */

int lufseek(LUFILE *param_1,long param_2,int param_3)

{
  int iVar1;
  bool bVar2;
  
  if (*param_1 == (LUFILE)0x0) {
    if (param_3 == 0) {
      *(long *)(param_1 + 0x18) = param_2;
    }
    else {
      iVar1 = 0;
      if (param_3 == 1) {
        *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + param_2;
        param_3 = iVar1;
      }
      else {
        bVar2 = param_3 == 2;
        param_3 = iVar1;
        if (bVar2) {
          *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x14) + param_2;
        }
      }
    }
  }
  else if (param_1[1] == (LUFILE)0x0) {
    param_3 = 0x1d;
  }
  else if (param_3 == 0) {
    fseek(*(FILE **)(param_1 + 4),param_2 + *(int *)(param_1 + 0xc),0);
  }
  else if ((param_3 == 1) || (param_3 == 2)) {
    fseek(*(FILE **)(param_1 + 4),param_2,param_3);
    param_3 = 0;
  }
  else {
    param_3 = 0x13;
  }
  return param_3;
}
