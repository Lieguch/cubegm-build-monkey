/* ============================================================
 * luftell   @ 0x00010b30   size=68B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* luftell(LUFILE*) */

int luftell(LUFILE *param_1)

{
  long lVar1;
  
  if (*param_1 == (LUFILE)0x0) {
    return *(int *)(param_1 + 0x18);
  }
  if (param_1[1] == (LUFILE)0x0) {
    return 0;
  }
  lVar1 = ftell(*(FILE **)(param_1 + 4));
  return lVar1 - *(int *)(param_1 + 0xc);
}
