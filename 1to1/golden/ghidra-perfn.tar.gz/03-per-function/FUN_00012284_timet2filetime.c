/* ============================================================
 * timet2filetime   @ 0x00012284   size=12B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* timet2filetime(long) */

void timet2filetime(long param_1)

{
  undefined4 in_r1;
  
  *(undefined4 *)param_1 = in_r1;
  *(undefined4 *)(param_1 + 4) = in_r1;
  return;
}
