/* ============================================================
 * unzlocal_getByte   @ 0x00010cc8   size=92B   callers=2
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzlocal_getByte(LUFILE*, int*) */

int unzlocal_getByte(LUFILE *param_1,int *param_2)

{
  int iVar1;
  byte local_11 [5];
  
  iVar1 = lufread(local_11,1,1,param_1);
  if (iVar1 != 1) {
    iVar1 = luferror(param_1);
    return -(uint)(iVar1 != 0);
  }
  *param_2 = (uint)local_11[0];
  return 0;
}
