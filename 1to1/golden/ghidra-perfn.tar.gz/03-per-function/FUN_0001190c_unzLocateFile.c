/* ============================================================
 * unzLocateFile   @ 0x0001190c   size=240B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzLocateFile(unz_s*, char const*, int) */

int unzLocateFile(unz_s *param_1,char *param_2,int param_3)

{
  size_t sVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char acStack_228 [260];
  char acStack_124 [260];
  
  if ((param_1 != (unz_s *)0x0) && (sVar1 = strlen(param_2), sVar1 < 0x100)) {
    memcpy(acStack_124,param_2,sVar1 + 1);
    if (*(int *)(param_1 + 0x18) == 0) {
      return -100;
    }
    uVar4 = *(undefined4 *)(param_1 + 0x10);
    uVar3 = *(undefined4 *)(param_1 + 0x14);
    iVar2 = unzGoToFirstFile(param_1);
    if (iVar2 == 0) {
      do {
        unzGetCurrentFileInfo
                  (param_1,(unz_file_info_s *)0x0,acStack_228,0x100,(void *)0x0,0,(char *)0x0,0);
        iVar2 = unzStringFileNameCompare(acStack_228,acStack_124,param_3);
        if (iVar2 == 0) {
          return 0;
        }
        iVar2 = unzGoToNextFile(param_1);
      } while (iVar2 == 0);
    }
    *(undefined4 *)(param_1 + 0x10) = uVar4;
    *(undefined4 *)(param_1 + 0x14) = uVar3;
    return iVar2;
  }
  return -0x66;
}
