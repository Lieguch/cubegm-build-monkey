/* ============================================================
 * stbtt_GetGlyphHMetrics   @ 0x0001a7d0   size=208B   callers=3
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_GetGlyphHMetrics(int param_1,int param_2,int *param_3,int *param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 4);
  iVar2 = *(int *)(param_1 + 0x1c) + 0x22;
  iVar2 = (uint)*(byte *)(iVar1 + iVar2 + 1) + (uint)*(byte *)(iVar1 + iVar2) * 0x100;
  if (param_2 < iVar2) {
    if (param_3 != (int *)0x0) {
      iVar2 = *(int *)(param_1 + 0x20) + param_2 * 4;
      *param_3 = (int)(short)((ushort)*(byte *)(iVar1 + iVar2 + 1) +
                             (ushort)*(byte *)(iVar1 + iVar2) * 0x100);
    }
    if (param_4 == (int *)0x0) {
      return;
    }
    iVar2 = param_2 * 4 + 2 + *(int *)(param_1 + 0x20);
  }
  else {
    if (param_3 != (int *)0x0) {
      iVar3 = *(int *)(param_1 + 0x20) + (iVar2 + -1) * 4;
      *param_3 = (int)(short)((ushort)*(byte *)(iVar1 + iVar3 + 1) +
                             (ushort)*(byte *)(iVar1 + iVar3) * 0x100);
    }
    if (param_4 == (int *)0x0) {
      return;
    }
    iVar2 = *(int *)(param_1 + 0x20) + iVar2 * 2 + param_2 * 2;
  }
  *param_4 = (int)(short)((ushort)*(byte *)(iVar1 + iVar2 + 1) +
                         (ushort)*(byte *)(iVar1 + iVar2) * 0x100);
  return;
}
