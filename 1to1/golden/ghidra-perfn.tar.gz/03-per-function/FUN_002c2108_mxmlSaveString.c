/* ============================================================
 * mxmlSaveString   @ 0x002c2108   size=160B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

int mxmlSaveString(undefined4 param_1,undefined1 *param_2,int param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  undefined1 *local_20;
  undefined1 *local_1c;
  
  uVar1 = _mxml_global();
  local_20 = param_2;
  local_1c = param_2 + param_3;
  iVar2 = mxml_write_node(param_1,&local_20,param_4,0,mxml_string_putc,uVar1);
  if (iVar2 < 0) {
    iVar2 = -1;
  }
  else {
    if (iVar2 != 0) {
      if (local_20 < local_1c) {
        *local_20 = 10;
      }
      local_20 = local_20 + 1;
    }
    if (local_20 < local_1c) {
      *local_20 = 0;
    }
    else {
      (param_2 + param_3)[-1] = 0;
    }
    iVar2 = (int)local_20 - (int)param_2;
  }
  return iVar2;
}
