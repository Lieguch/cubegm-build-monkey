/* ============================================================
 * inflate_codes   @ 0x0000ec98   size=2124B   callers=1
 * module: 07_zlib
 * ============================================================ */

/* inflate_codes(inflate_blocks_state*, z_stream_s*, int) */

void inflate_codes(inflate_blocks_state *param_1,z_stream_s *param_2,int param_3)

{
  byte bVar1;
  undefined1 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined1 *puVar5;
  inflate_huft_s *piVar6;
  int iVar7;
  char *pcVar8;
  uint uVar9;
  byte *pbVar10;
  inflate_huft_s *piVar11;
  int iVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  byte *pbVar16;
  undefined4 *puVar17;
  undefined1 *puVar18;
  undefined1 *puVar19;
  undefined1 *puVar20;
  undefined1 *puVar21;
  uint uVar22;
  bool bVar23;
  bool bVar24;
  
  puVar18 = *(undefined1 **)(param_1 + 0x34);
  puVar17 = *(undefined4 **)(param_1 + 4);
  pbVar16 = *(byte **)param_2;
  uVar14 = *(uint *)(param_2 + 4);
  uVar9 = *(uint *)(param_1 + 0x20);
  uVar13 = *(uint *)(param_1 + 0x1c);
  if (puVar18 < *(undefined1 **)(param_1 + 0x30)) {
    puVar5 = *(undefined1 **)(param_1 + 0x30) + (-1 - (int)puVar18);
  }
  else {
    puVar5 = (undefined1 *)(*(int *)(param_1 + 0x2c) - (int)puVar18);
  }
  uVar3 = *puVar17;
LAB_0000ecfc:
  switch(uVar3) {
  case 0:
    goto switchD_0000ed00_caseD_0;
  case 1:
    uVar4 = puVar17[3];
    goto LAB_0000eda4;
  case 2:
    goto LAB_0000ef3c;
  case 3:
    uVar4 = puVar17[3];
    goto LAB_0000efc0;
  case 4:
    goto LAB_0000f064;
  case 5:
    uVar4 = puVar17[3];
    goto LAB_0000f0cc;
  case 6:
    goto LAB_0000ee24;
  case 7:
LAB_0000f358:
    *(undefined1 **)(param_1 + 0x34) = puVar18;
    if (7 < uVar13) {
      uVar13 = uVar13 - 8;
      uVar14 = uVar14 + 1;
      pbVar16 = pbVar16 + -1;
    }
    param_3 = inflate_flush(param_1,param_2,param_3);
    puVar18 = *(undefined1 **)(param_1 + 0x34);
    if (puVar18 != *(undefined1 **)(param_1 + 0x30)) {
      iVar12 = *(int *)param_2;
      *(uint *)(param_1 + 0x20) = uVar9;
      iVar7 = *(int *)(param_2 + 8);
      *(uint *)(param_1 + 0x1c) = uVar13;
      *(uint *)(param_2 + 4) = uVar14;
      pbVar10 = pbVar16 + (iVar7 - iVar12);
      *(byte **)param_2 = pbVar16;
      goto LAB_0000f218;
    }
    *puVar17 = 8;
    break;
  case 8:
    break;
  case 9:
    pbVar10 = *(byte **)param_2;
LAB_0000f324:
    iVar7 = *(int *)(param_2 + 8);
    *(uint *)(param_1 + 0x20) = uVar9;
    *(uint *)(param_1 + 0x1c) = uVar13;
    pbVar10 = pbVar16 + (iVar7 - (int)pbVar10);
    *(uint *)(param_2 + 4) = uVar14;
    *(byte **)param_2 = pbVar16;
    param_3 = -3;
    goto LAB_0000f218;
  default:
    pbVar10 = pbVar16 + (*(int *)(param_2 + 8) - *(int *)param_2);
    param_3 = -2;
    *(uint *)(param_1 + 0x20) = uVar9;
    *(uint *)(param_1 + 0x1c) = uVar13;
    *(uint *)(param_2 + 4) = uVar14;
    *(byte **)param_2 = pbVar16;
    goto LAB_0000f218;
  }
  iVar7 = *(int *)param_2;
  *(uint *)(param_1 + 0x20) = uVar9;
  iVar12 = *(int *)(param_2 + 8);
  *(uint *)(param_1 + 0x1c) = uVar13;
  pbVar10 = pbVar16 + (iVar12 - iVar7);
  *(uint *)(param_2 + 4) = uVar14;
  *(byte **)param_2 = pbVar16;
  param_3 = 1;
  goto LAB_0000f218;
switchD_0000ed00_caseD_0:
  pbVar10 = pbVar16;
  do {
    bVar24 = (undefined1 *)0x100 < puVar5;
    bVar23 = puVar5 == (undefined1 *)0x101;
    if ((undefined1 *)0x101 < puVar5) {
      bVar24 = 8 < uVar14;
      bVar23 = uVar14 == 9;
    }
    if (bVar24 && !bVar23) {
      iVar7 = *(int *)param_2;
      iVar12 = *(int *)(param_2 + 8);
      *(uint *)(param_1 + 0x20) = uVar9;
      *(uint *)(param_1 + 0x1c) = uVar13;
      *(byte **)param_2 = pbVar10;
      *(uint *)(param_2 + 4) = uVar14;
      *(byte **)(param_2 + 8) = pbVar10 + (iVar12 - iVar7);
      piVar11 = (inflate_huft_s *)puVar17[6];
      piVar6 = (inflate_huft_s *)puVar17[5];
      *(undefined1 **)(param_1 + 0x34) = puVar18;
      param_3 = inflate_fast((uint)*(byte *)(puVar17 + 4),(uint)*(byte *)((int)puVar17 + 0x11),
                             piVar6,piVar11,param_1,param_2);
      puVar5 = *(undefined1 **)(param_1 + 0x30);
      puVar18 = *(undefined1 **)(param_1 + 0x34);
      pbVar10 = *(byte **)param_2;
      bVar23 = puVar18 < puVar5;
      uVar14 = *(uint *)(param_2 + 4);
      if (bVar23) {
        puVar5 = puVar5 + -(int)puVar18;
      }
      uVar9 = *(uint *)(param_1 + 0x20);
      if (bVar23) {
        puVar5 = puVar5 + -1;
      }
      else {
        puVar5 = *(undefined1 **)(param_1 + 0x2c);
      }
      uVar13 = *(uint *)(param_1 + 0x1c);
      if (!bVar23) {
        puVar5 = puVar5 + -(int)puVar18;
      }
      if (param_3 == 0) goto LAB_0000ed8c;
      if (param_3 != 1) {
        *puVar17 = 9;
        pbVar16 = pbVar10;
        goto LAB_0000f324;
      }
LAB_0000f350:
      *puVar17 = 7;
      pbVar16 = pbVar10;
      goto LAB_0000f358;
    }
LAB_0000ed8c:
    uVar4 = (uint)*(byte *)(puVar17 + 4);
    *puVar17 = 1;
    puVar17[3] = uVar4;
    puVar17[2] = puVar17[5];
    pbVar16 = pbVar10;
LAB_0000eda4:
    if (uVar13 < uVar4) {
      pbVar10 = pbVar16;
      if (uVar14 != 0) {
        while( true ) {
          pbVar16 = pbVar10 + 1;
          uVar14 = uVar14 - 1;
          uVar9 = uVar9 | (uint)*pbVar10 << (uVar13 & 0xff);
          uVar13 = uVar13 + 8;
          if (uVar4 <= uVar13) break;
          pbVar10 = pbVar16;
          if (uVar14 == 0) goto LAB_0000eec4;
        }
        param_3 = 0;
        goto LAB_0000eddc;
      }
      goto LAB_0000eed4;
    }
LAB_0000eddc:
    iVar7 = puVar17[2] + (*(uint *)(inflate_mask + uVar4 * 4) & uVar9) * 8;
    bVar1 = *(byte *)(puVar17[2] + (*(uint *)(inflate_mask + uVar4 * 4) & uVar9) * 8);
    uVar4 = (uint)bVar1;
    uVar9 = uVar9 >> (uint)*(byte *)(iVar7 + 1);
    uVar13 = uVar13 - *(byte *)(iVar7 + 1);
    if (uVar4 == 0) {
      uVar3 = *(undefined4 *)(iVar7 + 4);
      *puVar17 = 6;
      puVar17[2] = uVar3;
LAB_0000ee24:
      puVar21 = puVar18;
      if (puVar5 == (undefined1 *)0x0) {
        if (*(undefined1 **)(param_1 + 0x2c) == puVar18) {
          puVar5 = *(undefined1 **)(param_1 + 0x30);
          puVar21 = *(undefined1 **)(param_1 + 0x28);
          if (puVar5 != puVar21) {
            if (puVar5 < puVar21) {
              puVar5 = puVar18 + -(int)puVar21;
            }
            else {
              puVar5 = puVar5 + (-1 - (int)puVar21);
            }
            puVar18 = puVar21;
            if (puVar5 != (undefined1 *)0x0) goto LAB_0000ed64;
          }
        }
        *(undefined1 **)(param_1 + 0x34) = puVar18;
        param_3 = inflate_flush(param_1,param_2,param_3);
        puVar21 = *(undefined1 **)(param_1 + 0x34);
        puVar18 = *(undefined1 **)(param_1 + 0x30);
        if (puVar21 < puVar18) {
          puVar19 = *(undefined1 **)(param_1 + 0x2c);
          puVar5 = puVar18 + (-1 - (int)puVar21);
        }
        else {
          puVar19 = *(undefined1 **)(param_1 + 0x2c);
          puVar5 = puVar19 + -(int)puVar21;
        }
        if (puVar21 == puVar19) {
          puVar19 = *(undefined1 **)(param_1 + 0x28);
          if (puVar18 != puVar19) {
            if (puVar18 < puVar19) {
              puVar5 = puVar21 + -(int)puVar19;
              puVar21 = puVar19;
            }
            else {
              puVar5 = puVar18 + (-1 - (int)puVar19);
              puVar21 = puVar19;
            }
          }
        }
        if (puVar5 == (undefined1 *)0x0) {
LAB_0000ee8c:
          iVar12 = *(int *)param_2;
          *(uint *)(param_1 + 0x20) = uVar9;
          iVar7 = *(int *)(param_2 + 8);
          *(uint *)(param_1 + 0x1c) = uVar13;
          *(uint *)(param_2 + 4) = uVar14;
          *(byte **)param_2 = pbVar16;
          *(byte **)(param_2 + 8) = pbVar16 + (iVar7 - iVar12);
          *(undefined1 **)(param_1 + 0x34) = puVar21;
          goto LAB_0000ef08;
        }
      }
LAB_0000ed64:
      puVar5 = puVar5 + -1;
      puVar18 = puVar21 + 1;
      param_3 = 0;
      *puVar21 = (char)puVar17[2];
    }
    else {
      if ((bVar1 & 0x10) == 0) {
        if ((bVar1 & 0x40) == 0) {
          puVar17[3] = uVar4;
          uVar3 = *puVar17;
          puVar17[2] = iVar7 + *(int *)(iVar7 + 4) * 8;
          goto LAB_0000ecfc;
        }
        pbVar10 = pbVar16;
        if ((bVar1 & 0x20) != 0) goto LAB_0000f350;
        pcVar8 = "invalid literal/length code";
        goto LAB_0000f444;
      }
      puVar17[2] = uVar4 & 0xf;
      uVar3 = *(undefined4 *)(iVar7 + 4);
      *puVar17 = 2;
      puVar17[1] = uVar3;
LAB_0000ef3c:
      uVar22 = puVar17[2];
      if (uVar13 < uVar22) {
        pbVar10 = pbVar16;
        if (uVar14 == 0) goto LAB_0000eed4;
        while( true ) {
          pbVar16 = pbVar10 + 1;
          uVar14 = uVar14 - 1;
          uVar9 = uVar9 | (uint)*pbVar10 << (uVar13 & 0xff);
          uVar13 = uVar13 + 8;
          if (uVar22 <= uVar13) break;
          pbVar10 = pbVar16;
          if (uVar14 == 0) goto LAB_0000eec4;
        }
        param_3 = 0;
      }
      uVar13 = uVar13 - uVar22;
      uVar4 = (uint)*(byte *)((int)puVar17 + 0x11);
      puVar17[3] = uVar4;
      uVar15 = *(uint *)(inflate_mask + uVar22 * 4) & uVar9;
      uVar9 = uVar9 >> (uVar22 & 0xff);
      puVar17[2] = puVar17[6];
      puVar17[1] = puVar17[1] + uVar15;
      *puVar17 = 3;
LAB_0000efc0:
      if (uVar13 < uVar4) {
        pbVar10 = pbVar16;
        if (uVar14 == 0) goto LAB_0000eed4;
        while( true ) {
          pbVar16 = pbVar10 + 1;
          uVar14 = uVar14 - 1;
          uVar9 = uVar9 | (uint)*pbVar10 << (uVar13 & 0xff);
          uVar13 = uVar13 + 8;
          if (uVar4 <= uVar13) break;
          pbVar10 = pbVar16;
          if (uVar14 == 0) goto LAB_0000eec4;
        }
        param_3 = 0;
      }
      iVar7 = puVar17[2] + (*(uint *)(inflate_mask + uVar4 * 4) & uVar9) * 8;
      bVar1 = *(byte *)(puVar17[2] + (*(uint *)(inflate_mask + uVar4 * 4) & uVar9) * 8);
      uVar9 = uVar9 >> (uint)*(byte *)(iVar7 + 1);
      uVar13 = uVar13 - *(byte *)(iVar7 + 1);
      if ((bVar1 & 0x10) == 0) break;
      puVar17[2] = bVar1 & 0xf;
      uVar3 = *(undefined4 *)(iVar7 + 4);
      *puVar17 = 4;
      puVar17[3] = uVar3;
LAB_0000f064:
      uVar22 = puVar17[2];
      if (uVar13 < uVar22) {
        pbVar10 = pbVar16;
        if (uVar14 == 0) goto LAB_0000eed4;
        while( true ) {
          pbVar16 = pbVar10 + 1;
          uVar14 = uVar14 - 1;
          uVar9 = uVar9 | (uint)*pbVar10 << (uVar13 & 0xff);
          uVar13 = uVar13 + 8;
          if (uVar22 <= uVar13) break;
          pbVar10 = pbVar16;
          if (uVar14 == 0) goto LAB_0000eec4;
        }
        param_3 = 0;
      }
      uVar13 = uVar13 - uVar22;
      *puVar17 = 5;
      uVar4 = uVar9 & *(uint *)(inflate_mask + uVar22 * 4);
      uVar9 = uVar9 >> (uVar22 & 0xff);
      uVar4 = uVar4 + puVar17[3];
      puVar17[3] = uVar4;
LAB_0000f0cc:
      uVar22 = (int)puVar18 - *(int *)(param_1 + 0x28);
      bVar23 = uVar22 < uVar4;
      if (bVar23) {
        uVar4 = uVar22 - uVar4;
      }
      iVar7 = puVar17[1];
      if (bVar23) {
        puVar19 = (undefined1 *)(*(int *)(param_1 + 0x2c) + uVar4);
      }
      else {
        puVar19 = puVar18 + -uVar4;
      }
      while (iVar7 != 0) {
        if (puVar5 == (undefined1 *)0x0) {
          if (*(undefined1 **)(param_1 + 0x2c) == puVar18) {
            puVar5 = *(undefined1 **)(param_1 + 0x30);
            puVar21 = *(undefined1 **)(param_1 + 0x28);
            if (puVar5 != puVar21) {
              if (puVar5 < puVar21) {
                puVar5 = puVar18 + -(int)puVar21;
              }
              else {
                puVar5 = puVar5 + (-1 - (int)puVar21);
              }
              puVar18 = puVar21;
              if (puVar5 != (undefined1 *)0x0) goto LAB_0000f150;
            }
          }
          *(undefined1 **)(param_1 + 0x34) = puVar18;
          param_3 = inflate_flush(param_1,param_2,param_3);
          puVar21 = *(undefined1 **)(param_1 + 0x34);
          puVar18 = *(undefined1 **)(param_1 + 0x30);
          if (puVar21 < puVar18) {
            puVar20 = *(undefined1 **)(param_1 + 0x2c);
            puVar5 = puVar18 + (-1 - (int)puVar21);
          }
          else {
            puVar20 = *(undefined1 **)(param_1 + 0x2c);
            puVar5 = puVar20 + -(int)puVar21;
          }
          if (puVar21 == puVar20) {
            puVar20 = *(undefined1 **)(param_1 + 0x28);
            if (puVar18 != puVar20) {
              if (puVar18 < puVar20) {
                puVar5 = puVar21 + -(int)puVar20;
                puVar21 = puVar20;
              }
              else {
                puVar5 = puVar18 + (-1 - (int)puVar20);
                puVar21 = puVar20;
              }
            }
          }
          puVar18 = puVar21;
          if (puVar5 == (undefined1 *)0x0) goto LAB_0000ee8c;
        }
LAB_0000f150:
        uVar2 = *puVar19;
        puVar19 = puVar19 + 1;
        puVar5 = puVar5 + -1;
        *puVar18 = uVar2;
        param_3 = 0;
        iVar7 = puVar17[1] + -1;
        if (puVar19 == *(undefined1 **)(param_1 + 0x2c)) {
          puVar19 = *(undefined1 **)(param_1 + 0x28);
        }
        puVar17[1] = iVar7;
        puVar18 = puVar18 + 1;
      }
    }
    *puVar17 = 0;
    pbVar10 = pbVar16;
  } while( true );
  if ((bVar1 & 0x40) != 0) {
    pcVar8 = "invalid distance code";
LAB_0000f444:
    iVar12 = *(int *)param_2;
    *puVar17 = 9;
    *(char **)(param_2 + 0x18) = pcVar8;
    iVar7 = *(int *)(param_2 + 8);
    *(uint *)(param_1 + 0x20) = uVar9;
    *(uint *)(param_1 + 0x1c) = uVar13;
    pbVar10 = pbVar16 + (iVar7 - iVar12);
    *(uint *)(param_2 + 4) = uVar14;
    param_3 = -3;
    *(byte **)param_2 = pbVar16;
LAB_0000f218:
    *(byte **)(param_2 + 8) = pbVar10;
LAB_0000ef04:
    *(undefined1 **)(param_1 + 0x34) = puVar18;
LAB_0000ef08:
    inflate_flush(param_1,param_2,param_3);
    return;
  }
  puVar17[3] = (uint)bVar1;
  uVar3 = *puVar17;
  puVar17[2] = iVar7 + *(int *)(iVar7 + 4) * 8;
  goto LAB_0000ecfc;
LAB_0000eec4:
  param_3 = 0;
LAB_0000eed4:
  iVar7 = *(int *)param_2;
  *(uint *)(param_1 + 0x20) = uVar9;
  iVar12 = *(int *)(param_2 + 8);
  *(uint *)(param_1 + 0x1c) = uVar13;
  *(byte **)param_2 = pbVar16;
  *(undefined4 *)(param_2 + 4) = 0;
  *(byte **)(param_2 + 8) = pbVar16 + (iVar12 - iVar7);
  goto LAB_0000ef04;
}
