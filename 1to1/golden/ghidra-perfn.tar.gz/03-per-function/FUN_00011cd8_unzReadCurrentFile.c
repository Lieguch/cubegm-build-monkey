/* ============================================================
 * unzReadCurrentFile   @ 0x00011cd8   size=540B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzReadCurrentFile(unz_s*, void*, unsigned int) */

int unzReadCurrentFile(unz_s *param_1,void *param_2,uint param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  
  if (param_1 == (unz_s *)0x0) {
    return -0x66;
  }
  piVar5 = *(int **)(param_1 + 0x7c);
  if (piVar5 == (int *)0x0) {
    return -0x66;
  }
  if (*piVar5 == 0) {
    return -100;
  }
  if (param_3 == 0) {
    return 0;
  }
  uVar3 = piVar5[0x17];
  piVar5[5] = param_3;
  iVar6 = 0;
  piVar5[4] = (int)param_2;
  if (uVar3 < param_3) {
    piVar5[5] = uVar3;
    param_3 = uVar3;
  }
LAB_00011d24:
  if (param_3 == 0) {
    return iVar6;
  }
  do {
    if (piVar5[2] == 0) {
      uVar3 = piVar5[0x16];
      if (uVar3 != 0) {
        uVar4 = 0;
        if (uVar3 < 0x4000) {
          uVar4 = uVar3;
        }
        if (uVar3 >= 0x4000) {
          uVar4 = 0x4000;
        }
        iVar1 = lufseek((LUFILE *)piVar5[0x18],piVar5[0xf] + piVar5[0x1a],0);
        if ((iVar1 != 0) ||
           (iVar1 = lufread((void *)*piVar5,uVar4,1,(LUFILE *)piVar5[0x18]), iVar1 != 1)) {
          return -1;
        }
        piVar5[2] = uVar4;
        piVar5[0xf] = piVar5[0xf] + uVar4;
        piVar5[0x16] = piVar5[0x16] - uVar4;
        piVar5[1] = *piVar5;
        goto LAB_00011db0;
      }
      uVar4 = 0;
      if (piVar5[0x19] != 0) break;
    }
    else {
LAB_00011db0:
      if (piVar5[0x19] != 0) break;
      uVar3 = piVar5[5];
      if ((uint)piVar5[2] <= (uint)piVar5[5]) {
        uVar3 = piVar5[2];
      }
      uVar4 = 0;
      if (uVar3 == 0) {
        uVar4 = 0;
      }
      else {
        do {
          *(undefined1 *)(piVar5[4] + uVar4) = *(undefined1 *)(piVar5[1] + uVar4);
          uVar4 = uVar4 + 1;
        } while (uVar4 != uVar3);
      }
    }
    iVar6 = iVar6 + uVar4;
    iVar1 = ucrc32(piVar5[0x14],piVar5[4],uVar4);
    iVar2 = piVar5[5];
    piVar5[0x17] = piVar5[0x17] - uVar4;
    piVar5[2] = piVar5[2] - uVar4;
    piVar5[5] = iVar2 - uVar4;
    piVar5[4] = piVar5[4] + uVar4;
    piVar5[1] = piVar5[1] + uVar4;
    piVar5[6] = piVar5[6] + uVar4;
    piVar5[0x14] = iVar1;
    if (iVar2 - uVar4 == 0) {
      return iVar6;
    }
  } while( true );
  iVar7 = piVar5[6];
  iVar2 = piVar5[4];
  iVar1 = inflate((z_stream_s *)(piVar5 + 1),2);
  iVar7 = piVar5[6] - iVar7;
  iVar6 = iVar6 + iVar7;
  iVar2 = ucrc32(piVar5[0x14],iVar2,iVar7);
  piVar5[0x17] = piVar5[0x17] - iVar7;
  piVar5[0x14] = iVar2;
  if (iVar1 == 1) {
    return iVar6;
  }
  if (iVar1 != 0) {
    return iVar6;
  }
  param_3 = piVar5[5];
  goto LAB_00011d24;
}
