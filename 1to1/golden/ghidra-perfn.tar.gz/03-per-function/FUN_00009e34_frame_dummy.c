/* ============================================================
 * frame_dummy   @ 0x00009e34   size=56B   callers=1
 * module: 99_crt_glibc
 * ============================================================ */

/* WARNING: Removing unreachable block (ram,0x00009e5c) */
/* WARNING: Removing unreachable block (ram,0x00009e4c) */

void frame_dummy(void)

{
  register_tm_clones();
  return;
}
