/* ============================================================
 * mxmlWalkPrev   @ 0x002c3520   size=88B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

int mxmlWalkPrev(int param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_1 == param_2 || param_1 == 0) {
    return 0;
  }
  iVar1 = *(int *)(param_1 + 8);
  if (iVar1 != 0) {
    iVar2 = *(int *)(iVar1 + 0x14);
    if (param_3 == 0 || *(int *)(iVar1 + 0x14) == 0) {
      return iVar1;
    }
    do {
      iVar1 = iVar2;
      iVar2 = *(int *)(iVar1 + 0x14);
    } while (iVar2 != 0);
    return iVar1;
  }
  iVar1 = *(int *)(param_1 + 0xc);
  if (param_2 == iVar1) {
    iVar1 = 0;
  }
  return iVar1;
}
