/* ============================================================
 * stbtt_FreeSDF   @ 0x0001e0c8   size=4B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_FreeSDF(void *param_1)

{
  free(param_1);
  return;
}
