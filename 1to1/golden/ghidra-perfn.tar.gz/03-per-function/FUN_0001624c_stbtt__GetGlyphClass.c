/* ============================================================
 * stbtt__GetGlyphClass   @ 0x0001624c   size=284B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

int stbtt__GetGlyphClass(byte *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar2 = (uint)param_1[1] + (uint)*param_1 * 0x100;
  if (iVar2 == 1) {
    iVar2 = (uint)param_1[3] + (uint)param_1[2] * 0x100;
    if ((iVar2 <= param_2) && (param_2 < (int)((uint)param_1[5] + (uint)param_1[4] * 0x100 + iVar2))
       ) {
      iVar2 = (param_2 - iVar2) * 2;
      return (uint)param_1[iVar2 + 7] + (uint)param_1[iVar2 + 6] * 0x100;
    }
  }
  else if (iVar2 == 2) {
    iVar2 = (uint)param_1[3] + (uint)param_1[2] * 0x100 + -1;
    if (iVar2 == -1) {
      return -1;
    }
    iVar4 = 0;
    do {
      iVar1 = iVar4 + iVar2 >> 1;
      iVar3 = iVar1 * 6;
      if (param_2 < (int)((uint)param_1[iVar3 + 5] + (uint)param_1[iVar3 + 4] * 0x100)) {
        iVar2 = iVar1 + -1;
      }
      else {
        iVar4 = iVar1 + 1;
        if (param_2 <= (int)((uint)param_1[iVar3 + 7] + (uint)param_1[iVar3 + 6] * 0x100)) {
          return (uint)param_1[iVar3 + 9] + (uint)param_1[iVar3 + 8] * 0x100;
        }
      }
    } while (iVar4 <= iVar2);
    return -1;
  }
  return -1;
}
