/* ============================================================
 * unzlocal_getShort   @ 0x00010d24   size=96B   callers=3
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzlocal_getShort(LUFILE*, unsigned long*) */

void unzlocal_getShort(LUFILE *param_1,ulong *param_2)

{
  int iVar1;
  int iVar2;
  int local_14;
  
  iVar2 = unzlocal_getByte(param_1,&local_14);
  iVar1 = local_14;
  if (iVar2 == 0) {
    iVar2 = unzlocal_getByte(param_1,&local_14);
    if (iVar2 == 0) {
      *param_2 = iVar1 + local_14 * 0x100;
      return;
    }
  }
  *param_2 = 0;
  return;
}
