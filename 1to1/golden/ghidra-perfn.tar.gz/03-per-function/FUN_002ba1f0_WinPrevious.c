/* ============================================================
 * WinPrevious   @ 0x002ba1f0   size=404B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

void WinPrevious(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  
  if (param_3 != 2) {
    param_1 = param_1 + -1;
    param_3 = param_3 * 0x90;
    piVar2 = (int *)(xmp3_imdctWin + param_3 + 0x8c);
    piVar3 = param_2 + 0x11;
    piVar4 = (int *)(xmp3_imdctWin + param_3 + 0x48);
    do {
      param_1 = param_1 + 1;
      iVar1 = *param_1;
      iVar6 = *piVar2;
      piVar5 = piVar4 + 1;
      *param_2 = (int)((ulonglong)((longlong)*piVar4 * (longlong)iVar1) >> 0x20);
      *piVar3 = (int)((ulonglong)((longlong)iVar6 * (longlong)iVar1) >> 0x20);
      param_2 = param_2 + 1;
      piVar2 = piVar2 + -1;
      piVar3 = piVar3 + -1;
      piVar4 = piVar5;
    } while ((int *)(xmp3_imdctWin + param_3 + 0x6c) != piVar5);
    return;
  }
  *param_2 = (int)((ulonglong)((longlong)param_1[2] * -0x47311c28) >> 0x20) +
             (int)((ulonglong)((longlong)param_1[6] * 0x7311c28) >> 0x20);
  param_2[1] = (int)((ulonglong)((longlong)param_1[1] * -0x4d413ccd) >> 0x20) +
               (int)((ulonglong)((longlong)param_1[7] * 0xd413ccd) >> 0x20);
  param_2[2] = (int)((ulonglong)((longlong)*param_1 * -0x47311c28) >> 0x20) +
               (int)((ulonglong)((longlong)param_1[8] * 0x7311c28) >> 0x20);
  param_2[3] = (int)((ulonglong)((longlong)*param_1 * -0x36a09e66) >> 0x20) +
               (int)((ulonglong)((longlong)param_1[8] * -0x95f619a) >> 0x20);
  param_2[4] = (int)((ulonglong)((longlong)param_1[1] * -0x20000000) >> 0x20) +
               (int)((ulonglong)((longlong)param_1[7] * -0x20000000) >> 0x20);
  param_2[5] = (int)((ulonglong)((longlong)param_1[2] * -0x95f619a) >> 0x20) +
               (int)((ulonglong)((longlong)param_1[6] * -0x36a09e66) >> 0x20);
  param_2[6] = (int)((ulonglong)((longlong)param_1[5] * -0x47311c28) >> 0x20);
  param_2[7] = (int)((ulonglong)((longlong)param_1[4] * -0x4d413ccd) >> 0x20);
  param_2[8] = (int)((ulonglong)((longlong)param_1[3] * -0x47311c28) >> 0x20);
  param_2[9] = (int)((ulonglong)((longlong)param_1[3] * -0x36a09e66) >> 0x20);
  param_2[10] = (int)((ulonglong)((longlong)param_1[4] * -0x20000000) >> 0x20);
  param_2[0xb] = (int)((ulonglong)((longlong)param_1[5] * -0x95f619a) >> 0x20);
  param_2[0x11] = 0;
  param_2[0x10] = 0;
  param_2[0xf] = 0;
  param_2[0xe] = 0;
  param_2[0xd] = 0;
  param_2[0xc] = 0;
  return;
}
