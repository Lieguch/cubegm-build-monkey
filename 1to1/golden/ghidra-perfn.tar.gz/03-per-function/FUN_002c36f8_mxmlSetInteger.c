/* ============================================================
 * mxmlSetInteger   @ 0x002c36f8   size=72B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlSetInteger(int *param_1,int param_2)

{
  int iVar1;
  
  if (param_1 != (int *)0x0) {
    iVar1 = *param_1;
    if (iVar1 == 0) {
      param_1 = (int *)param_1[4];
      if (param_1 == (int *)0x0) {
        return 0xffffffff;
      }
      iVar1 = *param_1;
    }
    if (iVar1 == 1) {
      param_1[6] = param_2;
      return 0;
    }
  }
  return 0xffffffff;
}
