/* ============================================================
 * index_find.isra.0   @ 0x002c25bc   size=88B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

int index_find_isra_0(undefined4 *param_1,char *param_2,char *param_3,int param_4)

{
  int iVar1;
  char *__s2;
  
  if ((param_2 != (char *)0x0) && (iVar1 = strcmp(param_2,*(char **)(param_4 + 0x18)), iVar1 != 0))
  {
    return iVar1;
  }
  if (param_3 != (char *)0x0) {
    __s2 = (char *)mxmlElementGetAttr(param_4,*param_1);
    iVar1 = strcmp(param_3,__s2);
    return iVar1;
  }
  return 0;
}
