/* ============================================================
 * Get   @ 0x0001265c   size=152B   callers=4
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* TUnzip::Get(int, ZIPENTRY*) */

undefined4 __thiscall TUnzip::Get(TUnzip *this,int param_1,ZIPENTRY *param_2)

{
  undefined4 uVar1;
  
  if ((param_1 < -1) || (*(int *)(*(unz_s **)this + 4) <= param_1)) {
    return 0x10000;
  }
  if (*(int *)(this + 4) != -1) {
    unzCloseCurrentFile(*(unz_s **)this);
  }
  *(undefined4 *)(this + 4) = 0xffffffff;
  if (param_1 == -1 || *(int *)(this + 0x138) != param_1) {
    uVar1 = Get(this,param_1,param_2);
    return uVar1;
  }
  memcpy(param_2,this + 8,0x130);
  return 0;
}
