/* ============================================================
 * inflate_codes_new   @ 0x0000dd7c   size=80B   callers=1
 * module: 07_zlib
 * ============================================================ */

/* inflate_codes_new(unsigned int, unsigned int, inflate_huft_s const*, inflate_huft_s const*,
   z_stream_s*) */

void inflate_codes_new(uint param_1,uint param_2,inflate_huft_s *param_3,inflate_huft_s *param_4,
                      z_stream_s *param_5)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)(**(code **)(param_5 + 0x20))(*(undefined4 *)(param_5 + 0x28),1,0x1c);
  if (puVar1 == (undefined4 *)0x0) {
    return;
  }
  *(char *)(puVar1 + 4) = (char)param_1;
  *(char *)((int)puVar1 + 0x11) = (char)param_2;
  puVar1[5] = param_3;
  puVar1[6] = param_4;
  *puVar1 = 0;
  return;
}
