/* ============================================================
 * xmp3_CalcBitsUsed   @ 0x002bd8a4   size=24B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

int xmp3_CalcBitsUsed(int *param_1,int param_2,int param_3)

{
  return ((*param_1 - param_2) * 8 - param_1[2]) - param_3;
}
