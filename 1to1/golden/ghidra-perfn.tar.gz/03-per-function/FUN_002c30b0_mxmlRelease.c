/* ============================================================
 * mxmlRelease   @ 0x002c30b0   size=64B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

int mxmlRelease(int param_1)

{
  int iVar1;
  
  if (param_1 == 0) {
    iVar1 = -1;
  }
  else {
    iVar1 = *(int *)(param_1 + 0x28) + -1;
    *(int *)(param_1 + 0x28) = iVar1;
    if (iVar1 < 1) {
      mxmlDelete();
      return 0;
    }
  }
  return iVar1;
}
