/* ============================================================
 * deregister_tm_clones   @ 0x00009da4   size=44B   callers=1
 * module: 99_crt_glibc
 * ============================================================ */

/* WARNING: Removing unreachable block (ram,0x00009dcc) */
/* WARNING: Removing unreachable block (ram,0x00009dbc) */

void deregister_tm_clones(void)

{
  return;
}
