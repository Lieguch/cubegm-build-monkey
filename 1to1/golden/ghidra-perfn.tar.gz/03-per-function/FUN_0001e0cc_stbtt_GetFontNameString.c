/* ============================================================
 * stbtt_GetFontNameString   @ 0x0001e0cc   size=308B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

int stbtt_GetFontNameString
              (int param_1,int *param_2,int param_3,int param_4,int param_5,int param_6)

{
  byte bVar1;
  byte bVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  
  iVar5 = *(int *)(param_1 + 4);
  iVar3 = stbtt__find_table(iVar5,*(undefined4 *)(param_1 + 8),&DAT_002dcd70);
  if (iVar3 == 0) {
    return 0;
  }
  iVar7 = (uint)*(byte *)(iVar5 + iVar3 + 2 + 1) + (uint)*(byte *)(iVar5 + iVar3 + 2) * 0x100;
  if (iVar7 != 0) {
    iVar4 = iVar5 + iVar3;
    iVar6 = 0;
    do {
      iVar6 = iVar6 + 1;
      if (((((uint)*(byte *)(iVar4 + 7) + (uint)*(byte *)(iVar4 + 6) * 0x100 == param_3) &&
           ((uint)*(byte *)(iVar4 + 9) + (uint)*(byte *)(iVar4 + 8) * 0x100 == param_4)) &&
          ((uint)*(byte *)(iVar4 + 0xb) + (uint)*(byte *)(iVar4 + 10) * 0x100 == param_5)) &&
         ((uint)*(byte *)(iVar4 + 0xd) + (uint)*(byte *)(iVar4 + 0xc) * 0x100 == param_6)) {
        iVar7 = (iVar4 - iVar5) + 0xe;
        iVar4 = (iVar4 - iVar5) + 0x10;
        bVar1 = *(byte *)(iVar5 + iVar3 + 4);
        bVar2 = *(byte *)(iVar5 + iVar3 + 4 + 1);
        *param_2 = (uint)*(byte *)(iVar5 + iVar7 + 1) + (uint)*(byte *)(iVar5 + iVar7) * 0x100;
        return iVar5 + iVar3 + (uint)bVar2 + (uint)bVar1 * 0x100 +
                       (uint)*(byte *)(iVar5 + iVar4 + 1) + (uint)*(byte *)(iVar5 + iVar4) * 0x100;
      }
      iVar4 = iVar4 + 0xc;
    } while (iVar7 != iVar6);
  }
  return 0;
}
