/* ============================================================
 * stbtt_PackFontRangesGatherRects   @ 0x0001c6ac   size=436B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

int stbtt_PackFontRangesGatherRects
              (undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
              int param_5,int param_6,float *param_7,int param_8,int param_9)

{
  uint uVar1;
  byte bVar2;
  int extraout_r1;
  int iVar3;
  int extraout_r1_00;
  int *piVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  uint in_fpscr;
  float fVar8;
  float fVar9;
  undefined4 extraout_s1;
  undefined4 extraout_s1_00;
  float fVar10;
  undefined4 extraout_s1_01;
  undefined4 extraout_s1_02;
  undefined4 extraout_s2;
  undefined4 extraout_s2_00;
  undefined4 extraout_s2_01;
  undefined4 extraout_s3;
  undefined4 extraout_s3_00;
  undefined4 extraout_s3_01;
  int local_48;
  int local_40;
  int local_3c;
  int local_38;
  int local_34 [2];
  
  if (0 < param_8) {
    iVar7 = 0;
    local_48 = 0;
    iVar3 = param_6;
    do {
      fVar8 = *param_7;
      uVar1 = in_fpscr & 0xfffffff | (uint)(fVar8 < 0.0) << 0x1f | (uint)(fVar8 == 0.0) << 0x1e;
      in_fpscr = uVar1 | (uint)NAN(fVar8) << 0x1c;
      bVar2 = (byte)(uVar1 >> 0x18);
      if ((bool)(bVar2 >> 6 & 1) || bVar2 >> 7 != ((byte)(in_fpscr >> 0x1c) & 1)) {
        fVar8 = (float)stbtt_ScaleForMappingEmToPixels(-fVar8,param_2,param_3,param_4,param_6,iVar3)
        ;
        iVar3 = extraout_r1_00;
        param_2 = extraout_s1_02;
        param_3 = extraout_s2_01;
        param_4 = extraout_s3_01;
      }
      else {
        fVar8 = (float)stbtt_ScaleForPixelHeight(param_6);
        iVar3 = extraout_r1;
        param_2 = extraout_s1;
        param_3 = extraout_s2;
        param_4 = extraout_s3;
      }
      piVar4 = *(int **)(param_5 + 0x1c);
      *(char *)(param_7 + 5) = (char)piVar4;
      *(char *)((int)param_7 + 0x15) = (char)*(undefined4 *)(param_5 + 0x20);
      if (0 < (int)param_7[3]) {
        iVar6 = 0;
        iVar5 = iVar7 * 0x18 + param_9;
        do {
          if (param_7[2] == 0.0) {
            iVar3 = iVar6 + (int)param_7[1];
          }
          else {
            iVar3 = *(int *)((int)param_7[2] + iVar6 * 4);
          }
          iVar3 = stbtt_FindGlyphIndex(param_6,iVar3,piVar4);
          param_3 = 0;
          if ((iVar3 == 0) && (*(int *)(param_5 + 0x18) != 0)) {
            *(undefined4 *)(iVar5 + 0x10) = 0;
            *(undefined4 *)(iVar5 + 0xc) = 0;
            iVar3 = 0;
            piVar4 = &local_40;
            param_2 = extraout_s1_00;
            param_4 = 0;
          }
          else {
            fVar10 = (float)VectorUnsignedToFloat
                                      (*(undefined4 *)(param_5 + 0x20),(byte)(in_fpscr >> 0x16) & 3)
            ;
            fVar9 = (float)VectorUnsignedToFloat
                                     (*(undefined4 *)(param_5 + 0x1c),(byte)(in_fpscr >> 0x16) & 3);
            stbtt_GetGlyphBitmapBoxSubpixel
                      (fVar9 * fVar8,fVar10 * fVar8,param_6,iVar3,&local_40,&local_3c,&local_38,
                       local_34);
            iVar3 = *(int *)(param_5 + 0x14);
            *(int *)(iVar5 + 0xc) = (local_38 - local_40) + iVar3 + *(int *)(param_5 + 0x1c) + -1;
            piVar4 = (int *)(*(int *)(param_5 + 0x20) + -1);
            *(int *)(iVar5 + 0x10) = (local_34[0] - local_3c) + iVar3 + (int)piVar4;
            param_2 = extraout_s1_01;
            param_3 = extraout_s2_00;
            param_4 = extraout_s3_00;
          }
          iVar6 = iVar6 + 1;
          iVar7 = iVar7 + 1;
          iVar5 = iVar5 + 0x18;
        } while (iVar6 < (int)param_7[3]);
      }
      param_7 = param_7 + 6;
      local_48 = local_48 + 1;
    } while (param_8 != local_48);
    return iVar7;
  }
  return 0;
}
