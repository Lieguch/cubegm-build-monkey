/* ============================================================
 * _mxml_global   @ 0x002c3148   size=128B   callers=11
 * module: 04_mini_xml
 * ============================================================ */

void * _mxml_global(void)

{
  void *pvVar1;
  
  pthread_once((pthread_once_t *)&_mxml_key_once,_mxml_init);
  pvVar1 = pthread_getspecific(_mxml_key);
  if (pvVar1 != (void *)0x0) {
    return pvVar1;
  }
  pvVar1 = calloc(1,0x1a4);
  pthread_setspecific(_mxml_key,pvVar1);
  *(undefined4 *)((int)pvVar1 + 4) = 1;
  *(undefined4 *)((int)pvVar1 + 0x198) = 0x48;
  *(code **)((int)pvVar1 + 8) = _mxml_entity_cb;
  return pvVar1;
}
