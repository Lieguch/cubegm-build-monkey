/* ============================================================
 * stbtt_MakeGlyphBitmapSubpixel   @ 0x0001ba34   size=228B   callers=4
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_MakeGlyphBitmapSubpixel
               (undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
               undefined4 *param_5,undefined4 param_6,int param_7,int param_8,undefined4 param_9,
               undefined4 param_10)

{
  undefined4 uVar1;
  undefined4 local_4c;
  undefined4 local_48;
  void *local_44;
  int local_40;
  int local_3c;
  undefined4 local_38;
  undefined4 local_34;
  
  uVar1 = stbtt_GetGlyphShape(param_5,param_10,&local_44);
  stbtt_GetGlyphBitmapBoxSubpixel
            (param_1,param_2,param_3,param_4,param_5,param_10,&local_4c,&local_48,0,0);
  local_38 = param_9;
  local_40 = param_7;
  local_3c = param_8;
  local_34 = param_6;
  if (param_8 != 0 && param_7 != 0) {
    stbtt_Rasterize(0x3eb33333,param_1,param_2,param_3,param_4,&local_40,local_44,uVar1,local_4c,
                    local_48,1,*param_5);
  }
  free(local_44);
  return;
}
