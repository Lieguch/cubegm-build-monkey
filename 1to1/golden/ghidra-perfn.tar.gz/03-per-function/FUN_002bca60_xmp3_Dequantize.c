/* ============================================================
 * xmp3_Dequantize   @ 0x002bca60   size=916B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

undefined4 xmp3_Dequantize(undefined4 *param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  int *piVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int *piVar12;
  int iVar13;
  int *piVar14;
  int local_30;
  int local_2c;
  
  if (((((param_1 == (undefined4 *)0x0) || (piVar12 = (int *)*param_1, piVar12 == (int *)0x0)) ||
       (iVar4 = param_1[1], iVar4 == 0)) ||
      ((iVar5 = param_1[2], iVar5 == 0 || (piVar6 = (int *)param_1[3], piVar6 == (int *)0x0)))) ||
     (iVar7 = param_1[4], iVar7 == 0)) {
    return 0xffffffff;
  }
  iVar9 = 0;
  iVar3 = iVar7 + 0x318;
  local_2c = 0;
  local_30 = 0;
  if (0 < (int)param_1[0x1ef]) {
    iVar11 = param_2 * 0x7c + iVar5;
    iVar10 = param_2 * 0x90 + iVar4 + 0x28;
    piVar8 = piVar6 + 0x482;
    iVar13 = iVar3;
    piVar14 = piVar6;
    do {
      iVar9 = iVar9 + 1;
      iVar1 = xmp3_DequantChannel(piVar14,iVar7,piVar8 + -2,piVar12,iVar10,iVar11,iVar13);
      iVar10 = iVar10 + 0x48;
      iVar11 = iVar11 + 0x3e;
      iVar13 = iVar13 + 0x18;
      piVar14 = piVar14 + 0x240;
      *piVar8 = iVar1;
      piVar8 = piVar8 + 1;
    } while (iVar9 < (int)param_1[0x1ef]);
  }
  uVar2 = piVar12[8];
  if (uVar2 == 0) {
    return 0;
  }
  if ((piVar6[0x482] < 1) || (piVar6[0x483] < 1)) {
    iVar9 = piVar6[0x480];
    if (0 < iVar9) {
      piVar8 = piVar6;
      do {
        if (*piVar8 < -0x3fffffff) {
          *piVar8 = -0x3fffffff;
        }
        else if (0x3fffffff < *piVar8) {
          *piVar8 = 0x3fffffff;
        }
        piVar8 = piVar8 + 1;
      } while (piVar8 != piVar6 + iVar9);
    }
    iVar9 = piVar6[0x481];
    if (0 < iVar9) {
      piVar8 = piVar6 + 0x240;
      do {
        if (*piVar8 < -0x3fffffff) {
          *piVar8 = -0x3fffffff;
        }
        else if (0x3fffffff < *piVar8) {
          *piVar8 = 0x3fffffff;
        }
        piVar8 = piVar8 + 1;
      } while (piVar6 + iVar9 + 0x240 != piVar8);
    }
  }
  if (uVar2 >> 1 == 0) {
    uVar2 = 1;
  }
  else {
    if ((uVar2 & 1) == 0) {
      iVar7 = piVar6[0x481];
      if (piVar6[0x481] < piVar6[0x480]) {
        iVar7 = piVar6[0x480];
      }
    }
    else if (*(int *)(iVar7 + 0x330) == 0) {
      iVar7 = (int)*(short *)(piVar12[0xd] + *(int *)(iVar7 + 0x344) * 2 + 2);
    }
    else {
      iVar7 = *(short *)(piVar12[0xd] + *(int *)(iVar7 + 0x340) * 2 + 0x30) * 3;
    }
    xmp3_MidSideProc(piVar6,iVar7,&local_30);
    uVar2 = piVar12[8];
    if ((uVar2 & 1) == 0) goto LAB_002bcc58;
  }
  if (*piVar12 == 0) {
    xmp3_IntensityProcMPEG1
              (piVar6,piVar6[0x480],piVar12,param_2 * 0x7c + iVar5 + 0x3e,iVar3,(int)uVar2 >> 1,
               *(undefined4 *)(param_2 * 0x90 + iVar4 + 0x88),&local_30);
    uVar2 = piVar12[8];
  }
  else {
    xmp3_IntensityProcMPEG2
              (piVar6,piVar6[0x480],piVar12,param_2 * 0x7c + iVar5 + 0x3e,iVar3,iVar5 + 0xf8,
               (int)uVar2 >> 1,*(undefined4 *)(param_2 * 0x90 + iVar4 + 0x88),&local_30);
    uVar2 = piVar12[8];
  }
LAB_002bcc58:
  if (uVar2 == 0) {
    return 0;
  }
  if (local_30 == 0) {
    iVar4 = 0x1f;
  }
  else if (local_30 < 0) {
    iVar4 = -1;
  }
  else {
    iVar5 = 0;
    do {
      iVar4 = iVar5;
      local_30 = local_30 << 1;
      iVar5 = iVar4 + 1;
    } while (-1 < local_30);
  }
  piVar6[0x482] = iVar4;
  if (local_2c == 0) {
    iVar4 = 0x1f;
  }
  else if (local_2c < 0) {
    iVar4 = -1;
  }
  else {
    iVar5 = 0;
    do {
      iVar4 = iVar5;
      local_2c = local_2c << 1;
      iVar5 = iVar4 + 1;
    } while (-1 < local_2c);
  }
  piVar6[0x483] = iVar4;
  iVar4 = piVar6[0x481];
  if (piVar6[0x481] < piVar6[0x480]) {
    iVar4 = piVar6[0x480];
  }
  piVar6[0x480] = iVar4;
  piVar6[0x481] = iVar4;
  return 0;
}
