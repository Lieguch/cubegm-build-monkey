/* ============================================================
 * mxmlWalkNext   @ 0x002c3280   size=124B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

int mxmlWalkNext(int param_1,int param_2,int param_3)

{
  int iVar1;
  
  if (param_1 == 0) {
    return 0;
  }
  if (*(int *)(param_1 + 0x10) != 0 && param_3 != 0) {
    return *(int *)(param_1 + 0x10);
  }
  if (param_1 == param_2) {
    return 0;
  }
  if (*(int *)(param_1 + 4) == 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    if (iVar1 == 0 || param_2 == iVar1) {
      return 0;
    }
    do {
      if (*(int *)(iVar1 + 4) != 0) {
        return *(int *)(iVar1 + 4);
      }
      iVar1 = *(int *)(iVar1 + 0xc);
    } while (param_2 != iVar1 && iVar1 != 0);
    return 0;
  }
  return *(int *)(param_1 + 4);
}
