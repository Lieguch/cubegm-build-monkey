/* ============================================================
 * mxmlGetInteger   @ 0x002c2408   size=68B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

int mxmlGetInteger(int *param_1)

{
  if (param_1 == (int *)0x0) {
    return 0;
  }
  if (*param_1 != 1) {
    if (*param_1 == 0) {
      param_1 = (int *)param_1[4];
      if (param_1 == (int *)0x0) {
        return 0;
      }
      if (*param_1 == 1) goto LAB_002c2444;
    }
    return 0;
  }
LAB_002c2444:
  return param_1[6];
}
