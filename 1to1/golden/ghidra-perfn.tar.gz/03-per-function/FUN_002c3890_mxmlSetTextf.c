/* ============================================================
 * mxmlSetTextf   @ 0x002c3890   size=160B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlSetTextf(int *param_1,int param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  
  if ((param_1 == (int *)0x0) ||
     (((iVar1 = *param_1, iVar1 == 0 &&
       ((param_1 = (int *)param_1[4], param_1 == (int *)0x0 || (iVar1 = *param_1, iVar1 != 4)))) ||
      (iVar1 != 4 || param_3 == 0)))) {
    uVar2 = 0xffffffff;
  }
  else {
    if ((void *)param_1[7] != (void *)0x0) {
      free((void *)param_1[7]);
    }
    param_1[6] = param_2;
    iVar1 = _mxml_strdupf(param_3);
    uVar2 = 0;
    param_1[7] = iVar1;
  }
  return uVar2;
}
