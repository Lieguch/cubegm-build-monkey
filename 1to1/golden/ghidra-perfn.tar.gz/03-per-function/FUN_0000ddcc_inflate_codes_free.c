/* ============================================================
 * inflate_codes_free   @ 0x0000ddcc   size=20B   callers=2
 * module: 07_zlib
 * ============================================================ */

/* inflate_codes_free(inflate_codes_state*, z_stream_s*) */

void inflate_codes_free(inflate_codes_state *param_1,z_stream_s *param_2)

{
                    /* WARNING: Could not recover jumptable at 0x0000dddc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(param_2 + 0x24))(*(undefined4 *)(param_2 + 0x28),param_1);
  return;
}
