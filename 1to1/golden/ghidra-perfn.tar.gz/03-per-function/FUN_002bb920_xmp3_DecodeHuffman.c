/* ============================================================
 * xmp3_DecodeHuffman   @ 0x002bb920   size=2624B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

byte * xmp3_DecodeHuffman(undefined4 *param_1,byte *param_2,uint *param_3,int param_4,int param_5,
                         int param_6)

{
  byte bVar1;
  ushort uVar2;
  ushort uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  ushort *puVar7;
  byte *pbVar8;
  uint uVar10;
  uint uVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  int iVar15;
  uint uVar16;
  int iVar17;
  uint *puVar18;
  uint *puVar19;
  uint uVar20;
  undefined4 *puVar21;
  ushort *puVar22;
  int iVar23;
  int iVar24;
  uint *puVar25;
  int *piVar26;
  int iVar27;
  byte *pbVar28;
  uint uVar29;
  uint uVar30;
  bool bVar31;
  int local_84;
  byte *local_80;
  int local_7c;
  int local_70;
  byte *local_6c;
  int *local_68;
  int *local_5c;
  int local_34 [4];
  byte *pbVar9;
  
  if ((((param_1 == (undefined4 *)0x0) || (piVar26 = (int *)*param_1, piVar26 == (int *)0x0)) ||
      (iVar12 = param_1[1], iVar12 == 0)) ||
     ((param_1[2] == 0 || (iVar13 = param_1[3], iVar13 == 0 || param_4 < 0)))) {
    return (byte *)0xffffffff;
  }
  iVar14 = iVar12 + param_6 * 0x48 + param_5 * 0x90;
  if ((*(int *)(iVar14 + 0x38) == 0) || (*(int *)(iVar14 + 0x3c) != 2)) {
    iVar14 = (int)*(short *)(piVar26[0xd] +
                            (*(int *)(iVar12 + param_6 * 0x48 + param_5 * 0x90 + 0x5c) + 1) * 2);
  }
  else if (*(int *)(iVar14 + 0x40) == 0) {
    iVar14 = *(short *)(piVar26[0xd] + ((*(int *)(iVar14 + 0x5c) + 1) / 3) * 2 + 0x2e) * 3;
  }
  else if (*piVar26 == 0) {
    iVar14 = (int)*(short *)(piVar26[0xd] + *(int *)(iVar14 + 0x5c) * 2 + 2);
  }
  else {
    iVar14 = piVar26[0xd];
    iVar14 = (int)*(short *)(iVar14 + 0xc) +
             ((int)*(short *)(iVar14 + 0x36) - (int)*(short *)(iVar14 + 0x34)) * 2;
  }
  iVar4 = iVar13 + param_6 * 4;
  local_68 = (int *)(iVar12 + param_6 * 0x48 + 0x44 + param_5 * 0x90);
  iVar23 = 0;
  iVar27 = iVar13 + param_6 * 0x900;
  iVar15 = *(int *)(iVar12 + param_6 * 0x48 + param_5 * 0x90 + 0x2c) * 2;
  local_5c = local_34;
  if (0x23f < iVar15) {
    iVar15 = 0x240;
  }
  *(int *)(iVar4 + 0x1200) = iVar15;
  uVar16 = *param_3;
  local_70 = param_4;
  local_6c = param_2;
  if (iVar15 <= iVar14) {
    iVar14 = iVar15;
  }
  do {
    iVar14 = iVar14 - iVar23;
    puVar25 = (uint *)(iVar27 + iVar23 * 4);
    if (iVar14 < 1) {
      iVar23 = 0;
    }
    else {
      uVar16 = -uVar16 & 7;
      iVar6 = *local_68;
      iVar17 = *(int *)(xmp3_huffTabLookup + iVar6 * 8 + 4);
      if (uVar16 == 0) {
        uVar11 = 0;
        pbVar28 = local_6c;
      }
      else {
        pbVar28 = local_6c + 1;
        uVar11 = (uint)*local_6c << (0x20 - uVar16 & 0xff);
      }
      if (iVar17 == 0) {
        puVar18 = puVar25 + 1;
        do {
          iVar23 = 0;
          puVar18[-1] = 0;
          puVar19 = puVar18 + 2;
          *puVar18 = 0;
          puVar18 = puVar19;
        } while (puVar25 + (iVar14 - 1U & 0xfffffffe) + 3 != puVar19);
      }
      else {
        iVar23 = local_70 - uVar16;
        puVar22 = (ushort *)(xmp3_huffTable + *(int *)(xmp3_huffTabOffset + iVar6 * 4) * 2);
        if (iVar17 == 1) {
          uVar2 = *(ushort *)(xmp3_huffTable + *(int *)(xmp3_huffTabOffset + iVar6 * 4) * 2);
          iVar6 = 0;
          do {
            puVar18 = puVar25;
            if (iVar23 < 0x10) {
              iVar17 = iVar23 + uVar16;
              if (iVar17 < 1) {
                return (byte *)0xffffffff;
              }
              if (0 < iVar23) {
                bVar1 = *pbVar28;
                uVar10 = 0x18 - uVar16;
                if (iVar23 < 9) {
                  pbVar28 = pbVar28 + 1;
                }
                else {
                  uVar16 = 0x10 - uVar16;
                }
                uVar11 = uVar11 | (uint)bVar1 << (uVar10 & 0xff);
                if (8 < iVar23) {
                  pbVar9 = pbVar28 + 1;
                  pbVar28 = pbVar28 + 2;
                  uVar11 = uVar11 | (uint)*pbVar9 << (uVar16 & 0xff);
                }
              }
              uVar16 = iVar17 + 0xb;
              iVar6 = 0xb;
              uVar11 = uVar11 & -0x80000000 >> (iVar17 - 1U & 0xff);
              iVar23 = 0;
            }
            else {
              pbVar9 = pbVar28 + 1;
              uVar5 = 0x10 - uVar16;
              bVar1 = *pbVar28;
              uVar10 = 0x18 - uVar16;
              iVar23 = iVar23 + -0x10;
              pbVar28 = pbVar28 + 2;
              uVar16 = uVar16 + 0x10;
              uVar11 = uVar11 | (uint)*pbVar9 << (uVar5 & 0xff) | (uint)bVar1 << (uVar10 & 0xff);
            }
            do {
              puVar25 = puVar18 + 2;
              iVar14 = iVar14 + -2;
              uVar3 = puVar22[(uVar11 >> (0x20 - (uVar2 & 0xf) & 0xff)) + 1];
              uVar5 = (uVar3 & 0xff) >> 4;
              uVar11 = uVar11 << (uint)(uVar3 >> 0xc);
              uVar20 = (uVar3 & 0xfff) >> 8;
              uVar16 = uVar16 - (uVar3 >> 0xc);
              uVar10 = 0;
              if (uVar5 != 0) {
                uVar10 = uVar11 & 0x80000000;
                uVar16 = uVar16 - 1;
                uVar11 = uVar11 << 1;
                uVar10 = uVar10 | uVar5;
              }
              if (uVar20 != 0) {
                uVar16 = uVar16 - 1;
              }
              uVar5 = uVar11 & 0x80000000 | uVar20;
              if (uVar20 != 0) {
                uVar11 = uVar11 << 1;
              }
              else {
                uVar5 = 0;
              }
              if ((int)uVar16 < iVar6) {
                return (byte *)0xffffffff;
              }
              bVar31 = uVar16 == 10;
              iVar17 = uVar16 - 10;
              if ((int)uVar16 >= 0xb) {
                bVar31 = iVar14 == 0;
                iVar17 = iVar14;
              }
              *puVar18 = uVar10;
              puVar18[1] = uVar5;
              puVar18 = puVar25;
            } while (!bVar31 && iVar17 < 0 == ((int)uVar16 < 0xb && SBORROW4(uVar16,10)));
          } while (0 < iVar14);
          iVar23 = (uVar16 - iVar6) + iVar23;
        }
        else {
          if (1 < iVar17 - 2U) {
            return (byte *)0xffffffff;
          }
          uVar10 = *(uint *)(xmp3_huffTabLookup + iVar6 * 8);
          local_7c = 0;
          iVar6 = uVar10 + 1;
          puVar7 = puVar22;
          do {
            if (iVar23 < 0x10) {
              iVar24 = iVar23 + uVar16;
              if (iVar24 < 1) {
                return (byte *)0xffffffff;
              }
              if (0 < iVar23) {
                bVar1 = *pbVar28;
                uVar5 = 0x18 - uVar16;
                if (iVar23 < 9) {
                  pbVar28 = pbVar28 + 1;
                }
                else {
                  uVar16 = 0x10 - uVar16;
                }
                uVar11 = uVar11 | (uint)bVar1 << (uVar5 & 0xff);
                if (8 < iVar23) {
                  pbVar9 = pbVar28 + 1;
                  pbVar28 = pbVar28 + 2;
                  uVar11 = uVar11 | (uint)*pbVar9 << (uVar16 & 0xff);
                }
              }
              uVar16 = iVar24 + 0xb;
              iVar23 = 0;
              uVar11 = uVar11 & -0x80000000 >> (iVar24 - 1U & 0xff);
              local_7c = 0xb;
            }
            else {
              pbVar9 = pbVar28 + 1;
              uVar5 = 0x10 - uVar16;
              bVar1 = *pbVar28;
              uVar20 = 0x18 - uVar16;
              iVar23 = iVar23 + -0x10;
              pbVar28 = pbVar28 + 2;
              uVar16 = uVar16 + 0x10;
              uVar11 = uVar11 | (uint)*pbVar9 << (uVar5 & 0xff) | (uint)bVar1 << (uVar20 & 0xff);
            }
            while( true ) {
              bVar31 = uVar16 == 10;
              iVar24 = uVar16 - 10;
              if ((int)uVar16 >= 0xb) {
                bVar31 = iVar14 == 0;
                iVar24 = iVar14;
              }
              if (bVar31 || iVar24 < 0 != ((int)uVar16 < 0xb && SBORROW4(uVar16,10))) break;
              while( true ) {
                uVar30 = *puVar7 & 0xf;
                uVar20 = (uint)puVar7[(uVar11 >> (0x20 - uVar30 & 0xff)) + 1];
                uVar5 = (uint)(puVar7[(uVar11 >> (0x20 - uVar30 & 0xff)) + 1] >> 0xc);
                if (uVar5 != 0) break;
                uVar16 = uVar16 - uVar30;
                uVar11 = uVar11 << uVar30;
                bVar31 = uVar16 == 10;
                iVar24 = uVar16 - 10;
                if ((int)uVar16 >= 0xb) {
                  bVar31 = iVar14 == 0;
                  iVar24 = iVar14;
                }
                puVar7 = puVar7 + uVar20;
                if (bVar31 || iVar24 < 0 != ((int)uVar16 < 0xb && SBORROW4(uVar16,10)))
                goto LAB_002bbd6c;
              }
              uVar30 = (uVar20 & 0xff) >> 4;
              uVar16 = uVar16 - uVar5;
              uVar11 = uVar11 << uVar5;
              uVar5 = (uVar20 & 0xfff) >> 8;
              if (uVar30 == 0xf && iVar17 == 3) {
                iVar24 = iVar6;
                if (uVar5 != 0) {
                  iVar24 = uVar10 + 2;
                }
                if ((int)(uVar16 + iVar23) < iVar24) {
                  return (byte *)0xffffffff;
                }
                if ((int)uVar16 < iVar24) {
                  uVar20 = 0x18 - uVar16;
                  pbVar9 = pbVar28;
                  do {
                    pbVar8 = pbVar9 + 1;
                    uVar11 = uVar11 | (uint)*pbVar9 << (uVar20 & 0xff);
                    uVar20 = uVar20 - 8;
                    pbVar9 = pbVar8;
                  } while (pbVar8 != pbVar28 + (~uVar16 + iVar24 >> 3) + 1);
                  uVar20 = ~uVar16 + iVar24 >> 3;
                  pbVar28 = pbVar28 + uVar20 + 1;
                  iVar23 = iVar23 + -8 + uVar20 * -8;
                  uVar16 = uVar20 * 8 + uVar16 + 8;
                  if (iVar23 < 0) {
                    uVar16 = uVar16 + iVar23;
                    uVar11 = uVar11 & -0x80000000 >> (uVar16 - 1 & 0xff);
                    iVar23 = 0;
                  }
                }
                uVar30 = (uVar11 >> (0x20 - uVar10 & 0xff)) + 0xf;
                uVar16 = uVar16 - uVar10;
                uVar11 = uVar11 << (uVar10 & 0xff);
              }
              uVar20 = 0;
              if (uVar30 != 0) {
                uVar16 = uVar16 - 1;
                uVar20 = uVar11 & 0x80000000 | uVar30;
                uVar11 = uVar11 << 1;
              }
              if (uVar5 == 0xf && iVar17 == 3) {
                if ((int)(iVar23 + uVar16) < iVar6) {
                  return (byte *)0xffffffff;
                }
                if ((int)uVar16 < iVar6) {
                  uVar30 = 0x18 - uVar16;
                  uVar5 = uVar10 - uVar16 >> 3;
                  pbVar8 = pbVar28 + uVar5 + 1;
                  pbVar9 = pbVar28;
                  do {
                    pbVar28 = pbVar9 + 1;
                    uVar11 = uVar11 | (uint)*pbVar9 << (uVar30 & 0xff);
                    uVar30 = uVar30 - 8;
                    pbVar9 = pbVar28;
                  } while (pbVar28 != pbVar8);
                  iVar23 = iVar23 + -8 + uVar5 * -8;
                  uVar16 = uVar5 * 8 + uVar16 + 8;
                  if (iVar23 < 0) {
                    uVar16 = uVar16 + iVar23;
                    iVar23 = 0;
                    uVar11 = uVar11 & -0x80000000 >> (uVar16 - 1 & 0xff);
                  }
                }
                uVar5 = (uVar11 >> (0x20 - uVar10 & 0xff)) + 0xf;
                uVar16 = uVar16 - uVar10;
                uVar11 = uVar11 << (uVar10 & 0xff);
              }
              uVar30 = 0;
              if (uVar5 != 0) {
                uVar16 = uVar16 - 1;
                uVar30 = uVar11 & 0x80000000 | uVar5;
                uVar11 = uVar11 << 1;
              }
              if ((int)uVar16 < local_7c) {
                return (byte *)0xffffffff;
              }
              iVar14 = iVar14 + -2;
              *puVar25 = uVar20;
              puVar25[1] = uVar30;
              puVar7 = puVar22;
              puVar25 = puVar25 + 2;
            }
LAB_002bbd6c:
          } while (0 < iVar14);
          iVar23 = (uVar16 - local_7c) + iVar23;
        }
        iVar23 = local_70 - iVar23;
        if (local_70 < iVar23 || iVar23 < 0) {
          return (byte *)0xffffffff;
        }
      }
      uVar16 = *param_3;
    }
    uVar11 = uVar16 + iVar23;
    local_70 = local_70 - iVar23;
    uVar16 = uVar11 & 7;
    local_6c = local_6c + ((int)uVar11 >> 3);
    *param_3 = uVar16;
    local_68 = local_68 + 1;
    if (local_34 + 2 == local_5c) break;
    iVar23 = *local_5c;
    local_5c = local_5c + 1;
    iVar14 = *local_5c;
  } while( true );
  puVar25 = (uint *)(iVar27 + iVar15 * 4);
  if (local_70 == 0) {
    iVar14 = 0;
  }
  else {
    iVar23 = 0;
    iVar14 = 0;
    uVar16 = -uVar16 & 7;
    iVar12 = *(int *)(iVar12 + param_6 * 0x48 + param_5 * 0x90 + 0x6c);
    uVar10 = *(uint *)((int)&xmp3_quadTabOffset + iVar12 * 4);
    iVar12 = *(int *)(&xmp3_quadTabMaxBits + iVar12 * 4);
    uVar11 = uVar10;
    if (uVar16 != 0) {
      uVar11 = 0x20 - uVar16;
    }
    if (uVar16 != 0) {
      local_80 = local_6c + 1;
      uVar11 = (uint)*local_6c << (uVar11 & 0xff);
    }
    else {
      uVar11 = 0;
      local_80 = local_6c;
    }
    local_84 = local_70 - uVar16;
    while (iVar14 < 0x23d - iVar15) {
      puVar18 = puVar25;
      if (local_84 < 0x10) {
        iVar27 = local_84 + uVar16;
        if (iVar27 < 1) break;
        if (0 < local_84) {
          pbVar28 = local_80;
          if (8 < local_84) {
            pbVar28 = (byte *)(0x10 - uVar16);
          }
          bVar1 = *local_80;
          if (local_84 < 9) {
            pbVar28 = pbVar28 + 1;
            local_80 = pbVar28;
          }
          uVar11 = uVar11 | (uint)bVar1 << (0x18 - uVar16 & 0xff);
          if (8 < local_84) {
            uVar11 = uVar11 | (uint)local_80[1] << ((uint)pbVar28 & 0xff);
            local_80 = local_80 + 2;
          }
        }
        uVar16 = iVar27 + 10;
        iVar23 = 10;
        uVar11 = uVar11 & -0x80000000 >> (iVar27 - 1U & 0xff);
        local_84 = 0;
      }
      else {
        uVar20 = 0x10 - uVar16;
        uVar5 = 0x18 - uVar16;
        uVar16 = uVar16 + 0x10;
        local_84 = local_84 + -0x10;
        uVar11 = uVar11 | (uint)local_80[1] << (uVar20 & 0xff) | (uint)*local_80 << (uVar5 & 0xff);
        local_80 = local_80 + 2;
      }
      do {
        puVar25 = puVar18 + 4;
        bVar1 = xmp3_quadTable[uVar10 + (uVar11 >> (0x20U - iVar12 & 0xff))];
        uVar5 = (uint)bVar1;
        uVar20 = uVar5 & 8;
        uVar11 = uVar11 << (uint)(bVar1 >> 4);
        uVar16 = uVar16 - (bVar1 >> 4);
        if ((bVar1 & 8) != 0) {
          uVar20 = uVar11 & 0x80000000;
          uVar16 = uVar16 - 1;
          uVar11 = uVar11 << 1;
          uVar20 = uVar20 | 1;
        }
        uVar30 = uVar5 & 4;
        if ((bVar1 & 4) != 0) {
          uVar30 = uVar11 & 0x80000000;
          uVar16 = uVar16 - 1;
          uVar11 = uVar11 << 1;
          uVar30 = uVar30 | 1;
        }
        uVar29 = uVar5 & 2;
        if ((bVar1 & 2) != 0) {
          uVar29 = uVar11 & 0x80000000;
          uVar16 = uVar16 - 1;
          uVar11 = uVar11 << 1;
          uVar29 = uVar29 | 1;
        }
        uVar5 = uVar5 & 1;
        if ((bVar1 & 1) != 0) {
          uVar16 = uVar16 - 1;
          uVar5 = uVar11 & 0x80000000 | 1;
          uVar11 = uVar11 << 1;
        }
        if ((int)uVar16 < iVar23) goto LAB_002bc104;
        iVar14 = iVar14 + 4;
        *puVar18 = uVar20;
        puVar18[1] = uVar30;
        puVar18[2] = uVar29;
        puVar18[3] = uVar5;
        puVar18 = puVar25;
      } while (iVar14 < 0x23d - iVar15 && 9 < (int)uVar16);
    }
  }
LAB_002bc104:
  iVar14 = iVar14 + *(int *)(iVar4 + 0x1200);
  *(int *)(iVar4 + 0x1200) = iVar14;
  if (iVar14 < 0x240) {
    puVar21 = (undefined4 *)(iVar13 + (param_6 * 0x240 + iVar14) * 4 + -4);
    do {
      puVar21 = puVar21 + 1;
      *puVar21 = 0;
    } while ((undefined4 *)(iVar13 + param_6 * 0x900 + 0x8fc) != puVar21);
  }
  uVar16 = *param_3;
  *param_3 = local_70 + uVar16 & 7;
  return local_6c + (((int)(local_70 + uVar16) >> 3) - (int)param_2);
}
