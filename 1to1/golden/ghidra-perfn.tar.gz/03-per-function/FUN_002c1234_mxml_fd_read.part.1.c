/* ============================================================
 * mxml_fd_read.part.1   @ 0x002c1234   size=92B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxml_fd_read_part_1(int *param_1)

{
  int *piVar1;
  ssize_t sVar2;
  int *__buf;
  
  __buf = param_1 + 3;
  do {
    sVar2 = read(*param_1,__buf,0x2000);
    if (-1 < sVar2) {
      if (sVar2 == 0) {
        return 0xffffffff;
      }
      param_1[1] = (int)__buf;
      param_1[2] = (int)__buf + sVar2;
      return 0;
    }
    piVar1 = __errno_location();
  } while (*piVar1 == 0xb || *piVar1 == 4);
  return 0xffffffff;
}
