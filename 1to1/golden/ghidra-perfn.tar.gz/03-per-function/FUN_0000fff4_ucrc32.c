/* ============================================================
 * ucrc32   @ 0x0000fff4   size=340B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

uint ucrc32(uint param_1,byte *param_2,uint param_3)

{
  byte *pbVar1;
  byte *pbVar2;
  uint uVar3;
  uint uVar4;
  
  if (param_2 != (byte *)0x0) {
    param_1 = ~param_1;
    if (7 < param_3) {
      uVar3 = param_3 - 8;
      pbVar1 = param_2 + 8;
      do {
        pbVar2 = pbVar1 + 8;
        uVar4 = *(uint *)(crc_table + ((pbVar1[-8] ^ param_1) & 0xff) * 4) ^ param_1 >> 8;
        uVar4 = *(uint *)(crc_table + ((pbVar1[-7] ^ uVar4) & 0xff) * 4) ^ uVar4 >> 8;
        uVar4 = *(uint *)(crc_table + ((pbVar1[-6] ^ uVar4) & 0xff) * 4) ^ uVar4 >> 8;
        uVar4 = *(uint *)(crc_table + ((pbVar1[-5] ^ uVar4) & 0xff) * 4) ^ uVar4 >> 8;
        uVar4 = *(uint *)(crc_table + ((pbVar1[-4] ^ uVar4) & 0xff) * 4) ^ uVar4 >> 8;
        uVar4 = *(uint *)(crc_table + ((pbVar1[-3] ^ uVar4) & 0xff) * 4) ^ uVar4 >> 8;
        uVar4 = *(uint *)(crc_table + ((pbVar1[-2] ^ uVar4) & 0xff) * 4) ^ uVar4 >> 8;
        param_1 = *(uint *)(crc_table + ((pbVar1[-1] ^ uVar4) & 0xff) * 4) ^ uVar4 >> 8;
        pbVar1 = pbVar2;
      } while (param_2 + (uVar3 & 0xfffffff8) + 0x10 != pbVar2);
      param_3 = param_3 & 7;
      param_2 = param_2 + (uVar3 & 0xfffffff8) + 8;
    }
    if (param_3 != 0) {
      pbVar1 = param_2;
      do {
        pbVar2 = pbVar1 + 1;
        param_1 = *(uint *)(crc_table + ((*pbVar1 ^ param_1) & 0xff) * 4) ^ param_1 >> 8;
        pbVar1 = pbVar2;
      } while (pbVar2 != param_2 + param_3);
    }
    return ~param_1;
  }
  return 0;
}
