/* ============================================================
 * mxml_string_getc   @ 0x002bf0d4   size=896B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

uint mxml_string_getc(undefined4 *param_1,int *param_2)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  ushort uVar4;
  byte *pbVar5;
  byte *pbVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  bool bVar10;
  
  pbVar5 = (byte *)*param_1;
  uVar7 = (uint)*pbVar5;
  iVar9 = *param_2;
  pbVar6 = pbVar5;
  if (uVar7 == 0) {
    if (iVar9 != 2) {
      return 0xffffffff;
    }
LAB_002bf28c:
    uVar7 = 0;
    *param_1 = pbVar6 + 1;
LAB_002bf298:
    bVar1 = pbVar6[1];
    uVar8 = uVar7 | (uint)bVar1 << 8;
    if (uVar8 == 0) {
      *param_1 = pbVar6;
      return 0xffffffff;
    }
    *param_1 = pbVar6 + 2;
    if (uVar8 < 0x20) {
      bVar10 = 0xc < uVar8;
      if (uVar8 != 0xd) {
        bVar10 = uVar8 != 9;
      }
      if (bVar10 && (uVar8 != 0xd && uVar8 != 10)) {
        mxml_error("Bad control character 0x%02x not allowed by XML standard!",uVar8);
        return 0xffffffff;
      }
    }
    if (0x3ff < uVar8 - 0xd800) {
      return uVar8;
    }
    if (pbVar6[3] != 0) {
      uVar4 = *(ushort *)(pbVar6 + 2);
      *param_1 = pbVar6 + 4;
      if (uVar4 - 0xdc00 < 0x3ff) {
        return ((uVar7 | (uint)bVar1 << 8 & 0x3ff) << 10 | uVar4 & 0x3ff) + 0x10000;
      }
    }
  }
  else {
    *param_1 = pbVar5 + 1;
    if (iVar9 != 1) {
      if (iVar9 == 2) goto LAB_002bf298;
      if (iVar9 != 0) {
        return 0xffffffff;
      }
      while( true ) {
        if ((uVar7 & 0x80) == 0) {
          if (0x1f < uVar7) {
            return uVar7;
          }
          bVar10 = 0xc < uVar7;
          if (uVar7 != 0xd) {
            bVar10 = uVar7 != 9;
          }
          if (bVar10 && (uVar7 != 0xd && uVar7 != 10)) {
            mxml_error("Bad control character 0x%02x not allowed by XML standard!",uVar7);
            return 0xffffffff;
          }
          return uVar7;
        }
        if (uVar7 == 0xfe) break;
        if (uVar7 == 0xff) {
          if (pbVar5[1] != 0xfe) {
            return 0xffffffff;
          }
          pbVar6 = pbVar5 + 2;
          *param_2 = 2;
          *param_1 = pbVar6;
          uVar7 = (uint)pbVar5[2];
          if (uVar7 == 0) goto LAB_002bf28c;
          *param_1 = pbVar5 + 3;
          goto LAB_002bf298;
        }
        if ((uVar7 & 0xe0) == 0xc0) {
          if ((pbVar5[1] & 0xc0) != 0x80) {
            return 0xffffffff;
          }
          uVar7 = pbVar5[1] & 0x3f | (uVar7 & 0x1f) << 6;
          *param_1 = pbVar5 + 2;
          if (uVar7 < 0x80) {
            mxml_error("Invalid UTF-8 sequence for character 0x%04x!",uVar7);
            return 0xffffffff;
          }
          return uVar7;
        }
        if ((uVar7 & 0xf0) != 0xe0) {
          if ((uVar7 & 0xf8) != 0xf0) {
            return 0xffffffff;
          }
          bVar1 = pbVar5[1];
          if ((bVar1 & 0xc0) != 0x80) {
            return 0xffffffff;
          }
          bVar2 = pbVar5[2];
          if ((bVar2 & 0xc0) != 0x80) {
            return 0xffffffff;
          }
          bVar3 = pbVar5[3];
          if ((bVar3 & 0xc0) != 0x80) {
            return 0xffffffff;
          }
          *param_1 = pbVar5 + 4;
          uVar7 = bVar3 & 0x3f | (bVar2 & 0x3f | ((uVar7 & 7) << 6 | bVar1 & 0x3f) << 6) << 6;
          if (uVar7 < 0x10000) {
            mxml_error("Invalid UTF-8 sequence for character 0x%04x!",uVar7);
            return 0xffffffff;
          }
          return uVar7;
        }
        bVar1 = pbVar5[1];
        if ((bVar1 & 0xc0) != 0x80) {
          return 0xffffffff;
        }
        bVar2 = pbVar5[2];
        if ((bVar2 & 0xc0) != 0x80) {
          return 0xffffffff;
        }
        pbVar6 = pbVar5 + 3;
        *param_1 = pbVar6;
        uVar7 = bVar2 & 0x3f | ((uVar7 & 0xf) << 6 | bVar1 & 0x3f) << 6;
        if (uVar7 < 0x800) {
          mxml_error("Invalid UTF-8 sequence for character 0x%04x!",uVar7);
          return 0xffffffff;
        }
        if (uVar7 != 0xfeff) {
          return uVar7;
        }
        uVar7 = (uint)*pbVar6;
        if (uVar7 == 0) {
          return 0xffffffff;
        }
        *param_1 = pbVar5 + 4;
        pbVar5 = pbVar6;
      }
      if (pbVar5[1] != 0xff) {
        return 0xffffffff;
      }
      pbVar6 = pbVar5 + 2;
      *param_2 = 1;
      *param_1 = pbVar6;
      uVar7 = (uint)pbVar5[2];
      if (uVar7 == 0) {
        return 0xffffffff;
      }
      *param_1 = pbVar5 + 3;
    }
    bVar1 = pbVar6[1];
    *param_1 = pbVar6 + 2;
    uVar8 = (uint)bVar1 | uVar7 << 8;
    if (0x3ff < uVar8 - 0xd800) {
      return uVar8;
    }
    bVar2 = pbVar6[2];
    if (bVar2 != 0) {
      bVar3 = pbVar6[3];
      *param_1 = pbVar6 + 4;
      uVar8 = (uint)CONCAT11(bVar2,bVar3);
      if (uVar8 - 0xdc00 < 0x3ff) {
        return (((uint)bVar1 | uVar7 << 8 & 0x3ff) << 10 | uVar8 & 0x3ff) + 0x10000;
      }
    }
  }
  return 0xffffffff;
}
