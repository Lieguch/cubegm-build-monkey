/* ============================================================
 * stbtt_GetCodepointKernAdvance   @ 0x0001adbc   size=84B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

undefined4 stbtt_GetCodepointKernAdvance(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if ((*(int *)(param_1 + 0x24) == 0) && (*(int *)(param_1 + 0x28) == 0)) {
    return 0;
  }
  uVar1 = stbtt_FindGlyphIndex();
  uVar2 = stbtt_FindGlyphIndex(param_1,param_3);
  uVar1 = stbtt_GetGlyphKernAdvance(param_1,uVar1,uVar2);
  return uVar1;
}
