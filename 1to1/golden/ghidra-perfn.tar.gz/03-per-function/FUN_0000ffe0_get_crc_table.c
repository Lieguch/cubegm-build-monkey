/* ============================================================
 * get_crc_table   @ 0x0000ffe0   size=16B   callers=0
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */
/* get_crc_table() */

undefined1 * get_crc_table(void)

{
  return crc_table;
}
