/* ============================================================
 * stbtt__rasterize_sorted_edges.isra.16   @ 0x00016550   size=2404B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt__rasterize_sorted_edges_isra_16
               (int *param_1,float *param_2,int param_3,float *param_4,int param_5)

{
  uint uVar1;
  byte bVar2;
  float fVar3;
  int iVar4;
  float *pfVar5;
  undefined4 *puVar6;
  float *__s;
  int iVar7;
  int iVar8;
  float *__s_00;
  void *pvVar9;
  size_t __n;
  undefined4 *******pppppppuVar10;
  int iVar11;
  undefined4 *******pppppppuVar12;
  undefined4 *******pppppppuVar13;
  float *pfVar14;
  bool bVar15;
  uint in_fpscr;
  uint uVar16;
  uint uVar17;
  undefined4 ******ppppppuVar18;
  undefined4 ******extraout_s4;
  undefined4 ******extraout_s4_00;
  undefined4 ******extraout_s4_01;
  undefined4 ******extraout_s4_02;
  undefined4 ******extraout_s4_03;
  undefined4 ******extraout_s4_04;
  undefined4 ******extraout_s4_05;
  undefined4 ******extraout_s4_06;
  undefined4 ******extraout_s5;
  undefined4 ******extraout_s5_00;
  undefined4 ******extraout_s5_01;
  undefined4 ******extraout_s5_02;
  undefined4 ******extraout_s5_03;
  undefined4 ******extraout_s5_04;
  undefined4 ******extraout_s5_05;
  undefined4 ******extraout_s5_06;
  float extraout_s7;
  float extraout_s7_00;
  float extraout_s8;
  float extraout_s8_00;
  float extraout_s8_01;
  float extraout_s8_02;
  float extraout_s9;
  float extraout_s9_00;
  float extraout_s9_01;
  float extraout_s9_02;
  undefined4 ******ppppppuVar19;
  undefined4 ******ppppppuVar20;
  float extraout_s10;
  float extraout_s10_00;
  undefined4 ******extraout_s11;
  undefined4 ******extraout_s11_00;
  undefined4 ******extraout_s11_01;
  undefined4 ******extraout_s11_02;
  undefined4 ******extraout_s11_03;
  undefined4 ******extraout_s11_04;
  undefined4 ******extraout_s11_05;
  undefined4 ******extraout_s11_06;
  undefined4 extraout_s11_07;
  undefined4 ******extraout_s12;
  undefined4 ******ppppppuVar21;
  undefined4 ******ppppppuVar22;
  undefined4 ******extraout_s12_00;
  undefined4 ******extraout_s12_01;
  undefined4 ******extraout_s12_02;
  undefined4 ******extraout_s12_03;
  undefined4 ******extraout_s12_04;
  undefined4 ******extraout_s12_05;
  undefined4 ******extraout_s12_06;
  undefined4 ******extraout_s12_07;
  undefined4 ******extraout_s12_08;
  undefined4 ******extraout_s12_09;
  undefined4 ******extraout_s12_10;
  undefined4 ******extraout_s13;
  undefined4 ******ppppppuVar23;
  int iVar24;
  undefined4 ******extraout_s13_00;
  undefined4 ******extraout_s13_01;
  undefined4 ******extraout_s13_02;
  undefined4 ******extraout_s13_03;
  undefined4 ******extraout_s13_04;
  undefined4 ******extraout_s13_05;
  undefined4 ******extraout_s13_06;
  undefined4 ******extraout_s13_07;
  undefined4 ******extraout_s13_08;
  undefined4 ******extraout_s13_09;
  undefined4 ******extraout_s13_10;
  undefined4 ******ppppppuVar25;
  float fVar26;
  undefined4 ******ppppppuVar27;
  float fVar28;
  float fVar29;
  undefined4 ******ppppppuVar30;
  undefined4 ******ppppppuVar31;
  undefined4 ******ppppppuVar32;
  undefined4 ******ppppppuVar33;
  int local_278;
  float *local_270;
  undefined4 *local_26c;
  int local_268;
  float *local_25c;
  undefined4 ******local_258;
  float local_254 [130];
  
  iVar11 = *param_1;
  __s = param_4;
  if (iVar11 < 0x41) {
    __s = local_254;
  }
  local_258 = (undefined4 *******)0x0;
  local_25c = __s;
  if (0x40 < iVar11) {
    __s = malloc(iVar11 * 8 + 4);
    local_25c = local_254;
  }
  iVar8 = param_1[1];
  __n = iVar11 * 4;
  __s_00 = __s + iVar11;
  fVar28 = (float)VectorSignedToFloat(iVar8 + param_5,(byte)(in_fpscr >> 0x16) & 3);
  param_2[param_3 * 5 + 1] = fVar28 + 1.0;
  if (0 < iVar8) {
    pppppppuVar12 = (undefined4 *******)0x0;
    local_268 = 0;
    local_26c = (undefined4 *)0x0;
    local_278 = 0;
    pppppppuVar10 = (undefined4 *******)0x0;
    local_270 = param_2;
    do {
      memset(__s,0,__n);
      memset(__s_00,0,__n + 4);
      fVar28 = (float)VectorSignedToFloat(local_278 + param_5,(byte)(in_fpscr >> 0x16) & 3);
      ppppppuVar31 = (undefined4 ******)(fVar28 + 0.0);
      fVar28 = fVar28 + 1.0;
      pppppppuVar13 = &local_258;
      while (pppppppuVar10 != (undefined4 *******)0x0) {
        uVar16 = in_fpscr & 0xfffffff |
                 (uint)((float)ppppppuVar31 < (float)pppppppuVar10[6]) << 0x1f;
        in_fpscr = uVar16 | (uint)(NAN((float)ppppppuVar31) || NAN((float)pppppppuVar10[6])) << 0x1c
        ;
        if ((byte)(uVar16 >> 0x1f) == ((byte)(in_fpscr >> 0x1c) & 1)) {
          *pppppppuVar13 = *pppppppuVar10;
          *pppppppuVar10 = pppppppuVar12;
          pppppppuVar10[4] = (undefined4 ******)0x0;
          pppppppuVar12 = pppppppuVar10;
          pppppppuVar10 = pppppppuVar13;
        }
        pppppppuVar13 = pppppppuVar10;
        pppppppuVar10 = (undefined4 *******)*pppppppuVar13;
      }
      ppppppuVar32 = (undefined4 ******)local_270[1];
      uVar16 = in_fpscr & 0xfffffff | (uint)(fVar28 < (float)ppppppuVar32) << 0x1f;
      in_fpscr = uVar16 | (uint)(NAN(fVar28) || NAN((float)ppppppuVar32)) << 0x1c;
      pppppppuVar10 = (undefined4 *******)local_258;
      ppppppuVar21 = extraout_s12;
      ppppppuVar23 = extraout_s13;
      pfVar5 = local_270;
      if ((byte)(uVar16 >> 0x1f) == ((byte)(in_fpscr >> 0x1c) & 1)) {
        do {
          local_270 = pfVar5 + 5;
          ppppppuVar33 = (undefined4 ******)pfVar5[3];
          uVar16 = in_fpscr & 0xfffffff | (uint)((float)ppppppuVar33 == (float)ppppppuVar32) << 0x1e
          ;
          if (!SUB41(uVar16 >> 0x1e,0)) {
            if (pppppppuVar12 == (undefined4 *******)0x0) {
              if (local_268 == 0) {
                puVar6 = malloc(0xdac4);
                ppppppuVar21 = extraout_s12_10;
                ppppppuVar23 = extraout_s13_10;
                if (puVar6 == (undefined4 *)0x0) goto LAB_0001669c;
                local_268 = 1999;
                *puVar6 = local_26c;
                iVar8 = 0xdaa8;
                local_26c = puVar6;
              }
              else {
                local_268 = local_268 + -1;
                iVar8 = local_268 * 0x1c + 4;
              }
              pppppppuVar13 = (undefined4 *******)((int)local_26c + iVar8);
              if (pppppppuVar13 == (undefined4 *******)0x0) goto LAB_0001669c;
              fVar29 = *pfVar5;
              ppppppuVar21 = (undefined4 ******)(pfVar5[2] - fVar29);
              ppppppuVar25 = (undefined4 ******)
                             ((float)ppppppuVar21 / ((float)ppppppuVar33 - (float)ppppppuVar32));
            }
            else {
              fVar29 = *pfVar5;
              ppppppuVar21 = (undefined4 ******)(pfVar5[2] - fVar29);
              ppppppuVar25 = (undefined4 ******)
                             ((float)ppppppuVar21 / ((float)ppppppuVar33 - (float)ppppppuVar32));
              pppppppuVar13 = pppppppuVar12;
              pppppppuVar12 = (undefined4 *******)*pppppppuVar12;
            }
            pppppppuVar13[2] = ppppppuVar25;
            fVar3 = pfVar5[4];
            *pppppppuVar13 = (undefined4 ******)0x0;
            pppppppuVar13[5] = ppppppuVar32;
            pppppppuVar13[6] = ppppppuVar33;
            uVar17 = uVar16 & 0xfffffff;
            uVar16 = uVar17 | (uint)((float)ppppppuVar25 == 0.0) << 0x1e;
            ppppppuVar23 = (undefined4 ******)((float)ppppppuVar31 - (float)ppppppuVar32);
            bVar15 = SUB41(uVar16 >> 0x1e,0);
            if (!bVar15) {
              ppppppuVar21 = (undefined4 ******)(1.0 / (float)ppppppuVar25);
            }
            fVar26 = (float)VectorSignedToFloat(param_4,(byte)(uVar16 >> 0x16) & 3);
            if (bVar15) {
              ppppppuVar21 = (undefined4 ******)0x0;
            }
            pppppppuVar13[1] =
                 (undefined4 ******)((fVar29 + (float)ppppppuVar23 * (float)ppppppuVar25) - fVar26);
            ppppppuVar32 = (undefined4 ******)0x3f800000;
            if (fVar3 == 0.0) {
              ppppppuVar32 = (undefined4 ******)0xbf800000;
            }
            pppppppuVar13[3] = ppppppuVar21;
            pppppppuVar13[4] = ppppppuVar32;
            if (param_5 != 0 && local_278 == 0) {
              uVar17 = uVar17 | (uint)((float)ppppppuVar31 < (float)ppppppuVar33) << 0x1f |
                       (uint)((float)ppppppuVar31 == (float)ppppppuVar33) << 0x1e;
              uVar16 = uVar17 | (uint)(NAN((float)ppppppuVar31) || NAN((float)ppppppuVar33)) << 0x1c
              ;
              bVar2 = (byte)(uVar17 >> 0x18);
              if (!(bool)(bVar2 >> 6 & 1) && bVar2 >> 7 == ((byte)(uVar16 >> 0x1c) & 1)) {
                pppppppuVar13[6] = ppppppuVar31;
              }
            }
            *pppppppuVar13 = pppppppuVar10;
            pppppppuVar10 = pppppppuVar13;
            local_258 = pppppppuVar13;
          }
LAB_0001669c:
          ppppppuVar32 = (undefined4 ******)pfVar5[6];
          uVar16 = uVar16 & 0xfffffff | (uint)(fVar28 < (float)ppppppuVar32) << 0x1f;
          in_fpscr = uVar16 | (uint)(NAN(fVar28) || NAN((float)ppppppuVar32)) << 0x1c;
          pfVar5 = local_270;
        } while ((byte)(uVar16 >> 0x1f) == ((byte)(in_fpscr >> 0x1c) & 1));
      }
      if (pppppppuVar10 == (undefined4 *******)0x0) {
        if (0 < iVar11) goto LAB_000169d0;
      }
      else {
        ppppppuVar32 = (undefined4 ******)((float)ppppppuVar31 + 1.0);
        pppppppuVar13 = pppppppuVar10;
        do {
          while( true ) {
            ppppppuVar33 = pppppppuVar13[2];
            uVar16 = in_fpscr & 0xfffffff;
            uVar17 = uVar16 | (uint)((float)ppppppuVar33 == 0.0) << 0x1e;
            if (!SUB41(uVar17 >> 0x1e,0)) break;
            ppppppuVar33 = pppppppuVar13[1];
            fVar28 = (float)VectorSignedToFloat(iVar11,(byte)(uVar17 >> 0x16) & 3);
            in_fpscr = uVar16 | (uint)((float)ppppppuVar33 < fVar28) << 0x1f;
            if (SUB41(in_fpscr >> 0x1f,0)) {
              in_fpscr = uVar16 | (uint)((float)ppppppuVar31 == (float)ppppppuVar32) << 0x1e;
              bVar2 = (byte)(in_fpscr >> 0x18);
              if (NAN((float)ppppppuVar33)) {
                if (!(bool)(bVar2 >> 6)) {
                  stbtt__handle_clipped_edge_part_9
                            (ppppppuVar33,ppppppuVar31,ppppppuVar33,ppppppuVar32,__s_00,0,
                             pppppppuVar13);
                  ppppppuVar21 = extraout_s12_08;
                  ppppppuVar23 = extraout_s13_08;
                }
              }
              else if (!(bool)(bVar2 >> 6)) {
                stbtt__handle_clipped_edge_part_9
                          (ppppppuVar33,ppppppuVar31,ppppppuVar33,ppppppuVar32,__s,
                           (int)(float)ppppppuVar33,pppppppuVar13);
                stbtt__handle_clipped_edge_part_9
                          (extraout_s11_07,ppppppuVar31,extraout_s11_07,ppppppuVar32,__s_00,
                           (int)(float)ppppppuVar33 + 1,pppppppuVar13);
                ppppppuVar21 = extraout_s12_09;
                ppppppuVar23 = extraout_s13_09;
              }
            }
LAB_000167d0:
            pppppppuVar13 = (undefined4 *******)*pppppppuVar13;
            if (pppppppuVar13 == (undefined4 *******)0x0) goto LAB_000169c4;
          }
          ppppppuVar30 = pppppppuVar13[5];
          ppppppuVar25 = pppppppuVar13[1];
          ppppppuVar19 = pppppppuVar13[6];
          ppppppuVar27 = ppppppuVar25;
          if ((float)ppppppuVar31 < (float)ppppppuVar30) {
            ppppppuVar23 = (undefined4 ******)
                           ((float)ppppppuVar25 +
                           ((float)ppppppuVar30 - (float)ppppppuVar31) * (float)ppppppuVar33);
            ppppppuVar27 = ppppppuVar23;
          }
          ppppppuVar18 = (undefined4 ******)((float)ppppppuVar33 + (float)ppppppuVar25);
          if ((float)ppppppuVar31 >= (float)ppppppuVar30) {
            ppppppuVar30 = ppppppuVar31;
          }
          ppppppuVar22 = ppppppuVar21;
          if ((float)ppppppuVar19 < (float)ppppppuVar32) {
            ppppppuVar23 = (undefined4 ******)((float)ppppppuVar19 - (float)ppppppuVar31);
            ppppppuVar22 = ppppppuVar25;
          }
          uVar17 = uVar16 | (uint)((float)ppppppuVar27 < 0.0) << 0x1f;
          in_fpscr = uVar17 | (uint)NAN((float)ppppppuVar27) << 0x1c;
          ppppppuVar21 = ppppppuVar18;
          ppppppuVar20 = ppppppuVar32;
          if ((float)ppppppuVar19 < (float)ppppppuVar32) {
            ppppppuVar21 = (undefined4 ******)
                           ((float)ppppppuVar22 + (float)ppppppuVar23 * (float)ppppppuVar33);
            ppppppuVar20 = ppppppuVar19;
          }
          if (((byte)(uVar17 >> 0x1f) != ((byte)(in_fpscr >> 0x1c) & 1)) ||
             (uVar17 = uVar16 | (uint)((float)ppppppuVar21 < 0.0) << 0x1f,
             in_fpscr = uVar17 | (uint)NAN((float)ppppppuVar21) << 0x1c,
             (byte)(uVar17 >> 0x1f) != ((byte)(in_fpscr >> 0x1c) & 1))) {
LAB_00016a80:
            if (0 < iVar11) {
              iVar8 = 0;
              do {
                iVar24 = iVar8 + 1;
                fVar26 = (float)VectorSignedToFloat(iVar8,(byte)(in_fpscr >> 0x16) & 3);
                fVar28 = (float)VectorSignedToFloat(iVar24,(byte)(in_fpscr >> 0x16) & 3);
                uVar16 = in_fpscr & 0xfffffff;
                fVar3 = (fVar26 - (float)ppppppuVar25) / (float)ppppppuVar33 + (float)ppppppuVar31;
                fVar29 = (fVar28 - (float)ppppppuVar25) / (float)ppppppuVar33 + (float)ppppppuVar31;
                if ((float)ppppppuVar25 < fVar26) {
                  if ((float)ppppppuVar18 <= fVar28) {
                    uVar17 = uVar16 | (uint)((float)ppppppuVar18 < fVar26) << 0x1f;
                    if ((SUB41(uVar17 >> 0x1f,0)) &&
                       (uVar16 = uVar16 | (uint)((float)ppppppuVar25 < fVar28) << 0x1f |
                                 (uint)((float)ppppppuVar25 == fVar28) << 0x1e,
                       uVar17 = uVar16 | (uint)(NAN((float)ppppppuVar25) || NAN(fVar28)) << 0x1c,
                       bVar2 = (byte)(uVar16 >> 0x18),
                       !(bool)(bVar2 >> 6 & 1) && bVar2 >> 7 == ((byte)(uVar17 >> 0x1c) & 1)))
                    goto LAB_00016bec;
LAB_00016b7c:
                    uVar16 = uVar17 & 0xfffffff | (uint)((float)ppppppuVar18 < fVar26) << 0x1f |
                             (uint)((float)ppppppuVar18 == fVar26) << 0x1e;
                    uVar17 = uVar16 | (uint)(NAN((float)ppppppuVar18) || NAN(fVar26)) << 0x1c;
                    bVar2 = (byte)(uVar16 >> 0x18);
                    bVar15 = (bool)(bVar2 >> 7);
                    if (!(bool)(bVar2 >> 6 & 1) && bVar15 == (bool)((byte)(uVar17 >> 0x1c) & 1))
                    goto LAB_00016b40;
                    if (bVar15) goto LAB_00016b34;
                    goto LAB_00016b8c;
                  }
                  uVar17 = uVar16 | (uint)((float)ppppppuVar31 == fVar3) << 0x1e;
                  if (SUB41(uVar17 >> 0x1e,0)) {
                    uVar16 = uVar16 | (uint)(fVar3 == fVar29) << 0x1e;
                    bVar2 = (byte)(uVar16 >> 0x18);
                  }
                  else {
                    stbtt__handle_clipped_edge_part_9
                              (ppppppuVar25,ppppppuVar31,fVar26,fVar3,__s,iVar8,pppppppuVar13);
                    uVar16 = uVar17 & 0xfffffff | (uint)(extraout_s9_00 == extraout_s8_00) << 0x1e;
                    bVar2 = (byte)(uVar16 >> 0x18);
                    ppppppuVar18 = extraout_s4_03;
                    ppppppuVar33 = extraout_s5_03;
                    fVar28 = extraout_s7;
                    fVar29 = extraout_s8_00;
                    fVar3 = extraout_s9_00;
                    fVar26 = extraout_s10;
                    ppppppuVar25 = extraout_s11_03;
                    ppppppuVar21 = extraout_s12_04;
                    ppppppuVar23 = extraout_s13_04;
                  }
                  if (!(bool)(bVar2 >> 6)) {
                    stbtt__handle_clipped_edge_part_9
                              (fVar26,fVar3,fVar28,fVar29,__s,iVar8,pppppppuVar13);
                    ppppppuVar18 = extraout_s4_04;
                    ppppppuVar33 = extraout_s5_04;
                    fVar29 = extraout_s8_01;
                    ppppppuVar25 = extraout_s11_04;
                    ppppppuVar21 = extraout_s12_05;
                    ppppppuVar23 = extraout_s13_05;
                  }
LAB_00016ab4:
                  in_fpscr = uVar16 & 0xfffffff | (uint)((float)ppppppuVar32 == fVar29) << 0x1e;
                  bVar2 = (byte)(in_fpscr >> 0x18);
joined_r0x00016abc:
                  if (!(bool)(bVar2 >> 6)) {
                    stbtt__handle_clipped_edge_part_9(__s);
                    ppppppuVar18 = extraout_s4;
                    ppppppuVar33 = extraout_s5;
                    ppppppuVar25 = extraout_s11;
                    ppppppuVar21 = extraout_s12_00;
                    ppppppuVar23 = extraout_s13_00;
                  }
                }
                else {
                  uVar17 = uVar16 | (uint)((float)ppppppuVar18 < fVar26) << 0x1f;
                  if (SUB41(uVar17 >> 0x1f,0)) {
                    uVar1 = uVar16 | (uint)((float)ppppppuVar25 < fVar28) << 0x1f |
                            (uint)((float)ppppppuVar25 == fVar28) << 0x1e;
                    uVar17 = uVar1 | (uint)(NAN((float)ppppppuVar25) || NAN(fVar28)) << 0x1c;
                    bVar2 = (byte)(uVar1 >> 0x18);
                    if ((bool)(bVar2 >> 6 & 1) || bVar2 >> 7 != ((byte)(uVar17 >> 0x1c) & 1)) {
                      uVar17 = uVar16 | (uint)((float)ppppppuVar25 < fVar26) << 0x1f;
                      if (SUB41(uVar17 >> 0x1f,0)) goto LAB_00016b7c;
LAB_00016b34:
                      uVar16 = uVar17 & 0xfffffff | (uint)((float)ppppppuVar25 < fVar26) << 0x1f |
                               (uint)((float)ppppppuVar25 == fVar26) << 0x1e;
                      uVar17 = uVar16 | (uint)(NAN((float)ppppppuVar25) || NAN(fVar26)) << 0x1c;
                      bVar2 = (byte)(uVar16 >> 0x18);
                      if ((bool)(bVar2 >> 6 & 1) || bVar2 >> 7 != ((byte)(uVar17 >> 0x1c) & 1))
                      goto LAB_00016b8c;
LAB_00016b40:
                      uVar16 = uVar17 & 0xfffffff | (uint)((float)ppppppuVar31 == fVar3) << 0x1e;
                      if (!SUB41(uVar16 >> 0x1e,0)) {
                        stbtt__handle_clipped_edge_part_9
                                  (ppppppuVar25,ppppppuVar31,fVar26,fVar3,__s,iVar8,pppppppuVar13);
                        ppppppuVar18 = extraout_s4_05;
                        ppppppuVar33 = extraout_s5_05;
                        fVar3 = extraout_s9_01;
                        ppppppuVar25 = extraout_s11_05;
                        ppppppuVar21 = extraout_s12_06;
                        ppppppuVar23 = extraout_s13_06;
                      }
                    }
                    else {
LAB_00016bec:
                      uVar16 = uVar17 & 0xfffffff | (uint)((float)ppppppuVar31 == fVar29) << 0x1e;
                      if (!SUB41(uVar16 >> 0x1e,0)) {
                        stbtt__handle_clipped_edge_part_9
                                  (ppppppuVar25,ppppppuVar31,fVar28,fVar29,__s,iVar8,pppppppuVar13);
                        ppppppuVar18 = extraout_s4_06;
                        ppppppuVar33 = extraout_s5_06;
                        fVar28 = extraout_s7_00;
                        fVar29 = extraout_s8_02;
                        fVar3 = extraout_s9_02;
                        fVar26 = extraout_s10_00;
                        ppppppuVar25 = extraout_s11_06;
                        ppppppuVar21 = extraout_s12_07;
                        ppppppuVar23 = extraout_s13_07;
                      }
                      uVar16 = uVar16 & 0xfffffff | (uint)(fVar3 == fVar29) << 0x1e;
                      if (!SUB41(uVar16 >> 0x1e,0)) {
                        stbtt__handle_clipped_edge_part_9
                                  (fVar28,fVar29,fVar26,fVar3,__s,iVar8,pppppppuVar13);
                        ppppppuVar18 = extraout_s4_01;
                        ppppppuVar33 = extraout_s5_01;
                        fVar3 = extraout_s9;
                        ppppppuVar25 = extraout_s11_01;
                        ppppppuVar21 = extraout_s12_02;
                        ppppppuVar23 = extraout_s13_02;
                      }
                    }
                    in_fpscr = uVar16 & 0xfffffff | (uint)((float)ppppppuVar32 == fVar3) << 0x1e;
                    bVar2 = (byte)(in_fpscr >> 0x18);
                    goto joined_r0x00016abc;
                  }
LAB_00016b8c:
                  uVar16 = uVar17 & 0xfffffff | (uint)((float)ppppppuVar25 < fVar28) << 0x1f;
                  if ((SUB41(uVar16 >> 0x1f,0)) &&
                     (uVar16 = uVar17 & 0xfffffff | (uint)((float)ppppppuVar18 < fVar28) << 0x1f |
                               (uint)((float)ppppppuVar18 == fVar28) << 0x1e,
                     bVar2 = (byte)(uVar16 >> 0x18),
                     !(bool)(bVar2 >> 6 & 1) &&
                     (bool)(bVar2 >> 7) == (NAN((float)ppppppuVar18) || NAN(fVar28)))) {
LAB_00016ba4:
                    uVar16 = uVar16 & 0xfffffff | (uint)((float)ppppppuVar31 == fVar29) << 0x1e;
                    if (!SUB41(uVar16 >> 0x1e,0)) {
                      stbtt__handle_clipped_edge_part_9
                                (ppppppuVar25,ppppppuVar31,fVar28,fVar29,__s,iVar8,pppppppuVar13);
                      ppppppuVar18 = extraout_s4_00;
                      ppppppuVar33 = extraout_s5_00;
                      fVar29 = extraout_s8;
                      ppppppuVar25 = extraout_s11_00;
                      ppppppuVar21 = extraout_s12_01;
                      ppppppuVar23 = extraout_s13_01;
                    }
                    goto LAB_00016ab4;
                  }
                  uVar17 = uVar16 & 0xfffffff;
                  uVar16 = uVar17 | (uint)((float)ppppppuVar18 < fVar28) << 0x1f;
                  if ((SUB41(uVar16 >> 0x1f,0)) &&
                     (uVar16 = uVar17 | (uint)((float)ppppppuVar25 < fVar28) << 0x1f |
                               (uint)((float)ppppppuVar25 == fVar28) << 0x1e,
                     bVar2 = (byte)(uVar16 >> 0x18),
                     !(bool)(bVar2 >> 6 & 1) &&
                     (bool)(bVar2 >> 7) == (NAN((float)ppppppuVar25) || NAN(fVar28))))
                  goto LAB_00016ba4;
                  in_fpscr = uVar16 & 0xfffffff |
                             (uint)((float)ppppppuVar31 == (float)ppppppuVar32) << 0x1e;
                  if (!SUB41(in_fpscr >> 0x1e,0)) {
                    stbtt__handle_clipped_edge_part_9
                              (ppppppuVar25,ppppppuVar31,ppppppuVar18,ppppppuVar32,__s,iVar8,
                               pppppppuVar13);
                    ppppppuVar18 = extraout_s4_02;
                    ppppppuVar33 = extraout_s5_02;
                    ppppppuVar25 = extraout_s11_02;
                    ppppppuVar21 = extraout_s12_03;
                    ppppppuVar23 = extraout_s13_03;
                  }
                }
                iVar8 = iVar24;
              } while (iVar24 != iVar11);
            }
            goto LAB_000167d0;
          }
          ppppppuVar23 = (undefined4 ******)VectorSignedToFloat(iVar11,(byte)(in_fpscr >> 0x16) & 3)
          ;
          in_fpscr = uVar16 | (uint)((float)ppppppuVar27 < (float)ppppppuVar23) << 0x1f;
          if ((!SUB41(in_fpscr >> 0x1f,0)) ||
             (in_fpscr = uVar16 | (uint)((float)ppppppuVar21 < (float)ppppppuVar23) << 0x1f,
             !SUB41(in_fpscr >> 0x1f,0))) goto LAB_00016a80;
          iVar8 = (int)(float)ppppppuVar27;
          iVar24 = (int)(float)ppppppuVar21;
          if (iVar8 == iVar24) {
            fVar28 = (float)VectorSignedToFloat(iVar8,(byte)(in_fpscr >> 0x16) & 3);
            ppppppuVar23 = (undefined4 ******)
                           (1.0 - (((float)ppppppuVar27 - fVar28) + ((float)ppppppuVar21 - fVar28))
                                  * 0.5);
            __s[iVar8] = __s[iVar8] +
                         (float)ppppppuVar23 * (float)pppppppuVar13[4] *
                         ((float)ppppppuVar20 - (float)ppppppuVar30);
            __s_00[iVar8 + 1] =
                 __s_00[iVar8 + 1] +
                 ((float)ppppppuVar20 - (float)ppppppuVar30) * (float)pppppppuVar13[4];
            goto LAB_000167d0;
          }
          uVar16 = uVar16 | (uint)((float)ppppppuVar27 < (float)ppppppuVar21) << 0x1f |
                   (uint)((float)ppppppuVar27 == (float)ppppppuVar21) << 0x1e;
          in_fpscr = uVar16 | (uint)(NAN((float)ppppppuVar27) || NAN((float)ppppppuVar21)) << 0x1c;
          ppppppuVar33 = pppppppuVar13[3];
          bVar2 = (byte)(uVar16 >> 0x18);
          iVar7 = iVar24;
          ppppppuVar23 = ppppppuVar21;
          if (!(bool)(bVar2 >> 6 & 1) && bVar2 >> 7 == ((byte)(in_fpscr >> 0x1c) & 1)) {
            fVar28 = (float)ppppppuVar20 - (float)ppppppuVar31;
            ppppppuVar20 = (undefined4 ******)
                           ((float)ppppppuVar32 - ((float)ppppppuVar30 - (float)ppppppuVar31));
            ppppppuVar30 = (undefined4 ******)((float)ppppppuVar32 - fVar28);
            ppppppuVar33 = (undefined4 ******)-(float)ppppppuVar33;
            iVar7 = iVar8;
            iVar8 = iVar24;
            ppppppuVar25 = ppppppuVar18;
            ppppppuVar23 = ppppppuVar27;
            ppppppuVar27 = ppppppuVar21;
          }
          iVar24 = iVar8 + 1;
          ppppppuVar19 = pppppppuVar13[4];
          fVar28 = (float)VectorSignedToFloat(iVar24,(byte)(in_fpscr >> 0x16) & 3);
          fVar3 = (float)VectorSignedToFloat(iVar8,(byte)(in_fpscr >> 0x16) & 3);
          fVar28 = (float)ppppppuVar31 + (fVar28 - (float)ppppppuVar25) * (float)ppppppuVar33;
          fVar29 = (fVar28 - (float)ppppppuVar30) * (float)ppppppuVar19;
          __s[iVar8] = __s[iVar8] + (1.0 - (((float)ppppppuVar27 - fVar3) + 1.0) * 0.5) * fVar29;
          if (iVar24 < iVar7) {
            iVar4 = iVar7 * 4;
            pfVar5 = __s + iVar8 + 1;
            do {
              *pfVar5 = *pfVar5 + fVar29 + (float)ppppppuVar33 * (float)ppppppuVar19 * 0.5;
              pfVar5 = pfVar5 + 1;
              fVar29 = fVar29 + (float)ppppppuVar33 * (float)ppppppuVar19;
            } while (__s + iVar7 != pfVar5);
          }
          else {
            iVar4 = iVar7 << 2;
          }
          pppppppuVar13 = (undefined4 *******)*pppppppuVar13;
          pfVar5 = (float *)((int)__s_00 + iVar4 + 4);
          fVar26 = (float)VectorSignedToFloat(iVar7,(byte)(in_fpscr >> 0x16) & 3);
          fVar3 = (float)VectorSignedToFloat(iVar7 - iVar24,(byte)(in_fpscr >> 0x16) & 3);
          ppppppuVar21 = (undefined4 ******)
                         ((1.0 - (((float)ppppppuVar23 - fVar26) + 0.0) * 0.5) * (float)ppppppuVar19
                         );
          ppppppuVar23 = (undefined4 ******)
                         ((float)ppppppuVar20 - (fVar28 + fVar3 * (float)ppppppuVar33));
          *(float *)((int)__s + iVar4) =
               *(float *)((int)__s + iVar4) + fVar29 + (float)ppppppuVar21 * (float)ppppppuVar23;
          *pfVar5 = *pfVar5 + ((float)ppppppuVar20 - (float)ppppppuVar30) * (float)ppppppuVar19;
        } while (pppppppuVar13 != (undefined4 *******)0x0);
LAB_000169c4:
        if (0 < *param_1) {
LAB_000169d0:
          fVar28 = 0.0;
          iVar11 = 0;
          pfVar5 = __s;
          pfVar14 = __s_00;
          do {
            fVar29 = *pfVar14;
            pfVar14 = pfVar14 + 1;
            fVar3 = *pfVar5;
            pfVar5 = pfVar5 + 1;
            fVar28 = fVar28 + fVar29;
            iVar8 = (int)(ABS(fVar28 + fVar3) * 255.0 + 0.5);
            if (0xfe < iVar8) {
              iVar8 = 0xff;
            }
            *(char *)(param_1[2] * local_278 + param_1[3] + iVar11) = (char)iVar8;
            iVar11 = iVar11 + 1;
          } while (iVar11 < *param_1);
          if (pppppppuVar10 == (undefined4 *******)0x0) goto LAB_00016a58;
        }
        do {
          pppppppuVar10[1] = (undefined4 ******)((float)pppppppuVar10[1] + (float)pppppppuVar10[2]);
          pppppppuVar10 = (undefined4 *******)*pppppppuVar10;
        } while (pppppppuVar10 != (undefined4 *******)0x0);
      }
LAB_00016a58:
      local_278 = local_278 + 1;
      if (param_1[1] <= local_278) goto joined_r0x00016e68;
      iVar11 = *param_1;
      __n = iVar11 << 2;
      pppppppuVar10 = (undefined4 *******)local_258;
    } while( true );
  }
LAB_00016e80:
  if (__s != local_25c) {
    free(__s);
  }
  return;
joined_r0x00016e68:
  while (local_26c != (void *)0x0) {
    pvVar9 = (void *)*local_26c;
    free(local_26c);
    local_26c = pvVar9;
  }
  goto LAB_00016e80;
}
