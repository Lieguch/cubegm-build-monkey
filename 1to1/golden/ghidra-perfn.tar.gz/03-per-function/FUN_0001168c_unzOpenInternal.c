/* ============================================================
 * unzOpenInternal   @ 0x0001168c   size=468B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzOpenInternal(LUFILE*) */

unz_s * unzOpenInternal(LUFILE *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  unz_s *__dest;
  ulong uStack_a8;
  ulong local_a4;
  ulong local_a0;
  ulong local_9c;
  LUFILE *local_98;
  ulong local_94;
  ulong uStack_90;
  int local_8c;
  int local_7c;
  ulong local_78;
  ulong local_74 [22];
  int local_1c;
  
  zopenerror = 0;
  if (param_1 == (LUFILE *)0x0) {
    zopenerror = 0x10000;
  }
  else {
    iVar1 = unzlocal_SearchCentralDir(param_1);
    iVar2 = lufseek(param_1,iVar1,0);
    if (iVar2 == 0) {
      iVar2 = -(uint)(iVar1 == 0);
    }
    else {
      iVar2 = -1;
    }
    iVar3 = unzlocal_getLong(param_1,&uStack_a8);
    if (iVar3 != 0) {
      iVar2 = -1;
    }
    iVar3 = unzlocal_getShort(param_1,&local_a4);
    if (iVar3 != 0) {
      iVar2 = -1;
    }
    iVar3 = unzlocal_getShort(param_1,&local_a0);
    if (iVar3 != 0) {
      iVar2 = -1;
    }
    iVar3 = unzlocal_getShort(param_1,&local_94);
    if (iVar3 != 0) {
      iVar2 = -1;
    }
    iVar3 = unzlocal_getShort(param_1,&local_9c);
    if (iVar3 != 0) {
      iVar2 = -1;
    }
    if ((local_94 == local_9c) && (local_a0 == 0)) {
      if (local_a4 != 0) {
        iVar2 = -0x67;
      }
    }
    else {
      iVar2 = -0x67;
    }
    iVar3 = unzlocal_getLong(param_1,&local_78);
    if (iVar3 != 0) {
      iVar2 = -1;
    }
    iVar3 = unzlocal_getLong(param_1,local_74);
    if (iVar3 != 0) {
      iVar2 = -1;
    }
    iVar3 = unzlocal_getShort(param_1,&uStack_90);
    if (iVar3 == 0) {
      iVar3 = *(int *)(param_1 + 0xc);
      if (iVar2 == 0 && (uint)(iVar1 + iVar3) < local_74[0] + local_78) {
        iVar2 = -0x67;
      }
      else if (iVar2 == 0) {
        *(undefined4 *)(param_1 + 0xc) = 0;
        local_8c = (iVar1 + iVar3) - (local_74[0] + local_78);
        local_98 = param_1;
        local_7c = iVar1;
        local_1c = iVar2;
        __dest = malloc(0x80);
        memcpy(__dest,&local_98,0x80);
        unzGoToFirstFile(__dest);
        return __dest;
      }
    }
    else {
      iVar2 = -1;
    }
    lufclose(param_1);
    zopenerror = iVar2;
  }
  return (unz_s *)0x0;
}
