/* ============================================================
 * stbtt_GetFontBoundingBox   @ 0x0001af70   size=144B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_GetFontBoundingBox(int param_1,int *param_2,int *param_3,int *param_4,int *param_5)

{
  int iVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_1 + 4);
  iVar1 = *(int *)(param_1 + 0x14) + 0x24;
  *param_2 = (int)(short)((ushort)*(byte *)(iVar2 + iVar1 + 1) +
                         (ushort)*(byte *)(iVar2 + iVar1) * 0x100);
  iVar1 = *(int *)(param_1 + 0x14) + 0x26;
  *param_3 = (int)(short)((ushort)*(byte *)(iVar2 + iVar1 + 1) +
                         (ushort)*(byte *)(iVar2 + iVar1) * 0x100);
  iVar1 = *(int *)(param_1 + 0x14) + 0x28;
  *param_4 = (int)(short)((ushort)*(byte *)(iVar2 + iVar1 + 1) +
                         (ushort)*(byte *)(iVar2 + iVar1) * 0x100);
  iVar1 = *(int *)(param_1 + 0x14) + 0x2a;
  *param_5 = (int)(short)((ushort)*(byte *)(iVar2 + iVar1 + 1) +
                         (ushort)*(byte *)(iVar2 + iVar1) * 0x100);
  return;
}
