/* ============================================================
 * inflate_trees_fixed   @ 0x0000e7e0   size=60B   callers=1
 * module: 07_zlib
 * ============================================================ */

/* inflate_trees_fixed(unsigned int*, unsigned int*, inflate_huft_s const**, inflate_huft_s const**,
   z_stream_s*) */

undefined4
inflate_trees_fixed(uint *param_1,uint *param_2,inflate_huft_s **param_3,inflate_huft_s **param_4,
                   z_stream_s *param_5)

{
  *param_1 = 9;
  *param_2 = 5;
  *param_3 = (inflate_huft_s *)fixed_tl;
  *param_4 = (inflate_huft_s *)fixed_td;
  return 0;
}
