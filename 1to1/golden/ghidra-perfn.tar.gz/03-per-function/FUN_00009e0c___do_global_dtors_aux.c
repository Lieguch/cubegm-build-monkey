/* ============================================================
 * __do_global_dtors_aux   @ 0x00009e0c   size=40B   callers=1
 * module: 99_crt_glibc
 * ============================================================ */

void __do_global_dtors_aux(void)

{
  if (completed_10349 != '\0') {
    return;
  }
  deregister_tm_clones();
  completed_10349 = 1;
  return;
}
