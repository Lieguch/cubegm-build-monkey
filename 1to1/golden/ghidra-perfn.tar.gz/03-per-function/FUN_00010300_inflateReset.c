/* ============================================================
 * inflateReset   @ 0x00010300   size=92B   callers=1
 * module: 07_zlib
 * ============================================================ */

/* inflateReset(z_stream_s*) */

undefined4 inflateReset(z_stream_s *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  
  if ((param_1 != (z_stream_s *)0x0) &&
     (puVar2 = *(undefined4 **)(param_1 + 0x1c), puVar2 != (undefined4 *)0x0)) {
    iVar1 = puVar2[3];
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 0x18) = 0;
    if (iVar1 == 0) {
      uVar3 = 0;
    }
    else {
      uVar3 = 7;
    }
    *puVar2 = uVar3;
    inflate_blocks_reset((inflate_blocks_state *)puVar2[5],param_1,(ulong *)0x0);
    return 0;
  }
  return 0xfffffffe;
}
