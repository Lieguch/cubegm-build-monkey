/* ============================================================
 * unzlocal_GetCurrentFileInfoInternal   @ 0x000110d4   size=1296B   callers=3
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* WARNING: Type propagation algorithm not settling */
/* unzlocal_GetCurrentFileInfoInternal(unz_s*, unz_file_info_s*, unz_file_info_internal_s*, char*,
   unsigned long, void*, unsigned long, char*, unsigned long) */

int unzlocal_GetCurrentFileInfoInternal
              (unz_s *param_1,unz_file_info_s *param_2,unz_file_info_internal_s *param_3,
              char *param_4,ulong param_5,void *param_6,ulong param_7,char *param_8,ulong param_9)

{
  bool bVar1;
  int iVar2;
  int iVar3;
  long lVar4;
  bool bVar5;
  byte *pbVar6;
  byte *pbVar7;
  uint uVar8;
  bool bVar9;
  uint uVar10;
  ulong local_80;
  ulong local_7c;
  ulong uStack_78;
  ulong uStack_74;
  ulong uStack_70;
  ulong uStack_6c;
  ulong local_68;
  ulong uStack_64;
  ulong uStack_60;
  ulong uStack_5c;
  uint local_58;
  uint local_54;
  uint local_50;
  ulong uStack_4c;
  ulong uStack_48;
  ulong uStack_44;
  tm_unz_s atStack_40 [28];
  
  if (param_1 == (unz_s *)0x0) {
    return -0x66;
  }
  iVar2 = lufseek(*(LUFILE **)param_1,*(int *)(param_1 + 0x14) + *(int *)(param_1 + 0xc),0);
  if ((iVar2 == 0) && (iVar2 = unzlocal_getLong(*(LUFILE **)param_1,&local_7c), iVar2 == 0)) {
    if (key2._12_4_ == local_7c) {
      bVar5 = true;
      iVar2 = 0;
    }
    else {
      if (local_7c == key2._8_4_) {
        iVar2 = 0;
      }
      else {
        iVar2 = -0x67;
      }
      bVar5 = false;
    }
  }
  else {
    iVar2 = -1;
    bVar5 = false;
  }
  iVar3 = unzlocal_getShort(*(LUFILE **)param_1,&uStack_78);
  if (iVar3 != 0) {
    iVar2 = -1;
  }
  iVar3 = unzlocal_getShort(*(LUFILE **)param_1,&uStack_74);
  if (iVar3 != 0) {
    iVar2 = -1;
  }
  iVar3 = unzlocal_getShort(*(LUFILE **)param_1,&uStack_70);
  if (iVar3 != 0) {
    iVar2 = -1;
  }
  iVar3 = unzlocal_getShort(*(LUFILE **)param_1,&uStack_6c);
  if (iVar3 != 0) {
    iVar2 = -1;
  }
  iVar3 = unzlocal_getLong(*(LUFILE **)param_1,&local_68);
  if (iVar3 != 0) {
    iVar2 = -1;
  }
  unzlocal_DosDateToTmuDate(local_68,atStack_40);
  iVar3 = unzlocal_getLong(*(LUFILE **)param_1,&uStack_64);
  if (iVar3 != 0) {
    iVar2 = -1;
  }
  iVar3 = unzlocal_getLong(*(LUFILE **)param_1,&uStack_60);
  if (iVar3 != 0) {
    iVar2 = -1;
  }
  iVar3 = unzlocal_getLong(*(LUFILE **)param_1,&uStack_5c);
  if (iVar3 != 0) {
    iVar2 = -1;
  }
  iVar3 = unzlocal_getShort(*(LUFILE **)param_1,&local_58);
  if (iVar3 != 0) {
    iVar2 = -1;
  }
  iVar3 = unzlocal_getShort(*(LUFILE **)param_1,&local_54);
  if (iVar3 != 0) {
    iVar2 = -1;
  }
  iVar3 = unzlocal_getShort(*(LUFILE **)param_1,&local_50);
  if (iVar3 != 0) {
    iVar2 = -1;
  }
  iVar3 = unzlocal_getShort(*(LUFILE **)param_1,&uStack_4c);
  if (iVar3 != 0) {
    iVar2 = -1;
  }
  iVar3 = unzlocal_getShort(*(LUFILE **)param_1,&uStack_48);
  if (iVar3 != 0) {
    iVar2 = -1;
  }
  iVar3 = unzlocal_getLong(*(LUFILE **)param_1,&uStack_44);
  if (iVar3 == 0) {
    iVar3 = unzlocal_getLong(*(LUFILE **)param_1,&local_80);
    if (iVar3 != 0) {
LAB_00011400:
      bVar1 = false;
      iVar2 = -1;
      bVar5 = false;
      goto LAB_00011410;
    }
    bVar1 = iVar2 == 0;
    bVar9 = param_4 != (char *)0x0 && bVar1;
    if (param_4 != (char *)0x0 && bVar1) {
      if (local_58 < param_5) {
        param_4[local_58] = '\0';
        uVar10 = 0;
        uVar8 = local_58;
      }
      else {
        uVar10 = local_58 - param_5;
        uVar8 = param_5;
      }
      if (param_5 != 0 && local_58 != 0) {
        iVar2 = lufread(param_4,uVar8,1,*(LUFILE **)param_1);
        if (iVar2 != 1) {
          bVar1 = false;
          iVar2 = -1;
          local_58 = uVar10;
          goto LAB_00011504;
        }
        if ((bVar5) && (0 < (int)uVar8)) {
          pbVar6 = (byte *)param_4;
          do {
            pbVar7 = pbVar6 + 1;
            *pbVar6 = *pbVar6 ^ key2[0x18];
            pbVar6 = pbVar7;
          } while (pbVar7 != (byte *)(param_4 + uVar8));
        }
      }
      iVar2 = 0;
      bVar5 = false;
      bVar1 = bVar9;
      if (param_6 != (void *)0x0) {
        bVar5 = true;
      }
    }
    else {
      bVar5 = param_6 != (void *)0x0 && bVar1;
      uVar10 = local_58;
    }
    local_58 = uVar10;
    if (!bVar5) goto LAB_00011504;
    uVar8 = local_54;
    if (param_7 <= local_54) {
      uVar8 = param_7;
    }
    if (uVar10 == 0) {
      iVar3 = 0;
      iVar2 = 0;
      if (local_54 == 0 || param_7 == 0) goto LAB_000112f4;
LAB_000114b0:
      iVar2 = lufread(param_6,uVar8,1,*(LUFILE **)param_1);
      if (iVar2 == 1) {
        bVar1 = iVar3 == 0;
        iVar2 = iVar3;
        bVar5 = param_8 != (char *)0x0 && bVar1;
      }
      else {
        bVar1 = false;
        iVar2 = -1;
        bVar5 = false;
      }
    }
    else {
      iVar2 = lufseek(*(LUFILE **)param_1,uVar10,1);
      if (iVar2 == 0) {
        iVar3 = 0;
        uVar10 = 0;
      }
      else {
        iVar3 = -1;
      }
      iVar2 = iVar3;
      if (local_54 != 0 && param_7 != 0) goto LAB_000114b0;
LAB_000112f4:
      bVar1 = iVar2 == 0;
      bVar5 = bVar1;
      if (param_8 == (char *)0x0) {
        bVar5 = false;
      }
    }
    lVar4 = (uVar10 - uVar8) + local_54;
  }
  else {
    iVar2 = unzlocal_getLong(*(LUFILE **)param_1,&local_80);
    if (iVar2 != 0) goto LAB_00011400;
    iVar2 = -1;
    bVar1 = false;
LAB_00011504:
    bVar5 = bVar1;
    if (param_8 == (char *)0x0) {
      bVar5 = false;
    }
LAB_00011410:
    lVar4 = local_58 + local_54;
  }
  if (!bVar5) goto LAB_00011360;
  uVar10 = param_9;
  if (local_50 < param_9) {
    param_8[local_50] = '\0';
    uVar10 = local_50;
  }
  if ((lVar4 == 0) || (iVar2 = lufseek(*(LUFILE **)param_1,lVar4,1), iVar2 == 0)) {
    bVar1 = true;
    if (local_50 == 0) {
      iVar2 = 0;
      goto LAB_00011360;
    }
    if (param_9 == 0) {
      iVar2 = 0;
      goto LAB_00011360;
    }
    iVar2 = 0;
  }
  else {
    if (local_50 == 0) {
      return -1;
    }
    iVar2 = -1;
    if (param_9 == 0) {
      return -1;
    }
  }
  iVar3 = lufread(param_8,uVar10,1,*(LUFILE **)param_1);
  if (iVar3 != 1) {
    return -1;
  }
  bVar1 = iVar2 == 0;
LAB_00011360:
  bVar5 = bVar1;
  if (param_2 == (unz_file_info_s *)0x0) {
    bVar5 = false;
  }
  if (bVar5) {
    memcpy(param_2,&uStack_78,0x50);
    bVar1 = false;
    if (param_3 != (unz_file_info_internal_s *)0x0) {
      bVar1 = true;
    }
  }
  else if (param_3 == (unz_file_info_internal_s *)0x0) {
    bVar1 = false;
  }
  if (bVar1) {
    iVar2 = 0;
    *(ulong *)param_3 = local_80;
  }
  return iVar2;
}
