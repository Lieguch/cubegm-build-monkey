/* ============================================================
 * stbtt__cff_index_get.isra.2   @ 0x00015424   size=320B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt__cff_index_get_isra_2(undefined4 *param_1,undefined1 *param_2,uint param_3,int param_4)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  if (-1 < (int)param_3) {
    if (param_3 == 0) {
      iVar4 = 2;
      uVar6 = 0;
      uVar7 = 0;
      uVar1 = 0;
      goto LAB_000154f0;
    }
    if ((param_3 != 1) && (param_3 != 2)) {
      uVar3 = (uint)(byte)param_2[2];
      uVar1 = uVar3 * param_4 + 3;
      uVar6 = uVar1 >> 0x1f;
      iVar4 = CONCAT11(*param_2,param_2[1]) * uVar3 + uVar3 + 2;
      if ((int)param_3 < (int)uVar1) {
        uVar6 = 1;
      }
      if (uVar6 != 0) {
        uVar1 = param_3;
      }
      if (uVar3 == 0) {
        uVar6 = 0;
        uVar7 = 0;
        uVar1 = 0;
      }
      else {
        uVar6 = 0;
        uVar7 = 0;
        do {
          uVar6 = uVar6 + 1;
          uVar2 = 0;
          if ((int)uVar1 < (int)param_3) {
            uVar2 = (uint)(byte)param_2[uVar1];
            uVar1 = uVar1 + 1;
          }
          uVar7 = uVar7 << 8 | uVar2;
        } while (uVar6 != uVar3);
        uVar3 = 0;
        uVar2 = 0;
        do {
          uVar3 = uVar3 + 1;
          uVar5 = 0;
          if ((int)uVar1 < (int)param_3) {
            uVar5 = (uint)(byte)param_2[uVar1];
            uVar1 = uVar1 + 1;
          }
          uVar2 = uVar2 << 8 | uVar5;
        } while (uVar6 != uVar3);
        uVar6 = uVar2 - uVar7 >> 0x1f;
        uVar1 = uVar2 - uVar7;
      }
      goto LAB_000154f0;
    }
  }
  uVar6 = 0;
  iVar4 = 2;
  uVar7 = 0;
  uVar1 = uVar6;
LAB_000154f0:
  uVar7 = uVar7 + iVar4;
  uVar6 = uVar6 | uVar7 >> 0x1f;
  if ((int)param_3 < (int)uVar7) {
    uVar6 = 1;
  }
  if ((uVar6 == 0) && ((int)uVar1 <= (int)(param_3 - uVar7))) {
    param_1[1] = 0;
    *param_1 = param_2 + uVar7;
    param_1[2] = uVar1;
    return;
  }
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  return;
}
