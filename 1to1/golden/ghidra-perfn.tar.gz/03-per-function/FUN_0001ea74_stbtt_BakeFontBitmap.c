/* ============================================================
 * stbtt_BakeFontBitmap   @ 0x0001ea74   size=568B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

/* WARNING: Type propagation algorithm not settling */

int stbtt_BakeFontBitmap
              (undefined4 param_1,undefined4 param_2,undefined4 param_3,void *param_4,int param_5,
              int param_6,int param_7,int param_8,short *param_9)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  uint in_fpscr;
  float fVar9;
  float fVar10;
  undefined4 uVar11;
  int local_f0;
  undefined4 local_c4;
  undefined1 auStack_c0 [4];
  int local_bc;
  int local_b8;
  int local_b4;
  int local_b0 [33];
  
  piVar1 = local_b0 + 1;
  local_b0[1] = 0;
  iVar2 = stbtt_InitFont(piVar1,param_2,param_3);
  if (iVar2 == 0) {
    iVar2 = -1;
  }
  else {
    memset(param_4,0,param_6 * param_5);
    fVar9 = (float)stbtt_ScaleForPixelHeight(param_1,piVar1);
    if (param_8 < 1) {
      iVar2 = 1;
    }
    else {
      iVar7 = 1;
      local_f0 = 0;
      iVar6 = 1;
      iVar2 = 1;
      do {
        uVar3 = stbtt_FindGlyphIndex(piVar1,param_7 + local_f0);
        stbtt_GetGlyphHMetrics(piVar1,uVar3,&local_c4,auStack_c0);
        stbtt_GetGlyphBitmapBox(fVar9,fVar9,piVar1,uVar3,&local_bc,&local_b8,&local_b4,local_b0);
        iVar5 = local_b4 - local_bc;
        iVar4 = local_b0[0] - local_b8;
        if (param_5 <= iVar5 + iVar6 + 1) {
          iVar6 = 1;
          iVar7 = iVar2;
        }
        iVar8 = iVar4 + iVar7 + 1;
        if (param_6 <= iVar8) {
          return -local_f0;
        }
        local_f0 = local_f0 + 1;
        if (iVar2 <= iVar4 + iVar7) {
          iVar2 = iVar8;
        }
        stbtt_MakeGlyphBitmap
                  (fVar9,fVar9,piVar1,(int)param_4 + iVar7 * param_5 + iVar6,iVar5,iVar4,param_5,
                   uVar3);
        fVar10 = (float)VectorSignedToFloat(local_c4,(byte)(in_fpscr >> 0x16) & 3);
        *param_9 = (short)iVar6;
        param_9[2] = (short)iVar6 + (short)iVar5;
        iVar6 = iVar5 + iVar6 + 1;
        param_9[1] = (short)iVar7;
        param_9[3] = (short)iVar7 + (short)iVar4;
        *(float *)(param_9 + 8) = fVar10 * fVar9;
        uVar3 = VectorSignedToFloat(local_bc,(byte)(in_fpscr >> 0x16) & 3);
        uVar11 = VectorSignedToFloat(local_b8,(byte)(in_fpscr >> 0x16) & 3);
        *(undefined4 *)(param_9 + 4) = uVar3;
        *(undefined4 *)(param_9 + 6) = uVar11;
        param_9 = param_9 + 10;
      } while (param_8 != local_f0);
    }
  }
  return iVar2;
}
