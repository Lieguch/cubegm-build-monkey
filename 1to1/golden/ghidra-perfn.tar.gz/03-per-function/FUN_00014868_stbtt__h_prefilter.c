/* ============================================================
 * stbtt__h_prefilter   @ 0x00014868   size=804B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt__h_prefilter(int param_1,uint param_2,int param_3,int param_4,size_t param_5)

{
  undefined1 uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  undefined1 *puVar7;
  undefined1 *puVar8;
  int iVar9;
  int iVar10;
  byte local_30 [12];
  
  local_30[0] = 0;
  local_30[1] = 0;
  local_30[2] = 0;
  local_30[3] = 0;
  local_30[4] = 0;
  local_30[5] = 0;
  local_30[6] = 0;
  local_30[7] = 0;
  iVar10 = param_2 - param_5;
  if (0 < param_3) {
    puVar8 = (undefined1 *)(param_1 + -1);
    iVar9 = 0;
    do {
      memset(local_30,0,param_5);
      switch(param_5) {
      case 2:
        uVar6 = 0;
        if (iVar10 < 0) {
LAB_00014b84:
          uVar5 = 0;
          uVar6 = uVar5;
        }
        else {
          uVar5 = 0;
          puVar7 = puVar8;
          do {
            uVar2 = uVar5 & 7;
            uVar4 = uVar5 + 2;
            uVar5 = uVar5 + 1;
            uVar6 = uVar6 + ((uint)(byte)puVar7[1] - (uint)local_30[uVar2]);
            local_30[uVar4 & 7] = puVar7[1];
            puVar7 = puVar7 + 1;
            *puVar7 = (char)(uVar6 >> 1);
          } while (uVar5 != iVar10 + 1U);
        }
        break;
      case 3:
        uVar6 = 0;
        if (iVar10 < 0) goto LAB_00014b84;
        uVar5 = 0;
        puVar7 = puVar8;
        do {
          uVar2 = uVar5 & 7;
          uVar4 = uVar5 + 3;
          uVar5 = uVar5 + 1;
          uVar6 = uVar6 + ((uint)(byte)puVar7[1] - (uint)local_30[uVar2]);
          local_30[uVar4 & 7] = puVar7[1];
          puVar7 = puVar7 + 1;
          *puVar7 = (char)(uVar6 / 3);
        } while (uVar5 != iVar10 + 1U);
        break;
      case 4:
        uVar6 = 0;
        if (iVar10 < 0) goto LAB_00014b84;
        uVar2 = 0;
        uVar5 = iVar10 + 1;
        puVar7 = puVar8;
        do {
          uVar4 = uVar2 & 7;
          uVar3 = uVar2 + 4;
          uVar2 = uVar2 + 1;
          uVar6 = uVar6 + ((uint)(byte)puVar7[1] - (uint)local_30[uVar4]);
          local_30[uVar3 & 7] = puVar7[1];
          puVar7 = puVar7 + 1;
          *puVar7 = (char)(uVar6 >> 2);
        } while (uVar5 != uVar2);
        break;
      case 5:
        uVar6 = 0;
        if (iVar10 < 0) goto LAB_00014b84;
        uVar2 = 0;
        uVar5 = iVar10 + 1;
        puVar7 = puVar8;
        do {
          uVar4 = uVar2 & 7;
          uVar3 = uVar2 + 5;
          uVar2 = uVar2 + 1;
          uVar6 = uVar6 + ((uint)(byte)puVar7[1] - (uint)local_30[uVar4]);
          local_30[uVar3 & 7] = puVar7[1];
          puVar7 = puVar7 + 1;
          *puVar7 = (char)(uVar6 / 5);
        } while (uVar5 != uVar2);
        break;
      default:
        uVar6 = 0;
        if (iVar10 < 0) goto LAB_00014b84;
        uVar5 = 0;
        puVar7 = puVar8;
        do {
          uVar2 = uVar5 & 7;
          uVar4 = uVar5 + param_5;
          uVar5 = uVar5 + 1;
          uVar6 = uVar6 + ((uint)(byte)puVar7[1] - (uint)local_30[uVar2]);
          local_30[uVar4 & 7] = puVar7[1];
          uVar1 = __aeabi_uidiv(uVar6,param_5);
          puVar7 = puVar7 + 1;
          *puVar7 = uVar1;
        } while (uVar5 != iVar10 + 1U);
      }
      if ((int)uVar5 < (int)param_2) {
        puVar7 = puVar8 + uVar5 + 1;
        do {
          uVar2 = uVar5 & 7;
          uVar5 = uVar5 + 1;
          uVar6 = uVar6 - local_30[uVar2];
          uVar1 = __aeabi_uidiv(uVar6,param_5);
          *puVar7 = uVar1;
          puVar7 = puVar7 + 1;
        } while (param_2 != uVar5);
      }
      iVar9 = iVar9 + 1;
      puVar8 = puVar8 + param_4;
    } while (param_3 != iVar9);
  }
  return;
}
