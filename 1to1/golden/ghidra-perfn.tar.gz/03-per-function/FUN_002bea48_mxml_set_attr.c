/* ============================================================
 * mxml_set_attr   @ 0x002bea48   size=268B   callers=2
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxml_set_attr(int param_1,char *param_2,undefined4 param_3)

{
  int iVar1;
  void *pvVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 *__ptr;
  
  iVar5 = *(int *)(param_1 + 0x1c);
  __ptr = *(undefined4 **)(param_1 + 0x20);
  puVar3 = __ptr;
  iVar4 = iVar5;
  if (iVar5 < 1) {
    if (iVar5 == 0) {
      pvVar2 = malloc(8);
      goto LAB_002beac4;
    }
  }
  else {
    do {
      iVar1 = strcmp((char *)*puVar3,param_2);
      if (iVar1 == 0) {
        if ((void *)puVar3[1] != (void *)0x0) {
          free((void *)puVar3[1]);
        }
        puVar3[1] = param_3;
        return 0;
      }
      iVar4 = iVar4 + -1;
      puVar3 = puVar3 + 2;
    } while (iVar4 != 0);
  }
  pvVar2 = realloc(__ptr,(iVar5 + 1) * 8);
LAB_002beac4:
  if (pvVar2 == (void *)0x0) {
    mxml_error("Unable to allocate memory for attribute \'%s\' in element %s!",param_2,
               *(undefined4 *)(param_1 + 0x18));
  }
  else {
    *(void **)(param_1 + 0x20) = pvVar2;
    iVar5 = *(int *)(param_1 + 0x1c);
    iVar4 = __strdup(param_2);
    *(int *)((int)pvVar2 + iVar5 * 8) = iVar4;
    if (iVar4 != 0) {
      *(undefined4 *)((int)pvVar2 + iVar5 * 8 + 4) = param_3;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 1;
      return 0;
    }
    mxml_error("Unable to allocate memory for attribute \'%s\' in element %s!",param_2,
               *(undefined4 *)(param_1 + 0x18));
  }
  return 0xffffffff;
}
