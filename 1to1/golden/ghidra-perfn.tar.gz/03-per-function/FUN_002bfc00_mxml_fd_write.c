/* ============================================================
 * mxml_fd_write   @ 0x002bfc00   size=108B   callers=2
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxml_fd_write(int *param_1)

{
  ssize_t sVar1;
  int *piVar2;
  int *__buf;
  int *piVar3;
  
  if (param_1 == (int *)0x0) {
    return 0xffffffff;
  }
  piVar2 = (int *)param_1[1];
  piVar3 = param_1 + 3;
  if (piVar2 != piVar3) {
    __buf = piVar3;
    if (piVar3 <= piVar2) {
      do {
        sVar1 = write(*param_1,__buf,(int)piVar2 - (int)__buf);
        __buf = (int *)((int)__buf + sVar1);
        if (sVar1 < 0) {
          return 0xffffffff;
        }
        piVar2 = (int *)param_1[1];
      } while (__buf < piVar2);
    }
    param_1[1] = (int)piVar3;
    return 0;
  }
  return 0;
}
