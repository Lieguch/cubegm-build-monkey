/* ============================================================
 * mxmlSAXLoadFile   @ 0x002c2294   size=40B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

void mxmlSAXLoadFile(void)

{
  mxml_load_data();
  return;
}
