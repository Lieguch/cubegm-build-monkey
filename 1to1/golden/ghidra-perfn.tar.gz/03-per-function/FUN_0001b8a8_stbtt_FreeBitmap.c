/* ============================================================
 * stbtt_FreeBitmap   @ 0x0001b8a8   size=4B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_FreeBitmap(void *param_1)

{
  free(param_1);
  return;
}
