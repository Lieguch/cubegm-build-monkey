/* ============================================================
 * mxmlSetCDATA   @ 0x002c3578   size=168B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlSetCDATA(int *param_1,int param_2)

{
  int iVar1;
  
  if ((param_1 != (int *)0x0) && (*param_1 == 0)) {
    iVar1 = strncmp((char *)param_1[6],"![CDATA[",8);
    if (((iVar1 == 0) ||
        (((param_1 = (int *)param_1[4], param_1 != (int *)0x0 && (*param_1 == 0)) &&
         (iVar1 = strncmp((char *)param_1[6],"![CDATA[",8), iVar1 == 0)))) && (param_2 != 0)) {
      free((void *)param_1[6]);
      iVar1 = _mxml_strdupf("![CDATA[%s]]",param_2);
      param_1[6] = iVar1;
      return 0;
    }
  }
  return 0xffffffff;
}
