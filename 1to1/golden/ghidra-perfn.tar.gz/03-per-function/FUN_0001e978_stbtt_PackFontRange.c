/* ============================================================
 * stbtt_PackFontRange   @ 0x0001e978   size=68B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_PackFontRange(void)

{
  stbtt_PackFontRanges();
  return;
}
