/* ============================================================
 * stbtt__csctx_close_shape   @ 0x00013a84   size=100B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt__csctx_close_shape(int param_1)

{
  if ((*(float *)(param_1 + 8) == *(float *)(param_1 + 0x10)) &&
     (*(float *)(param_1 + 0xc) == *(float *)(param_1 + 0x14))) {
    return;
  }
  stbtt__csctx_v(param_1,2,(int)*(float *)(param_1 + 8),(int)*(float *)(param_1 + 0xc),0,0,0,0);
  return;
}
