/* ============================================================
 * stbtt_GetGlyphBitmapBox   @ 0x0001b1cc   size=12B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_GetGlyphBitmapBox(undefined4 param_1,undefined4 param_2)

{
  stbtt_GetGlyphBitmapBoxSubpixel(param_1,param_2,0);
  return;
}
