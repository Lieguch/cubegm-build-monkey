/* ============================================================
 * mxmlIndexDelete   @ 0x002c27a8   size=72B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

void mxmlIndexDelete(undefined4 *param_1)

{
  if (param_1 == (undefined4 *)0x0) {
    return;
  }
  if ((void *)*param_1 != (void *)0x0) {
    free((void *)*param_1);
  }
  if (param_1[2] == 0) {
    free(param_1);
    return;
  }
  free((void *)param_1[4]);
  free(param_1);
  return;
}
