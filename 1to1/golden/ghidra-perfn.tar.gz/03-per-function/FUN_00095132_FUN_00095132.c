/* ============================================================
 * FUN_00095132   @ 0x00095132   size=4B   callers=0
 * module: 90_unnamed_FUN
 * ============================================================ */

/* WARNING: Control flow encountered bad instruction data */

void FUN_00095132(void)

{
  undefined8 in_d3;
  undefined8 in_d18;
  
  VectorSignedDotProduct(in_d18,in_d3);
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}
