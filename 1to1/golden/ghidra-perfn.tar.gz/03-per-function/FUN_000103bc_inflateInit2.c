/* ============================================================
 * inflateInit2   @ 0x000103bc   size=232B   callers=1
 * module: 07_zlib
 * ============================================================ */

/* inflateInit2(z_stream_s*) */

undefined4 inflateInit2(z_stream_s *param_1)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  code *pcVar4;
  
  if (param_1 == (z_stream_s *)0x0) {
    return 0xfffffffe;
  }
  pcVar4 = *(code **)(param_1 + 0x20);
  *(undefined4 *)(param_1 + 0x18) = 0;
  if (pcVar4 == (code *)0x0) {
    pcVar4 = zcalloc;
    *(undefined4 *)(param_1 + 0x28) = 0;
    *(code **)(param_1 + 0x20) = zcalloc;
    iVar3 = *(int *)(param_1 + 0x24);
    uVar1 = 0;
  }
  else {
    iVar3 = *(int *)(param_1 + 0x24);
    uVar1 = *(undefined4 *)(param_1 + 0x28);
  }
  if (iVar3 == 0) {
    *(code **)(param_1 + 0x24) = zcfree;
  }
  iVar3 = (*pcVar4)(uVar1,1,0x18);
  *(int *)(param_1 + 0x1c) = iVar3;
  if (iVar3 != 0) {
    *(undefined4 *)(iVar3 + 0x14) = 0;
    *(undefined4 *)(iVar3 + 0xc) = 1;
    *(undefined4 *)(iVar3 + 0x10) = 0xf;
    iVar2 = inflate_blocks_new(param_1,(_func_ulong_ulong_uchar_ptr_uint *)0x0,0x8000);
    *(int *)(iVar3 + 0x14) = iVar2;
    if (iVar2 == 0) {
      inflateEnd(param_1);
      return 0xfffffffc;
    }
    inflateReset(param_1);
    return 0;
  }
  return 0xfffffffc;
}
