/* ============================================================
 * unzClose   @ 0x00012078   size=60B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzClose(unz_s*) */

undefined4 unzClose(unz_s *param_1)

{
  if (param_1 != (unz_s *)0x0) {
    if (*(int *)(param_1 + 0x7c) != 0) {
      unzCloseCurrentFile(param_1);
    }
    lufclose(*(LUFILE **)param_1);
    free(param_1);
    return 0;
  }
  return 0xffffff9a;
}
