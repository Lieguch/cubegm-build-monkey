/* ============================================================
 * stbtt_GetBakedQuad   @ 0x0001c43c   size=320B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_GetBakedQuad(int param_1,undefined4 param_2,undefined4 param_3,int param_4,float *param_5
                       ,float *param_6,float *param_7,int param_8)

{
  uint uVar1;
  int iVar2;
  uint in_fpscr;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  
  iVar2 = param_1 + param_4 * 0x14;
  fVar13 = 0.0;
  fVar9 = (float)VectorSignedToFloat(param_2,(byte)(in_fpscr >> 0x16) & 3);
  fVar11 = (float)VectorSignedToFloat(param_3,(byte)(in_fpscr >> 0x16) & 3);
  if (param_8 == 0) {
    fVar13 = -0.5;
  }
  fVar3 = floorf(*param_5 + *(float *)(iVar2 + 8) + 0.5);
  fVar4 = floorf(*param_6 + *(float *)(iVar2 + 0xc) + 0.5);
  uVar1 = (uint)*(ushort *)(param_1 + param_4 * 0x14);
  fVar6 = *(float *)(iVar2 + 0x10);
  fVar10 = (float)VectorSignedToFloat(uVar1,(byte)(in_fpscr >> 0x16) & 3);
  fVar12 = (float)VectorSignedToFloat((uint)*(ushort *)(iVar2 + 4),(byte)(in_fpscr >> 0x16) & 3);
  fVar7 = (float)VectorSignedToFloat((uint)*(ushort *)(iVar2 + 2),(byte)(in_fpscr >> 0x16) & 3);
  fVar8 = (float)VectorSignedToFloat((uint)*(ushort *)(iVar2 + 6),(byte)(in_fpscr >> 0x16) & 3);
  fVar14 = (float)VectorSignedToFloat((int)fVar3,(byte)(in_fpscr >> 0x16) & 3);
  fVar5 = (float)VectorSignedToFloat((int)fVar4,(byte)(in_fpscr >> 0x16) & 3);
  fVar3 = (float)VectorSignedToFloat(((int)fVar3 + (uint)*(ushort *)(iVar2 + 4)) - uVar1,
                                     (byte)(in_fpscr >> 0x16) & 3);
  fVar4 = (float)VectorSignedToFloat(((int)fVar4 + (uint)*(ushort *)(iVar2 + 6)) -
                                     (uint)*(ushort *)(iVar2 + 2),(byte)(in_fpscr >> 0x16) & 3);
  param_7[2] = fVar10 * (1.0 / fVar9);
  param_7[6] = fVar12 * (1.0 / fVar9);
  param_7[3] = fVar7 * (1.0 / fVar11);
  param_7[7] = fVar8 * (1.0 / fVar11);
  param_7[5] = fVar4 + fVar13;
  *param_7 = fVar14 + fVar13;
  param_7[1] = fVar5 + fVar13;
  param_7[4] = fVar3 + fVar13;
  *param_5 = *param_5 + fVar6;
  return;
}
