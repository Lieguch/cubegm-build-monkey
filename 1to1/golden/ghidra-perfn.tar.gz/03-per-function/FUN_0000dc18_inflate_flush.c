/* ============================================================
 * inflate_flush   @ 0x0000dc18   size=356B   callers=2
 * module: 07_zlib
 * ============================================================ */

/* inflate_flush(inflate_blocks_state*, z_stream_s*, int) */

int inflate_flush(inflate_blocks_state *param_1,z_stream_s *param_2,int param_3)

{
  undefined4 uVar1;
  uint uVar2;
  void *pvVar3;
  uint uVar4;
  void *pvVar5;
  void *__dest;
  code *pcVar6;
  
  pvVar3 = *(void **)(param_1 + 0x34);
  pvVar5 = *(void **)(param_1 + 0x30);
  uVar2 = *(uint *)(param_2 + 0x10);
  pcVar6 = *(code **)(param_1 + 0x38);
  __dest = *(void **)(param_2 + 0xc);
  if (pvVar3 < pvVar5) {
    pvVar3 = *(void **)(param_1 + 0x2c);
  }
  uVar4 = (int)pvVar3 - (int)pvVar5;
  if (uVar2 <= (uint)((int)pvVar3 - (int)pvVar5)) {
    uVar4 = uVar2;
  }
  *(uint *)(param_2 + 0x10) = uVar2 - uVar4;
  *(uint *)(param_2 + 0x14) = *(int *)(param_2 + 0x14) + uVar4;
  if (param_3 == -5 && uVar4 != 0) {
    param_3 = 0;
  }
  if (pcVar6 != (code *)0x0) {
    uVar1 = (*pcVar6)(*(undefined4 *)(param_1 + 0x3c),pvVar5,uVar4);
    *(undefined4 *)(param_1 + 0x3c) = uVar1;
    *(undefined4 *)(param_2 + 0x30) = uVar1;
  }
  if (uVar4 == 0) {
    pvVar3 = pvVar5;
    if (pvVar5 != *(void **)(param_1 + 0x2c)) goto LAB_0000dcb0;
  }
  else {
    pvVar3 = (void *)((int)pvVar5 + uVar4);
    memcpy(__dest,pvVar5,uVar4);
    __dest = (void *)((int)__dest + uVar4);
    if (pvVar3 != *(void **)(param_1 + 0x2c)) goto LAB_0000dcb0;
  }
  pvVar5 = *(void **)(param_1 + 0x28);
  uVar2 = *(uint *)(param_2 + 0x10);
  if (pvVar3 == *(void **)(param_1 + 0x34)) {
    uVar4 = 0;
    *(void **)(param_1 + 0x34) = pvVar5;
  }
  else {
    uVar4 = (int)*(void **)(param_1 + 0x34) - (int)pvVar5;
    if (uVar2 <= uVar4) {
      uVar4 = uVar2;
    }
    if (param_3 == -5 && uVar4 != 0) {
      param_3 = 0;
    }
  }
  pcVar6 = *(code **)(param_1 + 0x38);
  *(uint *)(param_2 + 0x10) = uVar2 - uVar4;
  *(uint *)(param_2 + 0x14) = *(int *)(param_2 + 0x14) + uVar4;
  if (pcVar6 != (code *)0x0) {
    uVar1 = (*pcVar6)(*(undefined4 *)(param_1 + 0x3c),pvVar5,uVar4);
    *(undefined4 *)(param_1 + 0x3c) = uVar1;
    *(undefined4 *)(param_2 + 0x30) = uVar1;
  }
  pvVar3 = (void *)((int)pvVar5 + uVar4);
  memcpy(__dest,pvVar5,uVar4);
  __dest = (void *)((int)__dest + uVar4);
LAB_0000dcb0:
  *(void **)(param_2 + 0xc) = __dest;
  *(void **)(param_1 + 0x30) = pvVar3;
  return param_3;
}
