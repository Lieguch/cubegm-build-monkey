/* ============================================================
 * mxmlSaveFd   @ 0x002c1fe0   size=184B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlSaveFd(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 local_2024;
  undefined1 *local_2020;
  undefined1 *local_201c;
  undefined1 local_2018 [8192];
  undefined1 auStack_18 [4];
  
  uVar1 = _mxml_global();
  local_2020 = local_2018;
  local_201c = auStack_18;
  local_2024 = param_2;
  iVar2 = mxml_write_node(param_1,&local_2024,param_3,0,mxml_fd_putc,uVar1);
  if (iVar2 < 0) {
LAB_002c2090:
    uVar1 = 0xffffffff;
  }
  else {
    if (iVar2 != 0) {
      if ((local_201c <= local_2020) && (iVar2 = mxml_fd_write(&local_2024), iVar2 < 0))
      goto LAB_002c2090;
      *local_2020 = 10;
      local_2020 = local_2020 + 1;
    }
    uVar1 = mxml_fd_write(&local_2024);
  }
  return uVar1;
}
