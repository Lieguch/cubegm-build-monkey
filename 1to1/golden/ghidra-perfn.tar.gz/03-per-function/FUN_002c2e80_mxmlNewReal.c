/* ============================================================
 * mxmlNewReal   @ 0x002c2e80   size=36B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

void mxmlNewReal(undefined4 param_1)

{
  int iVar1;
  undefined8 in_d0;
  
  iVar1 = mxml_new(param_1,3);
  if (iVar1 != 0) {
    *(undefined8 *)(iVar1 + 0x18) = in_d0;
  }
  return;
}
