/* ============================================================
 * mxmlGetFirstChild   @ 0x002c23ec   size=28B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

int mxmlGetFirstChild(int *param_1)

{
  int iVar1;
  
  if (param_1 != (int *)0x0) {
    if (*param_1 == 0) {
      iVar1 = param_1[4];
    }
    else {
      iVar1 = 0;
    }
    return iVar1;
  }
  return 0;
}
