/* ============================================================
 * xmp3_GetBits   @ 0x002bd78c   size=280B   callers=2
 * module: 06_helix_mp3
 * ============================================================ */

uint xmp3_GetBits(undefined4 *param_1,uint param_2)

{
  uint uVar1;
  byte bVar2;
  byte bVar3;
  byte *pbVar4;
  byte *pbVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  byte *pbVar11;
  
  param_2 = param_2 & 0x1f;
  iVar9 = param_1[2] - param_2;
  uVar1 = ((uint)param_1[1] >> (0x1f - param_2 & 0xff)) >> 1;
  param_1[1] = param_1[1] << param_2;
  param_1[2] = iVar9;
  if (iVar9 < 0) {
    iVar7 = param_1[3];
    if (iVar7 < 4) {
      uVar6 = 0;
      param_1[1] = 0;
      if (iVar7 == 0) {
        uVar6 = 0;
        iVar8 = 0;
      }
      else {
        pbVar4 = (byte *)*param_1;
        pbVar11 = pbVar4;
        do {
          pbVar5 = pbVar11 + 1;
          *param_1 = pbVar5;
          uVar6 = (*pbVar11 | uVar6) << 8;
          param_1[1] = uVar6;
          pbVar11 = pbVar5;
        } while (pbVar5 != pbVar4 + iVar7);
        uVar6 = uVar6 << ((3 - iVar7) * 8 & 0xffU);
        iVar8 = uVar6 << (-iVar9 & 0xffU);
        uVar6 = uVar6 >> (iVar9 + 0x20U & 0xff);
      }
      uVar10 = iVar9 + iVar7 * 8;
      param_1[3] = 0;
    }
    else {
      pbVar11 = (byte *)*param_1;
      uVar10 = iVar9 + 0x20;
      *param_1 = pbVar11 + 1;
      bVar2 = *pbVar11;
      *param_1 = pbVar11 + 2;
      param_1[1] = (uint)bVar2 << 0x18;
      bVar3 = pbVar11[1];
      *param_1 = pbVar11 + 3;
      uVar6 = (uint)bVar2 << 0x18 | (uint)bVar3 << 0x10;
      param_1[1] = uVar6;
      bVar2 = pbVar11[2];
      *param_1 = pbVar11 + 4;
      uVar6 = uVar6 | (uint)bVar2 << 8;
      param_1[1] = uVar6;
      bVar2 = pbVar11[3];
      param_1[3] = iVar7 + -4;
      uVar6 = bVar2 | uVar6;
      iVar8 = uVar6 << (-iVar9 & 0xffU);
      uVar6 = uVar6 >> (uVar10 & 0xff);
    }
    param_1[1] = iVar8;
    param_1[2] = uVar10;
    return uVar1 | uVar6;
  }
  return uVar1;
}
