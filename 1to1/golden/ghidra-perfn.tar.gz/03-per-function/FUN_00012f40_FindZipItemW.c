/* ============================================================
 * FindZipItemW   @ 0x00012f40   size=248B   callers=0
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* FindZipItemW(HZIP__*, char const*, unsigned char, int*, ZIPENTRYW*) */

int FindZipItemW(HZIP__ *param_1,char *param_2,uchar param_3,int *param_4,ZIPENTRYW *param_5)

{
  int iVar1;
  undefined4 local_140;
  char acStack_13c [260];
  undefined4 local_38;
  undefined4 local_34;
  undefined4 uStack_30;
  undefined4 local_2c;
  undefined4 uStack_28;
  undefined4 local_24;
  undefined4 uStack_20;
  undefined4 local_1c;
  undefined4 local_18;
  
  if (param_1 != (HZIP__ *)0x0) {
    if (*(int *)param_1 == 1) {
      iVar1 = TUnzip::Find(*(TUnzip **)(param_1 + 4),param_2,param_3,param_4,(ZIPENTRY *)&local_140)
      ;
      lasterrorU = iVar1;
      if (iVar1 == 0) {
        *(undefined4 *)param_5 = local_140;
        *(undefined4 *)(param_5 + 0x108) = local_38;
        *(undefined4 *)(param_5 + 0x10c) = local_34;
        *(undefined4 *)(param_5 + 0x110) = uStack_30;
        *(undefined4 *)(param_5 + 0x114) = local_2c;
        *(undefined4 *)(param_5 + 0x118) = uStack_28;
        *(undefined4 *)(param_5 + 0x11c) = local_24;
        *(undefined4 *)(param_5 + 0x120) = uStack_20;
        *(undefined4 *)(param_5 + 0x124) = local_1c;
        *(undefined4 *)(param_5 + 0x128) = local_18;
        strcpy((char *)(param_5 + 4),acStack_13c);
      }
    }
    else {
      iVar1 = 0x80000;
      lasterrorU = 0x80000;
    }
    return iVar1;
  }
  lasterrorU = 0x10000;
  return 0x10000;
}
