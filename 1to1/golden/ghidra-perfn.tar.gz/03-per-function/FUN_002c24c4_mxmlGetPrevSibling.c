/* ============================================================
 * mxmlGetPrevSibling   @ 0x002c24c4   size=12B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlGetPrevSibling(int param_1)

{
  undefined4 uVar1;
  
  uVar1 = 0;
  if (param_1 != 0) {
    uVar1 = *(undefined4 *)(param_1 + 8);
  }
  return uVar1;
}
