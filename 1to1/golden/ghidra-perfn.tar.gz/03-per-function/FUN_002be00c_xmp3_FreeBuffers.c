/* ============================================================
 * xmp3_FreeBuffers   @ 0x002be00c   size=4B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

void xmp3_FreeBuffers(void)

{
  return;
}
