/* ============================================================
 * stbtt_GetGlyphSDF   @ 0x0001cfd8   size=4200B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

void * stbtt_GetGlyphSDF(undefined4 param_1,undefined4 param_2,int param_3,undefined4 param_4,
                        int *param_5,int *param_6,int *param_7,int *param_8)

{
  uint uVar1;
  byte bVar2;
  byte bVar3;
  int iVar4;
  void *pvVar5;
  float *__ptr;
  int iVar6;
  int iVar7;
  char cVar8;
  int iVar9;
  int iVar10;
  short *psVar11;
  short *__ptr_00;
  int iVar12;
  int iVar13;
  float *pfVar14;
  int iVar15;
  int iVar16;
  int iVar17;
  int iVar18;
  int iVar19;
  uint in_fpscr;
  uint uVar20;
  uint uVar21;
  ulonglong in_d0;
  double dVar22;
  double dVar23;
  float fVar24;
  float fVar25;
  float fVar26;
  float fVar27;
  float fVar28;
  float fVar29;
  float fVar30;
  float fVar31;
  float fVar32;
  float fVar33;
  float fVar34;
  float fVar35;
  float fVar36;
  float fVar37;
  float fVar38;
  float fVar39;
  float fVar40;
  float fVar41;
  float fVar42;
  float fVar43;
  ulonglong uVar44;
  float fVar45;
  float fVar46;
  char local_b4;
  float local_b0;
  float local_a8;
  int local_7c;
  int local_78;
  int local_74;
  int local_70;
  short *local_6c [2];
  
  fVar28 = (float)in_d0;
  uVar21 = in_fpscr & 0xfffffff | (uint)(fVar28 == 0.0) << 0x1e;
  if (!SUB41(uVar21 >> 0x1e,0)) {
    uVar44 = in_d0 & 0xffffffff;
    stbtt_GetGlyphBitmapBoxSubpixel(param_1,param_2,&local_7c,&local_78,&local_74,&local_70);
    if ((local_7c != local_74) && (local_78 != local_70)) {
      local_7c = local_7c - param_3;
      local_78 = local_78 - param_3;
      local_74 = local_74 + param_3;
      local_70 = local_70 + param_3;
      iVar17 = local_74 - local_7c;
      iVar13 = local_70 - local_78;
      if (param_5 != (int *)0x0) {
        *param_5 = iVar17;
      }
      if (param_6 != (int *)0x0) {
        *param_6 = iVar13;
      }
      if (param_7 != (int *)0x0) {
        *param_7 = local_7c;
      }
      if (param_8 != (int *)0x0) {
        *param_8 = local_78;
      }
      fVar45 = -fVar28;
      iVar4 = stbtt_GetGlyphShape(param_1,param_2,local_6c);
      pvVar5 = malloc(iVar13 * iVar17);
      __ptr = malloc(iVar4 * 4);
      __ptr_00 = local_6c[0];
      if (0 < iVar4) {
        iVar13 = iVar4 + -1;
        iVar9 = 0;
        pfVar14 = __ptr;
        do {
          psVar11 = __ptr_00 + iVar9 * 7;
          if ((char)psVar11[6] == '\x02') {
            fVar29 = (float)VectorSignedToFloat((int)psVar11[1],(byte)(uVar21 >> 0x16) & 3);
            fVar31 = (float)VectorSignedToFloat((int)__ptr_00[iVar13 * 7 + 1],
                                                (byte)(uVar21 >> 0x16) & 3);
            fVar33 = (float)VectorSignedToFloat((int)__ptr_00[iVar9 * 7],(byte)(uVar21 >> 0x16) & 3)
            ;
            fVar29 = fVar31 * fVar45 - fVar29 * fVar45;
            fVar31 = (float)VectorSignedToFloat((int)__ptr_00[iVar13 * 7],(byte)(uVar21 >> 0x16) & 3
                                               );
            fVar31 = fVar31 * fVar28 - fVar33 * fVar28;
            fVar29 = fVar29 * fVar29 + fVar31 * fVar31;
            uVar21 = uVar21 & 0xfffffff | (uint)(fVar29 < 0.0) << 0x1f;
            if (SUB41(uVar21 >> 0x1f,0)) {
              sqrtf(fVar29);
              __ptr_00 = local_6c[0];
            }
            uVar21 = uVar21 & 0xfffffff | (uint)(SQRT(fVar29) == 0.0) << 0x1e;
            if (SUB41(uVar21 >> 0x1e,0)) {
              fVar29 = 0.0;
            }
            else {
              fVar29 = 1.0 / SQRT(fVar29);
            }
            *pfVar14 = fVar29;
          }
          else {
            if ((char)psVar11[6] == '\x03') {
              fVar39 = (float)VectorSignedToFloat((int)psVar11[3],(byte)(uVar21 >> 0x16) & 3);
              fVar35 = (float)VectorSignedToFloat((int)psVar11[2],(byte)(uVar21 >> 0x16) & 3);
              fVar29 = (float)VectorSignedToFloat((int)psVar11[1],(byte)(uVar21 >> 0x16) & 3);
              fVar31 = (float)VectorSignedToFloat((int)*psVar11,(byte)(uVar21 >> 0x16) & 3);
              fVar33 = (float)VectorSignedToFloat((int)__ptr_00[iVar13 * 7 + 1],
                                                  (byte)(uVar21 >> 0x16) & 3);
              fVar33 = (fVar29 * fVar45 - (fVar39 * fVar45 + fVar39 * fVar45)) + fVar33 * fVar45;
              fVar29 = (float)VectorSignedToFloat((int)__ptr_00[iVar13 * 7],
                                                  (byte)(uVar21 >> 0x16) & 3);
              fVar29 = (fVar31 * fVar28 - (fVar35 * fVar28 + fVar35 * fVar28)) + fVar29 * fVar28;
              fVar29 = fVar33 * fVar33 + fVar29 * fVar29;
              uVar21 = uVar21 & 0xfffffff | (uint)(fVar29 == 0.0) << 0x1e;
              if (!SUB41(uVar21 >> 0x1e,0)) {
                *pfVar14 = 1.0 / fVar29;
                goto LAB_0001d124;
              }
            }
            *pfVar14 = 0.0;
          }
LAB_0001d124:
          iVar10 = iVar9 + 1;
          pfVar14 = pfVar14 + 1;
          iVar13 = iVar9;
          iVar9 = iVar10;
        } while (iVar4 != iVar10);
      }
      if (local_78 < local_70) {
        iVar13 = local_7c;
        iVar9 = local_74;
        iVar10 = local_70;
        iVar15 = local_78;
        do {
          if (iVar13 < iVar9) {
            fVar28 = (float)VectorSignedToFloat(iVar15,(byte)(uVar21 >> 0x16) & 3);
            fVar31 = (float)uVar44;
            fVar28 = fVar28 + 0.5;
            uVar44 = CONCAT44(fVar28,fVar31);
            fVar29 = fVar28 / fVar45;
            fVar33 = (float)VectorSignedToFloat(param_4,(byte)(uVar21 >> 0x16) & 3);
            iVar12 = iVar13;
            do {
              fVar39 = (float)VectorSignedToFloat(iVar12,(byte)(uVar21 >> 0x16) & 3);
              fVar39 = fVar39 + 0.5;
              dVar22 = fmod((double)fVar29,1.0);
              fVar46 = fVar39 / fVar31;
              fVar35 = (float)dVar22;
              uVar20 = uVar21 & 0xfffffff | (uint)(fVar35 < 0.01) << 0x1f;
              if (SUB41(uVar20 >> 0x1f,0)) {
                fVar35 = fVar29 + 0.01;
                if (iVar4 < 1) goto LAB_0001da2c;
LAB_0001d310:
                iVar13 = 0;
                psVar11 = __ptr_00 + iVar4 * 7;
                do {
                  while ((char)__ptr_00[6] != '\x02') {
                    if ((char)__ptr_00[6] == '\x03') {
                      iVar16 = (int)__ptr_00[-6];
                      iVar6 = (int)__ptr_00[3];
                      iVar10 = (int)__ptr_00[1];
                      iVar9 = iVar6;
                      if (iVar16 < iVar6) {
                        iVar9 = iVar16;
                      }
                      if (iVar10 <= iVar9) {
                        iVar9 = iVar10;
                      }
                      fVar40 = (float)VectorSignedToFloat(iVar9,(byte)(uVar20 >> 0x16) & 3);
                      uVar21 = uVar20 & 0xfffffff;
                      uVar1 = uVar21 | (uint)(fVar35 < fVar40) << 0x1f |
                              (uint)(fVar35 == fVar40) << 0x1e;
                      uVar20 = uVar1 | (uint)(NAN(fVar35) || NAN(fVar40)) << 0x1c;
                      bVar2 = (byte)(uVar1 >> 0x18);
                      if (!(bool)(bVar2 >> 6 & 1) && bVar2 >> 7 == ((byte)(uVar20 >> 0x1c) & 1)) {
                        iVar9 = iVar6;
                        if (iVar6 <= iVar16) {
                          iVar9 = iVar16;
                        }
                        if (iVar9 < iVar10) {
                          iVar9 = iVar10;
                        }
                        fVar40 = (float)VectorSignedToFloat(iVar9,(byte)(uVar20 >> 0x16) & 3);
                        uVar20 = uVar21 | (uint)(fVar35 < fVar40) << 0x1f;
                        if (SUB41(uVar20 >> 0x1f,0)) {
                          iVar18 = (int)__ptr_00[-7];
                          iVar19 = (int)*__ptr_00;
                          iVar7 = (int)__ptr_00[2];
                          iVar9 = iVar19;
                          if (iVar18 < iVar19) {
                            iVar9 = iVar18;
                          }
                          if (iVar7 <= iVar9) {
                            iVar9 = iVar7;
                          }
                          fVar40 = (float)VectorSignedToFloat(iVar9,(byte)(uVar20 >> 0x16) & 3);
                          uVar1 = uVar21 | (uint)(fVar46 < fVar40) << 0x1f |
                                  (uint)(fVar46 == fVar40) << 0x1e;
                          uVar20 = uVar1 | (uint)(NAN(fVar46) || NAN(fVar40)) << 0x1c;
                          bVar2 = (byte)(uVar1 >> 0x18);
                          if (!(bool)(bVar2 >> 6 & 1) && bVar2 >> 7 == ((byte)(uVar20 >> 0x1c) & 1))
                          {
                            fVar30 = (float)VectorSignedToFloat(iVar18,(byte)(uVar20 >> 0x16) & 3);
                            fVar42 = (float)VectorSignedToFloat(iVar7,(byte)(uVar20 >> 0x16) & 3);
                            fVar37 = (float)VectorSignedToFloat(iVar16,(byte)(uVar20 >> 0x16) & 3);
                            fVar41 = (float)VectorSignedToFloat(iVar6,(byte)(uVar20 >> 0x16) & 3);
                            uVar20 = uVar21 | (uint)(fVar37 == fVar41) << 0x1e;
                            fVar36 = (float)VectorSignedToFloat(iVar19,(byte)(uVar20 >> 0x16) & 3);
                            fVar40 = (float)VectorSignedToFloat(iVar10,(byte)(uVar20 >> 0x16) & 3);
                            if ((SUB41(uVar20 >> 0x1e,0) && fVar30 == fVar42) ||
                               (uVar20 = uVar21 | (uint)(fVar41 == fVar40) << 0x1e,
                               SUB41(uVar20 >> 0x1e,0) && fVar42 == fVar36)) {
                              if (iVar16 < iVar10) {
                                uVar21 = uVar20 & 0xfffffff | (uint)(fVar35 < fVar37) << 0x1f |
                                         (uint)(fVar35 == fVar37) << 0x1e;
                                uVar20 = uVar21 | (uint)(NAN(fVar35) || NAN(fVar37)) << 0x1c;
                                bVar2 = (byte)(uVar21 >> 0x18);
                                if (!(bool)(bVar2 >> 6 & 1) &&
                                    bVar2 >> 7 == ((byte)(uVar20 >> 0x1c) & 1)) {
LAB_0001da4c:
                                  uVar21 = uVar20 & 0xfffffff;
                                  uVar20 = uVar21 | (uint)(fVar35 < fVar40) << 0x1f;
                                  if (SUB41(uVar20 >> 0x1f,0)) {
                                    if (iVar18 < iVar19) {
                                      fVar36 = fVar30;
                                    }
                                    uVar1 = uVar21 | (uint)(fVar46 < fVar36) << 0x1f |
                                            (uint)(fVar46 == fVar36) << 0x1e;
                                    uVar20 = uVar1 | (uint)(NAN(fVar46) || NAN(fVar36)) << 0x1c;
                                    bVar2 = (byte)(uVar1 >> 0x18);
                                    if (!(bool)(bVar2 >> 6 & 1) &&
                                        bVar2 >> 7 == ((byte)(uVar20 >> 0x1c) & 1)) {
                                      fVar40 = (float)VectorSignedToFloat(iVar10 - iVar16,
                                                                          (byte)(uVar20 >> 0x16) & 3
                                                                         );
                                      fVar36 = (float)VectorSignedToFloat(iVar19 - iVar18,
                                                                          (byte)(uVar20 >> 0x16) & 3
                                                                         );
                                      fVar30 = fVar30 + ((fVar35 - fVar37) / fVar40) * fVar36;
                                      uVar21 = uVar21 | (uint)(fVar46 < fVar30) << 0x1f |
                                               (uint)(fVar46 == fVar30) << 0x1e;
                                      uVar20 = uVar21 | (uint)(NAN(fVar46) || NAN(fVar30)) << 0x1c;
                                      bVar2 = (byte)(uVar21 >> 0x18);
                                      if (!(bool)(bVar2 >> 6 & 1) &&
                                          bVar2 >> 7 == ((byte)(uVar20 >> 0x1c) & 1)) {
                                        if (iVar16 < iVar10) {
                                          iVar9 = 1;
                                        }
                                        else {
                                          iVar9 = -1;
                                        }
                                        iVar13 = iVar13 + iVar9;
                                      }
                                    }
                                  }
                                }
                              }
                              else {
                                uVar21 = uVar20 & 0xfffffff | (uint)(fVar35 < fVar40) << 0x1f |
                                         (uint)(fVar35 == fVar40) << 0x1e;
                                uVar20 = uVar21 | (uint)(NAN(fVar35) || NAN(fVar40)) << 0x1c;
                                bVar2 = (byte)(uVar21 >> 0x18);
                                fVar40 = fVar37;
                                if (!(bool)(bVar2 >> 6 & 1) &&
                                    bVar2 >> 7 == ((byte)(uVar20 >> 0x1c) & 1)) goto LAB_0001da4c;
                              }
                            }
                            else {
                              fVar34 = fVar41 - fVar42 * 0.0;
                              fVar32 = fVar37 - fVar30 * 0.0;
                              fVar25 = (fVar40 - fVar36 * 0.0) + (fVar32 - (fVar34 + fVar34));
                              fVar34 = fVar34 - fVar32;
                              fVar32 = fVar32 - (fVar35 - fVar46 * 0.0);
                              if (fVar25 == 0.0) {
                                fVar32 = fVar32 / (fVar34 * -2.0);
                                uVar1 = uVar21 | (uint)(fVar32 < 0.0) << 0x1f;
                                uVar20 = uVar1 | (uint)NAN(fVar32) << 0x1c;
                                if (((byte)(uVar1 >> 0x1f) == ((byte)(uVar20 >> 0x1c) & 1)) &&
                                   (uVar20 = uVar21 | (uint)(fVar32 == 1.0) << 0x1e |
                                             (uint)(1.0 <= fVar32) << 0x1d,
                                   bVar2 = (byte)(uVar20 >> 0x18), fVar26 = 0.0,
                                   !(bool)(bVar2 >> 5 & 1) || (bool)(bVar2 >> 6))) {
LAB_0001dd10:
                                  iVar9 = 1;
LAB_0001dd14:
                                  fVar30 = fVar30 + fVar37 * 0.0;
                                  fVar37 = fVar30 - (fVar46 + fVar35 * 0.0);
                                  fVar41 = (fVar42 + fVar41 * 0.0) - fVar30;
                                  fVar30 = (fVar36 + fVar40 * 0.0) - fVar30;
                                  fVar40 = fVar37 + (2.0 - (fVar32 + fVar32)) * fVar32 * fVar41 +
                                           fVar32 * fVar32 * fVar30;
                                  if (iVar9 == 2) {
                                    uVar21 = uVar20 & 0xfffffff | (uint)(fVar40 < 0.0) << 0x1f;
                                    if (SUB41(uVar21 >> 0x1f,0)) {
                                      uVar21 = uVar20 & 0xfffffff |
                                               (uint)(fVar34 + fVar25 * fVar32 < 0.0) << 0x1f;
                                      if (SUB41(uVar21 >> 0x1f,0)) {
                                        iVar13 = iVar13 + -1;
                                      }
                                      else {
                                        iVar13 = iVar13 + 1;
                                      }
                                    }
                                    uVar20 = uVar21 & 0xfffffff |
                                             (uint)(fVar37 + (2.0 - (fVar26 + fVar26)) * fVar26 *
                                                             fVar41 + fVar26 * fVar26 * fVar30 < 0.0
                                                   ) << 0x1f;
                                    if (SUB41(uVar20 >> 0x1f,0)) {
                                      uVar20 = uVar21 & 0xfffffff |
                                               (uint)(fVar34 + fVar25 * fVar26 < 0.0) << 0x1f;
                                      if (SUB41(uVar20 >> 0x1f,0)) {
                                        iVar9 = -1;
                                      }
                                      else {
                                        iVar9 = 1;
                                      }
                                      iVar13 = iVar13 + iVar9;
                                    }
                                  }
                                  else {
                                    uVar21 = uVar20 & 0xfffffff;
                                    uVar20 = uVar21 | (uint)(fVar40 < 0.0) << 0x1f;
                                    if (SUB41(uVar20 >> 0x1f,0)) {
                                      uVar20 = uVar21 | (uint)(fVar34 + fVar25 * fVar32 < 0.0) <<
                                                        0x1f;
                                      if (SUB41(uVar20 >> 0x1f,0)) {
                                        iVar13 = iVar13 + -1;
                                      }
                                      else {
                                        iVar13 = iVar13 + 1;
                                      }
                                    }
                                  }
                                }
                              }
                              else {
                                fVar32 = fVar34 * fVar34 - fVar25 * fVar32;
                                uVar1 = uVar21 | (uint)(fVar32 < 0.0) << 0x1f |
                                        (uint)(fVar32 == 0.0) << 0x1e;
                                uVar20 = uVar1 | (uint)NAN(fVar32) << 0x1c;
                                bVar2 = (byte)(uVar1 >> 0x18);
                                if (!(bool)(bVar2 >> 6 & 1) &&
                                    bVar2 >> 7 == ((byte)(uVar20 >> 0x1c) & 1)) {
                                  uVar21 = uVar21 | (uint)(fVar32 < 0.0) << 0x1f;
                                  fVar24 = SQRT(fVar32);
                                  if (SUB41(uVar21 >> 0x1f,0)) {
                                    sqrtf(fVar32);
                                  }
                                  fVar32 = (fVar34 + fVar24) * (-1.0 / fVar25);
                                  uVar21 = uVar21 & 0xfffffff;
                                  fVar26 = (fVar34 - fVar24) * (-1.0 / fVar25);
                                  if (NAN(fVar32)) {
                                    uVar21 = uVar21 | (uint)(fVar24 < 0.0) << 0x1f |
                                             (uint)(fVar24 == 0.0) << 0x1e;
                                    uVar20 = uVar21 | (uint)NAN(fVar24) << 0x1c;
                                    bVar2 = (byte)(uVar21 >> 0x18);
                                    if (!(bool)(bVar2 >> 6 & 1) &&
                                        bVar2 >> 7 == ((byte)(uVar20 >> 0x1c) & 1)) {
LAB_0001d7d8:
                                      uVar21 = uVar20 & 0xfffffff;
                                      uVar1 = uVar21 | (uint)(fVar26 < 0.0) << 0x1f;
                                      uVar20 = uVar1 | (uint)NAN(fVar26) << 0x1c;
                                      if (((byte)(uVar1 >> 0x1f) == ((byte)(uVar20 >> 0x1c) & 1)) &&
                                         (uVar20 = uVar21 | (uint)(fVar26 == 1.0) << 0x1e |
                                                   (uint)(1.0 <= fVar26) << 0x1d,
                                         bVar2 = (byte)(uVar20 >> 0x18),
                                         !(bool)(bVar2 >> 5 & 1) || (bool)(bVar2 >> 6))) {
                                        iVar9 = 0;
                                        fVar32 = fVar26;
                                        goto LAB_0001e038;
                                      }
                                    }
                                  }
                                  else {
                                    uVar1 = uVar21 | (uint)(fVar24 < 0.0) << 0x1f |
                                            (uint)(fVar24 == 0.0) << 0x1e;
                                    uVar20 = uVar1 | (uint)NAN(fVar24) << 0x1c;
                                    bVar3 = (byte)(uVar20 >> 0x18);
                                    bVar2 = (byte)(uVar1 >> 0x18);
                                    if (fVar32 <= 1.0) {
                                      if ((((bool)(bVar2 >> 6 & 1) || bVar2 >> 7 != (bVar3 >> 4 & 1)
                                           ) || (uVar1 = uVar21 | (uint)(fVar26 < 0.0) << 0x1f,
                                                uVar20 = uVar1 | (uint)NAN(fVar26) << 0x1c,
                                                (byte)(uVar1 >> 0x1f) !=
                                                ((byte)(uVar20 >> 0x1c) & 1))) ||
                                         (uVar20 = uVar21 | (uint)(fVar26 == 1.0) << 0x1e |
                                                   (uint)(1.0 <= fVar26) << 0x1d,
                                         bVar2 = (byte)(uVar20 >> 0x18),
                                         (bool)(bVar2 >> 5 & 1) && !(bool)(bVar2 >> 6)))
                                      goto LAB_0001dd10;
                                      iVar9 = 1;
LAB_0001e038:
                                      iVar9 = iVar9 + 1;
                                      goto LAB_0001dd14;
                                    }
                                    if (!(bool)(bVar2 >> 6 & 1) && bVar2 >> 7 == (bVar3 >> 4 & 1))
                                    goto LAB_0001d7d8;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
LAB_0001d348:
                    __ptr_00 = __ptr_00 + 7;
                    if (psVar11 == __ptr_00) goto LAB_0001d410;
                  }
                  iVar9 = (int)__ptr_00[-6];
                  iVar10 = (int)__ptr_00[1];
                  if (iVar10 <= iVar9) {
                    fVar40 = (float)VectorSignedToFloat(iVar10,(byte)(uVar20 >> 0x16) & 3);
                    uVar21 = uVar20 & 0xfffffff | (uint)(fVar35 < fVar40) << 0x1f |
                             (uint)(fVar35 == fVar40) << 0x1e;
                    uVar20 = uVar21 | (uint)(NAN(fVar35) || NAN(fVar40)) << 0x1c;
                    bVar2 = (byte)(uVar21 >> 0x18);
                    if (!(bool)(bVar2 >> 6 & 1) && bVar2 >> 7 == ((byte)(uVar20 >> 0x1c) & 1)) {
                      fVar36 = (float)VectorSignedToFloat(iVar9,(byte)(uVar20 >> 0x16) & 3);
                      fVar40 = fVar36;
                      goto LAB_0001d38c;
                    }
                    goto LAB_0001d348;
                  }
                  fVar40 = (float)VectorSignedToFloat(iVar9,(byte)(uVar20 >> 0x16) & 3);
                  uVar21 = uVar20 & 0xfffffff | (uint)(fVar35 < fVar40) << 0x1f |
                           (uint)(fVar35 == fVar40) << 0x1e;
                  uVar20 = uVar21 | (uint)(NAN(fVar35) || NAN(fVar40)) << 0x1c;
                  bVar2 = (byte)(uVar21 >> 0x18);
                  if ((bool)(bVar2 >> 6 & 1) || bVar2 >> 7 != ((byte)(uVar20 >> 0x1c) & 1))
                  goto LAB_0001d348;
                  fVar36 = (float)VectorSignedToFloat(iVar10,(byte)(uVar20 >> 0x16) & 3);
LAB_0001d38c:
                  uVar21 = uVar20 & 0xfffffff;
                  uVar20 = uVar21 | (uint)(fVar35 < fVar36) << 0x1f;
                  if (!SUB41(uVar20 >> 0x1f,0)) goto LAB_0001d348;
                  iVar6 = (int)__ptr_00[-7];
                  iVar7 = (int)*__ptr_00;
                  iVar16 = iVar6;
                  if (iVar7 <= iVar6) {
                    iVar16 = iVar7;
                  }
                  fVar36 = (float)VectorSignedToFloat(iVar16,(byte)(uVar20 >> 0x16) & 3);
                  uVar1 = uVar21 | (uint)(fVar46 < fVar36) << 0x1f |
                          (uint)(fVar46 == fVar36) << 0x1e;
                  uVar20 = uVar1 | (uint)(NAN(fVar46) || NAN(fVar36)) << 0x1c;
                  bVar2 = (byte)(uVar1 >> 0x18);
                  if ((bool)(bVar2 >> 6 & 1) || bVar2 >> 7 != ((byte)(uVar20 >> 0x1c) & 1))
                  goto LAB_0001d348;
                  fVar36 = (float)VectorSignedToFloat(iVar10 - iVar9,(byte)(uVar20 >> 0x16) & 3);
                  fVar37 = (float)VectorSignedToFloat(iVar7 - iVar6,(byte)(uVar20 >> 0x16) & 3);
                  fVar41 = (float)VectorSignedToFloat(iVar6,(byte)(uVar20 >> 0x16) & 3);
                  fVar41 = fVar41 + ((fVar35 - fVar40) / fVar36) * fVar37;
                  uVar21 = uVar21 | (uint)(fVar46 < fVar41) << 0x1f |
                           (uint)(fVar46 == fVar41) << 0x1e;
                  uVar20 = uVar21 | (uint)(NAN(fVar46) || NAN(fVar41)) << 0x1c;
                  bVar2 = (byte)(uVar21 >> 0x18);
                  if ((bool)(bVar2 >> 6 & 1) || bVar2 >> 7 != ((byte)(uVar20 >> 0x1c) & 1))
                  goto LAB_0001d348;
                  __ptr_00 = __ptr_00 + 7;
                  if (iVar9 < iVar10) {
                    iVar9 = 1;
                  }
                  else {
                    iVar9 = -1;
                  }
                  iVar13 = iVar13 + iVar9;
                } while (psVar11 != __ptr_00);
LAB_0001d410:
                fVar35 = 999999.0;
                __ptr_00 = local_6c[0];
                iVar9 = -0xe;
                pfVar14 = __ptr;
                do {
                  while( true ) {
                    iVar16 = iVar9 + 0xe;
                    iVar10 = (int)__ptr_00 + iVar16;
                    fVar40 = (float)VectorSignedToFloat((int)*(short *)(iVar10 + 2),
                                                        (byte)(uVar20 >> 0x16) & 3);
                    fVar40 = fVar40 * fVar45;
                    fVar36 = (float)VectorSignedToFloat((int)*(short *)((int)__ptr_00 + iVar16),
                                                        (byte)(uVar20 >> 0x16) & 3);
                    fVar37 = fVar40 - fVar28;
                    fVar36 = fVar36 * fVar31;
                    fVar41 = fVar36 - fVar39;
                    fVar46 = fVar37 * fVar37 + fVar41 * fVar41;
                    uVar21 = uVar20 & 0xfffffff;
                    uVar20 = uVar21 | (uint)(fVar46 < fVar35 * fVar35) << 0x1f;
                    if (!SUB41(uVar20 >> 0x1f,0)) break;
                    uVar20 = uVar21 | (uint)(fVar46 < 0.0) << 0x1f;
                    fVar35 = SQRT(fVar46);
                    if (!SUB41(uVar20 >> 0x1f,0)) break;
                    sqrtf(fVar46);
                    iVar10 = (int)local_6c[0] + iVar16;
                    cVar8 = *(char *)(iVar10 + 0xc);
                    __ptr_00 = local_6c[0];
                    if (cVar8 == '\x02') goto LAB_0001d4c0;
LAB_0001d438:
                    if (cVar8 == '\x03') {
                      fVar32 = (float)VectorSignedToFloat((int)*(short *)(iVar10 + 4),
                                                          (byte)(uVar20 >> 0x16) & 3);
                      fVar32 = fVar32 * fVar31;
                      fVar30 = (float)VectorSignedToFloat((int)*(short *)((int)__ptr_00 + iVar9),
                                                          (byte)(uVar20 >> 0x16) & 3);
                      fVar34 = (float)VectorSignedToFloat((int)*(short *)(iVar10 + 6),
                                                          (byte)(uVar20 >> 0x16) & 3);
                      fVar30 = fVar30 * fVar31;
                      fVar34 = fVar34 * fVar45;
                      uVar21 = uVar20 & 0xfffffff;
                      uVar20 = uVar21 | (uint)(fVar36 < fVar32) << 0x1f;
                      fVar42 = (float)VectorSignedToFloat((int)*(short *)((int)__ptr_00 + iVar9 + 2)
                                                          ,(byte)(uVar20 >> 0x16) & 3);
                      fVar46 = fVar32;
                      if (SUB41(uVar20 >> 0x1f,0)) {
                        fVar46 = fVar36;
                      }
                      fVar42 = fVar42 * fVar45;
                      if (fVar30 <= fVar46) {
                        fVar46 = fVar30;
                      }
                      fVar25 = fVar34;
                      if (fVar40 < fVar34) {
                        fVar25 = fVar40;
                      }
                      if (fVar42 <= fVar25) {
                        fVar25 = fVar42;
                      }
                      fVar26 = fVar36;
                      if (fVar36 < fVar32) {
                        fVar26 = fVar32;
                      }
                      fVar46 = fVar46 - fVar35;
                      if (fVar26 < fVar30) {
                        fVar26 = fVar30;
                      }
                      fVar24 = fVar40;
                      if (fVar40 < fVar34) {
                        fVar24 = fVar34;
                      }
                      uVar1 = uVar21 | (uint)(fVar39 < fVar46) << 0x1f |
                              (uint)(fVar39 == fVar46) << 0x1e;
                      uVar20 = uVar1 | (uint)(NAN(fVar39) || NAN(fVar46)) << 0x1c;
                      if (fVar24 < fVar42) {
                        fVar24 = fVar42;
                      }
                      bVar2 = (byte)(uVar1 >> 0x18);
                      if (((!(bool)(bVar2 >> 6 & 1) && bVar2 >> 7 == ((byte)(uVar20 >> 0x1c) & 1))
                          && (uVar20 = uVar21 | (uint)(fVar39 < fVar35 + fVar26) << 0x1f,
                             SUB41(uVar20 >> 0x1f,0))) &&
                         (uVar20 = uVar21 | (uint)(fVar25 - fVar35 < fVar28) << 0x1f,
                         SUB41(uVar20 >> 0x1f,0))) {
                        fVar24 = fVar35 + fVar24;
                        uVar1 = uVar21 | (uint)(fVar24 < fVar28) << 0x1f |
                                (uint)(fVar24 == fVar28) << 0x1e;
                        uVar20 = uVar1 | (uint)(NAN(fVar24) || NAN(fVar28)) << 0x1c;
                        bVar2 = (byte)(uVar1 >> 0x18);
                        if (!(bool)(bVar2 >> 6 & 1) && bVar2 >> 7 == ((byte)(uVar20 >> 0x1c) & 1)) {
                          fVar46 = *pfVar14;
                          fVar26 = (fVar36 - (fVar32 + fVar32)) + fVar30;
                          fVar24 = (fVar40 - (fVar34 + fVar34)) + fVar42;
                          fVar25 = fVar32 - fVar36;
                          fVar43 = fVar34 - fVar40;
                          if (fVar46 == 0.0) {
                            fVar46 = fVar43 * fVar43 + fVar25 * fVar25;
                            fVar27 = (fVar43 * fVar24 + fVar25 * fVar26) * 3.0;
                            fVar46 = fVar46 + fVar46 + fVar37 * fVar24 + fVar41 * fVar26;
                            fVar37 = fVar37 * fVar43 + fVar41 * fVar25;
                            if (fVar27 == 0.0) {
                              uVar20 = uVar21 | (uint)(fVar46 == 0.0) << 0x1e;
                              if (!SUB41(uVar20 >> 0x1e,0)) {
                                fVar46 = -fVar37 / fVar46;
                                goto LAB_0001d99c;
                              }
                            }
                            else {
                              fVar37 = fVar46 * fVar46 - fVar27 * 4.0 * fVar37;
                              uVar20 = uVar21 | (uint)(fVar37 < 0.0) << 0x1f;
                              if (!SUB41(uVar20 >> 0x1f,0)) {
                                uVar21 = uVar21 | (uint)(fVar37 < 0.0) << 0x1f;
                                if (SUB41(uVar21 >> 0x1f,0)) {
                                  sqrtf(fVar37);
                                }
                                iVar9 = 2;
                                local_b0 = (SQRT(fVar37) - fVar46) / (fVar27 + fVar27);
                                fVar46 = (-fVar46 - SQRT(fVar37)) / (fVar27 + fVar27);
                                goto LAB_0001db30;
                              }
                            }
                          }
                          else {
                            fVar38 = fVar43 * fVar43 + fVar25 * fVar25;
                            fVar27 = (fVar43 * fVar24 + fVar25 * fVar26) * 3.0 * fVar46;
                            fVar24 = (fVar38 + fVar38 + fVar37 * fVar24 + fVar41 * fVar26) * fVar46;
                            fVar26 = fVar24 - (fVar27 * fVar27) / 3.0;
                            fVar38 = fVar26 * fVar26 * fVar26;
                            fVar46 = (((fVar27 + fVar27) * fVar27 - fVar24 * 9.0) * fVar27) / 27.0 +
                                     (fVar37 * fVar43 + fVar41 * fVar25) * fVar46;
                            fVar41 = -fVar27 / 3.0;
                            fVar37 = (fVar38 * 4.0) / 27.0 + fVar46 * fVar46;
                            if (NAN(fVar37)) {
                              fVar37 = -fVar26 / 3.0;
                              fVar25 = SQRT(fVar37);
                              uVar21 = uVar21 | (uint)(fVar37 < 0.0) << 0x1f;
                              if (SUB41(uVar21 >> 0x1f,0)) {
                                sqrtf(fVar37);
                              }
                              dVar22 = (double)(-27.0 / fVar38);
                              uVar21 = uVar21 & 0xfffffff | (uint)(dVar22 < 0.0) << 0x1f;
                              if (SUB41(uVar21 >> 0x1f,0)) {
                                sqrt(dVar22);
                              }
                              iVar9 = 3;
                              dVar22 = acos(-(SQRT(dVar22) * (double)fVar46) * 0.5);
                              dVar23 = cos((double)((float)dVar22 / 3.0));
                              fVar37 = (float)dVar23;
                              dVar22 = cos((double)((float)dVar22 / 3.0) - 1.570796);
                              fVar46 = fVar41 + (fVar25 + fVar25) * fVar37;
                              local_b0 = fVar41 - (fVar37 + (float)dVar22 * 1.7320508) * fVar25;
                              local_a8 = fVar41 - (fVar37 - (float)dVar22 * 1.7320508) * fVar25;
LAB_0001db30:
                              uVar1 = uVar21 & 0xfffffff | (uint)(fVar46 < 0.0) << 0x1f;
                              uVar20 = uVar1 | (uint)NAN(fVar46) << 0x1c;
                              if ((byte)(uVar1 >> 0x1f) == ((byte)(uVar20 >> 0x1c) & 1)) {
                                uVar20 = uVar21 & 0xfffffff | (uint)(fVar46 == 1.0) << 0x1e |
                                         (uint)(1.0 <= fVar46) << 0x1d;
                                bVar2 = (byte)(uVar20 >> 0x18);
                                if (!(bool)(bVar2 >> 5 & 1) || (bool)(bVar2 >> 6))
                                goto LAB_0001db48;
                                goto LAB_0001d9b8;
                              }
LAB_0001d9c0:
                              uVar21 = uVar20 & 0xfffffff;
                              uVar1 = uVar21 | (uint)(local_b0 < 0.0) << 0x1f;
                              uVar20 = uVar1 | (uint)NAN(local_b0) << 0x1c;
                              if (((byte)(uVar1 >> 0x1f) == ((byte)(uVar20 >> 0x1c) & 1)) &&
                                 (uVar20 = uVar21 | (uint)(local_b0 == 1.0) << 0x1e |
                                           (uint)(1.0 <= local_b0) << 0x1d,
                                 bVar2 = (byte)(uVar20 >> 0x18),
                                 !(bool)(bVar2 >> 5 & 1) || (bool)(bVar2 >> 6))) {
                                fVar41 = 1.0 - local_b0;
                                fVar37 = (local_b0 + local_b0) * fVar41;
                                fVar46 = (fVar34 * fVar37 + fVar40 * fVar41 * fVar41 +
                                         fVar42 * local_b0 * local_b0) - fVar28;
                                fVar37 = (fVar32 * fVar37 + fVar36 * fVar41 * fVar41 +
                                         fVar30 * local_b0 * local_b0) - fVar39;
                                fVar46 = fVar46 * fVar46 + fVar37 * fVar37;
                                uVar20 = uVar21 | (uint)(fVar46 < fVar35 * fVar35) << 0x1f;
                                if (SUB41(uVar20 >> 0x1f,0)) {
                                  uVar20 = uVar21 | (uint)(fVar46 < 0.0) << 0x1f;
                                  fVar35 = SQRT(fVar46);
                                  if (SUB41(uVar20 >> 0x1f,0)) {
                                    sqrtf(fVar46);
                                  }
                                }
                              }
                              __ptr_00 = local_6c[0];
                              if (iVar9 == 3) {
                                uVar21 = uVar20 & 0xfffffff;
                                uVar1 = uVar21 | (uint)(local_a8 < 0.0) << 0x1f;
                                uVar20 = uVar1 | (uint)NAN(local_a8) << 0x1c;
                                if (((byte)(uVar1 >> 0x1f) == ((byte)(uVar20 >> 0x1c) & 1)) &&
                                   (uVar20 = uVar21 | (uint)(local_a8 == 1.0) << 0x1e |
                                             (uint)(1.0 <= local_a8) << 0x1d,
                                   bVar2 = (byte)(uVar20 >> 0x18),
                                   !(bool)(bVar2 >> 5 & 1) || (bool)(bVar2 >> 6))) {
                                  fVar37 = 1.0 - local_a8;
                                  fVar41 = (local_a8 + local_a8) * fVar37;
                                  fVar46 = (fVar34 * fVar41 + fVar40 * fVar37 * fVar37 +
                                           fVar42 * local_a8 * local_a8) - fVar28;
                                  fVar40 = (fVar32 * fVar41 + fVar36 * fVar37 * fVar37 +
                                           fVar30 * local_a8 * local_a8) - fVar39;
                                  fVar46 = fVar46 * fVar46 + fVar40 * fVar40;
                                  uVar20 = uVar21 | (uint)(fVar46 < fVar35 * fVar35) << 0x1f;
                                  if (SUB41(uVar20 >> 0x1f,0)) {
                                    uVar20 = uVar21 | (uint)(fVar46 < 0.0) << 0x1f;
                                    fVar35 = SQRT(fVar46);
                                    if (SUB41(uVar20 >> 0x1f,0)) {
                                      sqrtf(fVar46);
                                      __ptr_00 = local_6c[0];
                                    }
                                  }
                                }
                              }
                            }
                            else {
                              uVar20 = uVar21 | (uint)(fVar37 < 0.0) << 0x1f;
                              if (SUB41(uVar20 >> 0x1f,0)) {
                                sqrtf(fVar37);
                              }
                              fVar25 = (float)stbtt__cuberoot((SQRT(fVar37) - fVar46) * 0.5);
                              fVar46 = (float)stbtt__cuberoot((-fVar46 - SQRT(fVar37)) * 0.5);
                              fVar46 = fVar41 + fVar25 + fVar46;
LAB_0001d99c:
                              uVar21 = uVar20 & 0xfffffff;
                              uVar1 = uVar21 | (uint)(fVar46 < 0.0) << 0x1f;
                              uVar20 = uVar1 | (uint)NAN(fVar46) << 0x1c;
                              __ptr_00 = local_6c[0];
                              if ((byte)(uVar1 >> 0x1f) == ((byte)(uVar20 >> 0x1c) & 1)) {
                                iVar9 = 1;
                                uVar20 = uVar21 | (uint)(fVar46 == 1.0) << 0x1e |
                                         (uint)(1.0 <= fVar46) << 0x1d;
                                bVar2 = (byte)(uVar20 >> 0x18);
                                if (!(bool)(bVar2 >> 5 & 1) || (bool)(bVar2 >> 6)) {
LAB_0001db48:
                                  fVar41 = 1.0 - fVar46;
                                  fVar25 = (fVar46 + fVar46) * fVar41;
                                  fVar37 = (fVar34 * fVar25 + fVar40 * fVar41 * fVar41 +
                                           fVar42 * fVar46 * fVar46) - fVar28;
                                  fVar46 = (fVar32 * fVar25 + fVar36 * fVar41 * fVar41 +
                                           fVar30 * fVar46 * fVar46) - fVar39;
                                  fVar46 = fVar37 * fVar37 + fVar46 * fVar46;
                                  uVar21 = uVar20 & 0xfffffff;
                                  uVar20 = uVar21 | (uint)(fVar46 < fVar35 * fVar35) << 0x1f;
                                  if (SUB41(uVar20 >> 0x1f,0)) {
                                    uVar20 = uVar21 | (uint)(fVar46 < 0.0) << 0x1f;
                                    fVar35 = SQRT(fVar46);
                                    if (SUB41(uVar20 >> 0x1f,0)) {
                                      sqrtf(fVar46);
                                    }
                                  }
                                }
LAB_0001d9b8:
                                __ptr_00 = local_6c[0];
                                if (iVar9 != 1) goto LAB_0001d9c0;
                              }
                            }
                          }
                        }
                      }
                    }
LAB_0001d440:
                    pfVar14 = pfVar14 + 1;
                    iVar9 = iVar16;
                    if (__ptr + iVar4 == pfVar14) goto LAB_0001d544;
                  }
                  cVar8 = *(char *)(iVar10 + 0xc);
                  if (cVar8 != '\x02') goto LAB_0001d438;
LAB_0001d4c0:
                  fVar42 = (float)VectorSignedToFloat((int)*(short *)((int)__ptr_00 + iVar9),
                                                      (byte)(uVar20 >> 0x16) & 3);
                  fVar46 = (float)VectorSignedToFloat((int)*(short *)((int)__ptr_00 + iVar9 + 2),
                                                      (byte)(uVar20 >> 0x16) & 3);
                  fVar40 = fVar46 * fVar45 - fVar40;
                  fVar36 = fVar42 * fVar31 - fVar36;
                  fVar46 = ABS(fVar37 * fVar36 - fVar41 * fVar40) * *pfVar14;
                  uVar21 = uVar20 & 0xfffffff;
                  uVar1 = uVar21 | (uint)(fVar35 < fVar46) << 0x1f |
                          (uint)(fVar35 == fVar46) << 0x1e;
                  uVar20 = uVar1 | (uint)(NAN(fVar35) || NAN(fVar46)) << 0x1c;
                  bVar2 = (byte)(uVar1 >> 0x18);
                  if ((bool)(bVar2 >> 6 & 1) || bVar2 >> 7 != ((byte)(uVar20 >> 0x1c) & 1))
                  goto LAB_0001d440;
                  fVar40 = -(fVar37 * fVar40 + fVar41 * fVar36) /
                           (fVar40 * fVar40 + fVar36 * fVar36);
                  uVar1 = uVar21 | (uint)(fVar40 < 0.0) << 0x1f;
                  uVar20 = uVar1 | (uint)NAN(fVar40) << 0x1c;
                  if ((byte)(uVar1 >> 0x1f) != ((byte)(uVar20 >> 0x1c) & 1)) goto LAB_0001d440;
                  uVar20 = uVar21 | (uint)(fVar40 == 1.0) << 0x1e | (uint)(1.0 <= fVar40) << 0x1d;
                  pfVar14 = pfVar14 + 1;
                  bVar2 = (byte)(uVar20 >> 0x18);
                  if (!(bool)(bVar2 >> 5 & 1) || (bool)(bVar2 >> 6)) {
                    fVar35 = fVar46;
                  }
                  iVar9 = iVar16;
                } while (__ptr + iVar4 != pfVar14);
LAB_0001d544:
                if (iVar13 == 0) goto LAB_0001d54c;
              }
              else {
                uVar21 = uVar21 & 0xfffffff | (uint)(fVar35 < 0.99) << 0x1f |
                         (uint)(fVar35 == 0.99) << 0x1e;
                uVar20 = uVar21 | (uint)NAN(fVar35) << 0x1c;
                bVar2 = (byte)(uVar21 >> 0x18);
                fVar35 = fVar29;
                if (!(bool)(bVar2 >> 6 & 1) && bVar2 >> 7 == ((byte)(uVar20 >> 0x1c) & 1)) {
                  fVar35 = fVar29 - 0.01;
                }
                if (0 < iVar4) goto LAB_0001d310;
LAB_0001da2c:
                fVar35 = 999999.0;
                __ptr_00 = local_6c[0];
LAB_0001d54c:
                fVar35 = -fVar35;
              }
              fVar35 = fVar33 + fVar35 * (float)(in_d0 >> 0x20);
              uVar21 = uVar20 & 0xfffffff | (uint)(fVar35 < 0.0) << 0x1f;
              if (SUB41(uVar21 >> 0x1f,0)) {
                local_b4 = '\0';
              }
              else {
                uVar20 = uVar20 & 0xfffffff | (uint)(fVar35 < 255.0) << 0x1f |
                         (uint)(fVar35 == 255.0) << 0x1e;
                uVar21 = uVar20 | (uint)NAN(fVar35) << 0x1c;
                bVar2 = (byte)(uVar20 >> 0x18);
                if ((bool)(bVar2 >> 6 & 1) || bVar2 >> 7 != ((byte)(uVar21 >> 0x1c) & 1)) {
                  local_b4 = (0.0 < fVar35) * (char)(int)fVar35;
                }
                else {
                  local_b4 = -1;
                }
              }
              iVar13 = iVar12 - local_7c;
              iVar12 = iVar12 + 1;
              *(char *)((int)pvVar5 + iVar13 + iVar17 * (iVar15 - local_78)) = local_b4;
              iVar13 = local_7c;
              iVar9 = local_74;
              iVar10 = local_70;
            } while (iVar12 < local_74);
          }
          iVar15 = iVar15 + 1;
        } while (iVar15 < iVar10);
      }
      free(__ptr);
      free(__ptr_00);
      return pvVar5;
    }
  }
  return (void *)0x0;
}
