/* ============================================================
 * mxmlRemove   @ 0x002c2be0   size=72B   callers=2
 * module: 04_mini_xml
 * ============================================================ */

void mxmlRemove(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  if (param_1 == 0) {
    return;
  }
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    iVar2 = *(int *)(param_1 + 4);
    iVar3 = *(int *)(param_1 + 8);
    if (iVar3 == 0) {
      *(int *)(iVar1 + 0x10) = iVar2;
    }
    else {
      *(int *)(iVar3 + 4) = iVar2;
      iVar2 = *(int *)(param_1 + 4);
    }
    if (iVar2 == 0) {
      *(int *)(iVar1 + 0x14) = iVar3;
    }
    else {
      *(int *)(iVar2 + 8) = iVar3;
    }
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 4) = 0;
    return;
  }
  return;
}
