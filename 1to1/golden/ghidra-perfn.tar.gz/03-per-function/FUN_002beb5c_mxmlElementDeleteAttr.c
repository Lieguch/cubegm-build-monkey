/* ============================================================
 * mxmlElementDeleteAttr   @ 0x002beb5c   size=160B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

void mxmlElementDeleteAttr(int *param_1,char *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *__dest;
  char *__s1;
  
  if (param_1 == (int *)0x0) {
    return;
  }
  if (*param_1 != 0 || param_2 == (char *)0x0) {
    return;
  }
  iVar2 = param_1[7];
  __dest = (undefined4 *)param_1[8];
  if (iVar2 < 1) {
    return;
  }
  do {
    __s1 = (char *)*__dest;
    iVar1 = strcmp(__s1,param_2);
    if (iVar1 == 0) {
      free(__s1);
      free((void *)__dest[1]);
      if (iVar2 + -1 != 0) {
        memmove(__dest,__dest + 2,(iVar2 + -1) * 8);
      }
      param_1[7] = param_1[7] + -1;
      return;
    }
    iVar2 = iVar2 + -1;
    __dest = __dest + 2;
  } while (iVar2 != 0);
  return;
}
