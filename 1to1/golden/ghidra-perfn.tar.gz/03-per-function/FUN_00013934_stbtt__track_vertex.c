/* ============================================================
 * stbtt__track_vertex   @ 0x00013934   size=180B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt__track_vertex(int param_1,int param_2,int param_3)

{
  int iVar1;
  
  if ((*(int *)(param_1 + 0x1c) < param_2) || (*(int *)(param_1 + 4) == 0)) {
    *(int *)(param_1 + 0x1c) = param_2;
  }
  if ((*(int *)(param_1 + 0x24) < param_3) || (*(int *)(param_1 + 4) == 0)) {
    *(int *)(param_1 + 0x24) = param_3;
    if (param_2 < *(int *)(param_1 + 0x18)) {
      iVar1 = *(int *)(param_1 + 0x20);
      *(int *)(param_1 + 0x18) = param_2;
      goto joined_r0x00013980;
    }
    if (*(int *)(param_1 + 4) != 0) goto LAB_000139ac;
    *(int *)(param_1 + 0x18) = param_2;
  }
  else if (param_2 < *(int *)(param_1 + 0x18)) {
    iVar1 = *(int *)(param_1 + 0x20);
    *(int *)(param_1 + 0x18) = param_2;
joined_r0x00013980:
    if ((iVar1 <= param_3) && (*(int *)(param_1 + 4) != 0)) goto LAB_00013988;
  }
  else {
LAB_000139ac:
    if (*(int *)(param_1 + 0x20) <= param_3) goto LAB_00013988;
  }
  *(int *)(param_1 + 0x20) = param_3;
LAB_00013988:
  *(undefined4 *)(param_1 + 4) = 1;
  return;
}
