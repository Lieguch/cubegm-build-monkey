/* ============================================================
 * stbtt_PackSetOversampling   @ 0x0001c690   size=20B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_PackSetOversampling(int param_1,uint param_2,uint param_3)

{
  if (param_2 < 9) {
    *(uint *)(param_1 + 0x1c) = param_2;
  }
  if (param_3 < 9) {
    *(uint *)(param_1 + 0x20) = param_3;
  }
  return;
}
