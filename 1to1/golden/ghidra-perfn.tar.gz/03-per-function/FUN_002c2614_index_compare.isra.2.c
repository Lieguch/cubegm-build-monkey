/* ============================================================
 * index_compare.isra.2   @ 0x002c2614   size=88B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

void index_compare_isra_2(int *param_1,int param_2,int param_3)

{
  int iVar1;
  char *__s1;
  char *__s2;
  
  iVar1 = strcmp(*(char **)(param_2 + 0x18),*(char **)(param_3 + 0x18));
  if (iVar1 != 0) {
    return;
  }
  if (*param_1 == 0) {
    return;
  }
  __s1 = (char *)mxmlElementGetAttr(param_2);
  __s2 = (char *)mxmlElementGetAttr(param_3,*param_1);
  strcmp(__s1,__s2);
  return;
}
