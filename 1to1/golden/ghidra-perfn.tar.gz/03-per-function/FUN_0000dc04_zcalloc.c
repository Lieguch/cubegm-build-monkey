/* ============================================================
 * zcalloc   @ 0x0000dc04   size=12B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* zcalloc(void*, unsigned int, unsigned int) */

void zcalloc(void *param_1,uint param_2,uint param_3)

{
  calloc(param_2,param_3);
  return;
}
