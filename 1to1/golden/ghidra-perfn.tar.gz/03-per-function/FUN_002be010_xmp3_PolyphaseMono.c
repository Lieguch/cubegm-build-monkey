/* ============================================================
 * xmp3_PolyphaseMono   @ 0x002be010   size=884B   callers=0
 * module: 06_helix_mp3
 * ============================================================ */

void xmp3_PolyphaseMono(ushort *param_1,int *param_2,int *param_3)

{
  longlong lVar1;
  longlong lVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  ushort *puVar11;
  ushort uVar12;
  int iVar13;
  bool bVar14;
  ushort *local_30;
  
  iVar9 = param_3[0x100];
  iVar10 = param_3[0x102];
  iVar13 = param_3[0x101];
  lVar1 = (longlong)-param_3[0xf] * (longlong)param_2[0x10] +
          (longlong)param_3[0xe] * (longlong)param_2[7] +
          (longlong)-param_3[0xd] * (longlong)param_2[0x11] +
          (longlong)param_3[0xc] * (longlong)param_2[6] +
          (longlong)-param_3[0xb] * (longlong)param_2[0x12] +
          (longlong)param_2[5] * (longlong)param_3[10] +
          (longlong)param_2[0x13] * (longlong)-param_3[9] +
          (longlong)param_2[4] * (longlong)param_3[8] +
          (longlong)param_2[0x14] * (longlong)-param_3[7] +
          (longlong)param_2[3] * (longlong)param_3[6] +
          (longlong)param_2[0x15] * (longlong)-param_3[5] +
          (longlong)param_2[2] * (longlong)param_3[4] +
          (longlong)param_2[0x16] * (longlong)-param_3[3] +
          (longlong)param_2[1] * (longlong)param_3[2] +
          (longlong)param_2[0x17] * (longlong)-param_3[1] +
          (longlong)*param_2 * (longlong)*param_3 + 0x2000000;
  uVar6 = (uint)lVar1 >> 0x14 | (int)((ulonglong)lVar1 >> 0x20) << 0xc;
  iVar7 = (int)uVar6 >> 0x1f;
  bVar14 = iVar7 == (int)uVar6 >> 0x15;
  if (bVar14) {
    iVar7 = (int)uVar6 >> 6;
  }
  uVar12 = (ushort)iVar7;
  iVar7 = param_2[0x400];
  if (!bVar14) {
    uVar12 = uVar12 ^ 0x7fff;
  }
  *param_1 = uVar12;
  puVar11 = param_1 + 0x20;
  lVar1 = (longlong)param_3[0x107] * (longlong)param_2[0x407] +
          (longlong)param_3[0x106] * (longlong)param_2[0x406] +
          (longlong)param_3[0x105] * (longlong)param_2[0x405] +
          (longlong)param_3[0x104] * (longlong)param_2[0x404] +
          (longlong)param_3[0x103] * (longlong)param_2[0x403] +
          (longlong)iVar10 * (longlong)param_2[0x402] +
          (longlong)iVar13 * (longlong)param_2[0x401] +
          (longlong)iVar9 * (longlong)iVar7 + 0x2000000;
  uVar6 = (int)((ulonglong)lVar1 >> 0x20) << 0xc;
  uVar8 = (uint)lVar1 >> 0x14 | uVar6;
  if ((int)uVar8 >> 0x1f == (int)uVar8 >> 0x15) {
    uVar12 = (ushort)((int)uVar8 >> 6);
  }
  else {
    uVar12 = (ushort)((int)uVar6 >> 0x1f) ^ 0x7fff;
  }
  param_1[0x10] = uVar12;
  piVar3 = param_3 + 0x20;
  piVar5 = param_2 + 0x80;
  local_30 = param_1;
  do {
    piVar4 = piVar3 + 0x10;
    lVar1 = (longlong)piVar5[-0x30] * (longlong)-piVar3[-1] +
            (longlong)piVar5[-0x39] * (longlong)piVar3[-2] +
            (longlong)piVar5[-0x2f] * (longlong)-piVar3[-3] +
            (longlong)piVar5[-0x3a] * (longlong)piVar3[-4] +
            (longlong)piVar5[-0x2e] * (longlong)-piVar3[-5] +
            (longlong)piVar5[-0x3b] * (longlong)piVar3[-6] +
            (longlong)piVar5[-0x2d] * (longlong)-piVar3[-7] +
            (longlong)piVar5[-0x3c] * (longlong)piVar3[-8] +
            (longlong)piVar5[-0x2c] * (longlong)-piVar3[-9] +
            (longlong)piVar5[-0x3d] * (longlong)piVar3[-10] +
            (longlong)piVar5[-0x2b] * (longlong)-piVar3[-0xb] +
            (longlong)piVar5[-0x3e] * (longlong)piVar3[-0xc] +
            (longlong)piVar5[-0x2a] * (longlong)-piVar3[-0xd] +
            (longlong)piVar5[-0x3f] * (longlong)piVar3[-0xe] +
            (longlong)piVar5[-0x29] * (longlong)-piVar3[-0xf] +
            (longlong)piVar5[-0x40] * (longlong)piVar3[-0x10] + 0x2000000;
    lVar2 = (longlong)piVar5[-0x30] * (longlong)piVar3[-2] +
            (longlong)piVar3[-1] * (longlong)piVar5[-0x39] +
            (longlong)piVar5[-0x2f] * (longlong)piVar3[-4] +
            (longlong)piVar3[-3] * (longlong)piVar5[-0x3a] +
            (longlong)piVar5[-0x2e] * (longlong)piVar3[-6] +
            (longlong)piVar3[-5] * (longlong)piVar5[-0x3b] +
            (longlong)piVar5[-0x2d] * (longlong)piVar3[-8] +
            (longlong)piVar3[-7] * (longlong)piVar5[-0x3c] +
            (longlong)piVar5[-0x2c] * (longlong)piVar3[-10] +
            (longlong)piVar3[-9] * (longlong)piVar5[-0x3d] +
            (longlong)piVar5[-0x2b] * (longlong)piVar3[-0xc] +
            (longlong)piVar3[-0xb] * (longlong)piVar5[-0x3e] +
            (longlong)piVar5[-0x2a] * (longlong)piVar3[-0xe] +
            (longlong)piVar3[-0xd] * (longlong)piVar5[-0x3f] +
            (longlong)piVar5[-0x29] * (longlong)piVar3[-0x10] +
            (longlong)piVar3[-0xf] * (longlong)piVar5[-0x40] + 0x2000000;
    uVar6 = (int)((ulonglong)lVar1 >> 0x20) << 0xc;
    uVar8 = (uint)lVar1 >> 0x14 | uVar6;
    uVar12 = (ushort)((int)uVar6 >> 0x1f) ^ 0x7fff;
    if ((int)uVar8 >> 0x1f == (int)uVar8 >> 0x15) {
      uVar12 = (ushort)((int)uVar8 >> 6);
    }
    uVar6 = (int)((ulonglong)lVar2 >> 0x20) << 0xc;
    uVar8 = (uint)lVar2 >> 0x14 | uVar6;
    local_30 = local_30 + 1;
    *local_30 = uVar12;
    uVar12 = (ushort)((int)uVar6 >> 0x1f) ^ 0x7fff;
    if ((int)uVar8 >> 0x1f == (int)uVar8 >> 0x15) {
      uVar12 = (ushort)((int)uVar8 >> 6);
    }
    puVar11 = puVar11 + -1;
    *puVar11 = uVar12;
    piVar3 = piVar4;
    piVar5 = piVar5 + 0x40;
  } while (param_3 + 0x110 != piVar4);
  return;
}
