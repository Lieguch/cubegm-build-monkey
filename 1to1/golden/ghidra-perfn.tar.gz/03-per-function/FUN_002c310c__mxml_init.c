/* ============================================================
 * _mxml_init   @ 0x002c310c   size=32B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

void _mxml_init(void)

{
  pthread_key_create(&_mxml_key,_mxml_destructor);
  return;
}
