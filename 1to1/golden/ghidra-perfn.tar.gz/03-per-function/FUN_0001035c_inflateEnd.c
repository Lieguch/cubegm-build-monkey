/* ============================================================
 * inflateEnd   @ 0x0001035c   size=96B   callers=2
 * module: 07_zlib
 * ============================================================ */

/* inflateEnd(z_stream_s*) */

undefined4 inflateEnd(z_stream_s *param_1)

{
  int iVar1;
  code *pcVar2;
  
  if (((param_1 != (z_stream_s *)0x0) && (iVar1 = *(int *)(param_1 + 0x1c), iVar1 != 0)) &&
     (pcVar2 = *(code **)(param_1 + 0x24), pcVar2 != (code *)0x0)) {
    if (*(inflate_blocks_state **)(iVar1 + 0x14) != (inflate_blocks_state *)0x0) {
      inflate_blocks_free(*(inflate_blocks_state **)(iVar1 + 0x14),param_1);
      pcVar2 = *(code **)(param_1 + 0x24);
      iVar1 = *(int *)(param_1 + 0x1c);
    }
    (*pcVar2)(*(undefined4 *)(param_1 + 0x28),iVar1);
    *(undefined4 *)(param_1 + 0x1c) = 0;
    return 0;
  }
  return 0xfffffffe;
}
