/* ============================================================
 * unzGetGlobalInfo   @ 0x00011074   size=32B   callers=0
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzGetGlobalInfo(unz_s*, unz_global_info_s*) */

undefined4 unzGetGlobalInfo(unz_s *param_1,unz_global_info_s *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (param_1 == (unz_s *)0x0) {
    uVar2 = 0xffffff9a;
  }
  else {
    uVar1 = *(undefined4 *)(param_1 + 8);
    uVar2 = 0;
    *(undefined4 *)param_2 = *(undefined4 *)(param_1 + 4);
    *(undefined4 *)(param_2 + 4) = uVar1;
  }
  return uVar2;
}
