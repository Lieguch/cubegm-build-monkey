/* ============================================================
 * stbtt_PackEnd   @ 0x0001c674   size=28B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_PackEnd(int param_1)

{
  free(*(void **)(param_1 + 0x28));
  free(*(void **)(param_1 + 4));
  return;
}
