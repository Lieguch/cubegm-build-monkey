/* ============================================================
 * inflate_blocks_free   @ 0x0000df58   size=76B   callers=1
 * module: 07_zlib
 * ============================================================ */

/* inflate_blocks_free(inflate_blocks_state*, z_stream_s*) */

undefined4 inflate_blocks_free(inflate_blocks_state *param_1,z_stream_s *param_2)

{
  inflate_blocks_reset(param_1,param_2,(ulong *)0x0);
  (**(code **)(param_2 + 0x24))(*(undefined4 *)(param_2 + 0x28),*(undefined4 *)(param_1 + 0x28));
  (**(code **)(param_2 + 0x24))(*(undefined4 *)(param_2 + 0x28),*(undefined4 *)(param_1 + 0x24));
  (**(code **)(param_2 + 0x24))(*(undefined4 *)(param_2 + 0x28),param_1);
  return 0;
}
