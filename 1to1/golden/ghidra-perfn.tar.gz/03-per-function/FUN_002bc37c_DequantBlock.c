/* ============================================================
 * DequantBlock   @ 0x002bc37c   size=636B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

uint DequantBlock(uint *param_1,int param_2,int param_3,uint param_4)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint *puVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  undefined1 *puVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  int iVar15;
  uint local_38 [5];
  
  puVar4 = (uint *)(param_2 + -4);
  puVar11 = &pow43_14;
  uVar10 = (int)param_4 >> 2;
  iVar1 = (param_4 & 3) * 0x40;
  iVar12 = *(int *)(pow14 + (param_4 & 3) * 4);
  if (0x1e < (int)uVar10) {
    uVar10 = 0x1f;
  }
  if ((int)uVar10 < 0x1c) {
    puVar11 = (undefined1 *)(uVar10 + 3);
  }
  if ((int)uVar10 < 0x1c) {
    uVar2 = (uint)puVar11 & ~((int)puVar11 >> 0x1f);
  }
  else {
    uVar2 = 0x1f;
  }
  local_38[0] = 0;
  local_38[3] = *(int *)(&DAT_002e4070 + iVar1) >> (uVar2 & 0xff);
  uVar3 = 0;
  local_38[2] = *(int *)(&DAT_002e406c + iVar1) >> (uVar2 & 0xff);
  local_38[1] = *(int *)(&DAT_002e4068 + iVar1) >> (uVar2 & 0xff);
  do {
    uVar2 = *param_1;
    uVar5 = uVar2 & 0x7fffffff;
    if (uVar5 < 4) {
      uVar5 = local_38[uVar2];
    }
    else if (uVar5 < 0x10) {
      if ((int)uVar10 < 0) {
        uVar5 = *(int *)(&pow43_14 + uVar2 * 4 + iVar1) << (-uVar10 & 0xff);
      }
      else {
        uVar5 = *(int *)(&pow43_14 + uVar2 * 4 + iVar1) >> (uVar10 & 0xff);
      }
    }
    else {
      if (uVar5 < 0x40) {
        iVar13 = (int)((ulonglong)((longlong)*(int *)(&DAT_002e4134 + uVar2 * 4) * (longlong)iVar12)
                      >> 0x20);
        uVar5 = uVar10 - 3;
      }
      else {
        iVar13 = uVar2 * 0x20000;
        if (iVar13 < 0x8000000) {
          iVar13 = uVar2 << 0x15;
          iVar7 = 4;
        }
        else {
          iVar7 = 0;
        }
        if (iVar13 < 0x20000000) {
          iVar13 = iVar13 << 2;
          iVar7 = iVar7 + 2;
        }
        if (iVar13 < 0x40000000) {
          iVar13 = iVar13 << 1;
          iVar7 = iVar7 + 1;
        }
        iVar6 = 0x27c2cef0;
        if (iVar13 < 0x5a82799a) {
          iVar6 = 0x236c498d;
        }
        iVar14 = -0x2ccc095c;
        if (iVar13 < 0x5a82799a) {
          iVar14 = -0x4fd1b7d8;
        }
        iVar15 = -0xa7e7a7;
        if (0x5a827999 < iVar13) {
          iVar15 = -0x10a884c;
        }
        iVar9 = 0x46e9408b;
        if (iVar13 < 0x5a82799a) {
          iVar9 = 0x5957aa1b;
        }
        iVar8 = 0x29a0bda9;
        if (0x5a827999 < iVar13) {
          iVar8 = 0x10852163;
        }
        iVar13 = (int)((ulonglong)
                       ((longlong)
                        ((int)((ulonglong)
                               ((longlong)
                                ((int)((ulonglong)
                                       ((longlong)
                                        ((int)((ulonglong)
                                               ((longlong)
                                                ((int)((ulonglong)
                                                       ((longlong)
                                                        ((int)((ulonglong)
                                                               ((longlong)iVar8 * (longlong)iVar13)
                                                              >> 0x20) + iVar14) * (longlong)iVar13)
                                                      >> 0x20) + iVar9) * (longlong)iVar13) >> 0x20)
                                        + iVar6) * (longlong)iVar13) >> 0x20) + iVar15) *
                               (longlong)*(int *)(pow2frac + iVar7 * 4)) >> 0x20) << 3) *
                       (longlong)iVar12) >> 0x20);
        uVar5 = uVar10 - *(int *)(pow2exp + iVar7 * 4);
      }
      if ((int)uVar5 < 0) {
        if (0x7fffffff >> (-uVar5 & 0xff) < iVar13) {
          uVar5 = 0x7fffffff;
        }
        else {
          uVar5 = iVar13 << (-uVar5 & 0xff);
        }
      }
      else {
        uVar5 = iVar13 >> (uVar5 & 0xff);
      }
    }
    uVar3 = uVar3 | uVar5;
    if ((int)uVar2 < 0) {
      uVar5 = -uVar5;
    }
    param_3 = param_3 + -1;
    puVar4 = puVar4 + 1;
    *puVar4 = uVar5;
    param_1 = param_1 + 1;
  } while (param_3 != 0);
  return uVar3;
}
