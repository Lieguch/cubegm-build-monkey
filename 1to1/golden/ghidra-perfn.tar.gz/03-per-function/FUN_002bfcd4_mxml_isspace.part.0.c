/* ============================================================
 * mxml_isspace.part.0   @ 0x002bfcd4   size=20B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

bool mxml_isspace_part_0(int param_1)

{
  return param_1 == 10 || param_1 == 0xd;
}
