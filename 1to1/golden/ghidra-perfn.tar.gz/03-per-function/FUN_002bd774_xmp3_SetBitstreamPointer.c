/* ============================================================
 * xmp3_SetBitstreamPointer   @ 0x002bd774   size=24B   callers=2
 * module: 06_helix_mp3
 * ============================================================ */

void xmp3_SetBitstreamPointer(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  *param_1 = param_3;
  param_1[3] = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  return;
}
