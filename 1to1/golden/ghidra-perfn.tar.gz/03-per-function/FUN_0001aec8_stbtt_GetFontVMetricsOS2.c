/* ============================================================
 * stbtt_GetFontVMetricsOS2   @ 0x0001aec8   size=164B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

undefined4 stbtt_GetFontVMetricsOS2(int param_1,int *param_2,int *param_3,int *param_4)

{
  int iVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_1 + 4);
  iVar1 = stbtt__find_table(iVar2,*(undefined4 *)(param_1 + 8),&DAT_002dce34);
  if (iVar1 == 0) {
    return 0;
  }
  if (param_2 != (int *)0x0) {
    *param_2 = (int)(short)((ushort)*(byte *)(iVar2 + iVar1 + 0x44 + 1) +
                           (ushort)*(byte *)(iVar2 + iVar1 + 0x44) * 0x100);
  }
  if (param_3 != (int *)0x0) {
    *param_3 = (int)(short)((ushort)*(byte *)(iVar2 + iVar1 + 0x46 + 1) +
                           (ushort)*(byte *)(iVar2 + iVar1 + 0x46) * 0x100);
  }
  if (param_4 != (int *)0x0) {
    *param_4 = (int)(short)((ushort)*(byte *)(iVar2 + iVar1 + 0x48 + 1) +
                           (ushort)*(byte *)(iVar2 + iVar1 + 0x48) * 0x100);
  }
  return 1;
}
