/* ============================================================
 * unzGoToNextFile   @ 0x00011868   size=164B   callers=3
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzGoToNextFile(unz_s*) */

int unzGoToNextFile(unz_s *param_1)

{
  int iVar1;
  
  if (param_1 == (unz_s *)0x0) {
    iVar1 = -0x66;
  }
  else if ((*(int *)(param_1 + 0x18) == 0) ||
          (*(int *)(param_1 + 0x10) + 1 == *(int *)(param_1 + 4))) {
    iVar1 = -100;
  }
  else {
    *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
    *(int *)(param_1 + 0x14) =
         *(int *)(param_1 + 0x14) + *(int *)(param_1 + 0x48) + 0x2e + *(int *)(param_1 + 0x4c) +
         *(int *)(param_1 + 0x50);
    iVar1 = unzlocal_GetCurrentFileInfoInternal
                      (param_1,(unz_file_info_s *)(param_1 + 0x28),
                       (unz_file_info_internal_s *)(param_1 + 0x78),(char *)0x0,0,(void *)0x0,0,
                       (char *)0x0,0);
    *(uint *)(param_1 + 0x18) = (uint)(iVar1 == 0);
  }
  return iVar1;
}
