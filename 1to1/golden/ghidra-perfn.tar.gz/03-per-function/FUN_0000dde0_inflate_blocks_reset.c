/* ============================================================
 * inflate_blocks_reset   @ 0x0000dde0   size=152B   callers=4
 * module: 07_zlib
 * ============================================================ */

/* inflate_blocks_reset(inflate_blocks_state*, z_stream_s*, unsigned long*) */

void inflate_blocks_reset(inflate_blocks_state *param_1,z_stream_s *param_2,ulong *param_3)

{
  undefined4 uVar1;
  int iVar2;
  
  if (param_3 != (ulong *)0x0) {
    *param_3 = *(ulong *)(param_1 + 0x3c);
  }
  iVar2 = *(int *)param_1;
  if (iVar2 - 4U < 2) {
    (**(code **)(param_2 + 0x24))(*(undefined4 *)(param_2 + 0x28),*(undefined4 *)(param_1 + 0xc));
    iVar2 = *(int *)param_1;
  }
  if (iVar2 == 6) {
    inflate_codes_free(*(inflate_codes_state **)(param_1 + 4),param_2);
  }
  *(undefined4 *)param_1 = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x34) = *(undefined4 *)(param_1 + 0x28);
  *(undefined4 *)(param_1 + 0x30) = *(undefined4 *)(param_1 + 0x28);
  *(undefined4 *)(param_1 + 0x20) = 0;
  if (*(code **)(param_1 + 0x38) != (code *)0x0) {
    uVar1 = (**(code **)(param_1 + 0x38))(0,0);
    *(undefined4 *)(param_1 + 0x3c) = uVar1;
    *(undefined4 *)(param_2 + 0x30) = uVar1;
    return;
  }
  return;
}
