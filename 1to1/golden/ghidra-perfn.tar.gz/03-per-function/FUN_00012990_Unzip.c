/* ============================================================
 * Unzip   @ 0x00012990   size=28B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* TUnzip::Unzip(int, void*, unsigned int, unsigned int) */

undefined4 __thiscall
TUnzip::Unzip(TUnzip *this,int param_1,void *param_2,uint param_3,uint param_4)

{
  undefined4 uVar1;
  
  if (2 < param_4 - 1) {
    return 0x10000;
  }
  uVar1 = Unzip((int)this,(void *)param_1,(uint)param_2,param_4);
  return uVar1;
}
