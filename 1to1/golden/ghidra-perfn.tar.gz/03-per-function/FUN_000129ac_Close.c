/* ============================================================
 * Close   @ 0x000129ac   size=68B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* TUnzip::Close() */

undefined4 __thiscall TUnzip::Close(TUnzip *this)

{
  if (*(int *)(this + 4) != -1) {
    unzCloseCurrentFile(*(unz_s **)this);
  }
  *(undefined4 *)(this + 4) = 0xffffffff;
  if (*(unz_s **)this != (unz_s *)0x0) {
    unzClose(*(unz_s **)this);
    *(undefined4 *)this = 0;
  }
  return 0;
}
