/* ============================================================
 * mxml_add_char   @ 0x002bf648   size=416B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxml_add_char(uint param_1,int *param_2,int *param_3,size_t *param_4)

{
  byte bVar1;
  byte *pbVar2;
  byte *pbVar3;
  void *pvVar4;
  size_t sVar5;
  
  sVar5 = *param_4;
  pvVar4 = (void *)*param_3;
  pbVar2 = (byte *)*param_2;
  if ((byte *)((int)pvVar4 + (sVar5 - 4)) <= pbVar2) {
    if ((int)sVar5 < 0x400) {
      sVar5 = sVar5 << 1;
    }
    else {
      sVar5 = sVar5 + 0x400;
    }
    *param_4 = sVar5;
    pvVar4 = realloc(pvVar4,sVar5);
    if (pvVar4 == (void *)0x0) {
      free((void *)*param_3);
      mxml_error("Unable to expand string buffer to %d bytes!",*param_4);
      return 0xffffffff;
    }
    *param_2 = (int)pvVar4 + (*param_2 - *param_3);
    *param_3 = (int)pvVar4;
    pbVar2 = (byte *)*param_2;
  }
  bVar1 = (byte)param_1;
  if ((int)param_1 < 0x80) {
    *param_2 = (int)(pbVar2 + 1);
    *pbVar2 = bVar1;
    return 0;
  }
  pbVar3 = pbVar2 + 1;
  if ((int)param_1 < 0x800) {
    *param_2 = (int)pbVar3;
    *pbVar2 = (byte)((int)param_1 >> 6) | 0xc0;
    pbVar2 = (byte *)*param_2;
    *param_2 = (int)(pbVar2 + 1);
    *pbVar2 = ~((byte)~(byte)(((param_1 & 0x3f) << 0x19) >> 0x18) >> 1);
    return 0;
  }
  if ((int)param_1 < 0x10000) {
    *param_2 = (int)pbVar3;
    *pbVar2 = (byte)((int)param_1 >> 0xc) | 0xe0;
    pbVar2 = (byte *)*param_2;
    *param_2 = (int)(pbVar2 + 1);
    *pbVar2 = (byte)((param_1 << 0x14) >> 0x1a) | 0x80;
    pbVar2 = (byte *)*param_2;
    *param_2 = (int)(pbVar2 + 1);
    *pbVar2 = bVar1 & 0x3f | 0x80;
    return 0;
  }
  *param_2 = (int)pbVar3;
  *pbVar2 = (byte)((int)param_1 >> 0x12) | 0xf0;
  pbVar2 = (byte *)*param_2;
  *param_2 = (int)(pbVar2 + 1);
  *pbVar2 = (byte)((param_1 << 0xe) >> 0x1a) | 0x80;
  pbVar2 = (byte *)*param_2;
  *param_2 = (int)(pbVar2 + 1);
  *pbVar2 = (byte)((param_1 << 0x14) >> 0x1a) | 0x80;
  pbVar2 = (byte *)*param_2;
  *param_2 = (int)(pbVar2 + 1);
  *pbVar2 = bVar1 & 0x3f | 0x80;
  return 0;
}
