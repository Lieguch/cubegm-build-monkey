/* ============================================================
 * stbtt_MakeGlyphBitmap   @ 0x0001bb1c   size=12B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_MakeGlyphBitmap(undefined4 param_1,undefined4 param_2)

{
  stbtt_MakeGlyphBitmapSubpixel(param_1,param_2,0);
  return;
}
