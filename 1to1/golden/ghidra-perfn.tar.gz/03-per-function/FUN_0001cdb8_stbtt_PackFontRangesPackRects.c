/* ============================================================
 * stbtt_PackFontRangesPackRects   @ 0x0001cdb8   size=196B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_PackFontRangesPackRects(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int *piVar8;
  int iVar9;
  
  piVar8 = *(int **)(param_1 + 4);
  if (param_3 < 1) {
    return;
  }
  iVar2 = 0;
  iVar3 = piVar8[2];
  iVar6 = *piVar8;
  iVar5 = piVar8[1];
  piVar1 = param_2;
  do {
    iVar4 = piVar1[3];
    if (iVar6 < iVar4 + iVar3) {
      piVar8[2] = 0;
      iVar3 = piVar8[4];
      piVar8[3] = iVar3;
    }
    else {
      iVar3 = piVar8[3];
    }
    iVar9 = iVar3 + piVar1[4];
    if (iVar5 < iVar9) {
      if (param_3 <= iVar2) {
        return;
      }
      piVar8 = param_2 + iVar2 * 6;
      do {
        piVar8[5] = 0;
        piVar8 = piVar8 + 6;
      } while (piVar8 != param_2 + param_3 * 6);
      return;
    }
    iVar7 = piVar8[2];
    iVar2 = iVar2 + 1;
    piVar1[1] = iVar3;
    piVar1[5] = 1;
    iVar3 = iVar4 + iVar7;
    *piVar1 = iVar7;
    piVar8[2] = iVar3;
    if (piVar8[4] < iVar9) {
      piVar8[4] = iVar9;
    }
    piVar1 = piVar1 + 6;
  } while (param_3 != iVar2);
  return;
}
