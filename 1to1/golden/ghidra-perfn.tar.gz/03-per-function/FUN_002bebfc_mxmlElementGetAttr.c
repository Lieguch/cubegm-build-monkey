/* ============================================================
 * mxmlElementGetAttr   @ 0x002bebfc   size=116B   callers=8
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlElementGetAttr(int *param_1,char *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  
  if (param_1 == (int *)0x0) {
    return 0;
  }
  if (*param_1 == 0 && param_2 != (char *)0x0) {
    iVar2 = param_1[7];
    puVar3 = (undefined4 *)param_1[8];
    if (0 < iVar2) {
      do {
        iVar1 = strcmp((char *)*puVar3,param_2);
        if (iVar1 == 0) {
          return puVar3[1];
        }
        iVar2 = iVar2 + -1;
        puVar3 = puVar3 + 2;
      } while (iVar2 != 0);
    }
  }
  return 0;
}
