/* ============================================================
 * stbtt__CompareUTF8toUTF16_bigendian_prefix   @ 0x00013f64   size=436B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

int stbtt__CompareUTF8toUTF16_bigendian_prefix(int param_1,int param_2,byte *param_3,int param_4)

{
  byte *pbVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  if (param_4 == 0) {
    return 0;
  }
  iVar2 = 0;
  do {
    uVar4 = (uint)param_3[1] + (uint)*param_3 * 0x100;
    if (uVar4 < 0x80) {
      if (param_2 <= iVar2) {
        return -1;
      }
      pbVar1 = (byte *)(param_1 + iVar2);
      iVar2 = iVar2 + 1;
      if (*pbVar1 != uVar4) {
        return -1;
      }
LAB_00013f94:
      param_4 = param_4 + -2;
      param_3 = param_3 + 2;
    }
    else {
      if (uVar4 < 0x800) {
        iVar3 = iVar2 + 1;
        if (param_2 <= iVar3) {
          return -1;
        }
        if ((uint)*(byte *)(param_1 + iVar2) != (uVar4 >> 6) + 0xc0) {
          return -1;
        }
        iVar2 = iVar2 + 2;
        if ((uint)*(byte *)(param_1 + iVar3) != (uVar4 & 0x3f) + 0x80) {
          return -1;
        }
        goto LAB_00013f94;
      }
      if (0x3ff < (uVar4 + 0x2800 & 0xffff)) {
        if ((uVar4 + 0x2400 & 0xffff) < 0x400) {
          return -1;
        }
        iVar3 = iVar2 + 2;
        if (param_2 <= iVar3) {
          return -1;
        }
        if ((uint)*(byte *)(param_1 + iVar2) != (uVar4 >> 0xc) + 0xe0) {
          return -1;
        }
        if ((uint)*(byte *)(param_1 + iVar2 + 1) != ((uVar4 & 0xfff) >> 6) + 0x80) {
          return -1;
        }
        iVar2 = iVar2 + 3;
        if ((uint)*(byte *)(param_1 + iVar3) != (uVar4 & 0x3f) + 0x80) {
          return -1;
        }
        goto LAB_00013f94;
      }
      iVar3 = iVar2 + 3;
      if (param_2 <= iVar3) {
        return -1;
      }
      uVar4 = (uint)param_3[3] + (uint)param_3[2] * 0x100 + uVar4 * 0x400 + 0xfca02400;
      if ((uint)*(byte *)(param_1 + iVar2) != (uVar4 >> 0x12) + 0xf0) {
        return -1;
      }
      if ((uint)*(byte *)(param_1 + iVar2 + 1) != ((uVar4 & 0x3ffff) >> 0xc) + 0x80) {
        return -1;
      }
      if ((uint)*(byte *)(param_1 + iVar2 + 2) != ((uVar4 & 0xfff) >> 6) + 0x80) {
        return -1;
      }
      iVar2 = iVar2 + 4;
      if ((uint)*(byte *)(param_1 + iVar3) != (uVar4 & 0x3f) + 0x80) {
        return -1;
      }
      param_4 = param_4 + -4;
      param_3 = param_3 + 4;
    }
    if (param_4 == 0) {
      return iVar2;
    }
  } while( true );
}
