/* ============================================================
 * utf8_wctomb   @ 0x002c46d0   size=254B   callers=0
 * module: 08_iconv_encoding
 * ============================================================ */

uint utf8_wctomb(undefined4 param_1,undefined1 *param_2,undefined *param_3,uint param_4)

{
  undefined *local_1c;
  uint local_c;
  
  if (param_3 < (undefined *)0x80) {
    local_c = 1;
  }
  else if (param_3 < (undefined *)0x800) {
    local_c = 2;
  }
  else if (param_3 < (undefined *)0x10000) {
    if (((undefined *)0xd7ff < param_3) && (param_3 < (undefined *)0xe000)) {
      return 0xffffffff;
    }
    local_c = 3;
  }
  else {
    if (&UNK_0010ffff < param_3) {
      return 0xffffffff;
    }
    local_c = 4;
  }
  if (param_4 < local_c) {
    local_c = 0xfffffffe;
  }
  else {
    local_1c = param_3;
    switch(local_c) {
    case 4:
      param_2[3] = (byte)param_3 & 0x3f | 0x80;
      local_1c = (undefined *)((uint)param_3 >> 6 | 0x10000);
    case 3:
      param_2[2] = (byte)local_1c & 0x3f | 0x80;
      local_1c = (undefined *)((uint)local_1c >> 6 | 0x800);
    case 2:
      param_2[1] = (byte)local_1c & 0x3f | 0x80;
      local_1c = (undefined *)((uint)local_1c >> 6 | 0xc0);
    case 1:
      *param_2 = (char)local_1c;
    }
  }
  return local_c;
}
