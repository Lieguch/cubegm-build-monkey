/* ============================================================
 * _init   @ 0x000095fc   size=12B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

int _init(EVP_PKEY_CTX *ctx)

{
  int iVar1;
  
  iVar1 = call_weak_fn();
  return iVar1;
}
