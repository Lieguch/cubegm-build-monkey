/* ============================================================
 * stbtt_MakeCodepointBitmap   @ 0x0001c42c   size=12B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_MakeCodepointBitmap(undefined4 param_1,undefined4 param_2)

{
  stbtt_MakeCodepointBitmapSubpixel(param_1,param_2,0);
  return;
}
