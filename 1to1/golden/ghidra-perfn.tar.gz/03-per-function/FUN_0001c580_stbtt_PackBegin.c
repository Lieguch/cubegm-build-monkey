/* ============================================================
 * stbtt_PackBegin   @ 0x0001c580   size=244B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

undefined4
stbtt_PackBegin(undefined4 *param_1,void *param_2,int param_3,int param_4,int param_5,int param_6,
               undefined4 param_7)

{
  size_t *__ptr;
  void *__ptr_00;
  
  __ptr = malloc(0x14);
  __ptr_00 = malloc(param_3 - param_6);
  if (__ptr_00 != (void *)0x0 && __ptr != (size_t *)0x0) {
    param_1[2] = param_3;
    if (param_5 == 0) {
      param_5 = param_3;
    }
    param_1[4] = param_5;
    *param_1 = param_7;
    param_1[3] = param_4;
    param_1[9] = param_2;
    param_1[1] = __ptr;
    param_1[10] = __ptr_00;
    param_1[5] = param_6;
    __ptr[1] = param_4 - param_6;
    param_1[6] = 0;
    *__ptr = param_3 - param_6;
    __ptr[2] = 0;
    __ptr[3] = 0;
    __ptr[4] = 0;
    param_1[7] = 1;
    param_1[8] = 1;
    if (param_2 == (void *)0x0) {
      return 1;
    }
    memset(param_2,0,param_4 * param_3);
    return 1;
  }
  if (__ptr != (size_t *)0x0) {
    free(__ptr);
  }
  if (__ptr_00 == (void *)0x0) {
    return 0;
  }
  free(__ptr_00);
  return 0;
}
