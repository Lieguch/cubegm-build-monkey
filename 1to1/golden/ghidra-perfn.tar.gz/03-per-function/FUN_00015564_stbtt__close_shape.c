/* ============================================================
 * stbtt__close_shape   @ 0x00015564   size=268B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

int stbtt__close_shape(int param_1,int param_2,int param_3,int param_4,undefined2 param_5,
                      undefined2 param_6,int param_7,int param_8,int param_9,int param_10)

{
  int iVar1;
  int iVar2;
  
  if (param_4 != 0) {
    if (param_3 != 0) {
      iVar1 = param_2 * 0xe;
      param_2 = param_2 + 1;
      iVar2 = param_1 + iVar1;
      *(undefined1 *)(iVar2 + 0xc) = 3;
      *(short *)(param_1 + iVar1) = (short)(param_9 + param_7 >> 1);
      *(short *)(iVar2 + 2) = (short)(param_10 + param_8 >> 1);
      *(undefined2 *)(iVar2 + 4) = (undefined2)param_9;
      *(undefined2 *)(iVar2 + 6) = (undefined2)param_10;
    }
    iVar1 = param_1 + param_2 * 0xe;
    *(undefined1 *)(iVar1 + 0xc) = 3;
    *(undefined2 *)(param_1 + param_2 * 0xe) = param_5;
    *(undefined2 *)(iVar1 + 2) = param_6;
    *(undefined2 *)(iVar1 + 4) = (undefined2)param_7;
    *(undefined2 *)(iVar1 + 6) = (undefined2)param_8;
    return param_2 + 1;
  }
  if (param_3 == 0) {
    iVar1 = param_1 + param_2 * 0xe;
    *(undefined1 *)(iVar1 + 0xc) = 2;
    *(undefined2 *)(param_1 + param_2 * 0xe) = param_5;
    *(undefined2 *)(iVar1 + 2) = param_6;
    *(undefined2 *)(iVar1 + 4) = 0;
    *(undefined2 *)(iVar1 + 6) = 0;
    return param_2 + 1;
  }
  iVar1 = param_1 + param_2 * 0xe;
  *(undefined1 *)(iVar1 + 0xc) = 3;
  *(undefined2 *)(param_1 + param_2 * 0xe) = param_5;
  *(undefined2 *)(iVar1 + 2) = param_6;
  *(undefined2 *)(iVar1 + 4) = (undefined2)param_9;
  *(undefined2 *)(iVar1 + 6) = (undefined2)param_10;
  return param_2 + 1;
}
