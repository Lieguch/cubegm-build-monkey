/* ============================================================
 * zlibVersion   @ 0x000102d8   size=12B   callers=0
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */
/* zlibVersion() */

char * zlibVersion(void)

{
  return "1.1.3";
}
