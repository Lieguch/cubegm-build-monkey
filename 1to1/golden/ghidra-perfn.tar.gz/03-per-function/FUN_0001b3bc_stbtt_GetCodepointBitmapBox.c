/* ============================================================
 * stbtt_GetCodepointBitmapBox   @ 0x0001b3bc   size=12B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_GetCodepointBitmapBox(undefined4 param_1,undefined4 param_2)

{
  stbtt_GetCodepointBitmapBoxSubpixel(param_1,param_2,0);
  return;
}
