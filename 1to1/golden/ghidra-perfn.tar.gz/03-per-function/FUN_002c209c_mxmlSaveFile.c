/* ============================================================
 * mxmlSaveFile   @ 0x002c209c   size=104B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

int mxmlSaveFile(undefined4 param_1,_IO_FILE *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  
  uVar1 = _mxml_global();
  iVar2 = mxml_write_node(param_1,param_2,param_3,0,mxml_file_putc,uVar1);
  if (iVar2 < 0) {
    iVar3 = -1;
  }
  else {
    iVar3 = 0;
    if (iVar2 != 0) {
      iVar3 = _IO_putc(10,param_2);
      iVar3 = iVar3 >> 0x1f;
    }
  }
  return iVar3;
}
