/* ============================================================
 * mxmlElementSetAttrf   @ 0x002becd8   size=156B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

void mxmlElementSetAttrf(int *param_1,int param_2,int param_3)

{
  void *__ptr;
  int iVar1;
  
  if (param_1 == (int *)0x0) {
    return;
  }
  if ((*param_1 == 0) && (param_3 != 0 && param_2 != 0)) {
    __ptr = (void *)_mxml_vstrdupf(param_3);
    if (__ptr == (void *)0x0) {
      mxml_error("Unable to allocate memory for attribute \'%s\' in element %s!",param_2,param_1[6])
      ;
    }
    else {
      iVar1 = mxml_set_attr(param_1,param_2,__ptr);
      if (iVar1 != 0) {
        free(__ptr);
      }
    }
  }
  return;
}
