/* ============================================================
 * __SetTruboSoundEnd   @ 0x002b4d5c   size=4B   callers=0
 * module: 99_crt_glibc
 * ============================================================ */

undefined4 __SetTruboSoundEnd(undefined4 param_1)

{
  return param_1;
}
