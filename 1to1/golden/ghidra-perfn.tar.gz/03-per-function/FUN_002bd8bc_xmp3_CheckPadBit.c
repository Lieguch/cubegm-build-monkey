/* ============================================================
 * xmp3_CheckPadBit   @ 0x002bd8bc   size=44B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

uint xmp3_CheckPadBit(int *param_1)

{
  if ((param_1 != (int *)0x0) && (*param_1 != 0)) {
    return (uint)(*(int *)(*param_1 + 0x14) != 0);
  }
  return 0xffffffff;
}
