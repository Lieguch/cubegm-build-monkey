/* ============================================================
 * stbtt__run_charstring   @ 0x00015670   size=3024B   callers=3
 * module: 05_stb_truetype_font
 * ============================================================ */

/* WARNING: Restarted to delay deadcode elimination for space: stack */

undefined4 stbtt__run_charstring(int param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  uint uVar2;
  bool bVar3;
  int iVar4;
  short sVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  byte *pbVar9;
  uint uVar10;
  int iVar11;
  int iVar12;
  uint uVar13;
  uint uVar14;
  int iVar15;
  float *pfVar16;
  int iVar17;
  uint uVar18;
  bool bVar19;
  uint uVar20;
  int iVar21;
  uint uVar22;
  int iVar23;
  int iVar24;
  uint uVar25;
  char *pcVar26;
  bool bVar27;
  uint in_fpscr;
  undefined4 extraout_s6;
  undefined4 uVar28;
  undefined4 extraout_s6_00;
  undefined4 extraout_s6_01;
  undefined4 extraout_s6_02;
  undefined4 extraout_s6_03;
  undefined4 extraout_s6_04;
  undefined4 extraout_s6_05;
  undefined4 extraout_s6_06;
  undefined4 extraout_s6_07;
  undefined4 extraout_s6_08;
  undefined4 extraout_s6_09;
  undefined4 extraout_s6_10;
  undefined4 extraout_s6_11;
  undefined4 extraout_s6_12;
  undefined4 extraout_s6_13;
  undefined4 extraout_s6_14;
  undefined4 extraout_s6_15;
  undefined4 extraout_s6_16;
  undefined4 extraout_s6_17;
  undefined4 extraout_s6_18;
  undefined4 extraout_s6_19;
  undefined4 extraout_s6_20;
  undefined4 extraout_s6_21;
  undefined4 extraout_s7;
  undefined4 uVar29;
  undefined4 extraout_s7_00;
  undefined4 extraout_s7_01;
  undefined4 extraout_s7_02;
  undefined4 extraout_s7_03;
  undefined4 extraout_s7_04;
  undefined4 extraout_s7_05;
  undefined4 extraout_s7_06;
  undefined4 extraout_s7_07;
  undefined4 extraout_s7_08;
  undefined4 extraout_s7_09;
  undefined4 extraout_s7_10;
  undefined4 extraout_s7_11;
  undefined4 extraout_s7_12;
  undefined4 extraout_s7_13;
  undefined4 extraout_s7_14;
  undefined4 extraout_s7_15;
  undefined4 extraout_s7_16;
  undefined4 extraout_s7_17;
  undefined4 extraout_s7_18;
  undefined4 extraout_s7_19;
  undefined4 extraout_s7_20;
  undefined4 extraout_s7_21;
  undefined4 extraout_s8;
  undefined4 extraout_s8_00;
  undefined4 extraout_s8_01;
  undefined4 extraout_s8_02;
  undefined4 extraout_s9;
  float extraout_s9_00;
  undefined4 extraout_s9_01;
  undefined4 extraout_s9_02;
  undefined4 extraout_s10;
  float extraout_s10_00;
  undefined4 extraout_s10_01;
  undefined4 extraout_s10_02;
  float fVar30;
  float extraout_s11;
  float extraout_s11_00;
  float extraout_s11_01;
  float extraout_s11_02;
  float extraout_s11_03;
  float extraout_s11_04;
  float extraout_s11_05;
  float extraout_s11_06;
  float extraout_s11_07;
  float extraout_s11_08;
  float extraout_s11_09;
  float extraout_s11_10;
  float extraout_s11_11;
  float extraout_s11_12;
  float extraout_s11_13;
  float extraout_s11_14;
  float extraout_s11_15;
  float extraout_s11_16;
  float extraout_s11_17;
  float fVar31;
  float extraout_s12;
  float extraout_s12_00;
  float extraout_s12_01;
  float extraout_s12_02;
  float extraout_s12_03;
  float extraout_s12_04;
  float extraout_s12_05;
  float extraout_s12_06;
  float extraout_s12_07;
  float extraout_s12_08;
  float extraout_s12_09;
  float extraout_s12_10;
  float extraout_s12_11;
  float extraout_s12_12;
  float extraout_s12_13;
  float extraout_s12_14;
  undefined4 extraout_s12_15;
  float extraout_s12_16;
  float extraout_s12_17;
  undefined4 extraout_s12_18;
  float extraout_s12_19;
  undefined4 extraout_s13;
  float extraout_s13_00;
  undefined4 extraout_s13_01;
  float extraout_s13_02;
  float fVar32;
  int local_1b8;
  int local_1b0;
  byte *local_1ac;
  uint local_1a0;
  uint uStack_19c;
  uint uStack_198;
  byte *local_190 [2];
  int local_188;
  uint local_184;
  uint local_180;
  uint local_17c;
  undefined4 local_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  uint local_16c [2];
  uint local_164;
  uint local_160 [28];
  float afStack_f0 [51];
  
  local_1ac = *(byte **)(param_1 + 0x58);
  bVar19 = false;
  local_1b0 = *(int *)(param_1 + 0x60);
  iVar17 = 0;
  stbtt__cff_index_get_isra_2
            (&local_1a0,*(undefined4 *)(param_1 + 0x40),*(undefined4 *)(param_1 + 0x48),param_2);
  fVar30 = 1.5258789e-05;
  local_1b8 = 0;
  bVar3 = true;
  fVar31 = 0.0;
  local_184 = local_1a0;
  local_17c = uStack_198;
  uVar14 = 0;
  uVar28 = extraout_s6;
  uVar29 = extraout_s7;
LAB_000156e8:
  uVar13 = uVar14;
  if ((int)uStack_198 <= (int)uStack_19c) {
switchD_00015d78_default:
    return 0;
  }
LAB_000156f0:
  uVar8 = uStack_19c + 1;
  local_180 = uVar8;
  uVar14 = (uint)*(byte *)(local_184 + uStack_19c);
  if (0x1e < uVar14 - 1) goto LAB_00015e38;
  switch(uVar14) {
  case 1:
    break;
  case 2:
    goto LAB_00015e38;
  case 3:
    break;
  case 4:
    if (uVar13 == 0) {
      return 0;
    }
    uVar14 = 0;
    bVar3 = false;
    stbtt__csctx_rmove_to(fVar31,afStack_f0[uVar13 + 1],param_3);
    uStack_198 = local_17c;
    uStack_19c = local_180;
    uVar28 = extraout_s6_12;
    uVar29 = extraout_s7_12;
    fVar30 = extraout_s11_11;
    fVar31 = extraout_s12_11;
    goto LAB_000156e8;
  case 5:
    if ((int)uVar13 < 2) {
      return 0;
    }
    pfVar16 = afStack_f0;
    iVar24 = 0;
    do {
      pfVar16 = pfVar16 + 2;
      iVar24 = iVar24 + 2;
      stbtt__csctx_rline_to(*pfVar16,pfVar16[1],param_3);
      uVar28 = extraout_s6_11;
      uVar29 = extraout_s7_11;
      fVar30 = extraout_s11_10;
      fVar31 = extraout_s12_10;
    } while (iVar24 != (uVar13 - 2 & 0xfffffffe) + 2);
    goto LAB_00015964;
  case 6:
    if (uVar13 == 0) {
      return 0;
    }
    iVar24 = 1;
    iVar11 = 0;
    goto LAB_00015c90;
  case 7:
    if (uVar13 == 0) {
      return 0;
    }
    iVar11 = 1;
    iVar24 = 0;
    goto LAB_00015c58;
  case 8:
    if ((int)uVar13 < 6) {
      return 0;
    }
    iVar24 = 5;
    pfVar16 = afStack_f0 + 2;
    do {
      iVar24 = iVar24 + 6;
      stbtt__csctx_rccurve_to
                (*pfVar16,pfVar16[1],pfVar16[2],pfVar16[3],pfVar16[4],pfVar16[5],param_3);
      pfVar16 = pfVar16 + 6;
      uVar28 = extraout_s6_08;
      uVar29 = extraout_s7_08;
      fVar30 = extraout_s11_07;
      fVar31 = extraout_s12_07;
    } while (iVar24 < (int)uVar13);
    goto LAB_00015964;
  case 9:
    goto LAB_00015e38;
  case 10:
    if (!bVar19) {
      iVar24 = *(int *)(param_1 + 0x78);
      if (iVar24 == 0) {
        bVar19 = true;
      }
      else {
        pcVar26 = *(char **)(param_1 + 0x70);
        iVar11 = iVar24;
        if (iVar24 < 0) {
LAB_00016124:
          iVar11 = param_2 + iVar11;
          if (iVar11 < iVar24 && -1 < iVar11) {
            uVar8 = (uint)(byte)pcVar26[iVar11];
          }
          else {
            uVar8 = 0;
          }
        }
        else {
          if (*pcVar26 == '\0') {
            iVar11 = 1;
            goto LAB_00016124;
          }
          if ((*pcVar26 == '\x03') && (iVar24 != 1)) {
            uVar6 = 3;
            if (iVar24 == 2) {
              uVar6 = 2;
            }
            uVar22 = (uint)(byte)pcVar26[1] << 8;
            uVar20 = 0;
            if (iVar24 != 2) {
              cVar1 = pcVar26[2];
              uVar22 = (uint)CONCAT11(pcVar26[1],cVar1);
              if (3 < iVar24) {
                if (iVar24 < 5) {
                  uVar6 = 4;
                }
                else {
                  cVar1 = pcVar26[4];
                }
                uVar20 = (uint)(byte)pcVar26[3] << 8;
                if (4 < iVar24) {
                  uVar6 = 5;
                  uVar20 = (uint)CONCAT11(pcVar26[3],cVar1);
                }
              }
            }
            if (uVar22 == 0) goto LAB_000157c4;
            uVar25 = 0;
            do {
              uVar18 = uVar6 + 1;
              uVar10 = uVar6 + 2;
              uVar8 = 0;
              if ((int)uVar6 < iVar24) {
                uVar8 = (uint)(byte)pcVar26[uVar6];
                uVar7 = uVar6 + 3;
                uVar6 = uVar18;
                if (iVar24 <= (int)uVar18) goto LAB_00016210;
                uVar6 = uVar10;
                uVar2 = uVar10;
                if ((int)uVar10 < iVar24) {
                  uVar6 = uVar7;
                  uVar2 = (uint)(byte)pcVar26[uVar10];
                }
                uVar18 = (uint)(byte)pcVar26[uVar18] << 8;
                if ((int)uVar10 < iVar24) {
                  uVar18 = uVar2 | uVar18;
                }
              }
              else {
LAB_00016210:
                uVar18 = 0;
              }
              uVar25 = uVar25 + 1;
              if (param_2 < (int)uVar18 && (int)uVar20 <= param_2) goto LAB_000157c8;
              uVar20 = uVar18;
            } while (uVar22 != uVar25);
            uVar8 = 0xffffffff;
          }
          else {
LAB_000157c4:
            uVar8 = 0xffffffff;
          }
        }
LAB_000157c8:
        bVar19 = true;
        stbtt__cff_index_get_isra_2
                  (&local_178,*(undefined4 *)(param_1 + 100),*(undefined4 *)(param_1 + 0x6c),uVar8);
        stbtt__get_subrs(local_190,*(undefined4 *)(param_1 + 0x34),*(undefined4 *)(param_1 + 0x38),
                         *(undefined4 *)(param_1 + 0x3c),local_178,uStack_174,uStack_170);
        local_1ac = local_190[0];
        local_1b0 = local_188;
      }
    }
    goto LAB_00015808;
  case 0xb:
    if (iVar17 == 0) {
      return 0;
    }
    iVar17 = iVar17 + -1;
    local_184 = local_160[iVar17 * 3];
    uStack_19c = local_160[iVar17 * 3 + 1];
    uStack_198 = local_160[iVar17 * 3 + 2];
    uVar14 = uVar13;
    local_17c = uStack_198;
    goto LAB_000156e8;
  case 0xc:
    if ((int)uStack_198 <= (int)uVar8) {
      return 0;
    }
    local_180 = uStack_19c + 2;
    switch(*(undefined1 *)(local_184 + uVar8)) {
    case 0x22:
      if ((int)uVar13 < 7) {
        return 0;
      }
      uVar14 = 0;
      stbtt__csctx_rccurve_to
                (afStack_f0[2],0,afStack_f0[3],afStack_f0[4],afStack_f0[5],fVar31,uVar28,uVar29,
                 afStack_f0[8],afStack_f0[7],afStack_f0[6],param_3);
      stbtt__csctx_rccurve_to
                (extraout_s10_02,0,extraout_s9_02,-extraout_s13_02,extraout_s8_02,extraout_s12_18,
                 param_3);
      uStack_198 = local_17c;
      uStack_19c = local_180;
      uVar28 = extraout_s6_21;
      uVar29 = extraout_s7_21;
      fVar30 = extraout_s11_17;
      fVar31 = extraout_s12_19;
      break;
    case 0x23:
      if ((int)uVar13 < 0xd) {
        return 0;
      }
      uVar14 = 0;
      stbtt__csctx_rccurve_to
                (afStack_f0[2],afStack_f0[3],afStack_f0[4],afStack_f0[5],afStack_f0[6],afStack_f0[7]
                 ,afStack_f0[0xd],afStack_f0[0xc],afStack_f0[0xb],afStack_f0[10],afStack_f0[9],
                 param_3);
      stbtt__csctx_rccurve_to
                (extraout_s13_01,extraout_s10_01,extraout_s9_01,extraout_s8_01,extraout_s7_19,
                 extraout_s6_19,param_3);
      uStack_198 = local_17c;
      uStack_19c = local_180;
      uVar28 = extraout_s6_20;
      uVar29 = extraout_s7_20;
      fVar30 = extraout_s11_16;
      fVar31 = extraout_s12_17;
      break;
    case 0x24:
      if ((int)uVar13 < 9) {
        return 0;
      }
      uVar14 = 0;
      stbtt__csctx_rccurve_to
                (afStack_f0[2],afStack_f0[3],afStack_f0[4],afStack_f0[5],afStack_f0[6],fVar31,
                 afStack_f0[10],afStack_f0[8],afStack_f0[7],param_3);
      stbtt__csctx_rccurve_to
                (extraout_s8_00,extraout_s12_15,extraout_s7_17,extraout_s13_00,extraout_s6_17,
                 -(extraout_s9_00 + extraout_s10_00 + extraout_s13_00),param_3);
      uStack_198 = local_17c;
      uStack_19c = local_180;
      uVar28 = extraout_s6_18;
      uVar29 = extraout_s7_18;
      fVar30 = extraout_s11_15;
      fVar31 = extraout_s12_16;
      break;
    case 0x25:
      if ((int)uVar13 < 0xb) {
        return 0;
      }
      uVar14 = 0;
      in_fpscr = in_fpscr & 0xfffffff;
      stbtt__csctx_rccurve_to(param_3);
      stbtt__csctx_rccurve_to
                (extraout_s9,extraout_s8,extraout_s7_15,extraout_s6_15,extraout_s13,extraout_s10,
                 param_3);
      uStack_198 = local_17c;
      uStack_19c = local_180;
      uVar28 = extraout_s6_16;
      uVar29 = extraout_s7_16;
      fVar30 = extraout_s11_14;
      fVar31 = extraout_s12_14;
      break;
    default:
      goto switchD_00015d78_default;
    }
    goto LAB_000156e8;
  case 0xd:
    goto LAB_00015e38;
  case 0xe:
    stbtt__csctx_close_shape(param_3);
    return 1;
  case 0xf:
    goto LAB_00015e38;
  case 0x10:
    goto LAB_00015e38;
  case 0x11:
    goto LAB_00015e38;
  case 0x12:
    break;
  case 0x13:
    goto LAB_00015df8;
  case 0x14:
LAB_00015df8:
    iVar24 = 0;
    if (bVar3) {
      iVar24 = local_1b8 + ((int)uVar13 >> 1);
    }
    uVar14 = 0;
    if (bVar3) {
      local_1b8 = iVar24;
    }
    bVar3 = false;
    uStack_19c = uVar8 + (local_1b8 + 7 >> 3);
    if ((int)uStack_198 < (int)uStack_19c || (int)uStack_19c < 0) {
      uStack_19c = uStack_198;
    }
    goto LAB_000156e8;
  case 0x15:
    if ((int)uVar13 < 2) {
      return 0;
    }
    bVar3 = false;
    stbtt__csctx_rmove_to(afStack_f0[uVar13],afStack_f0[uVar13 + 1],param_3);
    uStack_198 = local_17c;
    uVar14 = 0;
    uStack_19c = local_180;
    uVar28 = extraout_s6_13;
    uVar29 = extraout_s7_13;
    fVar30 = extraout_s11_12;
    fVar31 = extraout_s12_12;
    goto LAB_000156e8;
  case 0x16:
    if (uVar13 == 0) {
      return 0;
    }
    bVar3 = false;
    stbtt__csctx_rmove_to(afStack_f0[uVar13 + 1],fVar31,param_3);
    uStack_198 = local_17c;
    uVar14 = 0;
    uStack_19c = local_180;
    uVar28 = extraout_s6_07;
    uVar29 = extraout_s7_07;
    fVar30 = extraout_s11_06;
    fVar31 = extraout_s12_06;
    goto LAB_000156e8;
  case 0x17:
    break;
  case 0x18:
    if ((int)uVar13 < 8) {
      return 0;
    }
    pfVar16 = afStack_f0 + 2;
    iVar24 = 0;
    do {
      iVar11 = iVar24;
      stbtt__csctx_rccurve_to
                (*pfVar16,pfVar16[1],pfVar16[2],pfVar16[3],pfVar16[4],pfVar16[5],param_3);
      pfVar16 = pfVar16 + 6;
      iVar24 = iVar11 + 6;
    } while (iVar11 + 0xb < (int)(uVar13 - 2));
    if ((int)uVar13 <= iVar11 + 7) {
      return 0;
    }
    stbtt__csctx_rline_to(afStack_f0[iVar11 + 8],afStack_f0[iVar11 + 9],param_3);
    uStack_198 = local_17c;
    uVar14 = 0;
    uStack_19c = local_180;
    uVar28 = extraout_s6_06;
    uVar29 = extraout_s7_06;
    fVar30 = extraout_s11_05;
    fVar31 = extraout_s12_05;
    goto LAB_000156e8;
  case 0x19:
    if ((int)uVar13 < 8) {
      return 0;
    }
    pfVar16 = afStack_f0;
    iVar24 = 0;
    do {
      pfVar16 = pfVar16 + 2;
      iVar24 = iVar24 + 2;
      stbtt__csctx_rline_to(*pfVar16,pfVar16[1],param_3);
    } while ((uVar13 - 8 & 0xfffffffe) + 2 != iVar24);
    uVar14 = uVar13 - 8 >> 1;
    iVar24 = uVar14 + 1;
    if ((int)uVar13 <= iVar24 * 2 + 5) {
      return 0;
    }
    stbtt__csctx_rccurve_to
              (afStack_f0[iVar24 * 2 + 2],afStack_f0[uVar14 * 2 + 5],afStack_f0[iVar24 * 2 + 4],
               afStack_f0[iVar24 * 2 + 5],afStack_f0[iVar24 * 2 + 6],afStack_f0[iVar24 * 2 + 7],
               param_3);
    uStack_198 = local_17c;
    uVar14 = 0;
    uStack_19c = local_180;
    uVar28 = extraout_s6_04;
    uVar29 = extraout_s7_04;
    fVar30 = extraout_s11_03;
    fVar31 = extraout_s12_03;
    goto LAB_000156e8;
  case 0x1a:
    goto LAB_00015974;
  case 0x1b:
    goto switchD_00015708_caseD_1b;
  case 0x1c:
    goto LAB_00015e38;
  case 0x1d:
LAB_00015808:
    if (uVar13 == 0) {
      return 0;
    }
    fVar30 = afStack_f0[uVar13 + 1];
    if (9 < iVar17) {
      return 0;
    }
    local_160[iVar17 * 3] = local_184;
    local_160[iVar17 * 3 + 1] = local_180;
    local_160[iVar17 * 3 + 2] = local_17c;
    pbVar9 = local_1ac;
    iVar24 = local_1b0;
    if (uVar14 != 10) {
      pbVar9 = *(byte **)(param_1 + 0x4c);
      iVar24 = *(int *)(param_1 + 0x54);
    }
    if (iVar24 < 1) {
      uVar14 = 0;
      iVar24 = 0x6b;
    }
    else {
      uVar8 = local_184;
      if (iVar24 != 1) {
        uVar8 = (uint)pbVar9[1];
      }
      uVar14 = (uint)*pbVar9 << 8;
      if (iVar24 != 1) {
        uVar14 = uVar14 | uVar8;
      }
      if (uVar14 < 0x846c) {
        if ((int)uVar14 < 0x4d8) {
          iVar24 = 0x6b;
        }
        else {
          iVar24 = 0x46b;
        }
      }
      else {
        iVar24 = 0x8000;
      }
    }
    uVar8 = (uint)((int)fVar30 + iVar24) >> 0x1f;
    if ((int)uVar14 <= (int)fVar30 + iVar24) {
      uVar8 = 1;
    }
    if (uVar8 != 0) {
      return 0;
    }
    stbtt__cff_index_get_isra_2(local_16c);
    local_17c = local_164;
    local_184 = local_16c[0];
    if (local_164 == 0) {
      return 0;
    }
    uStack_19c = 0;
    uStack_198 = local_164;
    uVar13 = uVar13 - 1;
    iVar17 = iVar17 + 1;
    uVar28 = extraout_s6_00;
    uVar29 = extraout_s7_00;
    fVar30 = extraout_s11;
    fVar31 = extraout_s12;
    if ((int)local_164 < 1) {
      return 0;
    }
    goto LAB_000156f0;
  case 0x1e:
    if ((int)uVar13 < 4) {
      return 0;
    }
    iVar21 = 7;
    iVar15 = 4;
    iVar11 = 2;
    iVar24 = 1;
    iVar12 = 3;
    iVar23 = 0;
    goto LAB_00015adc;
  case 0x1f:
    if ((int)uVar13 < 4) {
      return 0;
    }
    iVar23 = 4;
    iVar11 = 2;
    iVar24 = 1;
    iVar12 = 7;
    iVar21 = 3;
    iVar15 = 0;
    goto LAB_00015908;
  }
  local_1b8 = local_1b8 + ((int)uVar13 >> 1);
  uVar14 = 0;
  uStack_19c = uVar8;
  goto LAB_000156e8;
LAB_00015adc:
  bVar27 = uVar13 - iVar23 == 5;
  iVar4 = iVar12;
  if (bVar27) {
    iVar4 = iVar15;
  }
  fVar30 = fVar31;
  if (bVar27) {
    fVar30 = afStack_f0[iVar4 + 2];
  }
  stbtt__csctx_rccurve_to
            (fVar31,afStack_f0[iVar23 + 2],afStack_f0[iVar24 + 2],afStack_f0[iVar11 + 2],
             afStack_f0[iVar12 + 2],fVar30,param_3);
  uVar28 = extraout_s6_05;
  uVar29 = extraout_s7_05;
  fVar30 = extraout_s11_04;
  fVar31 = extraout_s12_04;
  if ((int)uVar13 <= iVar21) goto LAB_00015964;
  iVar12 = iVar15 + 7;
  iVar24 = iVar15 + 1;
  iVar11 = iVar15 + 2;
  iVar23 = iVar15 + 4;
  fVar31 = extraout_s12_04;
LAB_00015908:
  bVar27 = uVar13 - iVar15 == 5;
  iVar4 = iVar11;
  if (bVar27) {
    iVar4 = iVar23;
  }
  fVar30 = fVar31;
  if (bVar27) {
    fVar30 = afStack_f0[iVar4 + 2];
  }
  stbtt__csctx_rccurve_to
            (afStack_f0[iVar15 + 2],fVar31,afStack_f0[iVar24 + 2],afStack_f0[iVar11 + 2],fVar30,
             afStack_f0[iVar21 + 2],param_3);
  uVar28 = extraout_s6_01;
  uVar29 = extraout_s7_01;
  fVar30 = extraout_s11_00;
  fVar31 = extraout_s12_00;
  if ((int)uVar13 <= iVar12) goto LAB_00015964;
  iVar24 = iVar23 + 1;
  iVar11 = iVar23 + 2;
  iVar15 = iVar23 + 4;
  iVar21 = iVar23 + 7;
  fVar31 = extraout_s12_00;
  goto LAB_00015adc;
switchD_00015708_caseD_1b:
LAB_00015974:
  if ((int)uVar13 < 4) {
    return 0;
  }
  uVar6 = uVar13 & 1;
  if (uVar6 == 0) {
    iVar24 = 3;
    fVar32 = fVar31;
  }
  else {
    if (uVar13 == 4) {
      uVar14 = 0;
      uStack_19c = uVar8;
      goto LAB_000156e8;
    }
    iVar24 = 4;
    fVar32 = afStack_f0[2];
  }
  pfVar16 = afStack_f0 + uVar6 + 2;
  iVar11 = uVar6 + 7;
  do {
    if (uVar14 == 0x1b) {
      stbtt__csctx_rccurve_to
                (*pfVar16,fVar32,pfVar16[1],pfVar16[2],afStack_f0[iVar24 + 2],fVar31,param_3);
      uVar28 = extraout_s6_03;
      uVar29 = extraout_s7_03;
      fVar30 = extraout_s11_02;
      fVar32 = extraout_s12_02;
    }
    else {
      stbtt__csctx_rccurve_to
                (fVar32,*pfVar16,pfVar16[1],pfVar16[2],fVar31,afStack_f0[iVar24 + 2],param_3);
      uVar28 = extraout_s6_02;
      uVar29 = extraout_s7_02;
      fVar30 = extraout_s11_01;
      fVar32 = extraout_s12_01;
    }
    pfVar16 = pfVar16 + 4;
    bVar27 = iVar11 < (int)uVar13;
    iVar24 = iVar11;
    iVar11 = iVar11 + 4;
    fVar31 = fVar32;
  } while (bVar27);
  goto LAB_00015964;
LAB_00015c90:
  stbtt__csctx_rline_to(afStack_f0[iVar11 + 2],fVar31,param_3);
  uVar28 = extraout_s6_10;
  uVar29 = extraout_s7_10;
  fVar30 = extraout_s11_09;
  fVar31 = extraout_s12_09;
  if ((int)uVar13 <= iVar24) goto LAB_00015964;
  iVar11 = iVar24 + 1;
LAB_00015c58:
  stbtt__csctx_rline_to(fVar31,afStack_f0[iVar24 + 2],param_3);
  uVar28 = extraout_s6_09;
  uVar29 = extraout_s7_09;
  fVar30 = extraout_s11_08;
  fVar31 = extraout_s12_08;
  if ((int)uVar13 <= iVar11) goto LAB_00015964;
  iVar24 = iVar11 + 1;
  goto LAB_00015c90;
LAB_00015964:
  uStack_198 = local_17c;
  uVar14 = 0;
  uStack_19c = local_180;
  goto LAB_000156e8;
LAB_00015e38:
  if (uVar14 == 0xff || uVar14 == 0x1c) {
    uVar8 = 0;
    if (uVar14 == 0xff) {
      iVar24 = 4;
      do {
        uVar14 = 0;
        if ((int)local_180 < (int)uStack_198) {
          uVar14 = (uint)*(byte *)(local_184 + local_180);
          local_180 = local_180 + 1;
        }
        iVar24 = iVar24 + -1;
        uVar8 = uVar8 << 8 | uVar14;
      } while (iVar24 != 0);
      fVar32 = (float)VectorSignedToFloat(uVar8,(byte)(in_fpscr >> 0x16) & 3);
      fVar32 = fVar32 * fVar30;
      goto LAB_00015e78;
    }
  }
  else if (0xde < uVar14 - 0x20) {
    return 0;
  }
  local_180 = uStack_19c;
  if ((int)uStack_19c < 0) {
    local_180 = uStack_198;
  }
  sVar5 = stbtt__cff_int(&local_184);
  fVar32 = (float)VectorSignedToFloat((int)sVar5,(byte)(in_fpscr >> 0x16) & 3);
  uVar28 = extraout_s6_14;
  uVar29 = extraout_s7_14;
  fVar30 = extraout_s11_13;
  fVar31 = extraout_s12_13;
LAB_00015e78:
  if (0x2f < (int)uVar13) {
    return 0;
  }
  afStack_f0[uVar13 + 2] = fVar32;
  uStack_198 = local_17c;
  uVar14 = uVar13 + 1;
  uStack_19c = local_180;
  goto LAB_000156e8;
}
