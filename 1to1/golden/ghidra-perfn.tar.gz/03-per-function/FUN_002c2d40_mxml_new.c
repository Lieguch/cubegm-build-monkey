/* ============================================================
 * mxml_new   @ 0x002c2d40   size=76B   callers=8
 * module: 04_mini_xml
 * ============================================================ */

undefined4 * mxml_new(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  
  puVar1 = calloc(1,0x30);
  if (puVar1 != (undefined4 *)0x0) {
    *puVar1 = param_2;
    puVar1[10] = 1;
    if (param_1 != 0) {
      mxmlAdd(param_1,1,0,puVar1);
    }
  }
  return puVar1;
}
