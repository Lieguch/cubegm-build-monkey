/* ============================================================
 * stbtt__dict_get_ints   @ 0x000133f8   size=412B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt__dict_get_ints(int *param_1,uint param_2,int param_3,int param_4)

{
  byte bVar1;
  uint uVar2;
  undefined4 uVar3;
  int iVar4;
  byte *pbVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  int iVar9;
  int local_24;
  int local_20;
  uint local_1c;
  
  uVar2 = param_1[2];
  local_1c = uVar2 & (int)uVar2 >> 0x1f;
  param_1[1] = local_1c;
  uVar7 = local_1c;
  if ((int)uVar2 <= (int)local_1c) {
    return;
  }
LAB_00013428:
  do {
    iVar4 = *param_1;
    if (*(byte *)(iVar4 + local_1c) < 0x1c) {
      iVar9 = local_1c + 1;
      param_1[1] = iVar9;
      uVar6 = (uint)*(byte *)(iVar4 + local_1c);
      if (uVar6 == 0xc) {
        if (iVar9 < (int)uVar2) {
          param_1[1] = local_1c + 2;
          uVar6 = *(byte *)(iVar4 + iVar9) | 0x100;
        }
        else {
          uVar6 = 0x100;
        }
      }
    }
    else {
      if (*(byte *)(iVar4 + local_1c) == 0x1e) {
        local_1c = local_1c + 1;
        uVar6 = local_1c >> 0x1f;
        if ((int)uVar2 < (int)local_1c) {
          uVar6 = 1;
        }
        if (uVar6 != 0) {
          local_1c = uVar2;
        }
        param_1[1] = local_1c;
        pbVar5 = (byte *)(iVar4 + local_1c);
        while ((int)local_1c < (int)uVar2) {
          local_1c = local_1c + 1;
          param_1[1] = local_1c;
          bVar1 = *pbVar5;
          if (((bVar1 & 0xf) == 0xf) || (pbVar5 = pbVar5 + 1, (int)(uint)bVar1 >> 4 == 0xf)) break;
        }
      }
      else {
        stbtt__cff_int(param_1);
        local_1c = param_1[1];
      }
      uVar2 = param_1[2];
      if ((int)local_1c < (int)uVar2) goto LAB_00013428;
      uVar6 = 0;
    }
    if (param_2 == uVar6) {
      local_1c = local_1c - uVar7;
      uVar6 = (local_1c | uVar7) >> 0x1f;
      if ((int)uVar2 < (int)uVar7) {
        uVar6 = 1;
      }
      if (uVar6 != 0) {
        return;
      }
      if ((int)(uVar2 - uVar7) < (int)local_1c) {
        return;
      }
      local_24 = *param_1 + uVar7;
      if (param_3 < 1) {
        return;
      }
      if (local_1c == 0) {
        return;
      }
      puVar8 = (undefined4 *)(param_4 + -4);
      iVar4 = 0;
      local_20 = 0;
      do {
        iVar4 = iVar4 + 1;
        uVar3 = stbtt__cff_int(&local_24);
        puVar8 = puVar8 + 1;
        *puVar8 = uVar3;
        if (param_3 == iVar4) {
          return;
        }
      } while (local_20 < (int)local_1c);
      return;
    }
    local_1c = param_1[1];
    uVar2 = param_1[2];
    uVar7 = local_1c;
    if ((int)uVar2 <= (int)local_1c) {
      return;
    }
  } while( true );
}
