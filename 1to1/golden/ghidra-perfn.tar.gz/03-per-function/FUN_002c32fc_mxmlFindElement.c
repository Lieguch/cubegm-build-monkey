/* ============================================================
 * mxmlFindElement   @ 0x002c32fc   size=240B   callers=7
 * module: 04_mini_xml
 * ============================================================ */

int * mxmlFindElement(int param_1,int param_2,char *param_3,int param_4,char *param_5,int param_6)

{
  int *piVar1;
  int iVar2;
  char *__s2;
  
  if ((param_2 != 0 && param_1 != 0) && (param_5 == (char *)0x0 || param_4 != 0)) {
    for (piVar1 = (int *)mxmlWalkNext(param_1,param_2,param_6); piVar1 != (int *)0x0;
        piVar1 = (int *)piVar1[1]) {
      while( true ) {
        if (((*piVar1 == 0) && ((char *)piVar1[6] != (char *)0x0)) &&
           ((param_3 == (char *)0x0 || (iVar2 = strcmp((char *)piVar1[6],param_3), iVar2 == 0)))) {
          if (param_4 == 0) {
            return piVar1;
          }
          __s2 = (char *)mxmlElementGetAttr(piVar1,param_4);
          if (__s2 != (char *)0x0) {
            if (param_5 == (char *)0x0) {
              return piVar1;
            }
            iVar2 = strcmp(param_5,__s2);
            if (iVar2 == 0) {
              return piVar1;
            }
          }
        }
        if (param_6 != 1) break;
        piVar1 = (int *)mxmlWalkNext(piVar1,param_2,1);
        if (piVar1 == (int *)0x0) {
          return (int *)0x0;
        }
      }
    }
  }
  return (int *)0x0;
}
