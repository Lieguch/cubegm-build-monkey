/* ============================================================
 * inflate_trees_bits   @ 0x0000e53c   size=216B   callers=1
 * module: 07_zlib
 * ============================================================ */

/* inflate_trees_bits(unsigned int*, unsigned int*, inflate_huft_s**, inflate_huft_s*, z_stream_s*)
    */

int inflate_trees_bits(uint *param_1,uint *param_2,inflate_huft_s **param_3,inflate_huft_s *param_4,
                      z_stream_s *param_5)

{
  uint *puVar1;
  int iVar2;
  uint local_24;
  
  local_24 = 0;
  puVar1 = (uint *)(**(code **)(param_5 + 0x20))(*(undefined4 *)(param_5 + 0x28),0x13,4);
  if (puVar1 == (uint *)0x0) {
    iVar2 = -4;
  }
  else {
    iVar2 = huft_build(param_1,0x13,0x13,(uint *)0x0,(uint *)0x0,param_3,param_2,param_4,&local_24,
                       puVar1);
    if (iVar2 == -3) {
      *(char **)(param_5 + 0x18) = "oversubscribed dynamic bit lengths tree";
    }
    else if ((iVar2 == -5) || (*param_2 == 0)) {
      iVar2 = -3;
      *(char **)(param_5 + 0x18) = "incomplete dynamic bit lengths tree";
    }
    (**(code **)(param_5 + 0x24))(*(undefined4 *)(param_5 + 0x28),puVar1);
  }
  return iVar2;
}
