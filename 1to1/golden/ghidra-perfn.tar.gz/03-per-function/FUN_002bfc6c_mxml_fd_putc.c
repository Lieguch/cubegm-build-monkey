/* ============================================================
 * mxml_fd_putc   @ 0x002bfc6c   size=76B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxml_fd_putc(undefined1 param_1,int param_2)

{
  int iVar1;
  undefined1 *puVar2;
  
  puVar2 = *(undefined1 **)(param_2 + 4);
  if (*(undefined1 **)(param_2 + 8) <= puVar2) {
    iVar1 = mxml_fd_write(param_2);
    if (iVar1 < 0) {
      return 0xffffffff;
    }
    puVar2 = *(undefined1 **)(param_2 + 4);
  }
  *(undefined1 **)(param_2 + 4) = puVar2 + 1;
  *puVar2 = param_1;
  return 0;
}
