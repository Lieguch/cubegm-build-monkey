/* ============================================================
 * xmp3_MidSideProc   @ 0x002b9754   size=148B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

void xmp3_MidSideProc(int param_1,int param_2,uint *param_3)

{
  uint uVar1;
  uint *puVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint *puVar7;
  
  if (param_2 < 1) {
    uVar5 = 0;
    uVar6 = uVar5;
  }
  else {
    uVar5 = 0;
    puVar2 = (uint *)(param_1 + -4);
    puVar7 = (uint *)(param_1 + 0x8fc);
    uVar6 = 0;
    iVar4 = 0;
    do {
      uVar3 = puVar2[1] - puVar7[1];
      puVar2[1] = puVar2[1] + puVar7[1];
      puVar7 = puVar7 + 1;
      *puVar7 = uVar3;
      puVar2 = puVar2 + 1;
      uVar1 = (int)*puVar2 >> 0x1f;
      uVar6 = uVar6 | (*puVar2 ^ uVar1) - uVar1;
      iVar4 = iVar4 + 1;
      uVar5 = uVar5 | (uVar3 ^ (int)uVar3 >> 0x1f) - ((int)uVar3 >> 0x1f);
    } while (param_2 != iVar4);
  }
  *param_3 = *param_3 | uVar6;
  param_3[1] = param_3[1] | uVar5;
  return;
}
