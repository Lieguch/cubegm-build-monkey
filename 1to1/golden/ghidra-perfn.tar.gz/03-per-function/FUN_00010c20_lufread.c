/* ============================================================
 * lufread   @ 0x00010c20   size=160B   callers=7
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* lufread(void*, unsigned int, unsigned int, LUFILE*) */

void lufread(void *param_1,uint param_2,uint param_3,LUFILE *param_4)

{
  int iVar1;
  size_t sVar2;
  
  if (*param_4 != (LUFILE)0x0) {
    sVar2 = fread(param_1,param_2,param_3,*(FILE **)(param_4 + 4));
    if (sVar2 == 0) {
      param_4[8] = (LUFILE)0x1;
    }
    return;
  }
  sVar2 = param_3 * param_2;
  iVar1 = *(int *)(param_4 + 0x18);
  if (*(uint *)(param_4 + 0x14) < sVar2 + iVar1) {
    sVar2 = *(uint *)(param_4 + 0x14) - iVar1;
  }
  if (SPI_MODE == 0) {
    memcpy(param_1,(void *)(*(int *)(param_4 + 0x10) + iVar1),sVar2);
  }
  else {
    spi_memcpy();
  }
  *(size_t *)(param_4 + 0x18) = *(int *)(param_4 + 0x18) + sVar2;
  __aeabi_uidiv(sVar2,param_2);
  return;
}
