/* ============================================================
 * mxmlIndexEnum   @ 0x002c27f0   size=44B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlIndexEnum(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    if (iVar2 < *(int *)(param_1 + 4)) {
      *(int *)(param_1 + 0xc) = iVar2 + 1;
      uVar1 = *(undefined4 *)(*(int *)(param_1 + 0x10) + iVar2 * 4);
    }
    else {
      uVar1 = 0;
    }
    return uVar1;
  }
  return 0;
}
