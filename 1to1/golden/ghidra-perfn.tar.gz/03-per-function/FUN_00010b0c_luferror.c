/* ============================================================
 * luferror   @ 0x00010b0c   size=36B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* luferror(LUFILE*) */

bool luferror(LUFILE *param_1)

{
  if (*param_1 != (LUFILE)0x0) {
    return param_1[8] != (LUFILE)0x0;
  }
  return false;
}
