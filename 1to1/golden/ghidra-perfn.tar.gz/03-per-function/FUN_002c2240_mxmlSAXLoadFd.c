/* ============================================================
 * mxmlSAXLoadFd   @ 0x002c2240   size=80B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

void mxmlSAXLoadFd(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  undefined4 local_2014;
  undefined1 *local_2010;
  undefined1 *local_200c;
  undefined1 auStack_2008 [8192];
  
  local_2010 = auStack_2008;
  local_200c = auStack_2008;
  local_2014 = param_2;
  mxml_load_data(param_1,&local_2014,param_3,mxml_fd_getc,param_4,param_5);
  return;
}
