/* ============================================================
 * stbtt_IsGlyphEmpty   @ 0x00019e10   size=156B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

bool stbtt_IsGlyphEmpty(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 local_38;
  int iStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 local_28;
  int iStack_24;
  undefined4 local_20;
  int iStack_1c;
  undefined4 local_18;
  int iStack_14;
  undefined4 local_10;
  int iStack_c;
  
  if (*(int *)(param_1 + 0x3c) == 0) {
    iVar1 = stbtt__GetGlyfOffset();
    if (-1 < iVar1) {
      return (uint)*(byte *)(*(int *)(param_1 + 4) + iVar1 + 1) +
             (uint)*(byte *)(*(int *)(param_1 + 4) + iVar1) * 0x100 == 0;
    }
  }
  else {
    iStack_34 = *(int *)((undefined1  [16])0x0 + (undefined1  [16])0x4);
    uStack_30 = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0x8);
    uStack_2c = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0xc);
    local_38 = 1;
    local_28 = 0;
    local_20 = 0;
    local_18 = 0;
    local_10 = 0;
    iStack_24 = iStack_34;
    iStack_1c = iStack_34;
    iStack_14 = iStack_34;
    iStack_c = iStack_34;
    iVar1 = stbtt__run_charstring(param_1,param_2,&local_38);
    if (iVar1 != 0) {
      return iStack_c == 0;
    }
  }
  return true;
}
