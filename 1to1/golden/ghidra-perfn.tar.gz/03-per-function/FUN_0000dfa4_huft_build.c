/* ============================================================
 * huft_build   @ 0x0000dfa4   size=1432B   callers=2
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* WARNING: Type propagation algorithm not settling */
/* huft_build(unsigned int*, unsigned int, unsigned int, unsigned int const*, unsigned int const*,
   inflate_huft_s**, unsigned int*, inflate_huft_s*, unsigned int*, unsigned int*) */

undefined4
huft_build(uint *param_1,uint param_2,uint param_3,uint *param_4,uint *param_5,
          inflate_huft_s **param_6,uint *param_7,inflate_huft_s *param_8,uint *param_9,
          uint *param_10)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  inflate_huft_s *piVar4;
  inflate_huft_s *piVar5;
  uint *puVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  uint *puVar10;
  uint uVar11;
  uint uVar12;
  uint *puVar13;
  uint *puVar14;
  uint uVar15;
  inflate_huft_s iVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  int iVar20;
  int iVar21;
  uint local_11c;
  uint local_118;
  uint *local_110;
  uint local_10c;
  uint local_108;
  int local_f4;
  int local_e4 [15];
  uint local_a8 [33];
  
  local_a8[0] = 0;
  local_a8[1] = 0;
  local_a8[2] = 0;
  local_a8[3] = 0;
  local_a8[4] = 0;
  local_a8[5] = 0;
  local_a8[6] = 0;
  local_a8[7] = 0;
  local_a8[8] = 0;
  local_a8[9] = 0;
  local_a8[10] = 0;
  local_a8[0xb] = 0;
  local_a8[0xc] = 0;
  local_a8[0xd] = 0;
  local_a8[0xe] = 0;
  local_a8[0xf] = 0;
  uVar19 = param_2;
  puVar6 = param_1;
  do {
    uVar19 = uVar19 - 1;
    local_a8[*puVar6] = local_a8[*puVar6] + 1;
    puVar6 = puVar6 + 1;
  } while (uVar19 != 0);
  if (param_2 == local_a8[0]) {
    *param_6 = (inflate_huft_s *)0x0;
    *param_7 = 0;
    return 0;
  }
  local_108 = *param_7;
  local_118 = 1;
  puVar6 = local_a8;
  do {
    puVar6 = puVar6 + 1;
    if (*puVar6 != 0) {
      uVar19 = 1 << (local_118 & 0xff);
      goto LAB_0000e060;
    }
    local_118 = local_118 + 1;
  } while (local_118 != 0x10);
  uVar19 = 0x10000;
LAB_0000e060:
  puVar10 = local_a8 + 0x10;
  uVar18 = 0xf;
  puVar6 = puVar10;
  if (local_108 < local_118) {
    local_108 = local_118;
  }
LAB_0000e07c:
  if (puVar6[-1] == 0) goto code_r0x0000e088;
  if (uVar18 <= local_108) {
    local_108 = uVar18;
  }
  *param_7 = local_108;
  if (local_118 < uVar18) {
    iVar20 = uVar19 - local_a8[local_118];
    if (iVar20 < 0) {
      return 0xfffffffd;
    }
    puVar6 = local_a8 + local_118;
    while (uVar19 = iVar20 * 2, local_a8 + uVar18 + 0x3fffffff != puVar6) {
      puVar6 = puVar6 + 1;
      iVar20 = uVar19 - *puVar6;
      if (iVar20 < 0) {
        return 0xfffffffd;
      }
    }
  }
  iVar20 = uVar18 * 4;
  local_f4 = uVar19 - local_a8[uVar18];
  if (local_f4 < 0) {
    return 0xfffffffd;
  }
  iVar7 = uVar18 - 1;
  local_a8[uVar18] = uVar19;
  local_a8[0x11] = 0;
  if (iVar7 == 0) goto LAB_0000e0d8;
  goto LAB_0000e0b8;
code_r0x0000e088:
  uVar18 = uVar18 - 1;
  puVar6 = puVar6 + -1;
  if (uVar18 == 0) {
    local_f4 = uVar19 - local_a8[0];
    *param_7 = 0;
    if (local_f4 < 0) {
      return 0xfffffffd;
    }
    iVar7 = -1;
    local_a8[0] = uVar19;
    local_a8[0x11] = uVar18;
    iVar20 = 0;
    local_108 = uVar18;
LAB_0000e0b8:
    puVar14 = local_a8 + 0x11;
    puVar6 = local_a8;
    uVar19 = 0;
    do {
      puVar6 = puVar6 + 1;
      iVar7 = iVar7 + -1;
      uVar19 = uVar19 + *puVar6;
      puVar14 = puVar14 + 1;
      *puVar14 = uVar19;
    } while (iVar7 != 0);
LAB_0000e0d8:
    uVar19 = 0;
    do {
      uVar8 = *param_1;
      if (uVar8 != 0) {
        uVar11 = local_a8[uVar8 + 0x10];
        local_a8[uVar8 + 0x10] = uVar11 + 1;
        param_10[uVar11] = uVar19;
      }
      uVar19 = uVar19 + 1;
      param_1 = param_1 + 1;
    } while (uVar19 < param_2);
    uVar8 = -local_108;
    uVar19 = 0;
    local_e4[0] = 0;
    local_a8[0x10] = 0;
    if ((int)local_118 <= (int)uVar18) {
      puVar6 = param_10 + *(int *)((int)local_a8 + iVar20 + 0x40);
      iVar20 = -1;
      piVar5 = (inflate_huft_s *)0x0;
      uVar11 = 0;
      local_110 = local_a8 + local_118;
      do {
        puVar14 = local_110 + 1;
        uVar1 = 1 << (local_118 - 1 & 0xff);
        for (local_11c = *local_110; local_11c != 0; local_11c = local_11c - 1) {
          uVar15 = uVar8 + local_108;
          uVar12 = local_118 - uVar15;
          uVar17 = uVar18 - uVar15;
          while (uVar2 = uVar15, (int)uVar2 < (int)local_118) {
            uVar19 = 1 << (uVar12 & 0xff);
            iVar7 = iVar20 + 1;
            if (local_11c < uVar19) {
              uVar15 = uVar17;
              if (local_108 <= uVar17) {
                uVar15 = local_108;
              }
              if (uVar15 <= uVar12) goto LAB_0000e3d0;
              uVar3 = uVar12 + 1;
              if (uVar3 < uVar15) {
                uVar19 = (uVar19 - local_11c) * 2;
                uVar9 = *puVar14;
                puVar13 = puVar14;
                if (uVar9 <= uVar19 && uVar19 - uVar9 != 0) {
                  do {
                    uVar3 = uVar3 + 1;
                    uVar19 = (uVar19 - uVar9) * 2;
                    if (uVar15 <= uVar3) break;
                    uVar9 = puVar13[1];
                    puVar13 = puVar13 + 1;
                  } while (uVar9 < uVar19);
                }
              }
              uVar15 = *param_9;
              uVar19 = 1 << (uVar3 & 0xff);
              uVar9 = uVar15 + uVar19;
            }
            else {
LAB_0000e3d0:
              uVar15 = *param_9;
              uVar9 = uVar15 + uVar19;
              uVar3 = uVar12;
            }
            if (0x5a0 < uVar9) {
              return 0xfffffffc;
            }
            piVar5 = param_8 + uVar15 * 8;
            *param_9 = uVar9;
            local_e4[iVar7] = (int)piVar5;
            if (iVar7 == 0) {
              *param_6 = piVar5;
            }
            else {
              iVar21 = local_e4[iVar20];
              uVar8 = uVar11 >> (uVar8 & 0xff);
              local_a8[iVar20 + 0x11] = uVar11;
              iVar20 = iVar21 + uVar8 * 8;
              *(char *)(iVar21 + uVar8 * 8) = (char)uVar3;
              local_10c = ((int)piVar5 - iVar21 >> 3) - uVar8;
              *(char *)(iVar20 + 1) = (char)local_108;
              *(uint *)(iVar20 + 4) = local_10c;
            }
            uVar12 = uVar12 - local_108;
            uVar17 = uVar17 - local_108;
            uVar8 = uVar2;
            iVar20 = iVar7;
            uVar15 = uVar2 + local_108;
          }
          uVar12 = local_118 - uVar8;
          if (param_10 < puVar6) {
            local_10c = *param_10;
            if (local_10c < param_3) {
              if (local_10c < 0x100) {
                iVar16 = (inflate_huft_s)0x0;
              }
              else {
                iVar16 = (inflate_huft_s)0x60;
              }
              param_10 = param_10 + 1;
            }
            else {
              param_10 = param_10 + 1;
              iVar16 = (inflate_huft_s)((char)param_5[local_10c - param_3] + 'P');
              local_10c = param_4[local_10c - param_3];
            }
          }
          else {
            iVar16 = (inflate_huft_s)0xc0;
          }
          uVar17 = uVar11 >> (uVar8 & 0xff);
          if (uVar17 < uVar19) {
            piVar4 = piVar5 + uVar17 * 8;
            do {
              uVar17 = uVar17 + (1 << (uVar12 & 0xff));
              *piVar4 = iVar16;
              piVar4[1] = SUB41(uVar12,0);
              *(uint *)(piVar4 + 4) = local_10c;
              piVar4 = piVar4 + (8 << (uVar12 & 0xff));
            } while (uVar17 < uVar19);
          }
          uVar17 = uVar11 & uVar1;
          uVar12 = uVar1;
          while (uVar17 != 0) {
            uVar11 = uVar11 ^ uVar12;
            uVar12 = uVar12 >> 1;
            uVar17 = uVar11 & uVar12;
          }
          uVar11 = uVar11 ^ uVar12;
          if (local_a8[iVar20 + 0x10] != ((1 << (uVar8 & 0xff)) - 1U & uVar11)) {
            puVar13 = puVar10 + iVar20;
            do {
              uVar8 = uVar8 - local_108;
              puVar13 = puVar13 + -1;
              iVar20 = iVar20 + -1;
            } while (((1 << (uVar8 & 0xff)) - 1U & uVar11) != *puVar13);
          }
        }
        local_118 = local_118 + 1;
        local_110 = puVar14;
      } while ((int)local_118 <= (int)uVar18);
    }
    if (local_f4 != 0 && uVar18 != 1) {
      return 0xfffffffb;
    }
    return 0;
  }
  goto LAB_0000e07c;
}
