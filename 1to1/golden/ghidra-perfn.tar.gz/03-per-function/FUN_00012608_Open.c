/* ============================================================
 * Open   @ 0x00012608   size=80B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* TUnzip::Open(void*, unsigned int, unsigned int) */

uint __thiscall TUnzip::Open(TUnzip *this,void *param_1,uint param_2,uint param_3)

{
  LUFILE *pLVar1;
  undefined4 uVar2;
  uint local_c;
  
  pLVar1 = (LUFILE *)lufopen(param_1,param_2,param_3,&local_c);
  if (pLVar1 != (LUFILE *)0x0) {
    uVar2 = unzOpenInternal(pLVar1);
    local_c = zopenerror;
    *(undefined4 *)this = uVar2;
  }
  return local_c;
}
