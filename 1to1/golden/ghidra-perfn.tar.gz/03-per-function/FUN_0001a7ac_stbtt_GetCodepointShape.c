/* ============================================================
 * stbtt_GetCodepointShape   @ 0x0001a7ac   size=36B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_GetCodepointShape(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  
  uVar1 = stbtt_FindGlyphIndex();
  stbtt_GetGlyphShape(param_1,uVar1,param_3);
  return;
}
