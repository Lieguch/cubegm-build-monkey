/* ============================================================
 * stbtt__cff_int   @ 0x000132c0   size=312B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

uint stbtt__cff_int(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  
  iVar3 = param_1[1];
  iVar2 = param_1[2];
  if (iVar2 <= iVar3) {
    return 0;
  }
  iVar6 = iVar3 + 1;
  iVar7 = *param_1;
  param_1[1] = iVar6;
  uVar4 = (uint)*(byte *)(iVar7 + iVar3);
  if (uVar4 - 0x20 < 0xd7) {
    uVar4 = uVar4 - 0x8b;
  }
  else {
    if (uVar4 - 0xf7 < 4) {
      if (iVar6 < iVar2) {
        param_1[1] = iVar3 + 2;
        uVar1 = (uint)*(byte *)(iVar7 + iVar6);
      }
      else {
        uVar1 = 0;
      }
      return (uVar4 - 0xf7) * 0x100 + uVar1 + 0x6c;
    }
    if (uVar4 - 0xfb < 4) {
      if (iVar6 < iVar2) {
        param_1[1] = iVar3 + 2;
        param_1 = (int *)(uint)*(byte *)(iVar7 + iVar6);
      }
      if (iVar2 <= iVar6) {
        param_1 = (int *)0x0;
      }
      return ((0xfb - uVar4) * 0x100 - (int)param_1) - 0x6c;
    }
    if (uVar4 == 0x1c) {
      if (iVar6 < iVar2) {
        iVar5 = iVar3 + 2;
        param_1[1] = iVar5;
        uVar1 = (uint)*(byte *)(iVar7 + iVar6) << 8;
        if (iVar5 < iVar2) {
          param_1[1] = iVar3 + 3;
          uVar4 = (uint)*(byte *)(iVar7 + iVar5);
        }
        else {
          uVar4 = 0;
        }
      }
      else {
        uVar1 = 0;
        uVar4 = uVar1;
      }
      uVar4 = uVar4 | uVar1;
    }
    else if (uVar4 == 0x1d) {
      iVar3 = 4;
      uVar4 = 0;
      do {
        iVar6 = param_1[1];
        uVar1 = 0;
        if (iVar6 < iVar2) {
          param_1[1] = iVar6 + 1;
          uVar1 = (uint)*(byte *)(iVar7 + iVar6);
        }
        iVar3 = iVar3 + -1;
        uVar4 = uVar4 << 8 | uVar1;
      } while (iVar3 != 0);
    }
    else {
      uVar4 = 0;
    }
  }
  return uVar4;
}
