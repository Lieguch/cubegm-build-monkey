/* ============================================================
 * mxmlSaveAllocString   @ 0x002c21ac   size=148B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

void * mxmlSaveAllocString(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  void *pvVar2;
  undefined1 auStack_2018 [8196];
  
  iVar1 = mxmlSaveString(param_1,auStack_2018,0x2000,param_2);
  if (iVar1 < 1) {
    pvVar2 = (void *)0x0;
  }
  else {
    if (iVar1 < 0x1fff) {
      pvVar2 = (void *)__strdup(auStack_2018);
      return pvVar2;
    }
    pvVar2 = malloc(iVar1 + 1U);
    if (pvVar2 != (void *)0x0) {
      mxmlSaveString(param_1,pvVar2,iVar1 + 1U,param_2);
    }
  }
  return pvVar2;
}
