/* ============================================================
 * unzlocal_getLong   @ 0x00010d84   size=156B   callers=3
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzlocal_getLong(LUFILE*, unsigned long*) */

void unzlocal_getLong(LUFILE *param_1,ulong *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int local_1c;
  
  iVar2 = unzlocal_getByte(param_1,&local_1c);
  iVar1 = local_1c;
  if (iVar2 == 0) {
    iVar3 = unzlocal_getByte(param_1,&local_1c);
    iVar2 = local_1c * 0x100;
    if (iVar3 == 0) {
      iVar4 = unzlocal_getByte(param_1,&local_1c);
      iVar3 = local_1c * 0x10000;
      if (iVar4 == 0) {
        iVar4 = unzlocal_getByte(param_1,&local_1c);
        if (iVar4 == 0) {
          *param_2 = iVar2 + iVar3 + iVar1 + local_1c * 0x1000000;
          return;
        }
      }
    }
  }
  *param_2 = 0;
  return;
}
