/* ============================================================
 * ascii_wctomb   @ 0x002c44d0   size=48B   callers=18
 * module: 08_iconv_encoding
 * ============================================================ */

undefined4 ascii_wctomb(undefined4 param_1,undefined1 *param_2,uint param_3)

{
  undefined4 uVar1;
  
  if (param_3 < 0x80) {
    *param_2 = (char)param_3;
    uVar1 = 1;
  }
  else {
    uVar1 = 0xffffffff;
  }
  return uVar1;
}
