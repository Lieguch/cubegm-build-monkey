/* ============================================================
 * xmp3_Subband   @ 0x002ba08c   size=348B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

undefined4 xmp3_Subband(int param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  
  if ((param_1 != 0) && (*(int *)(param_1 + 0xc) != 0)) {
    iVar4 = *(int *)(param_1 + 0x14);
    if ((iVar4 == 0) || (iVar7 = *(int *)(param_1 + 0x18), iVar7 == 0)) {
      uVar1 = 0xffffffff;
    }
    else {
      if (*(int *)(param_1 + 0x7bc) == 2) {
        uVar3 = *(uint *)(iVar7 + 0x2200);
        uVar8 = 0;
        iVar5 = iVar4;
        do {
          uVar6 = uVar8 & 1;
          uVar8 = uVar8 + 1;
          xmp3_FDCT32(iVar5,iVar7,uVar3,uVar6,*(undefined4 *)(iVar4 + 0x1b18));
          iVar2 = iVar5 + 0x900;
          iVar5 = iVar5 + 0x80;
          xmp3_FDCT32(iVar2,iVar7 + 0x80,*(undefined4 *)(iVar7 + 0x2200),uVar6,
                      *(undefined4 *)(iVar4 + 0x1b1c));
          xmp3_PolyphaseStereo
                    (param_2,iVar7 + (uVar6 * 0x440 + *(int *)(iVar7 + 0x2200)) * 4,&xmp3_polyCoef);
          uVar3 = *(int *)(iVar7 + 0x2200) - uVar6 & 7;
          *(uint *)(iVar7 + 0x2200) = uVar3;
          param_2 = param_2 + 0x80;
        } while (iVar5 != iVar4 + 0x900);
      }
      else {
        uVar8 = 0;
        uVar3 = *(uint *)(iVar7 + 0x2200);
        iVar5 = iVar4;
        do {
          uVar6 = uVar8 & 1;
          uVar8 = uVar8 + 1;
          xmp3_FDCT32(iVar5,iVar7,uVar3,uVar6,*(undefined4 *)(iVar4 + 0x1b18));
          uVar3 = *(int *)(iVar7 + 0x2200) - uVar6 & 7;
          *(uint *)(iVar7 + 0x2200) = uVar3;
          iVar5 = iVar5 + 0x80;
        } while (uVar8 != 0x12);
      }
      uVar1 = 0;
    }
    return uVar1;
  }
  return 0xffffffff;
}
