/* ============================================================
 * mxmlSAXLoadString   @ 0x002c22c0   size=52B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

void mxmlSAXLoadString(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      undefined4 param_5)

{
  undefined4 local_c [2];
  
  local_c[0] = param_2;
  mxml_load_data(param_1,local_c,param_3,mxml_string_getc,param_4,param_5);
  return;
}
