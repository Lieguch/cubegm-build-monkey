/* ============================================================
 * zError   @ 0x000102e8   size=20B   callers=0
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* zError(int) */

undefined * zError(int param_1)

{
  return (&z_errmsg)[2 - param_1];
}
