/* ============================================================
 * stbtt_MakeCodepointBitmapSubpixel   @ 0x0001bb90   size=104B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_MakeCodepointBitmapSubpixel
               (undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
               undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
               undefined4 param_9,undefined4 param_10)

{
  stbtt_FindGlyphIndex(param_5,param_10);
  stbtt_MakeGlyphBitmapSubpixel(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  return;
}
