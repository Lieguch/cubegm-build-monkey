/* ============================================================
 * unzlocal_CheckCurrentFileCoherencyHeader   @ 0x000119fc   size=724B   callers=2
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzlocal_CheckCurrentFileCoherencyHeader(unz_s*, unsigned int*, unsigned long*, unsigned int*) */

int unzlocal_CheckCurrentFileCoherencyHeader
              (unz_s *param_1,uint *param_2,ulong *param_3,uint *param_4)

{
  LUFILE *pLVar1;
  int iVar2;
  int iVar3;
  ulong local_34;
  uint local_30;
  uint local_2c;
  ulong local_28;
  uint local_24 [2];
  
  *param_2 = 0;
  *param_3 = 0;
  iVar2 = *(int *)(param_1 + 0x78);
  iVar3 = *(int *)(param_1 + 0xc);
  *param_4 = 0;
  iVar2 = lufseek(*(LUFILE **)param_1,iVar2 + iVar3,0);
  if (iVar2 != 0) {
    return -1;
  }
  iVar2 = unzlocal_getLong(*(LUFILE **)param_1,&local_34);
  if (iVar2 == 0) {
    iVar2 = 0;
    if ((key2._20_4_ != local_34) && (local_34 != key2._16_4_)) {
      iVar2 = -0x67;
    }
  }
  else {
    iVar2 = -1;
  }
  iVar3 = unzlocal_getShort(*(LUFILE **)param_1,&local_30);
  if (iVar3 != 0) {
    iVar2 = -1;
  }
  iVar3 = unzlocal_getShort(*(LUFILE **)param_1,&local_2c);
  if (iVar3 == 0) {
    iVar3 = unzlocal_getShort(*(LUFILE **)param_1,&local_30);
    if (iVar3 == 0) {
      if (iVar2 == 0) {
        if (*(uint *)(param_1 + 0x34) == local_30) {
          if ((*(uint *)(param_1 + 0x34) & 0xfffffff7) != 0) {
            iVar2 = -0x67;
          }
        }
        else {
          iVar2 = -0x67;
        }
      }
    }
    else {
      iVar2 = -1;
    }
  }
  else {
    unzlocal_getShort(*(LUFILE **)param_1,&local_30);
    iVar2 = -1;
  }
  iVar3 = unzlocal_getLong(*(LUFILE **)param_1,&local_30);
  if (iVar3 == 0) {
    iVar3 = unzlocal_getLong(*(LUFILE **)param_1,&local_30);
    if (iVar3 != 0) {
LAB_00011be0:
      iVar2 = -1;
LAB_00011b14:
      iVar3 = unzlocal_getLong(*(LUFILE **)param_1,&local_30);
      if (iVar3 == 0) goto LAB_00011c04;
LAB_00011b28:
      unzlocal_getLong(*(LUFILE **)param_1,&local_30);
      iVar2 = -1;
      goto LAB_00011b38;
    }
    if (iVar2 != 0) goto LAB_00011b14;
    if ((*(uint *)(param_1 + 0x3c) != local_30) && ((local_2c & 8) == 0)) {
      iVar2 = -0x67;
      goto LAB_00011b14;
    }
    iVar2 = unzlocal_getLong(*(LUFILE **)param_1,&local_30);
    if (iVar2 != 0) goto LAB_00011b28;
    if ((*(uint *)(param_1 + 0x40) != local_30) && ((local_2c & 8) == 0)) {
      iVar2 = -0x67;
      goto LAB_00011c04;
    }
    iVar2 = unzlocal_getLong(*(LUFILE **)param_1,&local_30);
    if (iVar2 != 0) goto LAB_00011c18;
    if ((*(uint *)(param_1 + 0x44) != local_30) && ((local_2c & 8) == 0)) {
      iVar2 = -0x67;
      goto LAB_00011b38;
    }
    iVar2 = unzlocal_getShort(*(LUFILE **)param_1,&local_28);
    if (iVar2 == 0) {
      iVar2 = 0;
      if (*(ulong *)(param_1 + 0x48) != local_28) {
        iVar2 = -0x67;
      }
      goto LAB_00011b54;
    }
  }
  else {
    iVar2 = unzlocal_getLong(*(LUFILE **)param_1,&local_30);
    if (iVar2 == 0) goto LAB_00011be0;
    unzlocal_getLong(*(LUFILE **)param_1,&local_30);
    iVar2 = -1;
LAB_00011c04:
    iVar3 = unzlocal_getLong(*(LUFILE **)param_1,&local_30);
    if (iVar3 != 0) {
LAB_00011c18:
      unzlocal_getShort(*(LUFILE **)param_1,&local_28);
      iVar2 = -1;
      goto LAB_00011b54;
    }
LAB_00011b38:
    iVar3 = unzlocal_getShort(*(LUFILE **)param_1,&local_28);
    if (iVar3 == 0) goto LAB_00011b54;
  }
  iVar2 = -1;
LAB_00011b54:
  pLVar1 = *(LUFILE **)param_1;
  *param_2 = *param_2 + local_28;
  iVar3 = unzlocal_getShort(pLVar1,local_24);
  *param_3 = local_28 + 0x1e + *(int *)(param_1 + 0x78);
  *param_4 = local_24[0];
  *param_2 = *param_2 + local_24[0];
  if (iVar3 != 0) {
    iVar2 = -1;
  }
  return iVar2;
}
