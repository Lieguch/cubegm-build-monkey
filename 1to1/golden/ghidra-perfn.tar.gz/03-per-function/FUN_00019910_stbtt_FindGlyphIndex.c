/* ============================================================
 * stbtt_FindGlyphIndex   @ 0x00019910   size=848B   callers=12
 * module: 05_stb_truetype_font
 * ============================================================ */

uint stbtt_FindGlyphIndex(int param_1,uint param_2)

{
  short sVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  
  iVar4 = *(int *)(param_1 + 4);
  iVar10 = *(int *)(param_1 + 0x2c);
  iVar11 = (uint)*(byte *)(iVar4 + iVar10 + 1) + (uint)*(byte *)(iVar4 + iVar10) * 0x100;
  if (iVar11 == 0) {
    if ((int)param_2 <
        (int)((uint)*(byte *)(iVar4 + iVar10 + 2 + 1) + (uint)*(byte *)(iVar4 + iVar10 + 2) * 0x100
             + -6)) {
      return (uint)*(byte *)(iVar4 + iVar10 + param_2 + 6);
    }
  }
  else if (iVar11 == 6) {
    uVar5 = (uint)*(byte *)(iVar4 + iVar10 + 6 + 1) + (uint)*(byte *)(iVar4 + iVar10 + 6) * 0x100;
    if ((uVar5 <= param_2) &&
       (param_2 < uVar5 + (uint)*(byte *)(iVar4 + iVar10 + 8 + 1) +
                          (uint)*(byte *)(iVar4 + iVar10 + 8) * 0x100)) {
      iVar10 = iVar10 + 10 + (param_2 - uVar5) * 2;
      return (uint)*(byte *)(iVar4 + iVar10 + 1) + (uint)*(byte *)(iVar4 + iVar10) * 0x100;
    }
  }
  else if (iVar11 != 2) {
    if (iVar11 == 4) {
      if ((int)param_2 < 0x10000) {
        iVar2 = iVar10 + 0xe;
        sVar1 = (ushort)*(byte *)(iVar4 + iVar10 + 10 + 1) +
                (ushort)*(byte *)(iVar4 + iVar10 + 10) * 0x100;
        iVar11 = iVar2 + ((uint)*(byte *)(iVar4 + iVar10 + 0xc + 1) +
                          (uint)*(byte *)(iVar4 + iVar10 + 0xc) * 0x100 & 0xfffffffe);
        if ((int)param_2 <
            (int)((uint)*(byte *)(iVar4 + iVar11 + 1) + (uint)*(byte *)(iVar4 + iVar11) * 0x100)) {
          iVar11 = iVar2;
        }
        iVar11 = iVar11 + -2;
        if (sVar1 != 0) {
          uVar5 = (uint)*(byte *)(iVar4 + iVar10 + 8 + 1) +
                  (uint)*(byte *)(iVar4 + iVar10 + 8) * 0x100 >> 1;
          do {
            uVar5 = uVar5 >> 1;
            sVar1 = sVar1 + -1;
            iVar7 = iVar11 + uVar5 * 2;
            if ((int)((uint)*(byte *)(iVar4 + iVar7 + 1) + (uint)*(byte *)(iVar4 + iVar7) * 0x100) <
                (int)param_2) {
              iVar11 = iVar7;
            }
          } while (sVar1 != 0);
        }
        uVar5 = (2 - iVar2) + iVar11 & 0x1fffe;
        uVar3 = (uint)*(byte *)(iVar4 + iVar10 + 6 + 1) +
                (uint)*(byte *)(iVar4 + iVar10 + 6) * 0x100 >> 1;
        iVar11 = iVar10 + 0x10 + uVar3 * 2 + uVar5;
        iVar11 = (uint)*(byte *)(iVar4 + iVar11 + 1) + (uint)*(byte *)(iVar4 + iVar11) * 0x100;
        if (iVar11 <= (int)param_2) {
          iVar10 = uVar3 * 6 + iVar10 + 0x10;
          iVar2 = uVar5 + iVar10;
          iVar7 = (uint)*(byte *)(iVar4 + iVar2 + 1) + (uint)*(byte *)(iVar4 + iVar2) * 0x100;
          if (iVar7 == 0) {
            iVar10 = iVar10 + uVar3 * -2 + uVar5;
            return *(byte *)(iVar4 + iVar10 + 1) + param_2 + (uint)*(byte *)(iVar4 + iVar10) * 0x100
                   & 0xffff;
          }
          iVar10 = iVar7 + iVar2 + (param_2 - iVar11) * 2;
          return (uint)*(byte *)(iVar4 + iVar10 + 1) + (uint)*(byte *)(iVar4 + iVar10) * 0x100;
        }
      }
    }
    else if (iVar11 - 0xcU < 2) {
      iVar7 = 0;
      iVar2 = iVar4 + iVar10 + 0xc;
      iVar2 = (uint)*(byte *)(iVar2 + 1) * 0x10000 +
              (uint)*(byte *)(iVar4 + iVar10 + 0xc) * 0x1000000 + (uint)*(byte *)(iVar2 + 2) * 0x100
              + (uint)*(byte *)(iVar2 + 3);
      while (iVar6 = iVar2, iVar7 < iVar6) {
        iVar2 = iVar7 + (iVar6 - iVar7 >> 1);
        iVar8 = iVar2 * 0xc + iVar10;
        iVar9 = iVar4 + iVar8 + 0x10;
        uVar5 = (uint)*(byte *)(iVar9 + 1) * 0x10000 +
                (uint)*(byte *)(iVar4 + iVar8 + 0x10) * 0x1000000 +
                (uint)*(byte *)(iVar9 + 2) * 0x100 + (uint)*(byte *)(iVar9 + 3);
        if (uVar5 <= param_2) {
          iVar7 = iVar4 + iVar8 + 0x14;
          if (param_2 <=
              (uint)*(byte *)(iVar7 + 1) * 0x10000 +
              (uint)*(byte *)(iVar4 + iVar8 + 0x14) * 0x1000000 + (uint)*(byte *)(iVar7 + 2) * 0x100
              + (uint)*(byte *)(iVar7 + 3)) {
            iVar10 = iVar4 + iVar8 + 0x18;
            if (iVar11 == 0xc) {
              uVar5 = param_2 - uVar5;
            }
            uVar3 = (uint)*(byte *)(iVar10 + 1) * 0x10000 +
                    (uint)*(byte *)(iVar4 + iVar8 + 0x18) * 0x1000000 +
                    (uint)*(byte *)(iVar10 + 2) * 0x100 + (uint)*(byte *)(iVar10 + 3);
            if (iVar11 == 0xc) {
              uVar3 = uVar3 + uVar5;
            }
            return uVar3;
          }
          iVar7 = iVar2 + 1;
          iVar2 = iVar6;
        }
      }
    }
  }
  return 0;
}
