/* ============================================================
 * mxmlGetCustom   @ 0x002c238c   size=68B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

int mxmlGetCustom(int *param_1)

{
  if (param_1 == (int *)0x0) {
    return 0;
  }
  if (*param_1 != 5) {
    if (*param_1 == 0) {
      param_1 = (int *)param_1[4];
      if (param_1 == (int *)0x0) {
        return 0;
      }
      if (*param_1 == 5) goto LAB_002c23c0;
    }
    return 0;
  }
LAB_002c23c0:
  return param_1[6];
}
