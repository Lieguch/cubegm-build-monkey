/* ============================================================
 * index_sort   @ 0x002c266c   size=316B   callers=2
 * module: 01_main_emurun_joystick
 * ============================================================ */

void index_sort(int param_1,int param_2,int param_3)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  
  while( true ) {
    iVar4 = *(int *)(param_1 + 0x10);
    uVar6 = *(undefined4 *)(iVar4 + param_2 * 4);
    iVar2 = param_2;
    iVar5 = param_3;
    iVar7 = param_3 << 2;
    if (param_2 < param_3) break;
LAB_002c272c:
    iVar2 = index_compare_isra_2(param_1,uVar6,*(undefined4 *)(iVar4 + iVar7));
    if (0 < iVar2) {
      iVar2 = *(int *)(param_1 + 0x10);
      *(undefined4 *)(iVar2 + param_2 * 4) = *(undefined4 *)(iVar2 + iVar7);
      *(undefined4 *)(iVar2 + iVar7) = uVar6;
    }
    if (param_2 < iVar5 + -1) {
      index_sort(param_1,param_2);
    }
    param_2 = iVar5 + 1;
    if (param_3 <= param_2) {
      return;
    }
  }
  do {
    if (iVar2 < param_3) {
      iVar7 = iVar2 << 2;
      do {
        puVar1 = (undefined4 *)(iVar4 + iVar7);
        iVar7 = iVar7 + 4;
        iVar4 = index_compare_isra_2(param_1,*puVar1,uVar6);
        if (0 < iVar4) {
          iVar4 = *(int *)(param_1 + 0x10);
          break;
        }
        iVar2 = iVar2 + 1;
        iVar4 = *(int *)(param_1 + 0x10);
      } while (param_3 != iVar2);
    }
    iVar7 = iVar5 << 2;
    iVar8 = iVar7;
    if (param_2 < iVar5) {
      do {
        iVar7 = index_compare_isra_2(param_1,*(undefined4 *)(iVar4 + iVar8),uVar6);
        if (iVar7 < 1) {
          iVar4 = *(int *)(param_1 + 0x10);
          iVar7 = iVar8;
          break;
        }
        iVar5 = iVar5 + -1;
        iVar8 = iVar8 + -4;
        iVar4 = *(int *)(param_1 + 0x10);
        iVar7 = param_2 * 4;
      } while (param_2 != iVar5);
    }
    if (iVar5 <= iVar2) goto LAB_002c272c;
    uVar3 = *(undefined4 *)(iVar4 + iVar2 * 4);
    *(undefined4 *)(iVar4 + iVar2 * 4) = *(undefined4 *)(iVar4 + iVar7);
    *(undefined4 *)(iVar4 + iVar7) = uVar3;
  } while( true );
}
