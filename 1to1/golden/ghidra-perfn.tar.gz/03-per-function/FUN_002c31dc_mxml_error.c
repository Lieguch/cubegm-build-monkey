/* ============================================================
 * mxml_error   @ 0x002c31dc   size=152B   callers=10
 * module: 04_mini_xml
 * ============================================================ */

void mxml_error(char *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  char acStack_428 [1028];
  undefined4 uStack_c;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  uStack_c = param_2;
  uStack_8 = param_3;
  uStack_4 = param_4;
  puVar1 = (undefined4 *)_mxml_global();
  if (param_1 != (char *)0x0) {
    vsnprintf(acStack_428,0x400,param_1,&uStack_c);
    if ((code *)*puVar1 == (code *)0x0) {
      fprintf(stderr,"mxml: %s\n",acStack_428);
    }
    else {
      (*(code *)*puVar1)(acStack_428);
    }
  }
  return;
}
