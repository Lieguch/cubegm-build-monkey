/* ============================================================
 * call_weak_fn   @ 0x00009d80   size=40B   callers=1
 * module: 99_crt_glibc
 * ============================================================ */

/* WARNING: Removing unreachable block (ram,0x00009d94) */

void call_weak_fn(void)

{
  __gmon_start__();
  return;
}
