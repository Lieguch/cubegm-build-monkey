/* ============================================================
 * stbtt__matchpair   @ 0x00014118   size=552B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

bool stbtt__matchpair(int param_1,int param_2,int param_3,int param_4,int param_5,int param_6)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  
  iVar5 = (uint)*(byte *)(param_1 + param_2 + 2 + 1) +
          (uint)*(byte *)(param_1 + param_2 + 2) * 0x100;
  iVar6 = param_2 + (uint)*(byte *)(param_1 + param_2 + 4 + 1) +
                    (uint)*(byte *)(param_1 + param_2 + 4) * 0x100;
  if (iVar5 == 0) {
    return false;
  }
  param_2 = param_1 + param_2;
  iVar2 = 1;
  do {
    if ((uint)*(byte *)(param_2 + 0xd) + (uint)*(byte *)(param_2 + 0xc) * 0x100 == param_5) {
      iVar3 = (uint)*(byte *)(param_2 + 7) + (uint)*(byte *)(param_2 + 6) * 0x100;
      iVar4 = (uint)*(byte *)(param_2 + 9) + (uint)*(byte *)(param_2 + 8) * 0x100;
      if (((iVar3 != 0) && (iVar3 != 3 || iVar4 != 10 && iVar4 != 1)) ||
         (iVar1 = stbtt__CompareUTF8toUTF16_bigendian_prefix
                            (param_3,param_4,
                             param_1 + iVar6 + (uint)*(byte *)(param_2 + 0x11) +
                                               (uint)*(byte *)(param_2 + 0x10) * 0x100,
                             (uint)*(byte *)(param_2 + 0xf) + (uint)*(byte *)(param_2 + 0xe) * 0x100
                            ), iVar1 < 0)) goto LAB_00014178;
      if (iVar5 <= iVar2) {
        return param_4 == iVar1;
      }
      if ((((uint)*(byte *)(param_2 + 0x19) + (uint)*(byte *)(param_2 + 0x18) * 0x100 == param_6) &&
          (iVar3 == (uint)*(byte *)(param_2 + 0x13) + (uint)*(byte *)(param_2 + 0x12) * 0x100)) &&
         ((iVar4 == (uint)*(byte *)(param_2 + 0x15) + (uint)*(byte *)(param_2 + 0x14) * 0x100 &&
          (((uint)*(byte *)(param_2 + 0xb) + (uint)*(byte *)(param_2 + 10) * 0x100 ==
            (uint)*(byte *)(param_2 + 0x17) + (uint)*(byte *)(param_2 + 0x16) * 0x100 &&
           ((uint)*(byte *)(param_2 + 0x1b) + (uint)*(byte *)(param_2 + 0x1a) * 0x100 != 0)))))) {
        if (((iVar1 < param_4) && (*(char *)(param_3 + iVar1) == ' ')) &&
           (iVar4 = param_4 - (iVar1 + 1),
           iVar3 = stbtt__CompareUTF8toUTF16_bigendian_prefix
                             (param_3 + iVar1 + 1,iVar4,
                              param_1 + iVar6 + (uint)*(byte *)(param_2 + 0x1d) +
                                                (uint)*(byte *)(param_2 + 0x1c) * 0x100),
           iVar4 == iVar3)) {
          return true;
        }
      }
      else if (param_4 == iVar1) {
        return true;
      }
    }
    else {
LAB_00014178:
      if (iVar5 <= iVar2) {
        return false;
      }
    }
    param_2 = param_2 + 0xc;
    iVar2 = iVar2 + 1;
  } while( true );
}
