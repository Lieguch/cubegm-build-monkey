/* ============================================================
 * stbtt_PackFontRanges   @ 0x0001e850   size=296B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

undefined4
stbtt_PackFontRanges
          (undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4,int param_5)

{
  int *piVar1;
  size_t __size;
  void *__ptr;
  undefined4 uVar2;
  undefined2 *puVar3;
  undefined2 *puVar4;
  undefined2 *puVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  undefined4 local_9c [31];
  
  if (param_5 < 1) {
    __size = 0;
  }
  else {
    iVar8 = param_4;
    do {
      iVar7 = *(int *)(iVar8 + 0xc);
      if (0 < iVar7) {
        puVar3 = *(undefined2 **)(iVar8 + 0x10);
        puVar4 = puVar3;
        do {
          puVar4[3] = 0;
          puVar4[2] = 0;
          puVar4[1] = 0;
          puVar5 = puVar4 + 0xe;
          *puVar4 = 0;
          puVar4 = puVar5;
        } while (puVar5 != puVar3 + iVar7 * 0xe);
      }
      iVar8 = iVar8 + 0x18;
    } while (param_5 * 0x18 + param_4 != iVar8);
    iVar6 = 0;
    iVar7 = param_4;
    do {
      piVar1 = (int *)(iVar7 + 0xc);
      iVar7 = iVar7 + 0x18;
      iVar6 = iVar6 + *piVar1;
    } while (iVar7 != iVar8);
    __size = iVar6 * 0x18;
  }
  __ptr = malloc(__size);
  if (__ptr == (void *)0x0) {
    uVar2 = 0;
  }
  else {
    local_9c[0] = *param_1;
    uVar2 = stbtt_GetFontOffsetForIndex(param_2,param_3);
    stbtt_InitFont(local_9c,param_2,uVar2);
    uVar2 = stbtt_PackFontRangesGatherRects(param_1,local_9c,param_4,param_5,__ptr);
    stbtt_PackFontRangesPackRects(param_1,__ptr,uVar2);
    uVar2 = stbtt_PackFontRangesRenderIntoRects(param_1,local_9c,param_4,param_5,__ptr);
    free(__ptr);
  }
  return uVar2;
}
