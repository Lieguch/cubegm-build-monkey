/* ============================================================
 * _mxml_vstrdupf   @ 0x002c3944   size=128B   callers=3
 * module: 04_mini_xml
 * ============================================================ */

char * _mxml_vstrdupf(char *param_1,__gnuc_va_list param_2)

{
  uint uVar1;
  char *pcVar2;
  char acStack_118 [260];
  
  uVar1 = vsnprintf(acStack_118,0x100,param_1,param_2);
  if (0xff < uVar1) {
    pcVar2 = calloc(1,uVar1 + 1);
    if (pcVar2 != (char *)0x0) {
      vsnprintf(pcVar2,uVar1 + 1,param_1,param_2);
    }
    return pcVar2;
  }
  pcVar2 = (char *)__strdup(acStack_118);
  return pcVar2;
}
