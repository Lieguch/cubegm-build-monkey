/* ============================================================
 * mxmlAdd   @ 0x002c2c28   size=280B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

void mxmlAdd(int param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  
  if (param_4 == 0 || param_1 == 0) {
    return;
  }
  if (*(int *)(param_4 + 0xc) != 0) {
    mxmlRemove(param_4);
  }
  *(int *)(param_4 + 0xc) = param_1;
  if (param_2 == 0) {
    iVar1 = *(int *)(param_1 + 0x10);
    if (param_3 == 0) {
LAB_002c2c94:
      *(int *)(param_4 + 4) = iVar1;
      if (iVar1 == 0) {
        *(int *)(param_1 + 0x14) = param_4;
        goto LAB_002c2ca8;
      }
    }
    else {
      if (param_3 != iVar1) {
        if (param_1 == *(int *)(param_3 + 0xc)) {
          uVar2 = *(undefined4 *)(param_3 + 8);
          *(int *)(param_4 + 4) = param_3;
          *(undefined4 *)(param_4 + 8) = uVar2;
          if (*(int *)(param_3 + 8) == 0) {
            *(int *)(param_1 + 0x10) = param_4;
          }
          else {
            *(int *)(*(int *)(param_3 + 8) + 4) = param_4;
          }
          *(int *)(param_3 + 8) = param_4;
          return;
        }
        goto LAB_002c2c94;
      }
      *(int *)(param_4 + 4) = iVar1;
    }
    *(int *)(iVar1 + 8) = param_4;
LAB_002c2ca8:
    *(int *)(param_1 + 0x10) = param_4;
    return;
  }
  if (param_2 != 1) {
    return;
  }
  iVar1 = *(int *)(param_1 + 0x14);
  if (param_3 == 0) {
LAB_002c2cd0:
    *(int *)(param_4 + 8) = iVar1;
    if (iVar1 == 0) {
      *(int *)(param_1 + 0x10) = param_4;
      goto LAB_002c2ce4;
    }
  }
  else {
    if (param_3 != iVar1) {
      if (param_1 == *(int *)(param_3 + 0xc)) {
        *(undefined4 *)(param_4 + 4) = *(undefined4 *)(param_3 + 4);
        *(int *)(param_4 + 8) = param_3;
        if (*(int *)(param_3 + 4) == 0) {
          *(int *)(param_1 + 0x14) = param_4;
        }
        else {
          *(int *)(*(int *)(param_3 + 4) + 8) = param_4;
        }
        *(int *)(param_3 + 4) = param_4;
        return;
      }
      goto LAB_002c2cd0;
    }
    *(int *)(param_4 + 8) = iVar1;
  }
  *(int *)(iVar1 + 4) = param_4;
LAB_002c2ce4:
  *(int *)(param_1 + 0x14) = param_4;
  return;
}
