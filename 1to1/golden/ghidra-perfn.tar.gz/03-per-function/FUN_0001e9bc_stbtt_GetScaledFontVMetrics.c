/* ============================================================
 * stbtt_GetScaledFontVMetrics   @ 0x0001e9bc   size=184B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_GetScaledFontVMetrics
               (float param_1,undefined4 param_2,undefined4 param_3,float *param_4,float *param_5,
               float *param_6)

{
  uint uVar1;
  byte bVar2;
  undefined4 uVar3;
  uint in_fpscr;
  uint uVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  undefined4 local_a8;
  undefined4 local_a4;
  undefined4 local_a0;
  undefined1 auStack_9c [124];
  
  uVar3 = stbtt_GetFontOffsetForIndex();
  stbtt_InitFont(auStack_9c,param_2,uVar3);
  uVar1 = in_fpscr & 0xfffffff | (uint)(param_1 < 0.0) << 0x1f | (uint)(param_1 == 0.0) << 0x1e;
  uVar4 = uVar1 | (uint)NAN(param_1) << 0x1c;
  bVar2 = (byte)(uVar1 >> 0x18);
  if ((bool)(bVar2 >> 6 & 1) || bVar2 >> 7 != ((byte)(uVar4 >> 0x1c) & 1)) {
    fVar5 = (float)stbtt_ScaleForMappingEmToPixels(-param_1,auStack_9c);
  }
  else {
    fVar5 = (float)stbtt_ScaleForPixelHeight(param_1,auStack_9c);
  }
  stbtt_GetFontVMetrics(auStack_9c,&local_a8,&local_a4,&local_a0);
  fVar6 = (float)VectorSignedToFloat(local_a8,(byte)(uVar4 >> 0x16) & 3);
  fVar7 = (float)VectorSignedToFloat(local_a4,(byte)(uVar4 >> 0x16) & 3);
  fVar8 = (float)VectorSignedToFloat(local_a0,(byte)(uVar4 >> 0x16) & 3);
  *param_4 = fVar6 * fVar5;
  *param_5 = fVar7 * fVar5;
  *param_6 = fVar8 * fVar5;
  return;
}
