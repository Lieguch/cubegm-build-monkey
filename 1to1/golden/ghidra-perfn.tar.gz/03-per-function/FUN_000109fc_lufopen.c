/* ============================================================
 * lufopen   @ 0x000109fc   size=208B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* lufopen(void*, unsigned int, unsigned int, unsigned int*) */

undefined1 * lufopen(void *param_1,uint param_2,uint param_3,uint *param_4)

{
  undefined1 *puVar1;
  FILE *__stream;
  
  if (param_3 - 1 < 3) {
    __stream = (FILE *)0x0;
    *param_4 = 0;
    if (param_3 - 1 == 2) {
      puVar1 = operator_new(0x1c);
      *puVar1 = 0;
      *(void **)(puVar1 + 0x10) = param_1;
      *(uint *)(puVar1 + 0x14) = param_2;
      *(undefined4 *)(puVar1 + 0x18) = 0;
      *(undefined4 *)(puVar1 + 0xc) = 0;
      puVar1[1] = 1;
    }
    else {
      if ((param_3 != 1) && (__stream = fopen(param_1,"r+b"), __stream == (FILE *)0x0)) {
        *param_4 = 0x200;
        return (undefined1 *)0x0;
      }
      puVar1 = operator_new(0x1c);
      *(FILE **)(puVar1 + 4) = __stream;
      puVar1[8] = 0;
      *puVar1 = 1;
      puVar1[1] = 1;
      *(undefined4 *)(puVar1 + 0xc) = 0;
      fseek(__stream,0,0);
    }
    *param_4 = 0;
  }
  else {
    puVar1 = (undefined1 *)0x0;
    *param_4 = 0x10000;
  }
  return puVar1;
}
