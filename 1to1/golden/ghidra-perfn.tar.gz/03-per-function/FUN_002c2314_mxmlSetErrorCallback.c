/* ============================================================
 * mxmlSetErrorCallback   @ 0x002c2314   size=20B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

void mxmlSetErrorCallback(undefined4 param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)_mxml_global();
  *puVar1 = param_1;
  return;
}
