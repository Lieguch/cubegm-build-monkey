/* ============================================================
 * Find   @ 0x000128dc   size=180B   callers=2
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* TUnzip::Find(char const*, unsigned char, int*, ZIPENTRY*) */

undefined4 __thiscall
TUnzip::Find(TUnzip *this,char *param_1,uchar param_2,int *param_3,ZIPENTRY *param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  if (param_2 == '\0') {
    iVar2 = 1;
  }
  else {
    iVar2 = 2;
  }
  iVar2 = unzLocateFile(*(unz_s **)this,param_1,iVar2);
  if (iVar2 != 0) {
    if (param_3 != (int *)0x0) {
      *param_3 = -1;
    }
    if (param_4 == (ZIPENTRY *)0x0) {
      return 0x500;
    }
    memset(param_4,0,0x130);
    *(undefined4 *)param_4 = 0xffffffff;
    return 0x500;
  }
  if (*(int *)(this + 4) != -1) {
    unzCloseCurrentFile(*(unz_s **)this);
    *(undefined4 *)(this + 4) = 0xffffffff;
  }
  iVar2 = *(int *)(*(int *)this + 0x10);
  if (param_3 != (int *)0x0) {
    *param_3 = iVar2;
  }
  if (param_4 == (ZIPENTRY *)0x0) {
    return 0;
  }
  uVar1 = Get(this,iVar2,param_4);
  return uVar1;
}
