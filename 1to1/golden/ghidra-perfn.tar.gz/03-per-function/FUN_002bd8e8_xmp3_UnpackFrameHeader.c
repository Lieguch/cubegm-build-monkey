/* ============================================================
 * xmp3_UnpackFrameHeader   @ 0x002bd8e8   size=664B   callers=2
 * module: 06_helix_mp3
 * ============================================================ */

undefined4 xmp3_UnpackFrameHeader(int *param_1,char *param_2)

{
  uint uVar1;
  uint uVar2;
  byte bVar3;
  byte bVar4;
  int iVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  uint *puVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  int iVar13;
  int iVar14;
  uint in_r12;
  int iVar15;
  
  if ((((param_1 != (int *)0x0) && (puVar9 = (uint *)*param_1, puVar9 != (uint *)0x0)) &&
      (*param_2 == -1)) && ((param_2[1] & 0xe0U) == 0xe0)) {
    bVar3 = (byte)param_2[1] >> 3;
    if ((bVar3 & 3) == 0) {
      uVar10 = 2;
    }
    else {
      uVar10 = ~(uint)bVar3 & 1;
    }
    *puVar9 = uVar10;
    uVar12 = ((byte)param_2[1] & 7) >> 1;
    uVar7 = 4 - uVar12;
    puVar9[1] = uVar7;
    bVar3 = param_2[1];
    puVar9[2] = ~(uint)bVar3 & 1;
    uVar1 = (uint)((byte)param_2[2] >> 4);
    puVar9[3] = uVar1;
    bVar4 = param_2[2];
    uVar11 = (bVar4 & 0xf) >> 2;
    puVar9[4] = uVar11;
    uVar8 = ((byte)param_2[2] & 3) >> 1;
    puVar9[5] = uVar8;
    if (uVar1 == 0xf || uVar11 == 3) {
      in_r12 = 1;
    }
    if (uVar1 != 0xf && uVar11 != 3) {
      in_r12 = 0;
    }
    if (uVar7 == 4) {
      in_r12 = in_r12 | 1;
    }
    puVar9[6] = (byte)param_2[2] & 1;
    uVar2 = (uint)((byte)param_2[3] >> 6);
    puVar9[7] = uVar2;
    puVar9[8] = ((byte)param_2[3] & 0x3f) >> 4;
    puVar9[9] = ((byte)param_2[3] & 0xf) >> 3;
    puVar9[10] = ((byte)param_2[3] & 7) >> 2;
    puVar9[0xb] = (byte)param_2[3] & 3;
    if (in_r12 == 0) {
      puVar9[0xd] = (int)&xmp3_sfBandTable +
                    uVar10 * 0xde + (short)(ushort)(((uint)bVar4 << 0x1c) >> 0x1e) * 0x4a;
      if ((uVar2 == 1) || (puVar9[8] = 0, uVar2 != 3)) {
        iVar5 = 2;
      }
      else {
        iVar5 = 1;
      }
      iVar14 = uVar10 * 2;
      param_1[0x1ef] = iVar5;
      iVar13 = 3 - uVar12;
      iVar5 = *(int *)(xmp3_samplerateTab + (uVar10 * 3 + uVar11) * 4);
      if (uVar10 == 0) {
        iVar15 = 2;
      }
      else {
        iVar15 = 1;
      }
      param_1[0x1f1] = iVar15;
      param_1[0x1f0] = iVar5;
      iVar5 = __aeabi_idiv((int)*(short *)(xmp3_samplesPerFrameTab + (uVar10 * 3 + iVar13) * 2),
                           iVar15);
      param_1[0x1f5] = uVar10;
      param_1[500] = uVar7;
      param_1[0x1f2] = iVar5;
      if (uVar1 != 0) {
        if (uVar2 != 3) {
          iVar14 = iVar14 + 1;
        }
        if ((bVar3 & 1) == 0) {
          iVar5 = 2;
        }
        else {
          iVar5 = 0;
        }
        param_1[0x1ee] =
             *(short *)(xmp3_bitrateTab + (iVar13 * 0xf + uVar10 * 0x2d + uVar1) * 2) * 1000;
        param_1[499] = ((((int)*(short *)(xmp3_slotTab + (uVar11 * 0xf + uVar10 * 0x2d + uVar1) * 2)
                         - (int)*(short *)(xmp3_sideBytesTab + iVar14 * 2)) + -4) - iVar5) + uVar8;
      }
      if ((bVar3 & 1) == 0) {
        uVar6 = 6;
        uVar10 = (uint)CONCAT11(param_2[4],param_2[5]);
      }
      else {
        uVar6 = 4;
        uVar10 = 0;
      }
      puVar9[0xc] = uVar10;
      return uVar6;
    }
  }
  return 0xffffffff;
}
