/* ============================================================
 * stbtt_CompareUTF8toUTF16_bigendian   @ 0x0001f134   size=28B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

bool stbtt_CompareUTF8toUTF16_bigendian(void)

{
  undefined8 uVar1;
  
  uVar1 = stbtt__CompareUTF8toUTF16_bigendian_prefix();
  return (int)((ulonglong)uVar1 >> 0x20) == (int)uVar1;
}
