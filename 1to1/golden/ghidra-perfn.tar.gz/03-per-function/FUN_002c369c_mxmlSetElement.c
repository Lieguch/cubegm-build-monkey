/* ============================================================
 * mxmlSetElement   @ 0x002c369c   size=92B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlSetElement(int *param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  if ((param_1 == (int *)0x0) || (*param_1 != 0 || param_2 == 0)) {
    uVar2 = 0xffffffff;
  }
  else {
    if ((void *)param_1[6] != (void *)0x0) {
      free((void *)param_1[6]);
    }
    iVar1 = __strdup(param_2);
    uVar2 = 0;
    param_1[6] = iVar1;
  }
  return uVar2;
}
