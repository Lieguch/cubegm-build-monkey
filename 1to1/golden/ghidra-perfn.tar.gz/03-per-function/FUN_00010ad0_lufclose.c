/* ============================================================
 * lufclose   @ 0x00010ad0   size=60B   callers=2
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* lufclose(LUFILE*) */

undefined4 lufclose(LUFILE *param_1)

{
  if (param_1 != (LUFILE *)0x0) {
    if (*param_1 != (LUFILE)0x0) {
      fclose(*(FILE **)(param_1 + 4));
    }
    operator_delete(param_1);
    return 0;
  }
  return 0xffffffff;
}
