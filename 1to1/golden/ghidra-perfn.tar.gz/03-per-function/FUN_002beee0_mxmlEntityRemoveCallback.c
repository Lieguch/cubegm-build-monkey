/* ============================================================
 * mxmlEntityRemoveCallback   @ 0x002beee0   size=132B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

void mxmlEntityRemoveCallback(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  iVar1 = _mxml_global();
  iVar4 = *(int *)(iVar1 + 4);
  if (iVar4 < 1) {
    return;
  }
  if (param_1 == *(int *)(iVar1 + 8)) {
    iVar3 = 0;
  }
  else {
    piVar2 = (int *)(iVar1 + 8);
    iVar3 = 0;
    do {
      iVar3 = iVar3 + 1;
      if (iVar3 == iVar4) {
        return;
      }
      piVar2 = piVar2 + 1;
    } while (*piVar2 != param_1);
  }
  iVar4 = iVar4 + -1;
  *(int *)(iVar1 + 4) = iVar4;
  if (iVar3 < iVar4) {
    memmove((void *)(iVar1 + 8 + iVar3 * 4),(void *)(iVar1 + 8 + iVar3 * 4 + 4),(iVar4 - iVar3) * 4)
    ;
    return;
  }
  return;
}
