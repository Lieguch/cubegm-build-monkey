/* ============================================================
 * stbtt_GetGlyphBitmapSubpixel   @ 0x0001b8ac   size=372B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

void * stbtt_GetGlyphBitmapSubpixel
                 (float param_1,float param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 *param_5,undefined4 param_6,int *param_7,int *param_8,int *param_9,
                 int *param_10)

{
  undefined4 uVar1;
  int local_54;
  int local_50;
  int local_4c;
  int local_48;
  void *local_44;
  int local_40;
  int local_3c;
  int local_38;
  void *local_34;
  
  uVar1 = stbtt_GetGlyphShape(param_5,param_6,&local_44);
  if (param_1 == 0.0) {
    param_1 = param_2;
    if (param_2 == 0.0) {
      free(local_44);
      return (void *)0x0;
    }
  }
  else if (param_2 == 0.0) {
    param_2 = param_1;
  }
  stbtt_GetGlyphBitmapBoxSubpixel
            (param_1,param_2,param_3,param_4,param_5,param_6,&local_54,&local_50,&local_4c,&local_48
            );
  local_4c = local_4c - local_54;
  if (param_7 != (int *)0x0) {
    *param_7 = local_4c;
  }
  local_3c = local_48 - local_50;
  if (param_8 != (int *)0x0) {
    *param_8 = local_3c;
  }
  if (param_9 != (int *)0x0) {
    *param_9 = local_54;
  }
  if (param_10 != (int *)0x0) {
    *param_10 = local_50;
  }
  local_34 = (void *)0x0;
  local_40 = local_4c;
  if ((local_4c != 0 && local_3c != 0) &&
     (local_34 = malloc(local_3c * local_4c), local_34 != (void *)0x0)) {
    local_38 = local_4c;
    stbtt_Rasterize(0x3eb33333,param_1,param_2,param_3,param_4,&local_40,local_44,uVar1,local_54,
                    local_50,1,*param_5);
  }
  free(local_44);
  return local_34;
}
