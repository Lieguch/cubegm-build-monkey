/* ============================================================
 * mxmlNewOpaque   @ 0x002c2e48   size=56B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

int mxmlNewOpaque(undefined4 param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  if (param_2 == 0) {
    iVar1 = 0;
  }
  else {
    iVar1 = mxml_new(param_1,2);
    if (iVar1 != 0) {
      uVar2 = __strdup(param_2);
      *(undefined4 *)(iVar1 + 0x18) = uVar2;
    }
  }
  return iVar1;
}
