/* ============================================================
 * stbtt__csctx_rccurve_to   @ 0x00013ba4   size=112B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt__csctx_rccurve_to
               (float param_1,float param_2,float param_3,float param_4,float param_5,float param_6,
               int param_7)

{
  param_1 = param_1 + *(float *)(param_7 + 0x10);
  param_2 = param_2 + *(float *)(param_7 + 0x14);
  param_3 = param_1 + param_3;
  param_4 = param_2 + param_4;
  param_5 = param_3 + param_5;
  param_6 = param_4 + param_6;
  *(float *)(param_7 + 0x10) = param_5;
  *(float *)(param_7 + 0x14) = param_6;
  stbtt__csctx_v(param_7,4,(int)param_5,(int)param_6,(int)param_1,(int)param_2,(int)param_3,
                 (int)param_4);
  return;
}
