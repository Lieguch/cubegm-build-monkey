/* ============================================================
 * mxmlSetText   @ 0x002c3808   size=136B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlSetText(int *param_1,int param_2,int param_3)

{
  int iVar1;
  
  if ((param_1 != (int *)0x0) &&
     (((iVar1 = *param_1, iVar1 != 0 ||
       ((param_1 = (int *)param_1[4], param_1 != (int *)0x0 && (iVar1 = *param_1, iVar1 == 4)))) &&
      (iVar1 == 4 && param_3 != 0)))) {
    if ((void *)param_1[7] != (void *)0x0) {
      free((void *)param_1[7]);
    }
    param_1[6] = param_2;
    iVar1 = __strdup(param_3);
    param_1[7] = iVar1;
    return 0;
  }
  return 0xffffffff;
}
