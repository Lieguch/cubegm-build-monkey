/* ============================================================
 * inflate   @ 0x000104b0   size=1336B   callers=1
 * module: 07_zlib
 * ============================================================ */

/* inflate(z_stream_s*, int) */

int inflate(z_stream_s *param_1,int param_2)

{
  byte bVar1;
  int iVar2;
  char *pcVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  byte *pbVar7;
  byte *pbVar8;
  
  if (((param_1 == (z_stream_s *)0x0) ||
      (puVar4 = *(undefined4 **)(param_1 + 0x1c), puVar4 == (undefined4 *)0x0)) ||
     (pbVar7 = *(byte **)param_1, pbVar7 == (byte *)0x0)) {
switchD_000104e8_default:
    return -2;
  }
  if (param_2 == 4) {
    iVar6 = -5;
  }
  else {
    iVar6 = 0;
  }
  switch(*puVar4) {
  case 0:
    if (*(int *)(param_1 + 4) == 0) {
      return -5;
    }
    iVar5 = *(int *)(param_1 + 4) + -1;
    *(byte **)param_1 = pbVar7 + 1;
    *(int *)(param_1 + 4) = iVar5;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    bVar1 = *pbVar7;
    puVar4[1] = (uint)bVar1;
    if ((bVar1 & 0xf) != 8) {
      pcVar3 = "unknown compression method";
      goto LAB_00010574;
    }
    if ((uint)puVar4[4] < (bVar1 >> 4) + 8) {
      pcVar3 = "invalid window size";
      goto LAB_00010574;
    }
    *puVar4 = 1;
    iVar2 = iVar6;
    break;
  case 1:
    iVar5 = *(int *)(param_1 + 4);
    iVar2 = -5;
    break;
  case 2:
    iVar5 = *(int *)(param_1 + 4);
    iVar2 = -5;
    goto LAB_00010670;
  case 3:
    iVar5 = *(int *)(param_1 + 4);
    if (iVar5 == 0) {
      return -5;
    }
    goto LAB_000106b4;
  case 4:
    iVar5 = *(int *)(param_1 + 4);
    if (iVar5 == 0) {
      return -5;
    }
    goto LAB_000106f8;
  case 5:
    iVar5 = *(int *)(param_1 + 4);
    if (iVar5 == 0) {
      return -5;
    }
    goto LAB_0001073c;
  case 6:
    *puVar4 = 0xd;
    *(char **)(param_1 + 0x18) = "need dictionary";
    puVar4[1] = 0;
    return -2;
  case 7:
    iVar5 = -5;
    goto LAB_00010608;
  case 8:
    iVar5 = -5;
    goto LAB_0001090c;
  case 9:
    iVar5 = *(int *)(param_1 + 4);
    if (iVar5 == 0) {
      return -5;
    }
    goto LAB_000107dc;
  case 10:
    iVar5 = *(int *)(param_1 + 4);
    if (iVar5 == 0) {
      return -5;
    }
    goto LAB_00010824;
  case 0xb:
    iVar5 = *(int *)(param_1 + 4);
    iVar6 = -5;
    goto LAB_00010860;
  case 0xc:
    return 1;
  case 0xd:
    return -3;
  default:
    goto switchD_000104e8_default;
  }
  if (iVar5 == 0) {
    return iVar2;
  }
  pbVar8 = *(byte **)param_1;
  iVar5 = iVar5 + -1;
  *(int *)(param_1 + 4) = iVar5;
  pbVar7 = pbVar8 + 1;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *(byte **)param_1 = pbVar7;
  bVar1 = *pbVar8;
  if (((uint)bVar1 + puVar4[1] * 0x100) % 0x1f != 0) {
    pcVar3 = "incorrect header check";
LAB_00010574:
    *puVar4 = 0xd;
    *(char **)(param_1 + 0x18) = pcVar3;
    puVar4[1] = 5;
    return -3;
  }
  if ((bVar1 & 0x20) != 0) {
    *puVar4 = 2;
    iVar2 = iVar6;
LAB_00010670:
    if (iVar5 == 0) {
      return iVar2;
    }
    iVar5 = iVar5 + -1;
    *(byte **)param_1 = pbVar7 + 1;
    *(int *)(param_1 + 4) = iVar5;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    bVar1 = *pbVar7;
    *puVar4 = 3;
    puVar4[2] = (uint)bVar1 << 0x18;
    if (iVar5 == 0) {
      return iVar6;
    }
LAB_000106b4:
    pbVar7 = *(byte **)param_1;
    iVar5 = iVar5 + -1;
    *(int *)(param_1 + 4) = iVar5;
    *(byte **)param_1 = pbVar7 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    bVar1 = *pbVar7;
    *puVar4 = 4;
    puVar4[2] = puVar4[2] + (uint)bVar1 * 0x10000;
    if (iVar5 == 0) {
      return iVar6;
    }
LAB_000106f8:
    pbVar7 = *(byte **)param_1;
    iVar5 = iVar5 + -1;
    *(int *)(param_1 + 4) = iVar5;
    *(byte **)param_1 = pbVar7 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    bVar1 = *pbVar7;
    *puVar4 = 5;
    puVar4[2] = puVar4[2] + (uint)bVar1 * 0x100;
    if (iVar5 == 0) {
      return iVar6;
    }
LAB_0001073c:
    pbVar7 = *(byte **)param_1;
    *(int *)(param_1 + 4) = iVar5 + -1;
    *(byte **)param_1 = pbVar7 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    iVar6 = (uint)*pbVar7 + puVar4[2];
    puVar4[2] = iVar6;
    *(int *)(param_1 + 0x30) = iVar6;
    *puVar4 = 6;
    return 2;
  }
  *puVar4 = 7;
  iVar5 = iVar6;
LAB_00010608:
  iVar5 = inflate_blocks((inflate_blocks_state *)puVar4[5],param_1,iVar5);
  if (iVar5 == -3) {
    puVar4 = *(undefined4 **)(param_1 + 0x1c);
    *puVar4 = 0xd;
    puVar4[1] = 0;
    return -3;
  }
  if (iVar5 != 0) {
    if (iVar5 != 1) {
      return iVar5;
    }
    inflate_blocks_reset
              (*(inflate_blocks_state **)(*(int *)(param_1 + 0x1c) + 0x14),param_1,
               (ulong *)(*(int *)(param_1 + 0x1c) + 4));
    puVar4 = *(undefined4 **)(param_1 + 0x1c);
    if (puVar4[3] != 0) {
      *puVar4 = 0xc;
      return 1;
    }
    *puVar4 = 8;
    iVar5 = iVar6;
LAB_0001090c:
    if (*(int *)(param_1 + 4) == 0) {
      return iVar5;
    }
    pbVar7 = *(byte **)param_1;
    iVar5 = *(int *)(param_1 + 4) + -1;
    *(int *)(param_1 + 4) = iVar5;
    *(byte **)param_1 = pbVar7 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    bVar1 = *pbVar7;
    *puVar4 = 9;
    puVar4[2] = (uint)bVar1 << 0x18;
    if (iVar5 == 0) {
      return iVar6;
    }
LAB_000107dc:
    pbVar7 = *(byte **)param_1;
    iVar5 = iVar5 + -1;
    puVar4 = *(undefined4 **)(param_1 + 0x1c);
    *(int *)(param_1 + 4) = iVar5;
    *(byte **)param_1 = pbVar7 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    bVar1 = *pbVar7;
    *puVar4 = 10;
    puVar4[2] = puVar4[2] + (uint)bVar1 * 0x10000;
    if (iVar5 == 0) {
      return iVar6;
    }
LAB_00010824:
    pbVar7 = *(byte **)param_1;
    iVar5 = iVar5 + -1;
    puVar4 = *(undefined4 **)(param_1 + 0x1c);
    *(int *)(param_1 + 4) = iVar5;
    *(byte **)param_1 = pbVar7 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    bVar1 = *pbVar7;
    *puVar4 = 0xb;
    puVar4[2] = puVar4[2] + (uint)bVar1 * 0x100;
LAB_00010860:
    if (iVar5 != 0) {
      pbVar7 = *(byte **)param_1;
      puVar4 = *(undefined4 **)(param_1 + 0x1c);
      *(int *)(param_1 + 4) = iVar5 + -1;
      *(byte **)param_1 = pbVar7 + 1;
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      iVar6 = (uint)*pbVar7 + puVar4[2];
      puVar4[2] = iVar6;
      if (iVar6 == puVar4[1]) {
        *puVar4 = 0xc;
        return 1;
      }
      *puVar4 = 0xd;
      *(char **)(param_1 + 0x18) = "incorrect data check";
      puVar4[1] = 5;
      return -3;
    }
  }
  return iVar6;
}
