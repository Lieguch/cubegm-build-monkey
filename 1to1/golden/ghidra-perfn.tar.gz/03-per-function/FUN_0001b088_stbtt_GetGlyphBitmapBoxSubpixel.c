/* ============================================================
 * stbtt_GetGlyphBitmapBoxSubpixel   @ 0x0001b088   size=324B   callers=6
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_GetGlyphBitmapBoxSubpixel
               (float param_1,float param_2,float param_3,float param_4,undefined4 param_5,
               undefined4 param_6,int *param_7,int *param_8,int *param_9,int *param_10)

{
  int iVar1;
  uint in_fpscr;
  float fVar2;
  undefined4 local_38;
  int local_34;
  undefined4 local_30;
  int local_2c [2];
  
  local_38 = 0;
  local_34 = 0;
  iVar1 = stbtt_GetGlyphBox(param_5,param_6,&local_38,&local_34,&local_30,local_2c);
  if (iVar1 == 0) {
    if (param_7 != (int *)0x0) {
      *param_7 = 0;
    }
    if (param_8 != (int *)0x0) {
      *param_8 = 0;
    }
    if (param_9 != (int *)0x0) {
      *param_9 = 0;
    }
    if (param_10 != (int *)0x0) {
      *param_10 = 0;
    }
  }
  else {
    if (param_7 != (int *)0x0) {
      fVar2 = (float)VectorSignedToFloat(local_38,(byte)(in_fpscr >> 0x16) & 3);
      fVar2 = floorf(param_3 + fVar2 * param_1);
      *param_7 = (int)fVar2;
    }
    if (param_8 != (int *)0x0) {
      fVar2 = (float)VectorSignedToFloat(-local_2c[0],(byte)(in_fpscr >> 0x16) & 3);
      fVar2 = floorf(param_4 + fVar2 * param_2);
      *param_8 = (int)fVar2;
    }
    if (param_9 != (int *)0x0) {
      fVar2 = (float)VectorSignedToFloat(local_30,(byte)(in_fpscr >> 0x16) & 3);
      fVar2 = ceilf(param_3 + fVar2 * param_1);
      *param_9 = (int)fVar2;
    }
    if (param_10 != (int *)0x0) {
      fVar2 = (float)VectorSignedToFloat(-local_34,(byte)(in_fpscr >> 0x16) & 3);
      fVar2 = ceilf(param_4 + fVar2 * param_2);
      *param_10 = (int)fVar2;
      return;
    }
  }
  return;
}
