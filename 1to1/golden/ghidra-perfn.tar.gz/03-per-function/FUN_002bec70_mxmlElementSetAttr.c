/* ============================================================
 * mxmlElementSetAttr   @ 0x002bec70   size=104B   callers=2
 * module: 04_mini_xml
 * ============================================================ */

void mxmlElementSetAttr(int *param_1,int param_2,int param_3)

{
  void *__ptr;
  int iVar1;
  
  if (param_1 == (int *)0x0) {
    return;
  }
  if (*param_1 == 0 && param_2 != 0) {
    if (param_3 == 0) {
      __ptr = (void *)0x0;
    }
    else {
      __ptr = (void *)__strdup(param_3);
    }
    iVar1 = mxml_set_attr(param_1,param_2,__ptr);
    if (iVar1 != 0) {
      free(__ptr);
      return;
    }
    return;
  }
  return;
}
