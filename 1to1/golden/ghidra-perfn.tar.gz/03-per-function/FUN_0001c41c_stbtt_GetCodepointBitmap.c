/* ============================================================
 * stbtt_GetCodepointBitmap   @ 0x0001c41c   size=12B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_GetCodepointBitmap(undefined4 param_1,undefined4 param_2)

{
  stbtt_GetCodepointBitmapSubpixel(param_1,param_2,0);
  return;
}
