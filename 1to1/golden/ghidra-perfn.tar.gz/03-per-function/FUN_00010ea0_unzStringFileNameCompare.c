/* ============================================================
 * unzStringFileNameCompare   @ 0x00010ea0   size=16B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzStringFileNameCompare(char const*, char const*, int) */

void unzStringFileNameCompare(char *param_1,char *param_2,int param_3)

{
  if (param_3 != 1) {
    strcmpcasenosensitive_internal(param_1,param_2);
    return;
  }
  strcmp(param_1,param_2);
  return;
}
