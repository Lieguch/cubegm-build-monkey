/* ============================================================
 * unztell   @ 0x00011ef4   size=36B   callers=0
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unztell(unz_s*) */

undefined4 unztell(unz_s *param_1)

{
  if ((param_1 != (unz_s *)0x0) && (*(int *)(param_1 + 0x7c) != 0)) {
    return *(undefined4 *)(*(int *)(param_1 + 0x7c) + 0x18);
  }
  return 0xffffff9a;
}
