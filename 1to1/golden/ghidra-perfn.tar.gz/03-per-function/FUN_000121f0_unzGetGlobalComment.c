/* ============================================================
 * unzGetGlobalComment   @ 0x000121f0   size=148B   callers=0
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzGetGlobalComment(unz_s*, char*, unsigned long) */

uint unzGetGlobalComment(unz_s *param_1,char *param_2,ulong param_3)

{
  int iVar1;
  uint uVar2;
  
  if (param_1 == (unz_s *)0x0) {
    return 0xffffff9a;
  }
  uVar2 = *(uint *)(param_1 + 8);
  if (param_3 < *(uint *)(param_1 + 8)) {
    uVar2 = param_3;
  }
  iVar1 = lufseek(*(LUFILE **)param_1,*(int *)(param_1 + 0x1c) + 0x16,0);
  if (iVar1 == 0) {
    if (uVar2 == 0) {
      if (param_2 == (char *)0x0) {
        return 0;
      }
    }
    else {
      *param_2 = '\0';
      iVar1 = lufread(param_2,uVar2,1,*(LUFILE **)param_1);
      if (iVar1 != 1) {
        return 0xffffffff;
      }
    }
    if (*(uint *)(param_1 + 8) < param_3) {
      param_2[*(uint *)(param_1 + 8)] = '\0';
    }
    return uVar2;
  }
  return 0xffffffff;
}
