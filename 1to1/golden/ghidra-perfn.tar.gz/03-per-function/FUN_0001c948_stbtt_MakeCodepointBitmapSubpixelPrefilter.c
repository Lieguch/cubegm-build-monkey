/* ============================================================
 * stbtt_MakeCodepointBitmapSubpixelPrefilter   @ 0x0001c948   size=152B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_MakeCodepointBitmapSubpixelPrefilter
               (undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
               undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 in_stack_00000014;
  
  stbtt_FindGlyphIndex(param_5,in_stack_00000014);
  stbtt_MakeGlyphBitmapSubpixelPrefilter
            (param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  return;
}
