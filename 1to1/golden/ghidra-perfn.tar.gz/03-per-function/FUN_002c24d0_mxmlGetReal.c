/* ============================================================
 * mxmlGetReal   @ 0x002c24d0   size=76B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlGetReal(int *param_1)

{
  int *piVar1;
  
  if (param_1 != (int *)0x0) {
    if (*param_1 == 3) {
      return (int)*(undefined8 *)(param_1 + 6);
    }
    if (((*param_1 == 0) && (piVar1 = (int *)param_1[4], piVar1 != (int *)0x0)) && (*piVar1 == 3)) {
      return (int)*(undefined8 *)(piVar1 + 6);
    }
  }
  return 0;
}
