/* ============================================================
 * stbtt_GetCodepointBox   @ 0x00019dd4   size=60B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_GetCodepointBox
               (undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  
  uVar1 = stbtt_FindGlyphIndex();
  stbtt_GetGlyphBox(param_1,uVar1,param_3,param_4);
  return;
}
