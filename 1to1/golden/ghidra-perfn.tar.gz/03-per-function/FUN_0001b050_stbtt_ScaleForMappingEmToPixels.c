/* ============================================================
 * stbtt_ScaleForMappingEmToPixels   @ 0x0001b050   size=48B   callers=3
 * module: 05_stb_truetype_font
 * ============================================================ */

float stbtt_ScaleForMappingEmToPixels(float param_1,int param_2)

{
  int iVar1;
  uint in_fpscr;
  float fVar2;
  
  iVar1 = *(int *)(param_2 + 0x14) + 0x12;
  fVar2 = (float)VectorSignedToFloat((uint)*(byte *)(*(int *)(param_2 + 4) + iVar1 + 1) +
                                     (uint)*(byte *)(*(int *)(param_2 + 4) + iVar1) * 0x100,
                                     (byte)(in_fpscr >> 0x16) & 3);
  return param_1 / fVar2;
}
