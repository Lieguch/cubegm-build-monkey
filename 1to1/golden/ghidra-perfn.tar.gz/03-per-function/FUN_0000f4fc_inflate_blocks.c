/* ============================================================
 * inflate_blocks   @ 0x0000f4fc   size=2756B   callers=1
 * module: 07_zlib
 * ============================================================ */

/* inflate_blocks(inflate_blocks_state*, z_stream_s*, int) */

void inflate_blocks(inflate_blocks_state *param_1,z_stream_s *param_2,int param_3)

{
  byte bVar1;
  char *pcVar2;
  uint uVar3;
  void *pvVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  byte *pbVar9;
  int iVar10;
  int iVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  byte *__src;
  uint uVar15;
  void *pvVar16;
  uint uVar17;
  bool bVar18;
  void *local_50;
  uint local_38;
  uint local_34;
  inflate_huft_s *piStack_30;
  inflate_huft_s *apiStack_2c [2];
  
  local_50 = *(void **)(param_1 + 0x34);
  __src = *(byte **)param_2;
  uVar13 = *(uint *)(param_2 + 4);
  uVar14 = *(uint *)(param_1 + 0x20);
  uVar12 = *(uint *)(param_1 + 0x1c);
  if (local_50 < *(void **)(param_1 + 0x30)) {
    uVar15 = (int)*(void **)(param_1 + 0x30) + (-1 - (int)local_50);
  }
  else {
    uVar15 = *(int *)(param_1 + 0x2c) - (int)local_50;
  }
  uVar5 = *(undefined4 *)param_1;
LAB_0000f570:
  switch(uVar5) {
  case 0:
LAB_0000f6dc:
    if (2 < uVar12) goto LAB_0000f704;
    do {
      uVar6 = 0;
      iVar10 = param_3;
      if (uVar13 == 0) goto LAB_0000f7bc;
      bVar1 = *__src;
      uVar13 = uVar13 - 1;
      __src = __src + 1;
      param_3 = 0;
      uVar14 = uVar14 | (uint)bVar1 << (uVar12 & 0xff);
      uVar12 = uVar12 + 8;
LAB_0000f704:
      uVar6 = (uVar14 & 7) >> 1;
      *(uint *)(param_1 + 0x18) = uVar14 & 1;
      if (uVar6 == 2) {
        uVar14 = uVar14 >> 3;
        uVar12 = uVar12 - 3;
        *(undefined4 *)param_1 = 3;
LAB_0000fa58:
        if (uVar12 < 0xe) {
          pbVar9 = __src;
          if (uVar13 == 0) goto LAB_0000f8a8;
          while( true ) {
            __src = pbVar9 + 1;
            uVar13 = uVar13 - 1;
            uVar14 = uVar14 | (uint)*pbVar9 << (uVar12 & 0xff);
            uVar12 = uVar12 + 8;
            if (0xd < uVar12) break;
            pbVar9 = __src;
            if (uVar13 == 0) {
LAB_0000f8a4:
              param_3 = 0;
              goto LAB_0000f8a8;
            }
          }
          param_3 = 0;
        }
        *(uint *)(param_1 + 4) = uVar14 & 0x3fff;
        if ((0x1d < (uVar14 & 0x1f)) || (uVar15 = (uVar14 & 0x3ff) >> 5, 0x1d < uVar15)) {
          pcVar2 = "too many length or distance symbols";
LAB_0000fec4:
          iVar10 = *(int *)param_2;
LAB_0000fe78:
          *(undefined4 *)param_1 = 9;
          iVar11 = *(int *)(param_2 + 8);
          *(char **)(param_2 + 0x18) = pcVar2;
          *(uint *)(param_1 + 0x20) = uVar14;
          pbVar9 = __src + (iVar11 - iVar10);
          *(uint *)(param_1 + 0x1c) = uVar12;
          *(uint *)(param_2 + 4) = uVar13;
          *(byte **)param_2 = __src;
          goto LAB_0000fbfc;
        }
        iVar10 = (**(code **)(param_2 + 0x20))
                           (*(undefined4 *)(param_2 + 0x28),(uVar14 & 0x1f) + 0x102 + uVar15,4);
        *(int *)(param_1 + 0xc) = iVar10;
        if (iVar10 == 0) goto LAB_0000fed0;
        uVar14 = uVar14 >> 0xe;
        uVar12 = uVar12 - 0xe;
        uVar15 = 0;
        *(undefined4 *)(param_1 + 8) = 0;
        *(undefined4 *)param_1 = 4;
LAB_0000faf4:
        do {
          if (uVar12 < 3) {
            uVar6 = uVar13;
            iVar10 = param_3;
            if (uVar13 != 0) {
              uVar13 = uVar13 - 1;
              param_3 = 0;
              uVar14 = uVar14 | (uint)*__src << (uVar12 & 0xff);
              uVar12 = uVar12 + 8;
              __src = __src + 1;
              goto LAB_0000fb1c;
            }
            goto LAB_0000f7bc;
          }
LAB_0000fb1c:
          uVar12 = uVar12 - 3;
          *(uint *)(param_1 + 8) = uVar15 + 1;
          uVar6 = uVar14 & 7;
          uVar14 = uVar14 >> 3;
          *(uint *)(*(int *)(param_1 + 0xc) + *(int *)(border + uVar15 * 4) * 4) = uVar6;
          uVar15 = *(uint *)(param_1 + 8);
        } while (uVar15 < (*(uint *)(param_1 + 4) >> 10) + 4);
joined_r0x0000fb68:
        while (uVar15 < 0x13) {
          *(uint *)(param_1 + 8) = uVar15 + 1;
          *(undefined4 *)(*(int *)(param_1 + 0xc) + *(int *)(border + uVar15 * 4) * 4) = 0;
          uVar15 = *(uint *)(param_1 + 8);
        }
        *(undefined4 *)(param_1 + 0x10) = 7;
        iVar10 = inflate_trees_bits(*(uint **)(param_1 + 0xc),(uint *)(param_1 + 0x10),
                                    (inflate_huft_s **)(param_1 + 0x14),
                                    *(inflate_huft_s **)(param_1 + 0x24),param_2);
        if (iVar10 != 0) {
          (**(code **)(param_2 + 0x24))
                    (*(undefined4 *)(param_2 + 0x28),*(undefined4 *)(param_1 + 0xc));
          if (iVar10 == -3) {
            *(undefined4 *)param_1 = 9;
          }
          iVar11 = *(int *)param_2;
          goto LAB_0000f7c4;
        }
        *(undefined4 *)(param_1 + 8) = 0;
        *(undefined4 *)param_1 = 5;
        uVar15 = 0;
        while( true ) {
          uVar6 = *(uint *)(param_1 + 4) & 0x1f;
          uVar7 = (*(uint *)(param_1 + 4) & 0x3ff) >> 5;
          uVar3 = uVar6 + 0x102 + uVar7;
          if (uVar3 <= uVar15) break;
          uVar6 = *(uint *)(param_1 + 0x10);
          if (uVar12 < uVar6) {
            pbVar9 = __src;
            if (uVar13 == 0) goto LAB_0000f8a8;
            while( true ) {
              __src = pbVar9 + 1;
              uVar13 = uVar13 - 1;
              uVar14 = uVar14 | (uint)*pbVar9 << (uVar12 & 0xff);
              uVar12 = uVar12 + 8;
              if (uVar6 <= uVar12) break;
              pbVar9 = __src;
              if (uVar13 == 0) goto LAB_0000f8a4;
            }
            param_3 = 0;
          }
          iVar10 = *(int *)(param_1 + 0x14) + (*(uint *)(inflate_mask + uVar6 * 4) & uVar14) * 8;
          uVar7 = *(uint *)(iVar10 + 4);
          uVar6 = (uint)*(byte *)(iVar10 + 1);
          if (uVar7 < 0x10) {
            uVar14 = uVar14 >> uVar6;
            uVar12 = uVar12 - uVar6;
            *(uint *)(param_1 + 8) = uVar15 + 1;
            *(uint *)(*(int *)(param_1 + 0xc) + uVar15 * 4) = uVar7;
LAB_0000f844:
            uVar15 = *(uint *)(param_1 + 8);
          }
          else {
            if (uVar7 == 0x12) {
              iVar10 = 0xb;
              uVar17 = 7;
            }
            else {
              uVar17 = uVar7 - 0xe;
              iVar10 = 3;
            }
            if (uVar12 < uVar6 + uVar17) {
              pbVar9 = __src;
              if (uVar13 == 0) {
LAB_0000f8a8:
                iVar10 = *(int *)param_2;
                *(uint *)(param_1 + 0x20) = uVar14;
                iVar11 = *(int *)(param_2 + 8);
                *(uint *)(param_1 + 0x1c) = uVar12;
                *(byte **)(param_2 + 8) = __src + (iVar11 - iVar10);
                *(byte **)param_2 = __src;
                *(undefined4 *)(param_2 + 4) = 0;
                *(void **)(param_1 + 0x34) = local_50;
                inflate_flush(param_1,param_2,param_3);
                return;
              }
              while( true ) {
                __src = pbVar9 + 1;
                uVar13 = uVar13 - 1;
                uVar14 = uVar14 | (uint)*pbVar9 << (uVar12 & 0xff);
                uVar12 = uVar12 + 8;
                if (uVar6 + uVar17 <= uVar12) break;
                pbVar9 = __src;
                if (uVar13 == 0) goto LAB_0000f8a4;
              }
              param_3 = 0;
            }
            uVar12 = (uVar12 - uVar6) - uVar17;
            uVar6 = uVar14 >> uVar6;
            uVar14 = uVar6 >> (uVar17 & 0xff);
            iVar10 = (uVar6 & *(uint *)(inflate_mask + uVar17 * 4)) + iVar10;
            uVar6 = iVar10 + uVar15;
            if ((uVar3 < uVar6) || (uVar7 == 0x10 && uVar15 == 0)) {
              (**(code **)(param_2 + 0x24))
                        (*(undefined4 *)(param_2 + 0x28),*(undefined4 *)(param_1 + 0xc));
              iVar10 = *(int *)param_2;
              iVar11 = *(int *)(param_2 + 8);
              *(undefined4 *)param_1 = 9;
              *(char **)(param_2 + 0x18) = "invalid bit length repeat";
              *(uint *)(param_1 + 0x20) = uVar14;
              *(uint *)(param_1 + 0x1c) = uVar12;
              *(byte **)(param_2 + 8) = __src + (iVar11 - iVar10);
              *(uint *)(param_2 + 4) = uVar13;
              *(byte **)param_2 = __src;
              *(void **)(param_1 + 0x34) = local_50;
              inflate_flush(param_1,param_2,-3);
              return;
            }
            uVar5 = 0;
            bVar18 = uVar7 == 0x10;
            if (bVar18) {
              uVar7 = uVar15 + 0x3fffffff;
            }
            iVar11 = uVar15 << 2;
            if (bVar18) {
              iVar8 = *(int *)(param_1 + 0xc);
              uVar5 = *(undefined4 *)(iVar8 + uVar7 * 4);
            }
            else {
              iVar8 = *(int *)(param_1 + 0xc);
            }
            while( true ) {
              iVar10 = iVar10 + -1;
              *(undefined4 *)(iVar8 + iVar11) = uVar5;
              iVar11 = iVar11 + 4;
              if (iVar10 == 0) break;
              iVar8 = *(int *)(param_1 + 0xc);
            }
            *(uint *)(param_1 + 8) = uVar6;
            uVar15 = uVar6;
          }
        }
        *(undefined4 *)(param_1 + 0x14) = 0;
        local_38 = 9;
        local_34 = 6;
        iVar10 = inflate_trees_dynamic
                           (uVar6 + 0x101,uVar7 + 1,*(uint **)(param_1 + 0xc),&local_38,&local_34,
                            &piStack_30,apiStack_2c,*(inflate_huft_s **)(param_1 + 0x24),param_2);
        (**(code **)(param_2 + 0x24))
                  (*(undefined4 *)(param_2 + 0x28),*(undefined4 *)(param_1 + 0xc));
        if (iVar10 != 0) {
          if (iVar10 == -3) {
            *(undefined4 *)param_1 = 9;
          }
          iVar11 = *(int *)param_2;
          goto LAB_0000f7c4;
        }
        iVar10 = inflate_codes_new(local_38,local_34,piStack_30,apiStack_2c[0],param_2);
        if (iVar10 == 0) {
LAB_0000fed0:
          iVar10 = *(int *)param_2;
          *(uint *)(param_1 + 0x20) = uVar14;
          iVar11 = *(int *)(param_2 + 8);
          *(uint *)(param_1 + 0x1c) = uVar12;
          *(byte **)(param_2 + 8) = __src + (iVar11 - iVar10);
          *(uint *)(param_2 + 4) = uVar13;
          *(byte **)param_2 = __src;
          *(void **)(param_1 + 0x34) = local_50;
          inflate_flush(param_1,param_2,-4);
          return;
        }
        *(int *)(param_1 + 4) = iVar10;
        *(undefined4 *)param_1 = 6;
LAB_0000f648:
        iVar10 = *(int *)param_2;
        *(uint *)(param_1 + 0x20) = uVar14;
        iVar11 = *(int *)(param_2 + 8);
        *(uint *)(param_1 + 0x1c) = uVar12;
        *(byte **)(param_2 + 8) = __src + (iVar11 - iVar10);
        *(uint *)(param_2 + 4) = uVar13;
        *(byte **)param_2 = __src;
        *(void **)(param_1 + 0x34) = local_50;
        iVar10 = inflate_codes(param_1,param_2,param_3);
        if (iVar10 != 1) {
          inflate_flush(param_1,param_2,iVar10);
          return;
        }
        inflate_codes_free(*(inflate_codes_state **)(param_1 + 4),param_2);
        local_50 = *(void **)(param_1 + 0x34);
        pvVar16 = *(void **)(param_1 + 0x30);
        __src = *(byte **)param_2;
        bVar18 = local_50 < pvVar16;
        if (bVar18) {
          pvVar16 = (void *)((int)pvVar16 - (int)local_50);
        }
        uVar13 = *(uint *)(param_2 + 4);
        if (bVar18) {
          uVar15 = (int)pvVar16 - 1;
        }
        else {
          uVar15 = *(uint *)(param_1 + 0x2c);
        }
        uVar14 = *(uint *)(param_1 + 0x20);
        uVar12 = *(uint *)(param_1 + 0x1c);
        if (!bVar18) {
          uVar15 = uVar15 - (int)local_50;
        }
        goto LAB_0000f6cc;
      }
      if (uVar6 == 3) {
        uVar14 = uVar14 >> 3;
        iVar10 = *(int *)param_2;
        uVar12 = uVar12 - 3;
        pcVar2 = "invalid block type";
        goto LAB_0000fe78;
      }
      if (uVar6 == 1) {
        inflate_trees_fixed(&local_38,&local_34,&piStack_30,apiStack_2c,param_2);
        iVar10 = inflate_codes_new(local_38,local_34,piStack_30,apiStack_2c[0],param_2);
        *(int *)(param_1 + 4) = iVar10;
        if (iVar10 == 0) goto LAB_0000fed0;
        uVar14 = uVar14 >> 3;
        uVar12 = uVar12 - 3;
        *(undefined4 *)param_1 = 6;
        goto LAB_0000f648;
      }
      uVar6 = uVar12 - 3 & 7;
      uVar14 = (uVar14 >> 3) >> uVar6;
      uVar12 = (uVar12 - 3) - uVar6;
      *(undefined4 *)param_1 = 1;
LAB_0000f744:
      if (uVar12 < 0x20) {
        pbVar9 = __src;
        if (uVar13 == 0) goto LAB_0000f8a8;
        while( true ) {
          __src = pbVar9 + 1;
          uVar13 = uVar13 - 1;
          uVar14 = uVar14 | (uint)*pbVar9 << (uVar12 & 0xff);
          uVar12 = uVar12 + 8;
          if (0x1f < uVar12) break;
          pbVar9 = __src;
          if (uVar13 == 0) goto LAB_0000f8a4;
        }
        param_3 = 0;
      }
      uVar6 = ~uVar14 >> 0x10;
      if (uVar6 != (uVar14 & 0xffff)) {
        pcVar2 = "invalid stored block lengths";
        goto LAB_0000fec4;
      }
      *(uint *)(param_1 + 4) = uVar6;
      if (uVar6 != 0) goto LAB_0000f9b4;
      if (*(int *)(param_1 + 0x18) != 0) {
        *(undefined4 *)param_1 = 7;
        uVar12 = 0;
        uVar14 = 0;
        goto LAB_0000f948;
      }
      *(undefined4 *)param_1 = 0;
      uVar12 = 0;
      uVar14 = 0;
    } while( true );
  case 1:
    goto LAB_0000f744;
  case 2:
    goto LAB_0000f9c4;
  case 3:
    goto LAB_0000fa58;
  case 4:
    uVar15 = *(uint *)(param_1 + 8);
    if (uVar15 < (*(uint *)(param_1 + 4) >> 10) + 4) goto LAB_0000faf4;
    goto joined_r0x0000fb68;
  case 5:
    goto LAB_0000f844;
  case 6:
    goto LAB_0000f648;
  case 7:
LAB_0000f948:
    *(void **)(param_1 + 0x34) = local_50;
    iVar10 = inflate_flush(param_1,param_2,param_3);
    local_50 = *(void **)(param_1 + 0x34);
    if (local_50 != *(void **)(param_1 + 0x30)) {
      iVar11 = *(int *)param_2;
      *(uint *)(param_1 + 0x20) = uVar14;
      iVar8 = *(int *)(param_2 + 8);
      *(uint *)(param_1 + 0x1c) = uVar12;
      *(uint *)(param_2 + 4) = uVar13;
      *(byte **)param_2 = __src;
      *(byte **)(param_2 + 8) = __src + (iVar8 - iVar11);
      *(void **)(param_1 + 0x34) = local_50;
      inflate_flush(param_1,param_2,iVar10);
      return;
    }
    *(undefined4 *)param_1 = 8;
    break;
  case 8:
    break;
  case 9:
    iVar10 = *(int *)param_2;
    *(uint *)(param_1 + 0x20) = uVar14;
    iVar11 = *(int *)(param_2 + 8);
    *(uint *)(param_1 + 0x1c) = uVar12;
    pbVar9 = __src + (iVar11 - iVar10);
    *(uint *)(param_2 + 4) = uVar13;
    *(byte **)param_2 = __src;
LAB_0000fbfc:
    *(byte **)(param_2 + 8) = pbVar9;
    *(void **)(param_1 + 0x34) = local_50;
    inflate_flush(param_1,param_2,-3);
    return;
  default:
    iVar10 = *(int *)param_2;
    *(uint *)(param_1 + 0x20) = uVar14;
    iVar11 = *(int *)(param_2 + 8);
    *(uint *)(param_1 + 0x1c) = uVar12;
    *(byte **)(param_2 + 8) = __src + (iVar11 - iVar10);
    *(uint *)(param_2 + 4) = uVar13;
    *(byte **)param_2 = __src;
    *(void **)(param_1 + 0x34) = local_50;
    inflate_flush(param_1,param_2,-2);
    return;
  }
  iVar10 = *(int *)param_2;
  *(uint *)(param_1 + 0x20) = uVar14;
  iVar11 = *(int *)(param_2 + 8);
  *(uint *)(param_1 + 0x1c) = uVar12;
  *(byte **)(param_2 + 8) = __src + (iVar11 - iVar10);
  *(uint *)(param_2 + 4) = uVar13;
  *(byte **)param_2 = __src;
  *(void **)(param_1 + 0x34) = local_50;
  inflate_flush(param_1,param_2,1);
  return;
LAB_0000f9b4:
  uVar12 = 0;
  uVar14 = 0;
  *(undefined4 *)param_1 = 2;
LAB_0000f9c4:
  uVar6 = uVar13;
  iVar10 = param_3;
  if (uVar13 == 0) {
LAB_0000f7bc:
    uVar13 = uVar6;
    iVar11 = *(int *)param_2;
LAB_0000f7c4:
    iVar8 = *(int *)(param_2 + 8);
    *(uint *)(param_1 + 0x20) = uVar14;
    *(uint *)(param_1 + 0x1c) = uVar12;
    *(byte **)(param_2 + 8) = __src + (iVar8 - iVar11);
    *(uint *)(param_2 + 4) = uVar13;
    *(byte **)param_2 = __src;
    *(void **)(param_1 + 0x34) = local_50;
    inflate_flush(param_1,param_2,iVar10);
    return;
  }
  if (uVar15 == 0) {
    if (*(void **)(param_1 + 0x2c) == local_50) {
      pvVar16 = *(void **)(param_1 + 0x30);
      pvVar4 = *(void **)(param_1 + 0x28);
      if (pvVar16 != pvVar4) {
        if (pvVar16 < pvVar4) {
          uVar15 = (int)local_50 - (int)pvVar4;
        }
        else {
          uVar15 = (int)pvVar16 + (-1 - (int)pvVar4);
        }
        local_50 = pvVar4;
        if (uVar15 != 0) goto LAB_0000fca4;
      }
    }
    *(void **)(param_1 + 0x34) = local_50;
    iVar10 = inflate_flush(param_1,param_2,param_3);
    local_50 = *(void **)(param_1 + 0x34);
    pvVar16 = *(void **)(param_1 + 0x30);
    if (local_50 < pvVar16) {
      uVar15 = (int)pvVar16 + (-1 - (int)local_50);
      pvVar4 = *(void **)(param_1 + 0x2c);
    }
    else {
      pvVar4 = *(void **)(param_1 + 0x2c);
      uVar15 = (int)pvVar4 - (int)local_50;
    }
    if (local_50 == pvVar4) {
      pvVar4 = *(void **)(param_1 + 0x28);
      if (pvVar16 != pvVar4) {
        if (pvVar16 < pvVar4) {
          uVar15 = (int)local_50 - (int)pvVar4;
          local_50 = pvVar4;
        }
        else {
          uVar15 = (int)pvVar16 + (-1 - (int)pvVar4);
          local_50 = pvVar4;
        }
      }
    }
    if (uVar15 == 0) {
      iVar11 = *(int *)param_2;
      goto LAB_0000f7c4;
    }
  }
LAB_0000fca4:
  uVar6 = *(uint *)(param_1 + 4);
  if (uVar13 <= *(uint *)(param_1 + 4)) {
    uVar6 = uVar13;
  }
  if (uVar15 < uVar6) {
    uVar6 = uVar15;
  }
  uVar13 = uVar13 - uVar6;
  uVar15 = uVar15 - uVar6;
  memcpy(local_50,__src,uVar6);
  iVar10 = *(int *)(param_1 + 4);
  __src = __src + uVar6;
  *(uint *)(param_1 + 4) = iVar10 - uVar6;
  local_50 = (void *)((int)local_50 + uVar6);
  if (iVar10 - uVar6 != 0) goto code_r0x0000fcf4;
LAB_0000f6cc:
  if (*(int *)(param_1 + 0x18) != 0) {
    param_3 = 0;
    *(undefined4 *)param_1 = 7;
    goto LAB_0000f948;
  }
  *(undefined4 *)param_1 = 0;
  param_3 = 0;
  goto LAB_0000f6dc;
code_r0x0000fcf4:
  uVar5 = *(undefined4 *)param_1;
  param_3 = 0;
  goto LAB_0000f570;
}
