/* ============================================================
 * xmp3_AllocateBuffers   @ 0x002bdf1c   size=204B   callers=0
 * module: 06_helix_mp3
 * ============================================================ */

undefined1 * xmp3_AllocateBuffers(void)

{
  ClearBuffer(mp3DecInfo,0x7f0);
  mp3DecInfo._0_4_ = fh;
  mp3DecInfo._4_4_ = si;
  mp3DecInfo._8_4_ = sfi;
  mp3DecInfo._12_4_ = hi;
  mp3DecInfo._16_4_ = di;
  mp3DecInfo._20_4_ = mi;
  mp3DecInfo._24_4_ = sbi;
  ClearBuffer(fh,0x38);
  ClearBuffer(si,0x148);
  ClearBuffer(sfi,0x11c);
  ClearBuffer(hi,0x1210);
  ClearBuffer(di,0x348);
  ClearBuffer(mi,0x1b20);
  ClearBuffer(sbi,0x2204);
  return mp3DecInfo;
}
