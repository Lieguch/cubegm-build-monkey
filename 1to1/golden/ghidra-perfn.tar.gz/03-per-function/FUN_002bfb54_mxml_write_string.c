/* ============================================================
 * mxml_write_string   @ 0x002bfb54   size=172B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxml_write_string(char *param_1,undefined4 param_2,code *param_3)

{
  char cVar1;
  char *pcVar2;
  int iVar3;
  
  cVar1 = *param_1;
  while( true ) {
    if (cVar1 == '\0') {
      return 0;
    }
    pcVar2 = (char *)mxmlEntityGetName();
    if (pcVar2 == (char *)0x0) {
      iVar3 = (*param_3)(*param_1,param_2);
    }
    else {
      iVar3 = (*param_3)(0x26);
      if (iVar3 < 0) {
        return 0xffffffff;
      }
      cVar1 = *pcVar2;
      while (cVar1 != '\0') {
        iVar3 = (*param_3)(cVar1,param_2);
        if (iVar3 < 0) {
          return 0xffffffff;
        }
        pcVar2 = pcVar2 + 1;
        cVar1 = *pcVar2;
      }
      iVar3 = (*param_3)(0x3b,param_2);
    }
    if (iVar3 < 0) break;
    param_1 = param_1 + 1;
    cVar1 = *param_1;
  }
  return 0xffffffff;
}
