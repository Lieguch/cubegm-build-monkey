/* ============================================================
 * stbtt_GetGlyphShape   @ 0x00019eac   size=2296B   callers=5
 * module: 05_stb_truetype_font
 * ============================================================ */

void * stbtt_GetGlyphShape(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  short sVar2;
  ushort uVar3;
  int iVar4;
  void *__dest;
  void *pvVar5;
  byte bVar6;
  int iVar7;
  short *psVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  short *psVar12;
  short *psVar13;
  int iVar14;
  short *psVar15;
  byte bVar16;
  int iVar17;
  void *pvVar18;
  void *__ptr;
  byte *pbVar19;
  byte *pbVar20;
  int iVar21;
  int iVar22;
  int iVar23;
  byte bVar24;
  short sVar25;
  uint in_fpscr;
  uint uVar26;
  float fVar27;
  float fVar28;
  float fVar29;
  float fVar30;
  float fVar31;
  float fVar32;
  float fVar33;
  float fVar34;
  float fVar35;
  float fVar36;
  float fVar37;
  float fVar38;
  int local_d0;
  int local_c4;
  int local_bc;
  int local_b8;
  int local_b4;
  int local_b0;
  undefined4 local_a8;
  void *pvStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 local_98;
  void *pvStack_94;
  undefined4 local_90;
  void *pvStack_8c;
  undefined4 local_88;
  void *pvStack_84;
  undefined4 local_80;
  void *pvStack_7c;
  short *local_78;
  void *pvStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  void *pvStack_64;
  undefined4 local_60;
  void *pvStack_5c;
  undefined4 local_58;
  void *pvStack_54;
  void *local_50;
  void *pvStack_4c;
  
  if (*(int *)(param_1 + 0x3c) != 0) {
    pvStack_a4 = *(void **)((undefined1  [16])0x0 + (undefined1  [16])0x4);
    uStack_a0 = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0x8);
    uStack_9c = *(undefined4 *)((undefined1  [16])0x0 + (undefined1  [16])0xc);
    local_a8 = 1;
    local_98 = 0;
    local_90 = 0;
    local_88 = 0;
    local_80 = 0;
    local_78 = (short *)0x0;
    local_68 = 0;
    local_60 = 0;
    local_58 = 0;
    local_50 = (void *)0x0;
    pvStack_94 = pvStack_a4;
    pvStack_8c = pvStack_a4;
    pvStack_84 = pvStack_a4;
    pvStack_7c = pvStack_a4;
    pvStack_74 = pvStack_a4;
    uStack_70 = uStack_a0;
    uStack_6c = uStack_9c;
    pvStack_64 = pvStack_a4;
    pvStack_5c = pvStack_a4;
    pvStack_54 = pvStack_a4;
    pvStack_4c = pvStack_a4;
    iVar4 = stbtt__run_charstring(param_1,param_2,&local_a8);
    if (iVar4 != 0) {
      local_50 = malloc((int)pvStack_7c * 0xe);
      *param_3 = local_50;
      iVar4 = stbtt__run_charstring(param_1,param_2,&local_78);
      if (iVar4 != 0) {
        return pvStack_4c;
      }
    }
    *param_3 = 0;
    return (void *)0x0;
  }
  iVar4 = stbtt__GetGlyfOffset();
  iVar14 = *(int *)(param_1 + 4);
  *param_3 = 0;
  if (iVar4 < 0) {
    return (void *)0x0;
  }
  iVar9 = (int)(short)((ushort)*(byte *)(iVar14 + iVar4 + 1) +
                      (ushort)*(byte *)(iVar14 + iVar4) * 0x100);
  if (iVar9 < 1) {
    pvVar5 = (void *)0x0;
    __dest = pvVar5;
    if (iVar9 == -1) {
      pbVar19 = (byte *)(iVar14 + iVar4 + 10);
      pvVar18 = pvVar5;
      __ptr = pvVar5;
      do {
        local_78 = (short *)0x0;
        bVar16 = pbVar19[1];
        bVar6 = pbVar19[2];
        bVar24 = pbVar19[3];
        if ((bVar16 & 2) == 0) {
          fVar36 = 0.0;
          pbVar19 = pbVar19 + 4;
          fVar35 = fVar36;
        }
        else if ((bVar16 & 1) == 0) {
          fVar35 = (float)VectorSignedToFloat((int)(char)pbVar19[4],(byte)(in_fpscr >> 0x16) & 3);
          fVar36 = (float)VectorSignedToFloat((int)(char)pbVar19[5],(byte)(in_fpscr >> 0x16) & 3);
          pbVar19 = pbVar19 + 6;
        }
        else {
          fVar35 = (float)VectorSignedToFloat((int)(short)((ushort)pbVar19[5] +
                                                          (ushort)pbVar19[4] * 0x100),
                                              (byte)(in_fpscr >> 0x16) & 3);
          fVar36 = (float)VectorSignedToFloat((int)(short)((ushort)pbVar19[7] +
                                                          (ushort)pbVar19[6] * 0x100),
                                              (byte)(in_fpscr >> 0x16) & 3);
          pbVar19 = pbVar19 + 8;
        }
        if ((bVar16 & 8) == 0) {
          if ((bVar16 & 0x40) != 0) {
            pbVar20 = pbVar19 + 4;
            fVar27 = 0.0;
            fVar33 = (float)VectorSignedToFloat((int)(short)((ushort)pbVar19[1] +
                                                            (ushort)*pbVar19 * 0x100),
                                                (byte)(in_fpscr >> 0x16) & 3);
            fVar32 = (float)VectorSignedToFloat((int)(short)((ushort)pbVar19[3] +
                                                            (ushort)pbVar19[2] * 0x100),
                                                (byte)(in_fpscr >> 0x16) & 3);
            fVar33 = fVar33 * 6.1035156e-05;
            fVar32 = fVar32 * 6.1035156e-05;
            fVar37 = fVar27;
            fVar34 = fVar27;
            goto LAB_0001a4b0;
          }
          if ((bVar16 & 0x80) != 0) {
            pbVar20 = pbVar19 + 8;
            fVar37 = (float)VectorSignedToFloat((int)(short)((ushort)pbVar19[3] +
                                                            (ushort)pbVar19[2] * 0x100),
                                                (byte)(in_fpscr >> 0x16) & 3);
            fVar37 = fVar37 * 6.1035156e-05;
            fVar33 = (float)VectorSignedToFloat((int)(short)((ushort)pbVar19[1] +
                                                            (ushort)*pbVar19 * 0x100),
                                                (byte)(in_fpscr >> 0x16) & 3);
            fVar34 = (float)VectorSignedToFloat((int)(short)((ushort)pbVar19[5] +
                                                            (ushort)pbVar19[4] * 0x100),
                                                (byte)(in_fpscr >> 0x16) & 3);
            fVar32 = (float)VectorSignedToFloat((int)(short)((ushort)pbVar19[7] +
                                                            (ushort)pbVar19[6] * 0x100),
                                                (byte)(in_fpscr >> 0x16) & 3);
            fVar27 = fVar37 * fVar37;
            fVar33 = fVar33 * 6.1035156e-05;
            fVar34 = fVar34 * 6.1035156e-05;
            fVar32 = fVar32 * 6.1035156e-05;
            goto LAB_0001a4b0;
          }
          fVar37 = 0.0;
          fVar33 = 1.0;
          fVar38 = 1.0;
          fVar27 = 1.0;
          fVar32 = fVar33;
          fVar34 = fVar37;
        }
        else {
          pbVar20 = pbVar19 + 2;
          fVar27 = 0.0;
          fVar33 = (float)VectorSignedFixedToFloat
                                    ((int)(short)((ushort)pbVar19[1] + (ushort)*pbVar19 * 0x100),
                                     0x20,0xe);
          fVar32 = fVar33;
          fVar37 = fVar27;
          fVar34 = fVar27;
LAB_0001a4b0:
          fVar27 = fVar27 + fVar33 * fVar33;
          uVar26 = in_fpscr & 0xfffffff | (uint)(fVar27 < 0.0) << 0x1f;
          fVar38 = SQRT(fVar27);
          if (SUB41(uVar26 >> 0x1f,0)) {
            sqrtf(fVar27);
          }
          fVar28 = fVar34 * fVar34 + fVar32 * fVar32;
          in_fpscr = uVar26 & 0xfffffff | (uint)(fVar28 < 0.0) << 0x1f;
          fVar27 = SQRT(fVar28);
          pbVar19 = pbVar20;
          if (SUB41(in_fpscr >> 0x1f,0)) {
            sqrtf(fVar28);
          }
        }
        iVar4 = stbtt_GetGlyphShape(param_1,(uint)bVar24 + (uint)bVar6 * 0x100,&local_78);
        psVar12 = local_78;
        pvVar5 = pvVar18;
        __dest = __ptr;
        if (0 < iVar4) {
          psVar15 = local_78;
          do {
            psVar13 = psVar15 + 7;
            fVar30 = (float)VectorSignedToFloat((int)psVar15[1],(byte)(in_fpscr >> 0x16) & 3);
            fVar28 = (float)VectorSignedToFloat((int)*psVar15,(byte)(in_fpscr >> 0x16) & 3);
            fVar31 = (float)VectorSignedToFloat((int)psVar15[3],(byte)(in_fpscr >> 0x16) & 3);
            fVar29 = (float)VectorSignedToFloat((int)psVar15[2],(byte)(in_fpscr >> 0x16) & 3);
            psVar15[1] = (short)(int)((fVar32 * fVar30 + fVar28 * fVar37 + fVar36) * fVar27);
            *psVar15 = (short)(int)((fVar30 * fVar34 + fVar28 * fVar33 + fVar35) * fVar38);
            psVar15[2] = (short)(int)((fVar31 * fVar34 + fVar29 * fVar33 + fVar35) * fVar38);
            psVar15[3] = (short)(int)((fVar32 * fVar31 + fVar29 * fVar37 + fVar36) * fVar27);
            psVar15 = psVar13;
          } while (local_78 + iVar4 * 7 != psVar13);
          pvVar5 = (void *)(iVar4 + (int)pvVar18);
          __dest = malloc((int)pvVar5 * 0xe);
          if (__dest == (void *)0x0) {
            if (__ptr != (void *)0x0) {
              free(__ptr);
            }
            if (psVar12 == (short *)0x0) {
              return (void *)0x0;
            }
            free(psVar12);
            return (void *)0x0;
          }
          if (pvVar18 == (void *)0x0) {
            memcpy(__dest,psVar12,(int)pvVar5 * 0xe);
            if (__ptr != (void *)0x0) goto LAB_0001a610;
          }
          else {
            memcpy(__dest,__ptr,(int)pvVar18 * 0xe);
            memcpy((void *)((int)__dest + (int)pvVar18 * 0xe),psVar12,iVar4 * 0xe);
LAB_0001a610:
            free(__ptr);
          }
          free(psVar12);
        }
        pvVar18 = pvVar5;
        __ptr = __dest;
      } while ((bVar16 & 0x20) != 0);
    }
  }
  else {
    iVar1 = iVar9 * 2;
    iVar7 = iVar14 + iVar4 + 10;
    iVar10 = iVar4 + iVar1 + 10;
    iVar21 = (uint)*(byte *)(iVar7 + iVar1 + -2 + 1) + (uint)*(byte *)(iVar7 + iVar1 + -2) * 0x100;
    iVar11 = iVar21 + 1;
    pbVar19 = (byte *)(iVar14 + iVar4 + iVar1 + 0xc +
                                (uint)*(byte *)(iVar14 + iVar10 + 1) +
                                (uint)*(byte *)(iVar14 + iVar10) * 0x100);
    __dest = malloc((iVar1 + iVar11) * 0xe);
    if (__dest == (void *)0x0) {
      return (void *)0x0;
    }
    psVar15 = (short *)(iVar9 * 0x1c + (int)__dest);
    bVar16 = 0;
    psVar12 = psVar15;
    bVar6 = 0;
    do {
      bVar24 = bVar6 - 1;
      if (bVar6 == 0) {
        bVar16 = *pbVar19;
        if ((bVar16 & 8) == 0) {
          pbVar19 = pbVar19 + 1;
          bVar24 = bVar6;
        }
        else {
          bVar24 = pbVar19[1];
          pbVar19 = pbVar19 + 2;
        }
      }
      *(byte *)(psVar12 + 6) = bVar16;
      psVar12 = psVar12 + 7;
      bVar6 = bVar24;
    } while ((short *)((int)__dest + (iVar1 + iVar21) * 0xe + 0xe) != psVar12);
    sVar25 = 0;
    psVar13 = psVar15;
    do {
      while( true ) {
        psVar8 = psVar13;
        bVar16 = *(byte *)(psVar8 + 6);
        if ((bVar16 & 2) == 0) break;
        uVar3 = -(ushort)*pbVar19;
        if ((bVar16 & 0x10) != 0) {
          uVar3 = (ushort)*pbVar19;
        }
        sVar25 = sVar25 + uVar3;
        pbVar19 = pbVar19 + 1;
LAB_0001a054:
        *psVar8 = sVar25;
        psVar13 = psVar8 + 7;
        if (psVar8 + 7 == psVar12) goto LAB_0001a098;
      }
      if ((bVar16 & 0x10) != 0) goto LAB_0001a054;
      pbVar20 = pbVar19 + 2;
      sVar25 = sVar25 + (ushort)pbVar19[1] + (ushort)*pbVar19 * 0x100;
      *psVar8 = sVar25;
      psVar13 = psVar8 + 7;
      pbVar19 = pbVar20;
    } while (psVar8 + 7 != psVar12);
LAB_0001a098:
    sVar25 = 0;
    do {
      while( true ) {
        bVar16 = *(byte *)(psVar15 + 6);
        if ((bVar16 & 4) == 0) break;
        uVar3 = -(ushort)*pbVar19;
        if ((bVar16 & 0x20) != 0) {
          uVar3 = (ushort)*pbVar19;
        }
        sVar25 = sVar25 + uVar3;
        pbVar19 = pbVar19 + 1;
LAB_0001a0b8:
        psVar15[1] = sVar25;
        psVar15 = psVar15 + 7;
        if (psVar8 + 7 == psVar15) goto LAB_0001a104;
      }
      if ((bVar16 & 0x20) != 0) goto LAB_0001a0b8;
      bVar16 = *pbVar19;
      psVar12 = psVar15 + 7;
      pbVar20 = pbVar19 + 1;
      pbVar19 = pbVar19 + 2;
      sVar25 = sVar25 + (ushort)*pbVar20 + (ushort)bVar16 * 0x100;
      psVar15[1] = sVar25;
      psVar15 = psVar12;
    } while (psVar8 + 7 != psVar12);
LAB_0001a104:
    iVar21 = 0;
    local_d0 = 0;
    iVar14 = 0;
    local_c4 = 0;
    iVar4 = 0;
    local_b0 = 0;
    iVar9 = 0;
    local_b4 = 0;
    iVar10 = 0;
    local_b8 = 0;
    local_bc = 0;
    bVar16 = 0;
    do {
      while( true ) {
        iVar17 = (iVar1 + iVar10) * 0xe;
        sVar25 = *(short *)((int)__dest + iVar17);
        iVar22 = (int)sVar25;
        bVar6 = *(byte *)((int)__dest + iVar17 + 0xc);
        sVar2 = *(short *)((int)__dest + iVar17 + 2);
        iVar23 = (int)sVar2;
        if (iVar10 != iVar9) break;
        if (iVar10 != 0) {
          iVar4 = stbtt__close_shape(__dest,iVar4,iVar14,bVar16,local_bc,local_b8,local_b4,local_b0,
                                     local_c4,local_d0);
        }
        bVar16 = ~bVar6 & 1;
        local_bc = iVar22;
        local_b8 = iVar23;
        if ((bVar6 & 1) == 0) {
          local_b4 = iVar22;
          local_b0 = iVar23;
          if ((*(byte *)((int)__dest + iVar17 + 0x1a) & 1) == 0) {
            local_bc = *(short *)((int)__dest + iVar17 + 0xe) + iVar22 >> 1;
            local_b8 = *(short *)((int)__dest + iVar17 + 0x10) + iVar23 >> 1;
          }
          else {
            iVar10 = iVar10 + 1;
            local_b8 = (int)*(short *)((int)__dest + iVar17 + 0x10);
            local_bc = (int)*(short *)((int)__dest + iVar17 + 0xe);
          }
        }
        iVar17 = iVar4 * 0xe;
        iVar4 = iVar4 + 1;
        iVar9 = iVar21 * 2;
        *(undefined1 *)((int)__dest + iVar17 + 0xc) = 1;
        *(short *)((int)__dest + iVar17) = (short)local_bc;
        iVar14 = 0;
        *(short *)((int)__dest + iVar17 + 2) = (short)local_b8;
        *(undefined2 *)((int)__dest + iVar17 + 4) = 0;
        *(undefined2 *)((int)__dest + iVar17 + 6) = 0;
        iVar17 = iVar21 * 2;
        iVar21 = iVar21 + 1;
        iVar9 = (uint)*(byte *)(iVar7 + iVar9 + 1) + (uint)*(byte *)(iVar7 + iVar17) * 0x100 + 1;
LAB_0001a190:
        iVar10 = iVar10 + 1;
        if (iVar11 <= iVar10) goto LAB_0001a214;
      }
      if ((bVar6 & 1) == 0) {
        if (iVar14 == 0) {
          iVar14 = 1;
          local_d0 = iVar23;
          local_c4 = iVar22;
        }
        else {
          iVar17 = iVar4 * 0xe;
          iVar4 = iVar4 + 1;
          *(undefined1 *)((int)__dest + iVar17 + 0xc) = 3;
          *(short *)((int)__dest + iVar17) = (short)(iVar22 + local_c4 >> 1);
          iVar14 = 1;
          *(undefined2 *)((int)__dest + iVar17 + 4) = (undefined2)local_c4;
          *(undefined2 *)((int)__dest + iVar17 + 6) = (undefined2)local_d0;
          *(short *)((int)__dest + iVar17 + 2) = (short)(iVar23 + local_d0 >> 1);
          local_d0 = iVar23;
          local_c4 = iVar22;
        }
        goto LAB_0001a190;
      }
      iVar17 = iVar4 * 0xe;
      if (iVar14 == 0) {
        iVar4 = iVar4 + 1;
        *(undefined1 *)((int)__dest + iVar17 + 0xc) = 2;
        *(short *)((int)__dest + iVar17) = sVar25;
        *(short *)((int)__dest + iVar17 + 2) = sVar2;
        *(undefined2 *)((int)__dest + iVar17 + 4) = 0;
        *(undefined2 *)((int)__dest + iVar17 + 6) = 0;
        goto LAB_0001a190;
      }
      iVar10 = iVar10 + 1;
      iVar14 = 0;
      *(undefined1 *)((int)__dest + iVar17 + 0xc) = 3;
      iVar4 = iVar4 + 1;
      *(short *)((int)__dest + iVar17) = sVar25;
      *(short *)((int)__dest + iVar17 + 2) = sVar2;
      *(undefined2 *)((int)__dest + iVar17 + 4) = (undefined2)local_c4;
      *(undefined2 *)((int)__dest + iVar17 + 6) = (undefined2)local_d0;
    } while (iVar10 < iVar11);
LAB_0001a214:
    pvVar5 = (void *)stbtt__close_shape(__dest,iVar4,iVar14,bVar16,local_bc,local_b8,local_b4,
                                        local_b0,local_c4,local_d0);
  }
  *param_3 = __dest;
  return pvVar5;
}
