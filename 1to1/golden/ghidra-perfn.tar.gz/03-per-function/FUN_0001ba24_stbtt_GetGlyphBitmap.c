/* ============================================================
 * stbtt_GetGlyphBitmap   @ 0x0001ba24   size=12B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt_GetGlyphBitmap(undefined4 param_1,undefined4 param_2)

{
  stbtt_GetGlyphBitmapSubpixel(param_1,param_2,0);
  return;
}
