/* ============================================================
 * mxmlGetOpaque   @ 0x002c2474   size=68B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

int mxmlGetOpaque(int *param_1)

{
  if (param_1 == (int *)0x0) {
    return 0;
  }
  if (*param_1 != 2) {
    if (*param_1 == 0) {
      param_1 = (int *)param_1[4];
      if (param_1 == (int *)0x0) {
        return 0;
      }
      if (*param_1 == 2) goto LAB_002c24a8;
    }
    return 0;
  }
LAB_002c24a8:
  return param_1[6];
}
