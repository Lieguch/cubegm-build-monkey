/* ============================================================
 * inflate_blocks_new   @ 0x0000de78   size=224B   callers=1
 * module: 07_zlib
 * ============================================================ */

/* inflate_blocks_new(z_stream_s*, unsigned long (*)(unsigned long, unsigned char const*, unsigned
   int), unsigned int) */

inflate_blocks_state *
inflate_blocks_new(z_stream_s *param_1,_func_ulong_ulong_uchar_ptr_uint *param_2,uint param_3)

{
  inflate_blocks_state *piVar1;
  int iVar2;
  
  piVar1 = (inflate_blocks_state *)
           (**(code **)(param_1 + 0x20))(*(undefined4 *)(param_1 + 0x28),1,0x40);
  if (piVar1 != (inflate_blocks_state *)0x0) {
    iVar2 = (**(code **)(param_1 + 0x20))(*(undefined4 *)(param_1 + 0x28),8,0x5a0);
    *(int *)(piVar1 + 0x24) = iVar2;
    if (iVar2 == 0) {
      (**(code **)(param_1 + 0x24))(*(undefined4 *)(param_1 + 0x28),piVar1);
      piVar1 = (inflate_blocks_state *)0x0;
    }
    else {
      iVar2 = (**(code **)(param_1 + 0x20))(*(undefined4 *)(param_1 + 0x28),1,param_3);
      *(int *)(piVar1 + 0x28) = iVar2;
      if (iVar2 == 0) {
        (**(code **)(param_1 + 0x24))
                  (*(undefined4 *)(param_1 + 0x28),*(undefined4 *)(piVar1 + 0x24));
        (**(code **)(param_1 + 0x24))(*(undefined4 *)(param_1 + 0x28),piVar1);
        piVar1 = (inflate_blocks_state *)0x0;
      }
      else {
        *(_func_ulong_ulong_uchar_ptr_uint **)(piVar1 + 0x38) = param_2;
        *(uint *)(piVar1 + 0x2c) = iVar2 + param_3;
        *(undefined4 *)piVar1 = 0;
        inflate_blocks_reset(piVar1,param_1,(ulong *)0x0);
      }
    }
  }
  return piVar1;
}
