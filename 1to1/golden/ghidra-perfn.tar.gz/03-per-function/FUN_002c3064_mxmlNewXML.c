/* ============================================================
 * mxmlNewXML   @ 0x002c3064   size=68B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

void mxmlNewXML(undefined *param_1)

{
  char acStack_408 [1024];
  
  if (param_1 == (undefined *)0x0) {
    param_1 = &DAT_002dedcc;
  }
  snprintf(acStack_408,0x400,"?xml version=\"%s\" encoding=\"utf-8\"?",param_1);
  mxmlNewElement(0,acStack_408);
  return;
}
