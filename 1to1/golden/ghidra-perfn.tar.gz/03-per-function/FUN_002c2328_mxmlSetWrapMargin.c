/* ============================================================
 * mxmlSetWrapMargin   @ 0x002c2328   size=20B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

void mxmlSetWrapMargin(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = _mxml_global();
  *(undefined4 *)(iVar1 + 0x198) = param_1;
  return;
}
