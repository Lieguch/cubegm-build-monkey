/* ============================================================
 * mxmlGetType   @ 0x002c25a0   size=16B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlGetType(undefined4 *param_1)

{
  undefined4 uVar1;
  
  if (param_1 == (undefined4 *)0x0) {
    uVar1 = 0xffffffff;
  }
  else {
    uVar1 = *param_1;
  }
  return uVar1;
}
