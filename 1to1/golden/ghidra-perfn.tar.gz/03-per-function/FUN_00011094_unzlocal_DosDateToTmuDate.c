/* ============================================================
 * unzlocal_DosDateToTmuDate   @ 0x00011094   size=64B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzlocal_DosDateToTmuDate(unsigned long, tm_unz_s*) */

void unzlocal_DosDateToTmuDate(ulong param_1,tm_unz_s *param_2)

{
  *(ulong *)(param_2 + 0xc) = (param_1 & 0x1fffff) >> 0x10;
  *(ulong *)(param_2 + 0x10) = ((param_1 & 0x1ffffff) >> 0x15) - 1;
  *(ulong *)(param_2 + 0x14) = (param_1 >> 0x19) + 0x7bc;
  *(ulong *)(param_2 + 8) = (param_1 & 0xffff) >> 0xb;
  *(ulong *)(param_2 + 4) = (param_1 & 0x7ff) >> 5;
  *(ulong *)param_2 = (param_1 & 0x1f) << 1;
  return;
}
