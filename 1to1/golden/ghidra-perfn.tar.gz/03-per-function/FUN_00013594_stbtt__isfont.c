/* ============================================================
 * stbtt__isfont   @ 0x00013594   size=232B   callers=3
 * module: 05_stb_truetype_font
 * ============================================================ */

bool stbtt__isfont(char *param_1)

{
  char cVar1;
  
  cVar1 = *param_1;
  if (cVar1 == '1') {
    if (param_1[1] != '\0') {
      return false;
    }
  }
  else {
    if (cVar1 == 't') {
      if (param_1[1] == 'y') {
        if (param_1[2] != 'p') {
          return false;
        }
        return param_1[3] == '1';
      }
      if (param_1[1] != 'r') {
        return false;
      }
      if (param_1[2] != 'u') {
        return false;
      }
      return param_1[3] == 'e';
    }
    if (cVar1 == 'O') {
      if (param_1[1] != 'T') {
        return false;
      }
      if (param_1[2] != 'T') {
        return false;
      }
      return param_1[3] == 'O';
    }
    if (cVar1 != '\0') {
      return false;
    }
    if (param_1[1] != '\x01') {
      return false;
    }
  }
  if (param_1[2] != '\0') {
    return false;
  }
  return param_1[3] == '\0';
}
