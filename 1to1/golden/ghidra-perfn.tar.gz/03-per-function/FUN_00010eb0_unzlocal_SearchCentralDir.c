/* ============================================================
 * unzlocal_SearchCentralDir   @ 0x00010eb0   size=444B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* unzlocal_SearchCentralDir(LUFILE*) */

int unzlocal_SearchCentralDir(LUFILE *param_1)

{
  int iVar1;
  uint uVar2;
  void *__ptr;
  byte *pbVar3;
  byte *pbVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  
  iVar1 = lufseek(param_1,0,2);
  if (iVar1 != 0) {
    return 0;
  }
  uVar2 = luftell(param_1);
  if (uVar2 < 0xffff) {
    __ptr = malloc(0x404);
    if (__ptr == (void *)0x0) {
      return 0;
    }
    iVar1 = 0;
    uVar8 = uVar2;
    if (uVar2 < 5) goto LAB_00010ff8;
  }
  else {
    __ptr = malloc(0x404);
    if (__ptr == (void *)0x0) {
      return 0;
    }
    uVar8 = 0xffff;
  }
  uVar7 = 4;
  do {
    uVar7 = uVar7 + 0x400;
    if (uVar8 <= uVar7) {
      uVar7 = uVar8;
    }
    uVar5 = uVar7;
    if (0x403 < uVar7) {
      uVar5 = 0x404;
    }
    iVar1 = lufseek(param_1,uVar2 - uVar7,0);
    if (iVar1 != 0) break;
    iVar1 = lufread(__ptr,uVar5,1,param_1);
    if (iVar1 != 1) {
      iVar1 = 0;
      goto LAB_00010ff8;
    }
    pbVar4 = (byte *)((int)__ptr + (uVar5 - 3));
    iVar6 = uVar5 - 3;
    do {
      pbVar3 = pbVar4;
      iVar1 = iVar6 + -1;
      if (iVar6 < 1) goto LAB_00011054;
      pbVar4 = pbVar3 + -1;
    } while ((((((uint)*pbVar4 != (int)key2[4]) || ((uint)*pbVar3 != (int)key2[5])) ||
              ((uint)pbVar3[1] != (int)key2[6])) || ((uint)pbVar3[2] != (int)key2[7])) &&
            (((iVar6 = iVar1, (uint)*pbVar4 != (int)key2[0] || ((uint)*pbVar3 != (int)key2[1])) ||
             (((uint)pbVar3[1] != (int)key2[2] || ((uint)pbVar3[2] != (int)key2[3]))))));
    iVar1 = iVar1 + (uVar2 - uVar7);
    if (iVar1 != 0) goto LAB_00010ff8;
LAB_00011054:
  } while (uVar7 < uVar8);
  iVar1 = 0;
LAB_00010ff8:
  free(__ptr);
  return iVar1;
}
