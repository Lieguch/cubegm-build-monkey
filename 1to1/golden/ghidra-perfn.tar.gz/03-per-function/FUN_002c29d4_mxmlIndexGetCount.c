/* ============================================================
 * mxmlIndexGetCount   @ 0x002c29d4   size=12B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlIndexGetCount(int param_1)

{
  undefined4 uVar1;
  
  uVar1 = 0;
  if (param_1 != 0) {
    uVar1 = *(undefined4 *)(param_1 + 4);
  }
  return uVar1;
}
