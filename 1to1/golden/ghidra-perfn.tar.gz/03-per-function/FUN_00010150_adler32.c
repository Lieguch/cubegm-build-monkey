/* ============================================================
 * adler32   @ 0x00010150   size=392B   callers=0
 * module: 07_zlib
 * ============================================================ */

/* adler32(unsigned long, unsigned char const*, unsigned int) */

uint adler32(ulong param_1,uchar *param_2,uint param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  byte *pbVar14;
  uint uVar15;
  int iVar16;
  uint uVar17;
  uint uVar18;
  int iVar19;
  byte *pbVar20;
  uint uVar21;
  
  if (param_2 == (uchar *)0x0) {
    return 1;
  }
  uVar15 = param_1 & 0xffff;
  uVar21 = param_1 >> 0x10;
  do {
    if (param_3 == 0) {
      return uVar15 | uVar21 << 0x10;
    }
    uVar17 = param_3;
    if (0x15af < param_3) {
      uVar17 = 0x15b0;
    }
    param_3 = param_3 - uVar17;
    if (uVar17 < 0x10) {
LAB_000102b0:
      pbVar14 = param_2 + uVar17;
      do {
        pbVar20 = param_2 + 1;
        uVar15 = uVar15 + *param_2;
        uVar21 = uVar21 + uVar15;
        param_2 = pbVar20;
      } while (pbVar20 != pbVar14);
    }
    else {
      uVar18 = uVar17 - 0x10 & 0xfffffff0;
      pbVar14 = param_2 + 0x10;
      do {
        pbVar20 = pbVar14 + 0x10;
        iVar16 = pbVar14[-0x10] + uVar15;
        iVar1 = (uint)pbVar14[-0xf] + iVar16;
        iVar2 = (uint)pbVar14[-0xe] + iVar1;
        iVar3 = (uint)pbVar14[-0xd] + iVar2;
        iVar4 = (uint)pbVar14[-0xc] + iVar3;
        iVar5 = (uint)pbVar14[-0xb] + iVar4;
        iVar6 = (uint)pbVar14[-10] + iVar5;
        iVar7 = (uint)pbVar14[-9] + iVar6;
        iVar8 = (uint)pbVar14[-8] + iVar7;
        iVar9 = (uint)pbVar14[-7] + iVar8;
        iVar10 = (uint)pbVar14[-6] + iVar9;
        iVar11 = (uint)pbVar14[-5] + iVar10;
        iVar12 = (uint)pbVar14[-4] + iVar11;
        iVar13 = (uint)pbVar14[-3] + iVar12;
        iVar19 = (uint)pbVar14[-2] + iVar13;
        uVar15 = (uint)pbVar14[-1] + iVar19;
        uVar21 = uVar21 + iVar16 + iVar1 + iVar2 + iVar3 + iVar4 + iVar5 + iVar6 + iVar7 + iVar8 +
                          iVar9 + iVar10 + iVar11 + iVar12 + iVar13 + iVar19 + uVar15;
        pbVar14 = pbVar20;
      } while (param_2 + uVar18 + 0x20 != pbVar20);
      uVar17 = uVar17 - 0x10 & 0xf;
      param_2 = param_2 + uVar18 + 0x10;
      pbVar14 = param_2;
      if (uVar17 != 0) goto LAB_000102b0;
    }
    uVar15 = uVar15 % 0xfff1;
    uVar21 = uVar21 % 0xfff1;
    param_2 = pbVar14;
  } while( true );
}
