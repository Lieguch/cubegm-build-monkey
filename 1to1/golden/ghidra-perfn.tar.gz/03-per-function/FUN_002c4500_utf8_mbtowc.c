/* ============================================================
 * utf8_mbtowc   @ 0x002c4500   size=464B   callers=0
 * module: 08_iconv_encoding
 * ============================================================ */

undefined4 utf8_mbtowc(undefined4 param_1,uint *param_2,byte *param_3,uint param_4)

{
  byte bVar1;
  undefined4 uVar2;
  
  bVar1 = *param_3;
  if ((char)bVar1 < '\0') {
    if (bVar1 < 0xc2) {
      uVar2 = 0xffffffff;
    }
    else if (bVar1 < 0xe0) {
      if (param_4 < 2) {
        uVar2 = 0xfffffffe;
      }
      else if ((byte)~(param_3[1] ^ 0x7f) < 0x40) {
        *param_2 = (bVar1 & 0x1f) << 6 | (uint)(byte)~(param_3[1] ^ 0x7f);
        uVar2 = 2;
      }
      else {
        uVar2 = 0xffffffff;
      }
    }
    else if (bVar1 < 0xf0) {
      if (param_4 < 3) {
        uVar2 = 0xfffffffe;
      }
      else if (((((byte)~(param_3[1] ^ 0x7f) < 0x40) && ((byte)~(param_3[2] ^ 0x7f) < 0x40)) &&
               ((0xe0 < bVar1 || (0x9f < param_3[1])))) && ((bVar1 != 0xed || (param_3[1] < 0xa0))))
      {
        *param_2 = (uint)(ushort)((ushort)bVar1 << 0xc) | (uint)(byte)~(param_3[1] ^ 0x7f) << 6 |
                   (uint)(byte)~(param_3[2] ^ 0x7f);
        uVar2 = 3;
      }
      else {
        uVar2 = 0xffffffff;
      }
    }
    else if (bVar1 < 0xf8) {
      if (param_4 < 4) {
        uVar2 = 0xfffffffe;
      }
      else if ((((((byte)~(param_3[1] ^ 0x7f) < 0x40) && ((byte)~(param_3[2] ^ 0x7f) < 0x40)) &&
                ((byte)~(param_3[3] ^ 0x7f) < 0x40)) && ((0xf0 < bVar1 || (0x8f < param_3[1])))) &&
              ((bVar1 < 0xf4 || ((bVar1 == 0xf4 && (param_3[1] < 0x90)))))) {
        *param_2 = (bVar1 & 7) << 0x12 | (uint)(byte)~(param_3[1] ^ 0x7f) << 0xc |
                   (uint)(byte)~(param_3[2] ^ 0x7f) << 6 | (uint)(byte)~(param_3[3] ^ 0x7f);
        uVar2 = 4;
      }
      else {
        uVar2 = 0xffffffff;
      }
    }
    else {
      uVar2 = 0xffffffff;
    }
  }
  else {
    *param_2 = (uint)bVar1;
    uVar2 = 1;
  }
  return uVar2;
}
