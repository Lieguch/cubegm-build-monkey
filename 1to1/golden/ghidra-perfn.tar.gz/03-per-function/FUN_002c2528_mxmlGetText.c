/* ============================================================
 * mxmlGetText   @ 0x002c2528   size=120B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

int mxmlGetText(int *param_1,int *param_2)

{
  int *piVar1;
  
  if (param_1 != (int *)0x0) {
    if (*param_1 == 4) {
      if (param_2 != (int *)0x0) {
        *param_2 = param_1[6];
      }
      return param_1[7];
    }
    if (((*param_1 == 0) && (piVar1 = (int *)param_1[4], piVar1 != (int *)0x0)) && (*piVar1 == 4)) {
      if (param_2 != (int *)0x0) {
        *param_2 = piVar1[6];
      }
      return piVar1[7];
    }
  }
  if (param_2 != (int *)0x0) {
    *param_2 = 0;
    return 0;
  }
  return 0;
}
