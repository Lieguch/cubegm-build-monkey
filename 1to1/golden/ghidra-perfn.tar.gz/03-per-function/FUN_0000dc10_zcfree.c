/* ============================================================
 * zcfree   @ 0x0000dc10   size=8B   callers=0
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* zcfree(void*, void*) */

void zcfree(void *param_1,void *param_2)

{
  free(param_2);
  return;
}
