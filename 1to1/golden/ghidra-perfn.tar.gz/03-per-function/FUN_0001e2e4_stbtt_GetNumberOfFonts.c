/* ============================================================
 * stbtt_GetNumberOfFonts   @ 0x0001e2e4   size=156B   callers=0
 * module: 05_stb_truetype_font
 * ============================================================ */

int stbtt_GetNumberOfFonts(undefined4 param_1)

{
  char *pcVar1;
  undefined8 uVar2;
  
  uVar2 = stbtt__isfont(param_1,param_1);
  pcVar1 = (char *)((ulonglong)uVar2 >> 0x20);
  if ((int)uVar2 != 0) {
    return 1;
  }
  if (*pcVar1 != 't') {
    return 0;
  }
  if (pcVar1[1] != 't') {
    return 0;
  }
  if (pcVar1[2] != 'c') {
    return 0;
  }
  if (pcVar1[3] != 'f') {
    return 0;
  }
  if ((((uint)(byte)pcVar1[5] * 0x10000 + (uint)(byte)pcVar1[4] * 0x1000000 +
        (uint)(byte)pcVar1[6] * 0x100 + (uint)(byte)pcVar1[7]) - 0x10000 & 0xfffeffff) != 0) {
    return 0;
  }
  return (uint)(byte)pcVar1[9] * 0x10000 + (uint)(byte)pcVar1[8] * 0x1000000 +
         (uint)(byte)pcVar1[10] * 0x100 + (uint)(byte)pcVar1[0xb];
}
