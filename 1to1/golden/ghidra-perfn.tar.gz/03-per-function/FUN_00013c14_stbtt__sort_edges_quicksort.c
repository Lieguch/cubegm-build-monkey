/* ============================================================
 * stbtt__sort_edges_quicksort   @ 0x00013c14   size=568B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt__sort_edges_quicksort(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined4 uVar11;
  int iVar12;
  undefined4 *puVar13;
  undefined4 *puVar14;
  float fVar15;
  float fVar16;
  
joined_r0x00013c24:
  if (param_2 < 0xd) {
    return;
  }
  puVar10 = param_1 + (param_2 >> 1) * 5;
  fVar15 = (float)param_1[param_2 * 5 + -4];
  fVar16 = (float)puVar10[1];
  if ((float)param_1[1] < fVar16 != fVar16 < fVar15) {
    if ((float)param_1[1] < fVar15 == fVar16 < fVar15) {
      iVar9 = 0;
    }
    else {
      iVar9 = param_2 * 0x14 + -0x14;
    }
    puVar14 = (undefined4 *)((int)param_1 + iVar9);
    uVar2 = *puVar14;
    uVar3 = puVar14[1];
    uVar5 = puVar14[2];
    uVar7 = puVar14[3];
    uVar4 = puVar10[1];
    uVar6 = puVar10[2];
    uVar8 = puVar10[3];
    uVar11 = puVar14[4];
    *puVar14 = *puVar10;
    puVar14[1] = uVar4;
    puVar14[2] = uVar6;
    puVar14[3] = uVar8;
    puVar14[4] = puVar10[4];
    *puVar10 = uVar2;
    puVar10[1] = uVar3;
    puVar10[2] = uVar5;
    puVar10[3] = uVar7;
    puVar10[4] = uVar11;
  }
  iVar9 = param_2 + -1;
  uVar2 = *param_1;
  uVar3 = param_1[1];
  uVar5 = param_1[2];
  uVar7 = param_1[3];
  uVar4 = puVar10[1];
  uVar6 = puVar10[2];
  uVar8 = puVar10[3];
  uVar11 = param_1[4];
  iVar12 = 2;
  *param_1 = *puVar10;
  param_1[1] = uVar4;
  param_1[2] = uVar6;
  param_1[3] = uVar8;
  param_1[4] = puVar10[4];
  *puVar10 = uVar2;
  puVar10[1] = uVar3;
  puVar10[2] = uVar5;
  puVar10[3] = uVar7;
  puVar10[4] = uVar11;
  fVar15 = (float)param_1[1];
  puVar10 = param_1;
  do {
    puVar14 = puVar10 + 5;
    if (fVar15 <= (float)puVar10[6]) {
      puVar13 = param_1 + iVar9 * 5;
      if (fVar15 < (float)puVar13[1]) {
        puVar1 = param_1 + iVar9 * 5 + -5;
        do {
          puVar13 = puVar1;
          iVar9 = iVar9 + -1;
          puVar1 = puVar13 + -5;
        } while (fVar15 < (float)puVar13[1]);
      }
      if (iVar9 <= iVar12 + -1) break;
      uVar2 = *puVar14;
      uVar3 = puVar10[6];
      uVar5 = puVar10[7];
      uVar7 = puVar10[8];
      iVar9 = iVar9 + -1;
      uVar4 = puVar13[1];
      uVar6 = puVar13[2];
      uVar8 = puVar13[3];
      uVar11 = puVar10[9];
      *puVar14 = *puVar13;
      puVar10[6] = uVar4;
      puVar10[7] = uVar6;
      puVar10[8] = uVar8;
      puVar10[9] = puVar13[4];
      *puVar13 = uVar2;
      puVar13[1] = uVar3;
      puVar13[2] = uVar5;
      puVar13[3] = uVar7;
      puVar13[4] = uVar11;
      fVar15 = (float)param_1[1];
    }
    iVar12 = iVar12 + 1;
    puVar10 = puVar14;
  } while( true );
  param_2 = param_2 - (iVar12 + -1);
  if (iVar9 < param_2) {
    stbtt__sort_edges_quicksort(param_1,iVar9);
    param_1 = puVar14;
  }
  else {
    stbtt__sort_edges_quicksort(puVar14,param_2);
    param_2 = iVar9;
  }
  goto joined_r0x00013c24;
}
