/* ============================================================
 * mxmlDelete   @ 0x002c2f44   size=288B   callers=7
 * module: 04_mini_xml
 * ============================================================ */

void mxmlDelete(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  void *pvVar3;
  void *pvVar4;
  
  if (param_1 == (undefined4 *)0x0) {
    return;
  }
  mxmlRemove();
  iVar2 = param_1[4];
  while (iVar2 != 0) {
    mxmlDelete();
    iVar2 = param_1[4];
  }
  switch(*param_1) {
  case 0:
    if ((void *)param_1[6] != (void *)0x0) {
      free((void *)param_1[6]);
    }
    if (param_1[7] != 0) {
      pvVar4 = (void *)param_1[8];
      if (0 < (int)param_1[7]) {
        iVar2 = 0;
        do {
          pvVar3 = *(void **)((int)pvVar4 + iVar2 * 8);
          iVar1 = iVar2 * 8;
          iVar2 = iVar2 + 1;
          if (pvVar3 != (void *)0x0) {
            free(pvVar3);
            pvVar4 = (void *)param_1[8];
          }
          pvVar3 = *(void **)((int)pvVar4 + iVar1 + 4);
          if (pvVar3 != (void *)0x0) {
            free(pvVar3);
            pvVar4 = (void *)param_1[8];
          }
        } while (iVar2 < (int)param_1[7]);
      }
      free(pvVar4);
    }
    break;
  case 1:
    break;
  case 2:
    pvVar4 = (void *)param_1[6];
    goto joined_r0x002c305c;
  case 3:
    break;
  case 4:
    pvVar4 = (void *)param_1[7];
joined_r0x002c305c:
    if (pvVar4 != (void *)0x0) {
      free(pvVar4);
      free(param_1);
      return;
    }
    break;
  case 5:
    if ((param_1[6] != 0) && ((code *)param_1[7] != (code *)0x0)) {
      (*(code *)param_1[7])();
    }
  }
  free(param_1);
  return;
}
