/* ============================================================
 * stbtt_GetFontOffsetForIndex   @ 0x0001e204   size=224B   callers=3
 * module: 05_stb_truetype_font
 * ============================================================ */

int stbtt_GetFontOffsetForIndex(char *param_1)

{
  int iVar1;
  undefined8 uVar2;
  
  uVar2 = stbtt__isfont();
  iVar1 = (int)((ulonglong)uVar2 >> 0x20);
  if ((int)uVar2 != 0) {
    return -(uint)(iVar1 != 0);
  }
  if ((((*param_1 == 't') && (param_1[1] == 't')) && (param_1[2] == 'c')) &&
     (((param_1[3] == 'f' &&
       ((((uint)(byte)param_1[5] * 0x10000 + (uint)(byte)param_1[4] * 0x1000000 +
          (uint)(byte)param_1[6] * 0x100 + (uint)(byte)param_1[7]) - 0x10000 & 0xfffeffff) == 0)) &&
      (iVar1 < (int)((uint)(byte)param_1[9] * 0x10000 + (uint)(byte)param_1[8] * 0x1000000 +
                     (uint)(byte)param_1[10] * 0x100 + (uint)(byte)param_1[0xb]))))) {
    iVar1 = iVar1 * 4;
    return (uint)(byte)param_1[iVar1 + 0xd] * 0x10000 + (uint)(byte)param_1[iVar1 + 0xc] * 0x1000000
           + (uint)(byte)param_1[iVar1 + 0xe] * 0x100 + (uint)(byte)param_1[iVar1 + 0xf];
  }
  return -1;
}
