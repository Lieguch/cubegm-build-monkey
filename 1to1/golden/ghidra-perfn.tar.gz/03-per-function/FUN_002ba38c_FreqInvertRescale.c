/* ============================================================
 * FreqInvertRescale   @ 0x002ba38c   size=460B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

uint FreqInvertRescale(int param_1,int param_2,uint param_3,uint param_4)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  
  if (param_4 == 0) {
    if ((param_3 & 1) != 0) {
      *(int *)(param_1 + 0x180) = -*(int *)(param_1 + 0x180);
      *(int *)(param_1 + 0x280) = -*(int *)(param_1 + 0x280);
      *(int *)(param_1 + 0x380) = -*(int *)(param_1 + 0x380);
      *(int *)(param_1 + 0x480) = -*(int *)(param_1 + 0x480);
      *(int *)(param_1 + 0x580) = -*(int *)(param_1 + 0x580);
      *(int *)(param_1 + 0x680) = -*(int *)(param_1 + 0x680);
      *(int *)(param_1 + 0x780) = -*(int *)(param_1 + 0x780);
      *(int *)(param_1 + 0x880) = -*(int *)(param_1 + 0x880);
      *(int *)(param_1 + 0x80) = -*(int *)(param_1 + 0x80);
    }
    return 0;
  }
  if ((param_3 & 1) != 0) {
    uVar3 = 0x1f - param_4;
    uVar2 = 0;
    iVar8 = param_1 + 0x100;
    puVar1 = (uint *)(param_2 + -4);
    uVar4 = ~(-1 << (uVar3 & 0xff));
    do {
      uVar5 = *(uint *)(iVar8 + -0x100);
      if ((int)uVar5 >> 0x1f != (int)uVar5 >> (uVar3 & 0xff)) {
        uVar5 = (int)uVar5 >> 0x1f ^ uVar4;
      }
      uVar5 = uVar5 << (param_4 & 0xff);
      *(uint *)(iVar8 + -0x100) = uVar5;
      uVar6 = -*(int *)(iVar8 + -0x80);
      if ((int)uVar6 >> 0x1f != (int)uVar6 >> (uVar3 & 0xff)) {
        uVar6 = uVar4 ^ (int)uVar6 >> 0x1f;
      }
      uVar6 = uVar6 << (param_4 & 0xff);
      *(uint *)(iVar8 + -0x80) = uVar6;
      puVar1 = puVar1 + 1;
      uVar7 = *puVar1;
      uVar2 = uVar2 | (uVar5 ^ (int)uVar5 >> 0x1f) - ((int)uVar5 >> 0x1f) |
                      (uVar6 ^ (int)uVar6 >> 0x1f) - ((int)uVar6 >> 0x1f);
      iVar8 = iVar8 + 0x100;
      if ((int)uVar7 >> 0x1f != (int)uVar7 >> (uVar3 & 0xff)) {
        uVar7 = uVar4 ^ (int)uVar7 >> 0x1f;
      }
      *puVar1 = uVar7 << (param_4 & 0xff);
    } while (param_1 + 0xa00 != iVar8);
    return uVar2;
  }
  uVar3 = 0x1f - param_4;
  iVar8 = param_1 + 0x100;
  puVar1 = (uint *)(param_2 + -4);
  uVar4 = ~(-1 << (uVar3 & 0xff));
  uVar2 = 0;
  do {
    uVar5 = *(uint *)(iVar8 + -0x100);
    if ((int)uVar5 >> 0x1f != (int)uVar5 >> (uVar3 & 0xff)) {
      uVar5 = (int)uVar5 >> 0x1f ^ uVar4;
    }
    uVar5 = uVar5 << (param_4 & 0xff);
    *(uint *)(iVar8 + -0x100) = uVar5;
    uVar6 = *(uint *)(iVar8 + -0x80);
    if ((int)uVar6 >> 0x1f != (int)uVar6 >> (uVar3 & 0xff)) {
      uVar6 = uVar4 ^ (int)uVar6 >> 0x1f;
    }
    uVar6 = uVar6 << (param_4 & 0xff);
    *(uint *)(iVar8 + -0x80) = uVar6;
    puVar1 = puVar1 + 1;
    uVar7 = *puVar1;
    uVar2 = uVar2 | (uVar5 ^ (int)uVar5 >> 0x1f) - ((int)uVar5 >> 0x1f) |
                    (uVar6 ^ (int)uVar6 >> 0x1f) - ((int)uVar6 >> 0x1f);
    iVar8 = iVar8 + 0x100;
    if ((int)uVar7 >> 0x1f != (int)uVar7 >> (uVar3 & 0xff)) {
      uVar7 = uVar4 ^ (int)uVar7 >> 0x1f;
    }
    *puVar1 = uVar7 << (param_4 & 0xff);
  } while (iVar8 != param_1 + 0xa00);
  return uVar2;
}
