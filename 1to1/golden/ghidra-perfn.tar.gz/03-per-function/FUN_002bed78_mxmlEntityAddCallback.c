/* ============================================================
 * mxmlEntityAddCallback   @ 0x002bed78   size=72B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlEntityAddCallback(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = _mxml_global();
  iVar2 = *(int *)(iVar1 + 4);
  if (iVar2 < 100) {
    *(undefined4 *)(iVar1 + (iVar2 + 2) * 4) = param_1;
    *(int *)(iVar1 + 4) = iVar2 + 1;
    return 0;
  }
  mxml_error("Unable to add entity callback!");
  return 0xffffffff;
}
