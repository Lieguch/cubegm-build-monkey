/* ============================================================
 * stbtt__csctx_rmove_to   @ 0x00013ae8   size=104B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt__csctx_rmove_to(int param_1)

{
  float fVar1;
  undefined8 uVar2;
  float fVar3;
  
  uVar2 = stbtt__csctx_close_shape();
  fVar3 = (float)((ulonglong)uVar2 >> 0x20) + *(float *)(param_1 + 0x14);
  fVar1 = (float)uVar2 + *(float *)(param_1 + 0x10);
  *(float *)(param_1 + 0x14) = fVar3;
  *(float *)(param_1 + 0xc) = fVar3;
  *(float *)(param_1 + 0x10) = fVar1;
  *(float *)(param_1 + 8) = fVar1;
  stbtt__csctx_v(param_1,1,(int)fVar1,(int)fVar3,0,0,0,0);
  return;
}
