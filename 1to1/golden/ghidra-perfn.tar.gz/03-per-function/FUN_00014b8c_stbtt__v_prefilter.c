/* ============================================================
 * stbtt__v_prefilter   @ 0x00014b8c   size=800B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

void stbtt__v_prefilter(int param_1,int param_2,uint param_3,int param_4,size_t param_5)

{
  undefined1 uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  undefined1 *puVar7;
  int iVar8;
  byte local_30 [12];
  
  local_30[0] = 0;
  local_30[1] = 0;
  local_30[2] = 0;
  local_30[3] = 0;
  local_30[4] = 0;
  local_30[5] = 0;
  local_30[6] = 0;
  local_30[7] = 0;
  iVar3 = param_3 - param_5;
  if (0 < param_2) {
    param_2 = param_1 + param_2;
    do {
      memset(local_30,0,param_5);
      switch(param_5) {
      case 2:
        if (iVar3 < 0) {
LAB_00014ea0:
          uVar5 = 0;
          uVar6 = uVar5;
        }
        else {
          iVar8 = 0;
          uVar6 = 0;
          uVar5 = 0;
          do {
            uVar2 = uVar5 & 7;
            uVar4 = uVar5 + 2;
            uVar5 = uVar5 + 1;
            uVar6 = uVar6 + ((uint)*(byte *)(param_1 + iVar8) - (uint)local_30[uVar2]);
            local_30[uVar4 & 7] = *(byte *)(param_1 + iVar8);
            *(char *)(param_1 + iVar8) = (char)(uVar6 >> 1);
            iVar8 = iVar8 + param_4;
          } while (uVar5 != iVar3 + 1U);
        }
        break;
      case 3:
        if (iVar3 < 0) goto LAB_00014ea0;
        iVar8 = 0;
        uVar6 = 0;
        uVar5 = 0;
        do {
          uVar2 = uVar5 & 7;
          uVar4 = uVar5 + 3;
          uVar5 = uVar5 + 1;
          uVar6 = uVar6 + ((uint)*(byte *)(param_1 + iVar8) - (uint)local_30[uVar2]);
          local_30[uVar4 & 7] = *(byte *)(param_1 + iVar8);
          *(char *)(param_1 + iVar8) = (char)(uVar6 / 3);
          iVar8 = iVar8 + param_4;
        } while (uVar5 != iVar3 + 1U);
        break;
      case 4:
        if (iVar3 < 0) goto LAB_00014ea0;
        iVar8 = 0;
        uVar6 = 0;
        uVar5 = 0;
        do {
          uVar2 = uVar5 & 7;
          uVar4 = uVar5 + 4;
          uVar5 = uVar5 + 1;
          uVar6 = uVar6 + ((uint)*(byte *)(param_1 + iVar8) - (uint)local_30[uVar2]);
          local_30[uVar4 & 7] = *(byte *)(param_1 + iVar8);
          *(char *)(param_1 + iVar8) = (char)(uVar6 >> 2);
          iVar8 = iVar8 + param_4;
        } while (uVar5 != iVar3 + 1U);
        break;
      case 5:
        if (iVar3 < 0) goto LAB_00014ea0;
        iVar8 = 0;
        uVar6 = 0;
        uVar5 = 0;
        do {
          uVar2 = uVar5 & 7;
          uVar4 = uVar5 + 5;
          uVar5 = uVar5 + 1;
          uVar6 = uVar6 + ((uint)*(byte *)(param_1 + iVar8) - (uint)local_30[uVar2]);
          local_30[uVar4 & 7] = *(byte *)(param_1 + iVar8);
          *(char *)(param_1 + iVar8) = (char)(uVar6 / 5);
          iVar8 = iVar8 + param_4;
        } while (uVar5 != iVar3 + 1U);
        break;
      default:
        if (iVar3 < 0) goto LAB_00014ea0;
        iVar8 = 0;
        uVar6 = 0;
        uVar5 = 0;
        do {
          uVar2 = uVar5 & 7;
          uVar4 = uVar5 + param_5;
          uVar5 = uVar5 + 1;
          uVar6 = uVar6 + ((uint)*(byte *)(param_1 + iVar8) - (uint)local_30[uVar2]);
          local_30[uVar4 & 7] = *(byte *)(param_1 + iVar8);
          uVar1 = __aeabi_uidiv(uVar6,param_5);
          *(undefined1 *)(param_1 + iVar8) = uVar1;
          iVar8 = iVar8 + param_4;
        } while (uVar5 != iVar3 + 1U);
      }
      if ((int)uVar5 < (int)param_3) {
        puVar7 = (undefined1 *)(uVar5 * param_4 + param_1);
        do {
          uVar2 = uVar5 & 7;
          uVar5 = uVar5 + 1;
          uVar6 = uVar6 - local_30[uVar2];
          uVar1 = __aeabi_uidiv(uVar6,param_5);
          *puVar7 = uVar1;
          puVar7 = puVar7 + param_4;
        } while (param_3 != uVar5);
      }
      param_1 = param_1 + 1;
    } while (param_1 != param_2);
  }
  return;
}
