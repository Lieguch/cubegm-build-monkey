/* ============================================================
 * stbtt__tesselate_curve   @ 0x00013e4c   size=280B   callers=2
 * module: 05_stb_truetype_font
 * ============================================================ */

undefined4
stbtt__tesselate_curve
          (float param_1,float param_2,float param_3,float param_4,float param_5,float param_6,
          float param_7,int param_8,int *param_9,int param_10,float *param_11)

{
  int iVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  
  if (0x10 < param_10) {
    return 1;
  }
  fVar5 = (param_4 + param_4 + param_2 + param_6) * 0.25;
  fVar4 = (param_3 + param_3 + param_1 + param_5) * 0.25;
  fVar3 = (param_2 + param_6) * 0.5 - fVar5;
  fVar2 = (param_1 + param_5) * 0.5 - fVar4;
  if (param_7 < fVar3 * fVar3 + fVar2 * fVar2) {
    stbtt__tesselate_curve
              (param_1,param_2,(param_3 + param_1) * 0.5,(param_4 + param_2) * 0.5,fVar4,fVar5,
               param_8,param_9,param_10 + 1);
    stbtt__tesselate_curve
              (fVar4,fVar5,(param_3 + param_5) * 0.5,(param_4 + param_6) * 0.5,param_5,param_6,
               param_7,param_8,param_9,param_10 + 1);
    return 1;
  }
  iVar1 = *param_9;
  if (param_8 != 0) {
    param_11 = (float *)(param_8 + iVar1 * 8);
    *param_11 = param_5;
  }
  if (param_8 != 0) {
    param_11[1] = param_6;
  }
  *param_9 = iVar1 + 1;
  return 1;
}
