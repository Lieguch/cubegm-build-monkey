/* ============================================================
 * strcmpcasenosensitive_internal   @ 0x00010e20   size=128B   callers=1
 * module: 01_main_emurun_joystick
 * ============================================================ */

/* strcmpcasenosensitive_internal(char const*, char const*) */

int strcmpcasenosensitive_internal(char *param_1,char *param_2)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  
  do {
    bVar1 = *param_1;
    bVar2 = *param_2;
    bVar3 = bVar2 - 0x20;
    if (bVar1 - 0x61 < 0x1a) {
      bVar1 = bVar1 - 0x20;
    }
    if (bVar2 - 0x61 < 0x1a) {
      if (bVar1 == 0) goto LAB_00010e88;
    }
    else {
      bVar3 = bVar2;
      if (bVar1 == 0) {
LAB_00010e88:
        return -(uint)(bVar3 != 0);
      }
      if (bVar2 == 0) {
        return 1;
      }
    }
    if ((char)bVar1 < (char)bVar3) {
      return -1;
    }
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
    if ((char)bVar3 < (char)bVar1) {
      return 1;
    }
  } while( true );
}
