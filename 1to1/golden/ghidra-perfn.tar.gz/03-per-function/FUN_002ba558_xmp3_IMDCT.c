/* ============================================================
 * xmp3_IMDCT   @ 0x002ba558   size=5044B   callers=1
 * module: 06_helix_mp3
 * ============================================================ */

undefined4 xmp3_IMDCT(undefined4 *param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  uint uVar11;
  undefined4 uVar12;
  int *piVar13;
  int iVar14;
  uint uVar15;
  int iVar16;
  uint uVar17;
  int iVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  int iVar22;
  uint *puVar23;
  uint uVar24;
  int iVar25;
  int iVar26;
  int *piVar27;
  uint uVar28;
  int iVar29;
  int iVar30;
  int iVar31;
  int *piVar32;
  int iVar33;
  int iVar34;
  int iVar35;
  int iVar36;
  int iVar37;
  int iVar38;
  int iVar39;
  int iVar40;
  int iVar41;
  int iVar42;
  int *piVar43;
  uint local_158;
  uint local_154;
  int *local_150;
  int *local_14c;
  int *local_148;
  int *local_144;
  uint local_140;
  int *local_138;
  uint *local_12c;
  int local_11c;
  uint local_118;
  int local_114;
  uint local_10c;
  int local_fc;
  int *local_f4;
  int *local_f0;
  int local_d8;
  int local_b8;
  int local_b4;
  int local_b0;
  int local_ac;
  int local_a8;
  int local_a4;
  int local_a0;
  int local_9c [4];
  int local_8c;
  int local_88;
  int local_84;
  int local_80;
  int local_7c;
  int local_78 [21];
  
  if ((((param_1 == (undefined4 *)0x0) || (piVar13 = (int *)*param_1, piVar13 == (int *)0x0)) ||
      (iVar36 = param_1[1], iVar36 == 0)) ||
     ((iVar37 = param_1[3], iVar37 == 0 || (iVar6 = param_1[5], iVar6 == 0)))) {
    return 0xffffffff;
  }
  if (*piVar13 == 0) {
    iVar14 = 0x10;
  }
  else {
    iVar14 = 0xc;
  }
  iVar1 = iVar36 + param_3 * 0x48 + param_2 * 0x90;
  uVar15 = (uint)(*(short *)(piVar13[0xd] + iVar14) / 0x12);
  if (*(int *)(iVar1 + 0x3c) == 2) {
    if (*(int *)(iVar1 + 0x40) == 0) {
      local_114 = 8;
      local_f0 = (int *)(iVar37 + param_3 * 0x900);
      local_10c = 0;
      local_d8 = 0;
      goto LAB_002ba928;
    }
    iVar14 = uVar15 - 1;
    local_10c = uVar15;
LAB_002bb470:
    local_114 = iVar14 * 0x12 + 8;
    local_f0 = (int *)(iVar37 + param_3 * 0x900);
    if (0 < iVar14) goto LAB_002ba664;
  }
  else {
    iVar14 = *(int *)(iVar37 + (param_3 + 0x480) * 4);
    if (iVar14 < 0x227) {
      iVar14 = (iVar14 + 7) / 0x12;
      local_10c = iVar14 + 1;
      goto LAB_002bb470;
    }
    local_114 = 0x236;
    local_10c = 0x20;
    iVar14 = 0x1f;
    local_f0 = (int *)(iVar37 + param_3 * 0x900);
LAB_002ba664:
    piVar13 = local_f0;
    do {
      piVar5 = piVar13 + 0x12;
      iVar1 = piVar13[0x11];
      piVar13[0x11] =
           ((int)((ulonglong)((longlong)iVar1 * 0x6dc253f0) >> 0x20) -
           (int)((ulonglong)((longlong)*piVar5 * -0x41daff56) >> 0x20)) * 2;
      iVar29 = piVar13[0x10];
      *piVar5 = ((int)((ulonglong)((longlong)*piVar5 * 0x6dc253f0) >> 0x20) +
                (int)((ulonglong)((longlong)iVar1 * -0x41daff56) >> 0x20)) * 2;
      piVar13[0x10] =
           ((int)((ulonglong)((longlong)iVar29 * 0x70dcebe4) >> 0x20) -
           (int)((ulonglong)((longlong)piVar13[0x13] * -0x3c61b6b7) >> 0x20)) * 2;
      iVar1 = piVar13[0xf];
      piVar13[0x13] =
           ((int)((ulonglong)((longlong)piVar13[0x13] * 0x70dcebe4) >> 0x20) +
           (int)((ulonglong)((longlong)iVar29 * -0x3c61b6b7) >> 0x20)) * 2;
      piVar13[0xf] = ((int)((ulonglong)((longlong)iVar1 * 0x798d6e73) >> 0x20) -
                     (int)((ulonglong)((longlong)piVar13[0x14] * -0x281cc0b6) >> 0x20)) * 2;
      iVar29 = piVar13[0xe];
      piVar13[0x14] =
           ((int)((ulonglong)((longlong)piVar13[0x14] * 0x798d6e73) >> 0x20) +
           (int)((ulonglong)((longlong)iVar1 * -0x281cc0b6) >> 0x20)) * 2;
      piVar13[0xe] = ((int)((ulonglong)((longlong)iVar29 * 0x7ddd40a7) >> 0x20) -
                     (int)((ulonglong)((longlong)piVar13[0x15] * -0x1748ee8a) >> 0x20)) * 2;
      iVar1 = piVar13[0xd];
      piVar13[0x15] =
           ((int)((ulonglong)((longlong)piVar13[0x15] * 0x7ddd40a7) >> 0x20) +
           (int)((ulonglong)((longlong)iVar29 * -0x1748ee8a) >> 0x20)) * 2;
      piVar13[0xd] = ((int)((ulonglong)((longlong)iVar1 * 0x7f6d20b7) >> 0x20) -
                     (int)((ulonglong)((longlong)piVar13[0x16] * -0xc1b01d1) >> 0x20)) * 2;
      iVar29 = piVar13[0xc];
      piVar13[0x16] =
           ((int)((ulonglong)((longlong)piVar13[0x16] * 0x7f6d20b7) >> 0x20) +
           (int)((ulonglong)((longlong)iVar1 * -0xc1b01d1) >> 0x20)) * 2;
      piVar13[0xc] = ((int)((ulonglong)((longlong)iVar29 * 0x7fe47e40) >> 0x20) -
                     (int)((ulonglong)((longlong)piVar13[0x17] * -0x53e5c39) >> 0x20)) * 2;
      iVar1 = piVar13[0xb];
      piVar13[0x17] =
           ((int)((ulonglong)((longlong)piVar13[0x17] * 0x7fe47e40) >> 0x20) +
           (int)((ulonglong)((longlong)iVar29 * -0x53e5c39) >> 0x20)) * 2;
      piVar13[0xb] = ((int)((ulonglong)((longlong)iVar1 * 0x7ffcb263) >> 0x20) -
                     (int)((ulonglong)((longlong)piVar13[0x18] * -0x1d1423a) >> 0x20)) * 2;
      iVar29 = piVar13[10];
      piVar13[0x18] =
           ((int)((ulonglong)((longlong)piVar13[0x18] * 0x7ffcb263) >> 0x20) +
           (int)((ulonglong)((longlong)iVar1 * -0x1d1423a) >> 0x20)) * 2;
      piVar13[10] = ((int)((ulonglong)((longlong)iVar29 * 0x7fffc694) >> 0x20) -
                    (int)((ulonglong)((longlong)piVar13[0x19] * -0x793da3) >> 0x20)) * 2;
      piVar13[0x19] =
           ((int)((ulonglong)((longlong)piVar13[0x19] * 0x7fffc694) >> 0x20) +
           (int)((ulonglong)((longlong)iVar29 * -0x793da3) >> 0x20)) * 2;
      piVar13 = piVar5;
    } while (piVar5 != local_f0 + iVar14 * 0x12);
  }
  local_d8 = *(int *)(iVar36 + param_3 * 0x48 + param_2 * 0x90 + 0x40);
LAB_002ba928:
  local_118 = param_3 * 0x900;
  iVar37 = iVar37 + param_3 * 4;
  iVar1 = iVar6 + param_3 * 4;
  iVar29 = iVar6 + local_118;
  iVar14 = *(int *)(iVar37 + 0x1200);
  if (*(int *)(iVar37 + 0x1200) <= local_114) {
    iVar14 = local_114;
  }
  uVar28 = (iVar14 + 0x11) / 0x12;
  iVar6 = param_3 * 0x480 + iVar6;
  iVar16 = iVar36 + param_3 * 0x48 + param_2 * 0x90 + 0x28;
  if (local_d8 == 0) {
    uVar15 = 0;
  }
  *(int *)(iVar37 + 0x1200) = iVar14;
  iVar7 = *(int *)(iVar37 + 0x1208);
  iVar37 = *(int *)(iVar1 + 0x1b08);
  uVar17 = *(uint *)(iVar1 + 0x1b00);
  iVar14 = *(int *)(iVar1 + 0x1b10);
  local_138 = (int *)(iVar6 + 0x1200);
  if ((int)local_10c < 1) {
    local_140 = 0;
    local_158 = 0;
  }
  else {
    local_148 = (int *)(iVar6 + 0x1224);
    uVar8 = 7 - iVar7;
    uVar9 = uVar8;
    if (6 < iVar7) {
      uVar9 = 0;
    }
    local_144 = local_f0 + 0xf;
    local_140 = 0;
    local_fc = 0xb27eb5c;
    local_158 = 0;
    local_154 = iVar29;
    do {
      piVar13 = local_148 + -9;
      local_11c = *(int *)(iVar16 + 0x14);
      if ((*(int *)(iVar16 + 0x18) != 0) && ((int)local_158 < (int)uVar15)) {
        local_11c = 0;
      }
      iVar2 = 0;
      iVar6 = iVar37;
      if ((int)local_158 < iVar14) {
        iVar6 = 0;
      }
      if (iVar7 < 7) {
        iVar18 = 0;
        piVar5 = local_144;
        piVar27 = local_148;
        piVar4 = local_9c + 2;
        do {
          piVar43 = piVar5 + 1;
          piVar32 = piVar5 + 2;
          piVar5 = piVar5 + -2;
          iVar10 = piVar27[-1];
          iVar18 = (*piVar32 >> (uVar8 & 0xff)) - iVar18;
          iVar2 = iVar18 - iVar2;
          iVar18 = (*piVar43 >> (uVar8 & 0xff)) - iVar18;
          piVar4[8] = iVar2;
          piVar27 = piVar27 + -1;
          *piVar27 = iVar10 >> (uVar8 & 0xff);
          piVar4 = piVar4 + -1;
          *piVar4 = iVar18;
        } while (local_144 + -0x12 != piVar5);
      }
      else {
        iVar18 = 0;
        piVar5 = local_144;
        piVar27 = local_9c + 2;
        do {
          piVar32 = piVar5 + 1;
          piVar4 = piVar5 + 2;
          piVar5 = piVar5 + -2;
          iVar2 = (*piVar4 - iVar18) - iVar2;
          iVar18 = *piVar32 - (*piVar4 - iVar18);
          piVar27[8] = iVar2;
          piVar27 = piVar27 + -1;
          *piVar27 = iVar18;
        } while (local_144 + -0x12 != piVar5);
      }
      iVar18 = local_b0 + local_a8;
      iVar41 = (local_b0 - local_a8) - local_9c[1];
      iVar26 = (local_b8 >> 1) - local_a0;
      iVar2 = (local_b4 + local_a4) - (local_b4 + local_9c[0]);
      iVar38 = (int)((ulonglong)((longlong)local_ac * 0x6ed9eba1) >> 0x20);
      iVar34 = (int)((ulonglong)((longlong)((local_b4 - local_a4) - local_9c[0]) * 0x6ed9eba1) >>
                    0x20);
      iVar10 = (int)((ulonglong)((longlong)((local_b0 + local_9c[1]) - iVar18) * 0x620dbe8b) >> 0x20
                    ) * 2 + (int)((ulonglong)((longlong)iVar18 * 0x163a1a7e) >> 0x20) * -2;
      iVar22 = (local_b8 >> 1) + (local_a0 >> 1);
      iVar18 = (int)((ulonglong)((longlong)(local_b0 + local_9c[1]) * 0x163a1a7e) >> 0x20) * 2 +
               (int)((ulonglong)((longlong)iVar18 * 0x620dbe8b) >> 0x20) * 2;
      iVar33 = iVar22 + iVar38 * 2;
      iVar30 = (int)((ulonglong)((longlong)(local_b4 + local_9c[0]) * 0x7e0e2e32) >> 0x20) * 2 +
               (int)((ulonglong)((longlong)iVar2 * 0x5246dd49) >> 0x20) * 2;
      iVar22 = iVar22 + iVar38 * -2;
      iVar2 = (int)((ulonglong)((longlong)(local_b4 + local_a4) * 0x5246dd49) >> 0x20) * 2 +
              (int)((ulonglong)((longlong)iVar2 * 0x7e0e2e32) >> 0x20) * -2;
      local_b8 = iVar33 + iVar18 + iVar30;
      iVar39 = iVar26 + (iVar41 >> 1);
      local_a8 = iVar26 - iVar41;
      local_b4 = iVar39 + iVar34 * 2;
      iVar38 = (iVar22 + iVar18) - iVar30;
      local_b0 = iVar22 + iVar10 + iVar2;
      iVar26 = local_8c + local_84;
      local_ac = (iVar22 - (iVar18 + iVar10)) - (iVar2 - iVar30);
      iVar41 = (local_8c - local_84) - local_78[1];
      local_9c[0] = iVar39 + iVar34 * -2;
      iVar40 = (local_9c[3] + local_80) - (local_9c[3] + local_78[0]);
      iVar39 = (local_9c[2] >> 1) - local_7c;
      local_a4 = (iVar33 - (iVar18 + iVar10)) + (iVar2 - iVar30);
      local_9c[1] = iVar38;
      local_a0 = (iVar33 + iVar10) - iVar2;
      iVar10 = (int)((ulonglong)((longlong)local_88 * 0x6ed9eba1) >> 0x20);
      iVar35 = (int)((ulonglong)((longlong)((local_9c[3] - local_80) - local_78[0]) * 0x6ed9eba1) >>
                    0x20);
      iVar34 = (int)((ulonglong)((longlong)(local_8c + local_78[1]) * 0x163a1a7e) >> 0x20) * 2 +
               (int)((ulonglong)((longlong)iVar26 * 0x620dbe8b) >> 0x20) * 2;
      iVar22 = (local_9c[2] >> 1) + (local_7c >> 1);
      iVar26 = (int)((ulonglong)((longlong)((local_8c + local_78[1]) - iVar26) * 0x620dbe8b) >> 0x20
                    ) * 2 + (int)((ulonglong)((longlong)iVar26 * 0x163a1a7e) >> 0x20) * -2;
      iVar18 = (int)((ulonglong)((longlong)(local_9c[3] + local_80) * 0x5246dd49) >> 0x20) * 2 +
               (int)((ulonglong)((longlong)iVar40 * 0x7e0e2e32) >> 0x20) * -2;
      iVar2 = iVar22 + iVar10 * 2;
      iVar22 = iVar22 + iVar10 * -2;
      iVar10 = (int)((ulonglong)((longlong)(local_9c[3] + local_78[0]) * 0x7e0e2e32) >> 0x20) * 2 +
               (int)((ulonglong)((longlong)iVar40 * 0x5246dd49) >> 0x20) * 2;
      iVar33 = iVar39 + (iVar41 >> 1);
      local_84 = iVar39 - iVar41;
      iVar30 = (iVar22 + iVar34) - iVar10;
      local_9c[2] = iVar2 + iVar34 + iVar10;
      local_9c[3] = iVar33 + iVar35 * 2;
      local_78[0] = iVar33 + iVar35 * -2;
      local_8c = iVar22 + iVar26 + iVar18;
      local_88 = (iVar22 - (iVar34 + iVar26)) - (iVar18 - iVar10);
      local_80 = (iVar2 - (iVar34 + iVar26)) + (iVar18 - iVar10);
      local_7c = (iVar2 + iVar26) - iVar18;
      local_78[1] = iVar30;
      if (local_11c == 0 && iVar6 == 0) {
        piVar4 = local_9c + 1;
        piVar27 = (int *)&DAT_002e1d14;
        iVar6 = 0;
        uVar24 = 0;
        iVar2 = local_fc;
        piVar5 = piVar13;
        while( true ) {
          iVar18 = (int)((ulonglong)((longlong)iVar2 * (longlong)iVar30) >> 0x20);
          iVar2 = *piVar5;
          iVar10 = iVar18 - (iVar38 >> 2);
          *piVar5 = iVar18 + (iVar38 >> 2);
          iVar18 = -iVar10 - iVar2;
          uVar19 = iVar10 + (int)((ulonglong)
                                  ((longlong)iVar18 * (longlong)*(int *)(fastWin36 + iVar6)) >> 0x20
                                 ) * 4;
          uVar11 = (int)((ulonglong)((longlong)iVar18 * (longlong)*(int *)(fastWin36 + iVar6 + 4))
                        >> 0x20) * 4 - iVar2;
          *(uint *)(local_154 + iVar6 * 0x10) = uVar19;
          *(uint *)(local_154 + iVar6 * -0x10 + 0x880) = uVar11;
          iVar6 = iVar6 + 8;
          uVar24 = uVar24 | (uVar19 ^ (int)uVar19 >> 0x1f) - ((int)uVar19 >> 0x1f) |
                            (uVar11 ^ (int)uVar11 >> 0x1f) - ((int)uVar11 >> 0x1f);
          if (iVar6 == 0x48) break;
          iVar30 = piVar4[8];
          piVar27 = piVar27 + -1;
          iVar2 = *piVar27;
          piVar4 = piVar4 + -1;
          iVar38 = *piVar4;
          piVar5 = piVar5 + 1;
        }
      }
      else {
        uVar24 = 0;
        piVar32 = local_78 + 0x14;
        WinPrevious(piVar13,local_78 + 2,iVar6);
        iVar2 = 0;
        local_150 = (int *)&DAT_002e1d14;
        piVar43 = (int *)(xmp3_ISFMpeg1 + local_11c * 0x90 + 0x34);
        piVar4 = (int *)(xmp3_imdctWin + local_11c * 0x90 + 0x48);
        piVar5 = local_78 + 1;
        iVar6 = local_fc;
        piVar27 = piVar13;
        while( true ) {
          iVar6 = (int)((ulonglong)((longlong)iVar6 * (longlong)iVar30) >> 0x20);
          iVar18 = (iVar38 >> 2) - iVar6;
          *piVar27 = iVar6 + (iVar38 >> 2);
          piVar43 = piVar43 + 1;
          piVar4 = piVar4 + -1;
          iVar6 = *piVar4;
          uVar11 = ((int)((ulonglong)((longlong)iVar18 * (longlong)*piVar43) >> 0x20) +
                   (local_78 + 2)[iVar2]) * 4;
          piVar32 = piVar32 + -1;
          iVar10 = *piVar32;
          *(uint *)(local_154 + iVar2 * 0x80) = uVar11;
          uVar19 = ((int)((ulonglong)((longlong)iVar18 * (longlong)iVar6) >> 0x20) + iVar10) * 4;
          *(uint *)(local_154 + iVar2 * -0x80 + 0x880) = uVar19;
          iVar2 = iVar2 + 1;
          uVar24 = uVar24 | (uVar11 ^ (int)uVar11 >> 0x1f) - ((int)uVar11 >> 0x1f) |
                            (uVar19 ^ (int)uVar19 >> 0x1f) - ((int)uVar19 >> 0x1f);
          if (iVar2 == 9) break;
          iVar30 = piVar5[-1];
          local_150 = local_150 + -1;
          iVar6 = *local_150;
          iVar38 = piVar5[-10];
          piVar5 = piVar5 + -1;
          piVar27 = piVar27 + 1;
        }
      }
      uVar11 = FreqInvertRescale(local_154,piVar13,local_158,uVar9);
      local_158 = local_158 + 1;
      local_148 = local_148 + 9;
      local_144 = local_144 + 0x12;
      local_154 = local_154 + 4;
      local_140 = local_140 | uVar11 | uVar24;
    } while (local_10c != local_158);
    local_f0 = local_f0 + local_158 * 0x12;
    local_138 = local_138 + local_158 * 9;
  }
  uVar9 = local_158;
  if ((int)local_158 < (int)uVar28) {
    local_12c = (uint *)(iVar29 + local_158 * 4);
    local_14c = local_138;
    uVar8 = 7 - iVar7;
    do {
      iVar6 = iVar37;
      if ((int)local_158 < iVar14) {
        iVar6 = 0;
      }
      if (iVar7 < 7) {
        piVar13 = local_f0 + 1;
        piVar5 = local_f0;
        piVar27 = local_14c;
        do {
          piVar13[-1] = piVar13[-1] >> (uVar8 & 0xff);
          piVar5[1] = piVar5[1] >> (uVar8 & 0xff);
          piVar4 = piVar27 + 1;
          *piVar27 = *piVar27 >> (uVar8 & 0xff);
          piVar13 = piVar13 + 2;
          piVar5 = piVar5 + 2;
          piVar27 = piVar4;
          local_118 = uVar8;
        } while (piVar4 != local_14c + 9);
      }
      else {
        local_118 = 0;
      }
      local_f4 = local_14c + 9;
      iVar22 = local_f0[0xf];
      iVar18 = local_f0[0xc] - iVar22;
      iVar10 = local_f0[6] - (local_f0[9] - iVar18);
      iVar2 = local_f0[3] - iVar10;
      iVar26 = (local_f0[9] - iVar18) - iVar22;
      iVar16 = *local_f0 - iVar2 >> 1;
      iVar2 = iVar2 - iVar26 >> 1;
      iVar30 = (int)((ulonglong)((longlong)iVar10 * 0x6ed9eba1) >> 0x20);
      iVar38 = iVar16 + (iVar18 >> 1);
      iVar10 = iVar30 * 2 + iVar38;
      iVar16 = iVar16 - iVar18;
      iVar38 = iVar38 + iVar30 * -2;
      iVar26 = (int)((ulonglong)((longlong)iVar26 * 0x6ed9eba1) >> 0x20);
      iVar30 = iVar2 + (iVar22 >> 1);
      iVar18 = (int)((ulonglong)((longlong)(iVar26 * 2 + iVar30) * 0x7ba3751d) >> 0x20);
      iVar22 = (int)((ulonglong)((longlong)(iVar2 - iVar22) * 0x5a82799a) >> 0x20);
      iVar2 = (int)((ulonglong)((longlong)(iVar30 + iVar26 * -2) * 0x2120fb83) >> 0x20);
      iVar30 = local_f0[0x10];
      local_b4 = iVar16 + iVar22 * 4;
      local_a8 = iVar16 + iVar22 * -4;
      iVar34 = local_f0[0xd] - iVar30;
      iVar33 = local_f0[7] - (local_f0[10] - iVar34);
      iVar22 = local_f0[4] - iVar33;
      iVar26 = (local_f0[10] - iVar34) - iVar30;
      iVar39 = iVar38 + iVar2 * 4;
      iVar38 = iVar38 + iVar2 * -4;
      iVar16 = local_f0[1] - iVar22 >> 1;
      local_150 = (int *)(iVar10 + iVar18 * 4);
      iVar10 = iVar10 + iVar18 * -4;
      iVar2 = iVar22 - iVar26 >> 1;
      iVar18 = (int)((ulonglong)((longlong)iVar33 * 0x6ed9eba1) >> 0x20);
      iVar31 = iVar16 + (iVar34 >> 1);
      iVar22 = iVar18 * 2 + iVar31;
      iVar16 = iVar16 - iVar34;
      iVar31 = iVar31 + iVar18 * -2;
      iVar18 = (int)((ulonglong)((longlong)iVar26 * 0x6ed9eba1) >> 0x20);
      iVar26 = iVar2 + (iVar30 >> 1);
      iVar35 = (int)((ulonglong)((longlong)(iVar18 * 2 + iVar26) * 0x7ba3751d) >> 0x20);
      iVar2 = (int)((ulonglong)((longlong)(iVar2 - iVar30) * 0x5a82799a) >> 0x20);
      iVar33 = (int)((ulonglong)((longlong)(iVar26 + iVar18 * -2) * 0x2120fb83) >> 0x20);
      iVar25 = local_f0[0x11];
      local_9c[3] = iVar16 + iVar2 * -4;
      iVar16 = iVar16 + iVar2 * 4;
      iVar40 = local_f0[0xe] - iVar25;
      iVar41 = local_f0[8] - (local_f0[0xb] - iVar40);
      iVar30 = (local_f0[0xb] - iVar40) - iVar25;
      iVar18 = local_f0[5] - iVar41;
      iVar26 = iVar31 + iVar33 * 4;
      iVar31 = iVar31 + iVar33 * -4;
      iVar34 = iVar22 + iVar35 * -4;
      iVar22 = iVar22 + iVar35 * 4;
      iVar2 = local_f0[2] - iVar18 >> 1;
      iVar18 = iVar18 - iVar30 >> 1;
      iVar33 = (int)((ulonglong)((longlong)iVar41 * 0x6ed9eba1) >> 0x20);
      iVar35 = iVar2 + (iVar40 >> 1);
      iVar2 = iVar2 - iVar40;
      iVar40 = iVar33 * 2 + iVar35;
      iVar35 = iVar35 + iVar33 * -2;
      iVar33 = (int)((ulonglong)((longlong)iVar30 * 0x6ed9eba1) >> 0x20);
      iVar30 = iVar18 + (iVar25 >> 1);
      iVar42 = (int)((ulonglong)((longlong)(iVar33 * 2 + iVar30) * 0x7ba3751d) >> 0x20);
      iVar41 = (int)((ulonglong)((longlong)(iVar18 - iVar25) * 0x5a82799a) >> 0x20);
      iVar18 = (int)((ulonglong)((longlong)(iVar30 + iVar33 * -2) * 0x2120fb83) >> 0x20);
      iVar30 = iVar40 + iVar42 * 4;
      local_84 = iVar2 + iVar41 * 4;
      local_78[0] = iVar2 + iVar41 * -4;
      local_80 = iVar35 + iVar18 * 4;
      local_7c = iVar35 + iVar18 * -4;
      local_78[1] = iVar40 + iVar42 * -4;
      local_154 = 0;
      local_b8 = (int)local_150;
      local_b0 = iVar39;
      local_ac = iVar38;
      local_a4 = iVar10;
      local_a0 = iVar22;
      local_9c[0] = iVar16;
      local_9c[1] = iVar26;
      local_9c[2] = iVar31;
      local_8c = iVar34;
      local_88 = iVar30;
      WinPrevious(local_14c,local_78 + 2,iVar6);
      piVar13 = &local_b0;
      puVar23 = local_12c;
      piVar5 = local_78 + 2;
      piVar27 = (int *)(xmp3_imdctWin + 0x11c);
      local_144 = &local_b8;
      while( true ) {
        uVar24 = *piVar5 << 2;
        *puVar23 = uVar24;
        uVar11 = piVar5[3] << 2;
        puVar23[0x60] = uVar11;
        uVar19 = (int)((ulonglong)((longlong)piVar27[1] * (longlong)iVar38) >> 0x20) + piVar5[6] * 4
        ;
        puVar23[0xc0] = uVar19;
        uVar3 = (int)((ulonglong)((longlong)piVar27[4] * (longlong)iVar10) >> 0x20) + piVar5[9] * 4;
        puVar23[0x120] = uVar3;
        uVar20 = (int)((ulonglong)((longlong)piVar27[7] * (longlong)iVar39) >> 0x20) +
                 (int)((ulonglong)((longlong)piVar27[1] * (longlong)iVar31) >> 0x20) +
                 piVar5[0xc] * 4;
        puVar23[0x180] = uVar20;
        uVar21 = (int)((ulonglong)((longlong)piVar27[10] * (longlong)(int)local_150) >> 0x20) +
                 (int)((ulonglong)((longlong)piVar27[4] * (longlong)iVar34) >> 0x20) +
                 piVar5[0xf] * 4;
        puVar23[0x1e0] = uVar21;
        puVar23 = puVar23 + 0x20;
        local_154 = local_154 |
                    (uVar24 ^ (int)uVar24 >> 0x1f) - ((int)uVar24 >> 0x1f) |
                    (uVar11 ^ (int)uVar11 >> 0x1f) - ((int)uVar11 >> 0x1f) |
                    (uVar19 ^ (int)uVar19 >> 0x1f) - ((int)uVar19 >> 0x1f) |
                    (uVar3 ^ (int)uVar3 >> 0x1f) - ((int)uVar3 >> 0x1f) |
                    (uVar20 ^ (int)uVar20 >> 0x1f) - ((int)uVar20 >> 0x1f) |
                    (uVar21 ^ (int)uVar21 >> 0x1f) - ((int)uVar21 >> 0x1f);
        if (piVar13 == &local_b8) break;
        iVar10 = piVar13[2];
        iVar39 = piVar13[-1];
        iVar38 = local_144[4];
        iVar31 = local_144[10];
        local_144 = local_144 + 1;
        local_150 = (int *)*local_144;
        iVar34 = piVar13[8];
        piVar13 = piVar13 + -1;
        piVar5 = piVar5 + 1;
        piVar27 = piVar27 + 1;
      }
      *local_14c = iVar22 >> 2;
      local_14c[1] = iVar16 >> 2;
      local_14c[2] = iVar26 >> 2;
      piVar13 = &local_88;
      piVar5 = local_14c + 3;
      while( true ) {
        piVar27 = piVar5 + 1;
        *piVar5 = iVar30 >> 2;
        if (piVar27 == local_f4) break;
        piVar13 = piVar13 + 1;
        iVar30 = *piVar13;
        piVar5 = piVar27;
      }
      local_f0 = local_f0 + 0x12;
      uVar24 = FreqInvertRescale(local_12c,local_14c,local_158,local_118);
      local_158 = local_158 + 1;
      local_12c = local_12c + 1;
      local_140 = local_140 | local_154 | uVar24;
      local_14c = piVar27;
    } while (uVar28 != local_158);
    local_138 = local_138 + (local_158 - uVar9) * 9;
  }
  local_154 = local_158;
  if ((int)local_158 < (int)uVar17) {
    local_150 = (int *)(local_158 << 0x1f);
    iVar6 = iVar29 + local_158 * 4;
    do {
      iVar16 = iVar37;
      if ((int)local_154 < iVar14) {
        iVar16 = 0;
      }
      WinPrevious(local_138,local_78 + 2,iVar16);
      iVar7 = 0;
      piVar13 = local_138 + -1;
      uVar28 = 0;
      iVar16 = iVar6;
      do {
        uVar9 = *(int *)((int)(local_78 + 2) + iVar7) << 2;
        *(uint *)(iVar6 + iVar7 * 0x20) = uVar9;
        uVar8 = ((int)local_150 >> 0x1f ^ *(int *)((int)local_78 + iVar7 + 0xc) << 2) +
                (local_154 & 1);
        *(uint *)(iVar16 + 0x80) = uVar8;
        uVar28 = uVar28 | uVar9 | uVar8;
        iVar7 = iVar7 + 8;
        local_140 = local_140 |
                    (uVar9 ^ (int)uVar9 >> 0x1f) - ((int)uVar9 >> 0x1f) |
                    (uVar8 ^ (int)uVar8 >> 0x1f) - ((int)uVar8 >> 0x1f);
        piVar13 = piVar13 + 1;
        *piVar13 = 0;
        iVar16 = iVar16 + 0x100;
      } while (iVar7 != 0x48);
      iVar6 = iVar6 + 4;
      if (uVar28 != 0) {
        local_158 = local_154;
      }
      local_154 = local_154 + 1;
      local_138 = local_138 + 9;
      local_150 = (int *)((int)local_150 + -0x80000000);
    } while (uVar17 != local_154);
  }
  if ((int)local_154 < 0x20) {
    iVar29 = iVar29 + local_154 * 4;
    do {
      iVar37 = 0;
      do {
        *(undefined4 *)(iVar29 + iVar37 * 0x80) = 0;
        iVar37 = iVar37 + 1;
      } while (iVar37 != 0x12);
      local_154 = local_154 + 1;
      iVar29 = iVar29 + 4;
    } while (local_154 != 0x20);
  }
  if (local_140 == 0) {
    iVar37 = 0x1f;
  }
  else if ((int)local_140 < 0) {
    iVar37 = -1;
  }
  else {
    iVar6 = 0;
    do {
      iVar37 = iVar6;
      local_140 = local_140 << 1;
      iVar6 = iVar37 + 1;
    } while (-1 < (int)local_140);
  }
  *(uint *)(iVar1 + 0x1b00) = local_158;
  uVar12 = *(undefined4 *)(iVar36 + param_3 * 0x48 + param_2 * 0x90 + 0x3c);
  *(int *)(iVar1 + 0x1b18) = iVar37;
  *(uint *)(iVar1 + 0x1b10) = uVar15;
  *(undefined4 *)(iVar1 + 0x1b08) = uVar12;
  return 0;
}
