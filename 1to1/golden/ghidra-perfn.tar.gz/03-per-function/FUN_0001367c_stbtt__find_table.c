/* ============================================================
 * stbtt__find_table   @ 0x0001367c   size=188B   callers=4
 * module: 05_stb_truetype_font
 * ============================================================ */

int stbtt__find_table(int param_1,int param_2,char *param_3)

{
  int iVar1;
  int iVar2;
  
  iVar1 = (uint)*(byte *)(param_1 + param_2 + 4 + 1) +
          (uint)*(byte *)(param_1 + param_2 + 4) * 0x100;
  if (iVar1 != 0) {
    param_2 = param_1 + param_2;
    iVar2 = 0;
    do {
      iVar2 = iVar2 + 1;
      if ((((*(char *)(param_2 + 0xc) == *param_3) && (*(char *)(param_2 + 0xd) == param_3[1])) &&
          (*(char *)(param_2 + 0xe) == param_3[2])) && (*(char *)(param_2 + 0xf) == param_3[3])) {
        iVar2 = (param_2 - param_1) + 0x14;
        iVar1 = param_1 + iVar2;
        return (uint)*(byte *)(iVar1 + 1) * 0x10000 + (uint)*(byte *)(param_1 + iVar2) * 0x1000000 +
               (uint)*(byte *)(iVar1 + 2) * 0x100 + (uint)*(byte *)(iVar1 + 3);
      }
      param_2 = param_2 + 0x10;
    } while (iVar1 != iVar2);
  }
  return 0;
}
