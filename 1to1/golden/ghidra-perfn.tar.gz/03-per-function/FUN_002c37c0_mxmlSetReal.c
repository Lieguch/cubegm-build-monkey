/* ============================================================
 * mxmlSetReal   @ 0x002c37c0   size=72B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlSetReal(int *param_1)

{
  int iVar1;
  undefined8 in_d0;
  
  if (param_1 != (int *)0x0) {
    iVar1 = *param_1;
    if (iVar1 == 0) {
      param_1 = (int *)param_1[4];
      if (param_1 == (int *)0x0) {
        return 0xffffffff;
      }
      iVar1 = *param_1;
    }
    if (iVar1 == 3) {
      *(undefined8 *)(param_1 + 6) = in_d0;
      return 0;
    }
  }
  return 0xffffffff;
}
