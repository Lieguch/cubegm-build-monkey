/* ============================================================
 * mxmlIndexFind   @ 0x002c281c   size=440B   callers=0
 * module: 04_mini_xml
 * ============================================================ */

undefined4 mxmlIndexFind(int *param_1,int param_2,int param_3)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  
  if ((param_1 != (int *)0x0) && (param_3 == 0 || *param_1 != 0)) {
    if (param_2 == 0 && param_3 == 0) {
      uVar4 = mxmlIndexEnum();
      return uVar4;
    }
    iVar7 = param_1[1];
    if (iVar7 != 0) {
      if (param_1[3] != 0) {
        if (param_1[3] < iVar7) {
          iVar7 = index_find_isra_0();
          if (iVar7 == 0) {
            iVar7 = param_1[3];
            param_1[3] = iVar7 + 1;
            return *(undefined4 *)(param_1[4] + iVar7 * 4);
          }
          iVar7 = param_1[1];
        }
        param_1[3] = iVar7;
        return 0;
      }
      iVar5 = 0;
      iVar7 = iVar7 + -1;
      while( true ) {
        iVar6 = iVar5;
        iVar3 = (iVar6 + iVar7) / 2;
        if (iVar7 - iVar6 < 2) {
          if (iVar6 <= iVar7) {
            iVar5 = iVar6 << 2;
            do {
              iVar3 = index_find_isra_0(param_1,param_2,param_3,*(undefined4 *)(param_1[4] + iVar5))
              ;
              if (iVar3 == 0) {
                param_1[3] = iVar6 + 1;
                return *(undefined4 *)(param_1[4] + iVar5);
              }
              iVar6 = iVar6 + 1;
              iVar5 = iVar5 + 4;
            } while (iVar6 <= iVar7);
          }
          param_1[3] = param_1[1];
          return 0;
        }
        iVar5 = iVar3 << 2;
        iVar2 = index_find_isra_0(param_1,param_2,param_3,*(undefined4 *)(param_1[4] + iVar3 * 4));
        if (iVar2 == 0) break;
        iVar5 = iVar3;
        if (iVar2 < 0) {
          iVar5 = iVar6;
          iVar7 = iVar3;
        }
      }
      if (0 < iVar3) {
        iVar7 = (iVar3 + 0x3fffffff) * 4;
        do {
          puVar1 = (undefined4 *)(param_1[4] + iVar7);
          iVar7 = iVar7 + -4;
          iVar5 = index_find_isra_0(param_1,param_2,param_3,*puVar1);
          if (iVar5 != 0) {
            iVar5 = iVar3 << 2;
            goto LAB_002c299c;
          }
          iVar3 = iVar3 + -1;
        } while (iVar3 != 0);
        iVar5 = 0;
      }
LAB_002c299c:
      param_1[3] = iVar3 + 1;
      return *(undefined4 *)(param_1[4] + iVar5);
    }
  }
  return 0;
}
