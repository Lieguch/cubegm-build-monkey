/* ============================================================
 * stbtt__GetGlyfOffset   @ 0x00013854   size=224B   callers=3
 * module: 05_stb_truetype_font
 * ============================================================ */

int stbtt__GetGlyfOffset(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  if ((param_2 < *(int *)(param_1 + 0xc)) && (*(int *)(param_1 + 0x30) < 2)) {
    if (*(int *)(param_1 + 0x30) == 0) {
      iVar2 = *(int *)(param_1 + 4);
      iVar1 = *(int *)(param_1 + 0x10) + param_2 * 2;
      iVar3 = *(int *)(param_1 + 0x18) +
              ((uint)*(byte *)(iVar2 + iVar1 + 2 + 1) + (uint)*(byte *)(iVar2 + iVar1 + 2) * 0x100)
              * 2;
      iVar1 = *(int *)(param_1 + 0x18) +
              ((uint)*(byte *)(iVar2 + iVar1 + 1) + (uint)*(byte *)(iVar2 + iVar1) * 0x100) * 2;
    }
    else {
      iVar2 = *(int *)(param_1 + 4);
      iVar1 = *(int *)(param_1 + 0x10) + param_2 * 4;
      iVar4 = iVar2 + iVar1;
      iVar3 = iVar2 + iVar1 + 4;
      iVar3 = (uint)*(byte *)(iVar3 + 1) * 0x10000 + (uint)*(byte *)(iVar2 + iVar1 + 4) * 0x1000000
              + (uint)*(byte *)(iVar3 + 2) * 0x100 + (uint)*(byte *)(iVar3 + 3) +
              *(int *)(param_1 + 0x18);
      iVar1 = (uint)*(byte *)(iVar4 + 1) * 0x10000 + (uint)*(byte *)(iVar2 + iVar1) * 0x1000000 +
              (uint)*(byte *)(iVar4 + 2) * 0x100 + (uint)*(byte *)(iVar4 + 3) +
              *(int *)(param_1 + 0x18);
    }
    if (iVar1 == iVar3) {
      iVar1 = -1;
    }
    return iVar1;
  }
  return -1;
}
