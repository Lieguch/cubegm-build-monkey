/* ============================================================
 * mxmlNewInteger   @ 0x002c2e2c   size=28B   callers=1
 * module: 04_mini_xml
 * ============================================================ */

void mxmlNewInteger(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = mxml_new(param_1,1);
  if (iVar1 != 0) {
    *(undefined4 *)(iVar1 + 0x18) = param_2;
  }
  return;
}
