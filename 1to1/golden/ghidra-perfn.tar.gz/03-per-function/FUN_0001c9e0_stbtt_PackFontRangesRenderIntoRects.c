/* ============================================================
 * stbtt_PackFontRangesRenderIntoRects   @ 0x0001c9e0   size=980B   callers=1
 * module: 05_stb_truetype_font
 * ============================================================ */

undefined4
stbtt_PackFontRangesRenderIntoRects
          (int param_1,undefined4 param_2,float *param_3,int param_4,int param_5)

{
  byte bVar1;
  int iVar2;
  undefined4 uVar3;
  int extraout_r1;
  int iVar4;
  int iVar5;
  int extraout_r1_00;
  float fVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  uint uVar10;
  int iVar11;
  int *piVar12;
  int iVar13;
  int iVar14;
  undefined4 uVar15;
  bool bVar16;
  uint in_fpscr;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  int local_70;
  undefined4 local_60;
  undefined1 auStack_5c [4];
  int local_58;
  int local_54;
  undefined1 auStack_50 [4];
  undefined1 auStack_4c [8];
  
  uVar8 = *(undefined4 *)(param_1 + 0x1c);
  uVar9 = *(undefined4 *)(param_1 + 0x20);
  if (param_4 < 1) {
    uVar15 = 1;
  }
  else {
    uVar15 = 1;
    iVar13 = 0;
    local_70 = 0;
    do {
      fVar17 = *param_3;
      uVar10 = in_fpscr & 0xfffffff | (uint)(fVar17 < 0.0) << 0x1f | (uint)(fVar17 == 0.0) << 0x1e;
      in_fpscr = uVar10 | (uint)NAN(fVar17) << 0x1c;
      bVar1 = (byte)(uVar10 >> 0x18);
      if ((bool)(bVar1 >> 6 & 1) || bVar1 >> 7 != ((byte)(in_fpscr >> 0x1c) & 1)) {
        fVar17 = (float)stbtt_ScaleForMappingEmToPixels(-fVar17,param_2);
        iVar4 = extraout_r1_00;
      }
      else {
        fVar17 = (float)stbtt_ScaleForPixelHeight(param_2);
        iVar4 = extraout_r1;
      }
      fVar6 = (float)(uint)*(byte *)(param_3 + 5);
      bVar16 = fVar6 != 0.0;
      *(float *)(param_1 + 0x1c) = fVar6;
      uVar10 = (uint)*(byte *)((int)param_3 + 0x15);
      if (bVar16) {
        iVar4 = 1 - (int)fVar6;
      }
      fVar20 = (float)VectorUnsignedToFloat(fVar6,(byte)(in_fpscr >> 0x16) & 3);
      *(uint *)(param_1 + 0x20) = uVar10;
      fVar22 = (float)VectorUnsignedToFloat(uVar10,(byte)(in_fpscr >> 0x16) & 3);
      fVar23 = fVar22;
      if (bVar16) {
        fVar23 = fVar6;
      }
      fVar6 = param_3[3];
      if (bVar16) {
        fVar23 = (float)VectorSignedToFloat(fVar23,(byte)(in_fpscr >> 0x16) & 3);
        fVar23 = fVar23 + fVar23;
      }
      fVar21 = 0.0;
      if (bVar16) {
        fVar21 = (float)VectorSignedToFloat(iVar4,(byte)(in_fpscr >> 0x16) & 3);
        fVar21 = fVar21 / fVar23;
      }
      if (uVar10 == 0) {
        fVar24 = 0.0;
      }
      else {
        fVar23 = (float)VectorSignedToFloat(uVar10,(byte)(in_fpscr >> 0x16) & 3);
        fVar24 = (float)VectorSignedToFloat(1 - uVar10,(byte)(in_fpscr >> 0x16) & 3);
        fVar24 = fVar24 / (fVar23 + fVar23);
      }
      if (0 < (int)fVar6) {
        iVar4 = 0;
        piVar12 = (int *)(iVar13 * 0x18 + param_5);
        do {
          if (((piVar12[5] == 0) || (piVar12[3] == 0)) || (piVar12[4] == 0)) {
            uVar15 = 0;
          }
          else {
            fVar6 = param_3[4];
            iVar14 = (int)fVar6 + iVar4 * 0x1c;
            if (param_3[2] == 0.0) {
              iVar5 = iVar4 + (int)param_3[1];
            }
            else {
              iVar5 = *(int *)((int)param_3[2] + iVar4 * 4);
            }
            uVar3 = stbtt_FindGlyphIndex(param_2,iVar5);
            iVar5 = *(int *)(param_1 + 0x14);
            *piVar12 = *piVar12 + iVar5;
            piVar12[1] = piVar12[1] + iVar5;
            piVar12[3] = piVar12[3] - iVar5;
            piVar12[4] = piVar12[4] - iVar5;
            stbtt_GetGlyphHMetrics(param_2,uVar3,&local_60,auStack_5c);
            fVar18 = (float)VectorUnsignedToFloat
                                      (*(undefined4 *)(param_1 + 0x20),(byte)(in_fpscr >> 0x16) & 3)
            ;
            fVar23 = (float)VectorUnsignedToFloat
                                      (*(undefined4 *)(param_1 + 0x1c),(byte)(in_fpscr >> 0x16) & 3)
            ;
            stbtt_GetGlyphBitmapBox
                      (fVar23 * fVar17,fVar18 * fVar17,param_2,uVar3,&local_58,&local_54,auStack_50,
                       auStack_4c);
            fVar18 = (float)VectorUnsignedToFloat
                                      (*(int *)(param_1 + 0x20),(byte)(in_fpscr >> 0x16) & 3);
            fVar23 = (float)VectorUnsignedToFloat
                                      (*(int *)(param_1 + 0x1c),(byte)(in_fpscr >> 0x16) & 3);
            stbtt_MakeGlyphBitmapSubpixel
                      (fVar23 * fVar17,fVar18 * fVar17,0,0,param_2,
                       *(int *)(param_1 + 0x24) + piVar12[1] * *(int *)(param_1 + 0x10) + *piVar12,
                       (1 - *(int *)(param_1 + 0x1c)) + piVar12[3],
                       (1 - *(int *)(param_1 + 0x20)) + piVar12[4],*(int *)(param_1 + 0x10),uVar3);
            if (1 < *(uint *)(param_1 + 0x1c)) {
              stbtt__h_prefilter(*(int *)(param_1 + 0x24) +
                                 piVar12[1] * *(int *)(param_1 + 0x10) + *piVar12,piVar12[3],
                                 piVar12[4],*(int *)(param_1 + 0x10),*(uint *)(param_1 + 0x1c));
            }
            if (1 < *(uint *)(param_1 + 0x20)) {
              stbtt__v_prefilter(*(int *)(param_1 + 0x24) +
                                 piVar12[1] * *(int *)(param_1 + 0x10) + *piVar12,piVar12[3],
                                 piVar12[4],*(int *)(param_1 + 0x10),*(uint *)(param_1 + 0x20));
            }
            iVar7 = piVar12[3];
            iVar11 = piVar12[4];
            fVar23 = (float)VectorSignedToFloat(iVar7 + local_58,(byte)(in_fpscr >> 0x16) & 3);
            iVar5 = *piVar12;
            fVar18 = (float)VectorSignedToFloat(iVar11 + local_54,(byte)(in_fpscr >> 0x16) & 3);
            fVar19 = (float)VectorSignedToFloat(local_58,(byte)(in_fpscr >> 0x16) & 3);
            *(short *)((int)fVar6 + iVar4 * 0x1c) = (short)iVar5;
            iVar2 = piVar12[1];
            *(short *)(iVar14 + 4) = (short)iVar5 + (short)iVar7;
            fVar6 = param_3[3];
            *(float *)(iVar14 + 0x14) = fVar21 + fVar23 * (1.0 / fVar20);
            *(short *)(iVar14 + 2) = (short)iVar2;
            *(short *)(iVar14 + 6) = (short)iVar2 + (short)iVar11;
            fVar23 = (float)VectorSignedToFloat(local_54,(byte)(in_fpscr >> 0x16) & 3);
            *(float *)(iVar14 + 0x18) = fVar24 + fVar18 * (1.0 / fVar22);
            *(float *)(iVar14 + 8) = fVar21 + fVar19 * (1.0 / fVar20);
            fVar18 = (float)VectorSignedToFloat(local_60,(byte)(in_fpscr >> 0x16) & 3);
            *(float *)(iVar14 + 0xc) = fVar24 + fVar23 * (1.0 / fVar22);
            *(float *)(iVar14 + 0x10) = fVar18 * fVar17;
          }
          iVar4 = iVar4 + 1;
          iVar13 = iVar13 + 1;
          piVar12 = piVar12 + 6;
        } while (iVar4 < (int)fVar6);
      }
      param_3 = param_3 + 6;
      local_70 = local_70 + 1;
    } while (param_4 != local_70);
  }
  *(undefined4 *)(param_1 + 0x1c) = uVar8;
  *(undefined4 *)(param_1 + 0x20) = uVar9;
  return uVar15;
}
